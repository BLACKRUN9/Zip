/**
 * Order-book deltas, shared by the server (diff) and the web client (apply).
 * A level is [price, qty] as integer strings. qty "0" means "remove this level".
 * Invariant (tested): applyDelta(prevTopN, diffBook(prevTopN, nextTopN)) == nextTopN.
 */
export type Level = [price: string, qty: string];
export interface BookView { bids: Level[]; asks: Level[] }
export interface BookDelta { bids: Level[]; asks: Level[] }

export const emptyBook = (): BookView => ({ bids: [], asks: [] });
export const isEmptyDelta = (d: BookDelta): boolean => d.bids.length === 0 && d.asks.length === 0;

function diffSide(prev: Level[], next: Level[]): Level[] {
  const p = new Map(prev);
  const n = new Map(next);
  const out: Level[] = [];
  for (const [price, qty] of next) if (p.get(price) !== qty) out.push([price, qty]);
  for (const [price] of prev) if (!n.has(price)) out.push([price, '0']);
  return out;
}
export const diffBook = (prev: BookView, next: BookView): BookDelta => ({ bids: diffSide(prev.bids, next.bids), asks: diffSide(prev.asks, next.asks) });

const cmp = (a: string, b: string): number => {
  const x = BigInt(a), y = BigInt(b);
  return x < y ? -1 : x > y ? 1 : 0;
};
function applySide(levels: Level[], changes: Level[], desc: boolean, depth: number): Level[] {
  const m = new Map<string, string>(levels);
  for (const [p, q] of changes) {
    if (q === '0') m.delete(p);
    else m.set(p, q);
  }
  const arr = [...m.entries()] as Level[];
  arr.sort((a, b) => (desc ? cmp(b[0], a[0]) : cmp(a[0], b[0])));
  return arr.slice(0, depth);
}
export const applyDelta = (book: BookView, d: BookDelta, depth = 50): BookView => ({
  bids: applySide(book.bids, d.bids, true, depth),
  asks: applySide(book.asks, d.asks, false, depth),
});

/**
 * Client-side sequencing: a snapshot sets the base seq; each delta must be exactly seq+1.
 * A gap (dropped message / queue overflow) means "resubscribe to resync".
 */
export class BookSync {
  view: BookView = emptyBook();
  seq = -1;
  depth: number;
  constructor(depth = 50) { this.depth = depth; }
  snapshot(view: BookView, seq: number): void {
    this.view = { bids: view.bids.slice(0, this.depth), asks: view.asks.slice(0, this.depth) };
    this.seq = seq;
  }
  /** Returns 'ok' | 'stale' (ignore) | 'gap' (caller must resubscribe). */
  update(d: BookDelta, seq: number): 'ok' | 'stale' | 'gap' {
    if (this.seq < 0) return 'gap'; // delta before any snapshot
    if (seq <= this.seq) return 'stale';
    if (seq !== this.seq + 1) return 'gap';
    this.view = applyDelta(this.view, d, this.depth);
    this.seq = seq;
    return 'ok';
  }
}
