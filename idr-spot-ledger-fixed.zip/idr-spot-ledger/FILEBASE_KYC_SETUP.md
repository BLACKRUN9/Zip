# Filebase KYC object storage

Set these backend environment variables (never expose them in the frontend):

- `FILEBASE_ACCESS_KEY` — Filebase S3 access key
- `FILEBASE_SECRET_KEY` — Filebase S3 secret key
- `FILEBASE_BUCKET` — existing private bucket name
- `FILEBASE_S3_ENDPOINT` — optional; defaults to `https://s3.filebase.com`

The server enables KYC upload URL generation only when all three required variables are present. Upload URLs expire after 5 minutes; reviewer download URLs expire after at most 2 minutes. Keep the bucket private and do not enable public/IPFS gateway access for KYC objects. Use a dedicated bucket/key and rotate credentials if they were ever exposed.

The client must PUT the file to the returned URL with the returned `Content-Type` header, then submit the returned object key as `docKeys` / `selfieKey` to `POST /v1/kyc`.

Important limitation: presigned S3 PUT URLs do not enforce a hard maximum upload size at the object-storage layer in a portable way. The API advertises a 5 MiB limit, but before production KYC launch, add server-side `HeadObject` verification of uploaded object size/content type before accepting the submission (or use a signed POST policy with a content-length-range condition if supported by the chosen Filebase endpoint). The bucket must remain private.
