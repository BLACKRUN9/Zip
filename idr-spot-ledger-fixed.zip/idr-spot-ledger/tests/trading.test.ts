import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { startDb, stopDb, resetData, createUser, fund, bal, sysBal, makeHarness, uniq } from './helpers.ts';
import { Market, Order, Trade } from '../src/db/models.ts';
import { cancelOrder, placeOrder } from '../src/services/orders.ts';
import { settleTrade } from '../src/services/settlement.ts';
import { reconcile } from '../src/services/reconcile.ts';

beforeAll(startDb);
afterAll(stopDb);
beforeEach(resetData);

const P = '1000000000'; // 1,000,000,000 IDR per BTC
const sell = (h: any, userId: any, price: string, qty: string, extra: any = {}) =>
  placeOrder({ userId: String(userId), market: 'BTC_IDR', side: 'sell', type: 'limit', price, qty, idempotencyKey: uniq(), ...extra }, h.gateway);
const buy = (h: any, userId: any, price: string, qty: string, extra: any = {}) =>
  placeOrder({ userId: String(userId), market: 'BTC_IDR', side: 'buy', type: 'limit', price, qty, idempotencyKey: uniq(), ...extra }, h.gateway);

describe('matching + settlement, exact numbers', () => {
  it('full fill: buyer(taker 20bps) vs seller(maker 10bps)', async () => {
    const h = makeHarness();
    const S = await createUser('seller'), B = await createUser('buyer');
    await fund(S._id, 'BTC', '100000000');
    await fund(B._id, 'IDR', '600000000');

    const so = await sell(h, S._id, P, '50000000');
    expect(await bal(S._id, 'BTC')).toEqual({ available: 50_000_000n, locked: 50_000_000n });

    const bo = await buy(h, B._id, P, '50000000'); // reserve = 500,000,000 + ceil(0.20%) 1,000,000
    // quoteQty = 1e9 * 5e7 / 1e8 = 500,000,000 ; buyer fee 1,000,000 ; seller fee 500,000
    expect(await bal(B._id, 'IDR')).toEqual({ available: 99_000_000n, locked: 0n });
    expect(await bal(B._id, 'BTC')).toEqual({ available: 50_000_000n, locked: 0n });
    expect(await bal(S._id, 'BTC')).toEqual({ available: 50_000_000n, locked: 0n });
    expect(await bal(S._id, 'IDR')).toEqual({ available: 499_500_000n, locked: 0n });
    expect((await sysBal('fee_revenue', 'IDR')).available).toBe(1_500_000n);

    const t: any = await Trade.findOne({}).lean();
    expect([t.price, t.qty, t.quoteQty, t.takerFee, t.makerFee, t.takerSide]).toEqual([P, '50000000', '500000000', '1000000', '500000', 'buy']);
    expect(((await Order.findById(so.id).lean()) as any).status).toBe('filled');
    expect(((await Order.findById(bo.id).lean()) as any).status).toBe('filled');
    expect(await reconcile()).toEqual([]);
  });

  it('price improvement: taker pays the maker price, unused reserve is released', async () => {
    const h = makeHarness();
    const S = await createUser('seller'), B = await createUser('buyer');
    await fund(S._id, 'BTC', '100000000');
    await fund(B._id, 'IDR', '600000000');
    await sell(h, S._id, '900000000', '10000000');
    await buy(h, B._id, P, '10000000'); // reserved at the limit: 100,000,000 + 200,000
    // executes at 900,000,000: quoteQty 90,000,000 ; buyer fee 180,000
    expect(await bal(B._id, 'IDR')).toEqual({ available: 600_000_000n - 90_180_000n, locked: 0n });
    expect(await reconcile()).toEqual([]);
  });

  it('partial fill then cancel releases exactly the remaining reserve', async () => {
    const h = makeHarness();
    const S = await createUser('seller'), B = await createUser('buyer');
    await fund(S._id, 'BTC', '100000000');
    await fund(B._id, 'IDR', '600000000');
    await sell(h, S._id, P, '30000000');
    const bo = await buy(h, B._id, P, '50000000');
    let o: any = await Order.findById(bo.id).lean();
    expect([o.status, o.filledQty, o.lockedAmount]).toEqual(['partial', '30000000', '200400000']); // reserve for the 2e7 still open
    expect((await bal(B._id, 'IDR')).locked).toBe(200_400_000n);

    await cancelOrder(String(B._id), bo.id, h.gateway);
    o = await Order.findById(bo.id).lean();
    expect([o.status, o.lockedAmount]).toEqual(['canceled', '0']);
    expect(await bal(B._id, 'IDR')).toEqual({ available: 600_000_000n - 300_600_000n, locked: 0n });
    await cancelOrder(String(B._id), bo.id, h.gateway); // idempotent
    expect(await reconcile()).toEqual([]);
  });

  it('market buy (IOC with price cap): fills what exists, remainder is cancelled and unlocked', async () => {
    const h = makeHarness();
    const S = await createUser('seller'), B = await createUser('buyer');
    await fund(S._id, 'BTC', '100000000');
    await fund(B._id, 'IDR', '600000000');
    await sell(h, S._id, P, '10000000');
    const bo = await placeOrder({ userId: String(B._id), market: 'BTC_IDR', side: 'buy', type: 'market', price: '1100000000', qty: '30000000', idempotencyKey: uniq() }, h.gateway);
    const o: any = await Order.findById(bo.id).lean();
    expect([o.status, o.filledQty, o.lockedAmount]).toEqual(['canceled', '10000000', '0']);
    expect((await bal(B._id, 'IDR')).locked).toBe(0n);
    expect(await reconcile()).toEqual([]);
  });

  it('self-trade is prevented: incoming order cancelled, resting order untouched, funds consistent', async () => {
    const h = makeHarness();
    const U = await createUser('both');
    await fund(U._id, 'BTC', '100000000');
    await fund(U._id, 'IDR', '600000000');
    const so = await sell(h, U._id, P, '10000000');
    const bo = await buy(h, U._id, P, '10000000');
    expect(await Trade.countDocuments({})).toBe(0);
    expect(((await Order.findById(bo.id).lean()) as any).status).toBe('canceled');
    expect(((await Order.findById(so.id).lean()) as any).status).toBe('new');
    expect(await reconcile()).toEqual([]);
  });
});

describe('validation and safety', () => {
  it('rejects bad tick/lot/min-notional/market-buy-without-cap/KYC and leaves nothing behind', async () => {
    const h = makeHarness();
    const U = await createUser('u');
    const nokyc = await createUser('nokyc', { kycLevel: 0 });
    await fund(U._id, 'IDR', '600000000');
    await expect(buy(h, U._id, '1000000500', '10000000')).rejects.toMatchObject({ code: 'VALIDATION' }); // tick
    await expect(buy(h, U._id, P, '10000500')).rejects.toMatchObject({ code: 'VALIDATION' }); // lot
    await expect(buy(h, U._id, '1000', '1000')).rejects.toMatchObject({ code: 'VALIDATION' }); // notional
    await expect(placeOrder({ userId: String(U._id), market: 'BTC_IDR', side: 'buy', type: 'market', qty: '10000000', idempotencyKey: uniq() })).rejects.toMatchObject({ code: 'VALIDATION' });
    await expect(buy(h, U._id, '1e9', '10000000')).rejects.toMatchObject({ code: 'VALIDATION' }); // not an integer string
    await expect(buy(h, nokyc._id, P, '10000000')).rejects.toMatchObject({ code: 'FORBIDDEN' });
    expect(await Order.countDocuments({})).toBe(0);
    expect(await bal(U._id, 'IDR')).toEqual({ available: 600_000_000n, locked: 0n });
  });

  it('insufficient funds: order not created, nothing locked', async () => {
    const h = makeHarness();
    const U = await createUser('u');
    await fund(U._id, 'IDR', '100000000');
    await expect(buy(h, U._id, P, '50000000')).rejects.toMatchObject({ code: 'INSUFFICIENT_FUNDS' });
    expect(await Order.countDocuments({})).toBe(0);
    expect(await bal(U._id, 'IDR')).toEqual({ available: 100_000_000n, locked: 0n });
  });

  it('halted market refuses new orders', async () => {
    const h = makeHarness();
    const U = await createUser('u');
    await fund(U._id, 'IDR', '600000000');
    await Market.updateOne({ symbol: 'BTC_IDR' }, { $set: { status: 'halted' } });
    await expect(buy(h, U._id, P, '10000000')).rejects.toMatchObject({ code: 'MARKET_NOT_ACTIVE' });
  });

  it('settleTrade is idempotent and refuses fills that break invariants', async () => {
    const h = makeHarness();
    const S = await createUser('seller'), B = await createUser('buyer');
    await fund(S._id, 'BTC', '100000000');
    await fund(B._id, 'IDR', '1200000000');
    const so = await sell(h, S._id, P, '50000000');
    const bo = await buy(h, B._id, P, '50000000');
    const t: any = await Trade.findOne({}).lean();
    const input = { marketId: t.marketId.toString(), seq: t.seq, price: t.price, qty: t.qty, takerOrderId: bo.id, makerOrderId: so.id };
    const before = [await bal(B._id, 'IDR'), await bal(S._id, 'IDR'), await sysBal('fee_revenue', 'IDR')];
    const again: any = await settleTrade(input);
    expect(again._id.toString()).toBe(t._id.toString());
    expect(await Trade.countDocuments({})).toBe(1);
    expect([await bal(B._id, 'IDR'), await bal(S._id, 'IDR'), await sysBal('fee_revenue', 'IDR')]).toEqual(before);

    // a NEW fill on a filled order, or at a non-maker price, must be refused
    await expect(settleTrade({ ...input, seq: t.seq + 100 })).rejects.toMatchObject({ code: 'CONFLICT' });
    const so2 = await sell(h, S._id, P, '10000000');
    const bo2 = await buy(h, B._id, '1100000000', '10000000'); // fills at the maker price P
    expect(((await Order.findById(bo2.id).lean()) as any).status).toBe('filled');
    void so2;
    expect(await reconcile()).toEqual([]);
  });

  it('a fill at a price other than the maker price is refused', async () => {
    const h = makeHarness();
    const S = await createUser('seller'), B = await createUser('buyer');
    await fund(S._id, 'BTC', '100000000');
    await fund(B._id, 'IDR', '600000000');
    const so = await placeOrder({ userId: String(S._id), market: 'BTC_IDR', side: 'sell', type: 'limit', price: P, qty: '10000000', idempotencyKey: uniq() }); // no gateway: not in the engine
    const bo = await placeOrder({ userId: String(B._id), market: 'BTC_IDR', side: 'buy', type: 'limit', price: P, qty: '10000000', idempotencyKey: uniq() });
    const mid = String(((await Market.findOne({ symbol: 'BTC_IDR' }).lean()) as any)._id);
    await expect(settleTrade({ marketId: mid, seq: 1, price: '999999000', qty: '10000000', takerOrderId: bo.id, makerOrderId: so.id })).rejects.toMatchObject({ code: 'INVARIANT' });
    await expect(settleTrade({ marketId: mid, seq: 1, price: P, qty: '99999999000', takerOrderId: bo.id, makerOrderId: so.id })).rejects.toMatchObject({ code: 'INVARIANT' });
    expect(await Trade.countDocuments({})).toBe(0);
  });
});
