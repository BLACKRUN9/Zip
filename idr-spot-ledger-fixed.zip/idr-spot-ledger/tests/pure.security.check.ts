// Dependency-free: node --experimental-strip-types tests/pure.security.check.ts
import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { dummyHash, hashPassword, makeBox, needsRehash, newToken, sha256Hex, signRequest, verifyPassword, verifySignature } from '../src/security/crypto.ts';
import { base32Decode, base32Encode, generateTotpSecret, hotp, totp, totpCounter, verifyTotp } from '../src/security/totp.ts';
import { ageInYears, maskNik, normalizeEmail, validateAddress, validateNik, validatePassword } from '../src/security/policy.ts';
import { TokenBucket } from '../src/security/ratelimit.ts';
import { httpStatusFor, toErrorBody } from '../src/api/http.ts';
import { AppError, InsufficientFunds, InvariantViolation } from '../src/errors.ts';

let passed = 0;
const t = async (name: string, fn: () => void | Promise<void>) => { await fn(); passed++; console.log('ok -', name); };
const FAST = { N: 1024, r: 8, p: 1 };

await t('password hash: verify ok/wrong, unique salts, rehash detection, malformed hash', async () => {
  const h1 = await hashPassword('correct horse battery', FAST);
  const h2 = await hashPassword('correct horse battery', FAST);
  assert.notEqual(h1, h2);
  assert.equal(await verifyPassword('correct horse battery', h1), true);
  assert.equal(await verifyPassword('correct horse batterY', h1), false);
  assert.equal(await verifyPassword('x', 'garbage'), false);
  assert.equal(await verifyPassword('x', 'scrypt$a$b$c$d$e'), false);
  assert.equal(needsRehash(h1), true); // weaker than DEFAULT_COST
  assert.equal(await verifyPassword('pässword-unicode', await hashPassword('pässword-unicode', FAST)), true);
});
await t('default-cost hash works and the dummy hash verifies false for real input', async () => {
  const h = await hashPassword('Another-Strong-Pass-1');
  assert.equal(needsRehash(h), false);
  assert.equal(await verifyPassword('Another-Strong-Pass-1', h), true);
  assert.equal(await verifyPassword('anything', await dummyHash()), false);
});

const kA = randomBytes(32).toString('base64'), kB = randomBytes(32).toString('base64');
await t('AES-GCM box: roundtrip, AAD binding, tamper detection, key rules', () => {
  const box = makeBox(kA, kB);
  const ct = box.encrypt('3201011203900001', 'user:1');
  assert.ok(!ct.includes('3201'));
  assert.equal(box.decrypt(ct, 'user:1'), '3201011203900001');
  assert.throws(() => box.decrypt(ct, 'user:2'), (e: any) => e.code === 'DECRYPT_FAILED'); // moved to another user
  const parts = ct.split('.');
  const flipped = [parts[0], parts[1], parts[2], Buffer.from(Buffer.from(parts[3], 'base64url').map((b, i) => (i === 0 ? b ^ 1 : b))).toString('base64url')].join('.');
  assert.throws(() => box.decrypt(flipped, 'user:1'), (e: any) => e.code === 'DECRYPT_FAILED');
  assert.notEqual(box.encrypt('same', 'a'), box.encrypt('same', 'a')); // random IV
  assert.equal(box.blindIndex('x'), box.blindIndex('x'));
  assert.notEqual(box.blindIndex('x'), box.blindIndex('y'));
  assert.throws(() => makeBox('short', kB));
  assert.throws(() => makeBox(kA, kA));
});
await t('tokens and request signatures', () => {
  assert.notEqual(newToken(), newToken());
  assert.equal(sha256Hex('abc'), 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad');
  const req = { timestamp: 1700000000000, method: 'post', path: '/v1/orders', body: '{"a":1}' };
  const sig = signRequest('s3cret', req);
  assert.equal(verifySignature('s3cret', req, sig), true);
  assert.equal(verifySignature('s3cret', req, sig.toUpperCase()), true);
  assert.equal(verifySignature('s3cret', { ...req, body: '{"a":2}' }, sig), false);
  assert.equal(verifySignature('s3cret', { ...req, path: '/v1/withdrawals' }, sig), false);
  assert.equal(verifySignature('other', req, sig), false);
  assert.equal(verifySignature('s3cret', req, 'short'), false);
});

await t('base32: RFC 4648 vectors and roundtrip', () => {
  assert.equal(base32Encode(Buffer.from('foobar')), 'MZXW6YTBOI');
  assert.equal(base32Decode('MZXW6YTBOI======').toString(), 'foobar');
  const b = randomBytes(20);
  assert.deepEqual(base32Decode(base32Encode(b)), b);
  assert.throws(() => base32Decode('not*valid'));
});
await t('TOTP: RFC 6238 test vectors (SHA-1, last 6 digits of the 8-digit values)', () => {
  const secret = base32Encode(Buffer.from('12345678901234567890'));
  const vec: Array<[number, string]> = [[59, '287082'], [1111111109, '081804'], [1111111111, '050471'], [1234567890, '005924'], [2000000000, '279037']];
  for (const [sec, code] of vec) assert.equal(totp(secret, sec * 1000), code);
  assert.equal(hotp(Buffer.from('12345678901234567890'), 0), '755224'); // RFC 4226 vector
});
await t('TOTP verify: drift window, wrong code, malformed, replay counter returned', () => {
  const secret = generateTotpSecret();
  const now = 1_800_000_000_000;
  const code = totp(secret, now);
  assert.equal(verifyTotp(secret, code, now), totpCounter(now));
  assert.equal(verifyTotp(secret, code, now + 30_000), totpCounter(now)); // one step late
  assert.equal(verifyTotp(secret, code, now + 90_000), null); // too old
  assert.equal(verifyTotp(secret, totp(secret, now + 30_000), now), totpCounter(now) + 1);
  assert.equal(verifyTotp(secret, '000000x', now), null);
  assert.equal(verifyTotp(secret, '12345', now), null);
  assert.ok(base32Decode(secret).length === 20);
});

await t('policy: email, password, NIK, age, addresses', () => {
  assert.equal(normalizeEmail('  Foo@Example.COM '), 'foo@example.com');
  for (const bad of ['a', 'a@b', '@x.com', 'a b@x.com', 5 as any]) assert.throws(() => normalizeEmail(bad));
  assert.throws(() => validatePassword('short1'));
  assert.throws(() => validatePassword('password123'));
  assert.throws(() => validatePassword('aaaaaaaaaaaa'));
  assert.throws(() => validatePassword('budi.santoso-2024', 'budi.santoso@x.com'));
  assert.equal(validatePassword('Tr0ub4dor&3-horse'), 'Tr0ub4dor&3-horse');
  assert.equal(validateNik('3201011203900001'), '3201011203900001');
  assert.equal(validateNik('3201014103900001'), '3201014103900001'); // female: day 01 + 40
  for (const bad of ['123', '3201013213900001', '0000001203900001', '3201011200900001', '320101120390000A', '3201011203900000']) assert.throws(() => validateNik(bad));
  assert.equal(maskNik('3201011203900001'), '3201********0001');
  assert.equal(ageInYears(new Date('2000-06-15'), new Date('2026-06-14')), 25);
  assert.equal(ageInYears(new Date('2000-06-15'), new Date('2026-06-15')), 26);
  assert.ok(validateAddress('BTC', 'bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq'));
  assert.ok(validateAddress('BTC', '1BvBMSEYstWetqTFn5Au4m4GFg7xJaNVN2'));
  assert.ok(validateAddress('ETH', '0x52908400098527886E0F7030069857D2E4169EE7'));
  assert.ok(validateAddress('TRON', 'TQn9Y2khEsLJW1ChVWFMSMeRDow5KcbLSE'));
  for (const [c, a] of [['BTC', 'dest'], ['BTC', '0x52908400098527886E0F7030069857D2E4169EE7'], ['ETH', '0x123'], ['TRON', 'T123'], ['DOGE', 'D...']] as const) assert.equal(validateAddress(c, a), false);
});

await t('token bucket: burst, refill, isolation per key', () => {
  const b = new TokenBucket(3, 1);
  const t0 = 1_000_000;
  assert.deepEqual([b.consume('a', t0).ok, b.consume('a', t0).ok, b.consume('a', t0).ok, b.consume('a', t0).ok], [true, true, true, false]);
  assert.equal(b.consume('a', t0).retryAfterMs, 1000);
  assert.equal(b.consume('b', t0).ok, true);
  assert.equal(b.consume('a', t0 + 1000).ok, true);
  assert.equal(b.consume('a', t0 + 1000).ok, false);
  assert.equal(b.consume('a', t0 + 60_000).ok, true); // capped at capacity, not accumulated
  b.sweep(t0 + 3_600_000);
  assert.equal(b.buckets.size, 0);
});

await t('HTTP error mapping never leaks internals', () => {
  assert.equal(httpStatusFor('INSUFFICIENT_FUNDS'), 422);
  assert.equal(httpStatusFor('RATE_LIMITED'), 429);
  const known = toErrorBody(new InsufficientFunds('insufficient available IDR'), 'r1');
  assert.equal(known.status, 422);
  const inv = toErrorBody(new InvariantViolation('buyer reserve 5 < 6 at account u:abc'), 'r2');
  assert.deepEqual(inv, { status: 500, body: { error: 'INTERNAL', message: 'internal error', requestId: 'r2' } });
  const unk = toErrorBody(new Error('mongo: connect ECONNREFUSED 10.0.0.5'), 'r3');
  assert.equal(unk.body.message, 'internal error');
  assert.equal(toErrorBody(new AppError('NOT_A_REAL_CODE', 'x'), 'r4').status, 500);
});

console.log(`\nall ${passed} security checks passed`);
