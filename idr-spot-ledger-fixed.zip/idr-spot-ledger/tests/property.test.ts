import fc from 'fast-check';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { startDb, stopDb, resetData, createUser, fund, makeHarness, uniq } from './helpers.ts';
import { Account, Market, Order, Trade } from '../src/db/models.ts';
import { MatchingEngine } from '../src/engine/engine.ts';
import { cancelOrder, placeOrder } from '../src/services/orders.ts';
import { reconcile } from '../src/services/reconcile.ts';

beforeAll(startDb);
afterAll(stopDb);

const IDR_EACH = 20_000_000_000n;
const BTC_EACH = 500_000_000n;
const USERS = 4;

const opArb = fc.oneof(
  { weight: 5, arbitrary: fc.record({ k: fc.constant('place' as const), user: fc.nat(USERS - 1), side: fc.constantFrom('buy' as const, 'sell' as const),
      type: fc.constantFrom('limit' as const, 'limit' as const, 'limit' as const, 'market' as const), tif: fc.constantFrom('GTC' as const, 'IOC' as const),
      p: fc.integer({ min: 95, max: 105 }), q: fc.integer({ min: 1, max: 20 }) }) },
  { weight: 1, arbitrary: fc.record({ k: fc.constant('cancel' as const), pick: fc.nat(1000) }) },
);

describe('property: random order flow keeps the books exact', () => {
  it('conservation, reserve accounting, replay equality, clean reconcile', async () => {
    await fc.assert(
      fc.asyncProperty(fc.array(opArb, { minLength: 5, maxLength: 22 }), async (ops) => {
        await resetData();
        const users: any[] = [];
        for (let i = 0; i < USERS; i++) {
          const u = await createUser(`u${i}`);
          await fund(u._id, 'IDR', IDR_EACH.toString());
          await fund(u._id, 'BTC', BTC_EACH.toString());
          users.push(u);
        }
        const h = makeHarness();
        const placed: Array<{ id: string; userId: string }> = [];

        for (const op of ops) {
          if (op.k === 'place') {
            const price = BigInt(op.p) * 10_000_000n;
            try {
              const o = await placeOrder(
                {
                  userId: String(users[op.user]._id), market: 'BTC_IDR', side: op.side, type: op.type,
                  tif: op.tif, qty: (BigInt(op.q) * 1_000_000n).toString(), idempotencyKey: uniq(),
                  ...(op.type === 'limit' ? { price: price.toString() } : op.side === 'buy' ? { price: (price + 50_000_000n).toString() } : {}),
                },
                h.gateway,
              );
              placed.push({ id: o.id, userId: String(users[op.user]._id) });
            } catch (e: any) {
              if (e.code !== 'INSUFFICIENT_FUNDS') throw e; // running out of money is fine; anything else is a bug
            }
          } else if (placed.length) {
            const t = placed[op.pick % placed.length];
            await cancelOrder(t.userId, t.id, h.gateway);
          }
        }

        const mid = String(((await Market.findOne({ symbol: 'BTC_IDR' }).lean()) as any)._id);

        // 1) the engine log replays to the identical book
        if (h.engine.snapshot(mid)) {
          const e2 = new MatchingEngine();
          await e2.recover(mid);
          expect(e2.snapshot(mid)).toEqual(h.engine.snapshot(mid));
        }

        // 2) books are clean mid-flight (open orders still hold reserves)
        expect(await reconcile()).toEqual([]);

        // 3) matched quantity is consistent across trades and both sides' orders
        const trades: any[] = await Trade.find({}).lean();
        const tradedQty = trades.reduce((s, t) => s + BigInt(t.qty), 0n);
        const orders: any[] = await Order.find({}).lean();
        const sum = (side: string) => orders.filter((o) => o.side === side).reduce((s, o) => s + BigInt(o.filledQty), 0n);
        expect(sum('buy')).toBe(tradedQty);
        expect(sum('sell')).toBe(tradedQty);
        for (const o of orders) expect(BigInt(o.filledQty) <= BigInt(o.qty)).toBe(true);

        // 4) cancel everything: every reserve must come back
        for (const o of orders.filter((x) => x.status === 'new' || x.status === 'partial')) {
          await cancelOrder(String(o.userId), String(o._id), h.gateway);
        }
        const open = await Order.countDocuments({ status: { $in: ['new', 'partial'] } });
        expect(open).toBe(0);
        const accounts: any[] = await Account.find({}).lean();
        for (const a of accounts) expect(a.locked).toBe('0');

        // 5) conservation: money is neither created nor destroyed (fees stay inside the system)
        const total = (asset: string) => accounts.filter((a) => a.asset === asset && a.normalSide === 'credit').reduce((s, a) => s + BigInt(a.available) + BigInt(a.locked), 0n);
        expect(total('IDR')).toBe(IDR_EACH * BigInt(USERS));
        expect(total('BTC')).toBe(BTC_EACH * BigInt(USERS));
        expect(await reconcile()).toEqual([]);
      }),
      { numRuns: 8 },
    );
  });
});
