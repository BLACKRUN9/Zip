import { randomBytes } from 'node:crypto';
import type { AddressInfo } from 'node:net';
import { createServer } from 'node:http';
import request from 'supertest';
import WebSocket from 'ws';
import { afterAll, afterEach, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import { startDb, stopDb, resetData, createUser, fund, uniq } from './helpers.ts';
import { createApp } from '../src/api/app.ts';
import { Candle, Market, Order, Trade, User } from '../src/db/models.ts';
import { MatchingEngine } from '../src/engine/engine.ts';
import { MarketFeed } from '../src/marketdata/feed.ts';
import { configureSecurity, signRequest } from '../src/security/crypto.ts';
import { totp } from '../src/security/totp.ts';
import { applyDelta, emptyBook } from '../shared/bookDelta.ts';
import { placeOrder } from '../src/services/orders.ts';
import { applyEngineEvent, settleTrade } from '../src/services/settlement.ts';
import type { EngineGateway } from '../src/services/orders.ts';
import { attachWebSocket } from '../src/ws/server.ts';

const T0 = Date.UTC(2026, 5, 10, 12, 0, 10); // 12:00:10 UTC, mid-minute so one scenario stays inside one candle
const BIG: [number, number] = [100000, 100000];
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

let engine: MatchingEngine;
let feed: MarketFeed;
let gateway: EngineGateway;
let app: any;

beforeAll(async () => {
  configureSecurity(randomBytes(32).toString('base64'), randomBytes(32).toString('base64'));
  await startDb();
});
afterAll(stopDb);
beforeEach(async () => {
  await resetData();
  engine = new MatchingEngine();
  feed = new MarketFeed(engine, undefined, 20);
  const handle = async (evs: any[]) => { for (const e of evs) await applyEngineEvent(e); await feed.onEngineEvents(evs); };
  gateway = { submit: async (o) => handle(await engine.submit(o)), cancel: async (m, id) => handle(await engine.cancel(m, id)) };
  app = createApp({ gateway, engine, mailer: { async sendPasswordReset() {} }, limits: { global: BIG, authIp: BIG, login: BIG, trade: BIG, withdraw: BIG, forgot: BIG } });
  vi.useFakeTimers({ toFake: ['Date'] }); // freeze the clock only (timers stay real); makes candle buckets deterministic
  vi.setSystemTime(T0);
});
afterEach(() => vi.useRealTimers());

async function market() {
  const S = await createUser('seller'), B = await createUser('buyer');
  await fund(S._id, 'BTC', '500000000');
  await fund(B._id, 'IDR', '20000000000');
  const px = (n: string, q: string, side: 'buy' | 'sell', u: any) =>
    placeOrder({ userId: String(u._id), market: 'BTC_IDR', side, type: 'limit', price: n, qty: q, idempotencyKey: uniq() }, gateway);
  return { S, B, px };
}

describe('candles', () => {
  it('trades land in every interval exactly once, with correct OHLCV; replays do not double count', async () => {
    const { S, B, px } = await market();
    await px('1000000000', '10000000', 'sell', S);
    await px('950000000', '10000000', 'sell', S);
    await px('1000000000', '20000000', 'buy', B); // fills 9.5e8 first, then 1e9 (maker prices)
    const trades: any[] = await Trade.find({}).sort({ seq: 1 }).lean();
    expect(trades.map((t) => t.price)).toEqual(['950000000', '1000000000']);

    const candles: any[] = await Candle.find({ marketSymbol: 'BTC_IDR' }).lean();
    expect(candles.length).toBe(6); // one per interval
    const m1 = candles.find((c) => c.interval === '1m');
    expect([m1.open, m1.high, m1.low, m1.close, m1.volume, m1.quoteVolume, m1.trades]).toEqual(['950000000', '1000000000', '950000000', '1000000000', '20000000', '195000000', 2]);
    expect(m1.openTime).toBe(Date.UTC(2026, 5, 10, 12, 0));

    for (const t of trades) { // crash-recovery style replay of both settlements
      await settleTrade({ marketId: String(t.marketId), seq: t.seq, price: t.price, qty: t.qty, takerOrderId: String(t.takerOrderId), makerOrderId: String(t.makerOrderId) });
    }
    const after: any = await Candle.findOne({ marketSymbol: 'BTC_IDR', interval: '1m' }).lean();
    expect([after.trades, after.volume, after.version]).toEqual([2, '20000000', m1.version]);
  });

  it('REST: candles with gap filling, validation, ticker and all-tickers; no user data leaks', async () => {
    const { S, B, px } = await market();
    await px('950000000', '10000000', 'sell', S);
    await px('950000000', '10000000', 'buy', B);
    vi.setSystemTime(T0 + 3 * 60_000); // three quiet minutes pass
    await px('1000000000', '10000000', 'sell', S);
    await px('1000000000', '10000000', 'buy', B);

    expect((await request(app).get('/v1/markets/BTC_IDR/candles?interval=2h')).status).toBe(400);
    expect((await request(app).get('/v1/markets/NOPE_IDR/candles?interval=1m')).status).toBe(404);
    expect((await request(app).get('/v1/markets/BTC_IDR/candles?interval=1m&before=abc')).status).toBe(400);

    const filled = await request(app).get('/v1/markets/BTC_IDR/candles?interval=1m&limit=10');
    expect(filled.body.candles.map((c: any) => [c.o, c.n])).toEqual([['950000000', 1], ['950000000', 0], ['950000000', 0], ['1000000000', 1]]);
    const raw = await request(app).get('/v1/markets/BTC_IDR/candles?interval=1m&limit=10&fill=false');
    expect(raw.body.candles.length).toBe(2);

    const tk = await request(app).get('/v1/markets/BTC_IDR/ticker');
    expect(tk.body).toMatchObject({ market: 'BTC_IDR', last: '1000000000', open: '950000000', high: '1000000000', low: '950000000', volume: '20000000', trades: 2, changeBps: 526 });
    const all = await request(app).get('/v1/tickers');
    expect(all.body.items.find((x: any) => x.market === 'ETH_IDR').last).toBeNull(); // no trades yet
    expect(JSON.stringify([filled.body, tk.body, all.body])).not.toMatch(new RegExp(`${S._id}|${B._id}`));
  });
});

describe('feed', () => {
  it('publishes trades, book, ticker and candles publicly, and orders/balances only to the owner', async () => {
    const { S, B, px } = await market();
    const seen: Record<string, any[]> = {};
    const listen = (ch: string) => feed.hub.subscribe(ch, (m) => { (seen[ch] ??= []).push(m); });
    listen('trades:BTC_IDR'); listen('book:BTC_IDR'); listen('ticker:BTC_IDR'); listen('candles:BTC_IDR:1m');
    listen(`orders:${B._id}`); listen(`balances:${B._id}`); listen(`orders:${S._id}`);

    await px('1000000000', '10000000', 'sell', S);
    await px('1000000000', '10000000', 'buy', B);
    await sleep(200); // let the coalesced publications run

    expect(seen['trades:BTC_IDR'].length).toBe(1);
    expect(seen['trades:BTC_IDR'][0].data).toMatchObject({ price: '1000000000', qty: '10000000', takerSide: 'buy' });
    expect(JSON.stringify(seen['trades:BTC_IDR'])).not.toMatch(new RegExp(`${S._id}|${B._id}`));
    const deltas: any[] = seen['book:BTC_IDR'] ?? [];
    expect(deltas.map((m) => m.seq)).toEqual(deltas.map((_, i) => i + 1)); // consecutive sequence numbers: clients can detect gaps
    let view = emptyBook();
    for (const m of deltas) view = applyDelta(view, m.data);
    expect(view).toEqual({ bids: [], asks: [] }); // fully matched: the deltas reconstruct an empty book
    expect(seen['ticker:BTC_IDR'].at(-1).data.last).toBe('1000000000');
    expect(seen['candles:BTC_IDR:1m'].at(-1).data).toMatchObject({ o: '1000000000', n: 1 });
    expect(seen[`orders:${B._id}`].at(-1).data.status).toBe('filled');
    expect(seen[`balances:${B._id}`].at(-1).data.find((a: any) => a.asset === 'BTC').available).toBe('10000000');
    for (const m of seen[`orders:${S._id}`]) expect(m.data.side).toBe('sell'); // seller only sees seller orders
  });

  it('snapshots: open orders are per-user; candles snapshot is gap-filled', async () => {
    const { S, B, px } = await market();
    await px('900000000', '10000000', 'buy', B);
    const mine = await feed.snapshot({ kind: 'orders' }, String(B._id));
    const theirs = await feed.snapshot({ kind: 'orders' }, String(S._id));
    expect([mine.data.length, theirs.data.length]).toEqual([1, 0]);
    const book = await feed.snapshot({ kind: 'book', market: 'BTC_IDR' });
    expect(book.data).toEqual({ bids: [['900000000', '10000000']], asks: [] });
    await expect(feed.snapshot({ kind: 'book', market: 'XXX_IDR' })).rejects.toThrow();
  });
});

describe('websocket (real server)', () => {
  it('auth, private streams, live updates, origin policy and limits', async () => {
    vi.useRealTimers(); // sockets need real time
    const http = createServer(app);
    const wsSrv = attachWebSocket(http, { feed, allowedOrigins: ['https://app.example.id'], maxPerIp: 3 });
    await new Promise<void>((r) => http.listen(0, '127.0.0.1', r));
    const port = (http.address() as AddressInfo).port;
    const url = `ws://127.0.0.1:${port}/ws`;
    try {
      const email = `ws${uniq()}@test.id`;
      await request(app).post('/v1/auth/register').send({ email, password: 'Correct-Horse-Battery-9' });
      const login = await request(app).post('/v1/auth/login').send({ email, password: 'Correct-Horse-Battery-9' });
      const token = login.body.accessToken as string;
      const uid = (await request(app).get('/v1/me').set('Authorization', `Bearer ${token}`)).body.id as string;
      await User.updateOne({ _id: uid }, { $set: { kycLevel: 1 } });
      await fund(uid, 'IDR', '600000000');

      const open = () => new Promise<WebSocket>((res, rej) => { const w = new WebSocket(url); w.once('open', () => res(w)); w.once('error', rej); });
      const inbox = (w: WebSocket) => { const msgs: any[] = []; w.on('message', (d) => msgs.push(JSON.parse(d.toString()))); return msgs; };
      const until = async (msgs: any[], pred: (m: any) => boolean, ms = 3000) => { const t = Date.now(); while (Date.now() - t < ms) { const m = msgs.find(pred); if (m) return m; await sleep(15); } throw new Error('timeout waiting for message'); };

      const w = await open();
      const msgs = inbox(w);
      w.send(JSON.stringify({ op: 'subscribe', channel: 'orders' }));
      expect((await until(msgs, (m) => m.type === 'error')).code).toBe('AUTH_REQUIRED');
      w.send(JSON.stringify({ op: 'auth', token }));
      await until(msgs, (m) => m.type === 'authed');
      w.send(JSON.stringify({ op: 'subscribe', channel: 'orders' }));
      w.send(JSON.stringify({ op: 'subscribe', channel: 'book:BTC_IDR' }));
      const snap = await until(msgs, (m) => m.type === 'snapshot' && m.channel === 'orders');
      expect(snap.data).toEqual([]);
      const bookSnap = await until(msgs, (m) => m.type === 'snapshot' && m.channel === 'book:BTC_IDR');
      expect(bookSnap.seq).toBe(0);

      const placed = await request(app).post('/v1/orders').set('Authorization', `Bearer ${token}`).set('Idempotency-Key', 'ws-order-0001')
        .send({ market: 'BTC_IDR', side: 'buy', type: 'limit', price: '900000000', qty: '10000000' });
      expect(placed.status).toBe(201);
      const upd = await until(msgs, (m) => m.type === 'update' && m.channel === 'orders');
      expect(upd.data).toMatchObject({ id: placed.body.id, status: 'new' });
      const book = await until(msgs, (m) => m.type === 'update' && m.channel === 'book:BTC_IDR');
      expect(book.data.bids).toEqual([['900000000', '10000000']]); // a DELTA: only the changed level
      expect(book.seq).toBe(1);

      // protocol hygiene
      w.send('not json');
      expect((await until(msgs, (m) => m.code === 'BAD_MESSAGE')).type).toBe('error');
      const big = await open();
      const closed = new Promise<number>((res) => big.once('close', (code) => res(code)));
      big.send('x'.repeat(10_000));
      expect(await closed).toBe(1009); // message too big

      // origin policy: a browser from an unlisted origin is refused; no-Origin clients (bots) are fine
      await expect(new Promise((res, rej) => { const bad = new WebSocket(url, { origin: 'https://evil.example' }); bad.once('open', () => res('open')); bad.once('error', rej); })).rejects.toBeTruthy();
      const good = await new Promise<WebSocket>((res, rej) => { const g = new WebSocket(url, { origin: 'https://app.example.id' }); g.once('open', () => res(g)); g.once('error', rej); });
      good.close();
      await sleep(200); // let the server finish releasing the closed sockets before counting connections

      // per-IP connection cap (3): w is one, open two more, the fourth is refused
      const extra = [await open(), await open()];
      await expect(open()).rejects.toBeTruthy();
      for (const e of extra) e.close();
      w.close();
    } finally {
      await wsSrv.close();
      await new Promise<void>((r) => http.close(() => r()));
    }
  });
});

describe('websocket bots (API key)', () => {
  it('signed auth, order entry over the socket, idempotent replay, errors per id, and revocation kicks the bot', async () => {
    vi.useRealTimers();
    const http = createServer(app);
    const wsSrv = attachWebSocket(http, { feed, gateway, allowedOrigins: [], heartbeatMs: 150 });
    await new Promise<void>((r) => http.listen(0, '127.0.0.1', r));
    const url = `ws://127.0.0.1:${(http.address() as AddressInfo).port}/ws`;
    try {
      // a user with 2FA (needed to create API keys), a trade key limited to loopback, and some money
      const email = `bot${uniq()}@test.id`;
      await request(app).post('/v1/auth/register').send({ email, password: 'Correct-Horse-Battery-9' });
      const token = (await request(app).post('/v1/auth/login').send({ email, password: 'Correct-Horse-Battery-9' })).body.accessToken as string;
      const bearer = { Authorization: `Bearer ${token}` };
      const uid = (await request(app).get('/v1/me').set(bearer)).body.id as string;
      await User.updateOne({ _id: uid }, { $set: { kycLevel: 1 } });
      await fund(uid, 'IDR', '600000000');
      const setup = await request(app).post('/v1/auth/2fa/setup').set(bearer);
      await request(app).post('/v1/auth/2fa/confirm').set(bearer).send({ code: totp(setup.body.secret, Date.now()) });
      const key = (await request(app).post('/v1/api-keys').set(bearer).send({ permissions: ['read', 'trade'], ipWhitelist: ['127.0.0.1', '::ffff:127.0.0.1', '::1'] })).body;
      expect(key.secret).toBeTruthy();

      const connect = () => new Promise<WebSocket>((res, rej) => { const w = new WebSocket(url); w.once('open', () => res(w)); w.once('error', rej); });
      const inbox = (w: WebSocket) => { const msgs: any[] = []; w.on('message', (d) => msgs.push(JSON.parse(d.toString()))); return msgs; };
      const until = async (msgs: any[], pred: (m: any) => boolean, ms = 3000) => { const t = Date.now(); while (Date.now() - t < ms) { const m = msgs.find(pred); if (m) return m; await sleep(15); } throw new Error('timeout waiting for message'); };
      const authMsg = (secret: string) => { const ts = String(Date.now()); return { op: 'auth', apiKey: key.keyId, timestamp: ts, signature: signRequest(secret, { timestamp: ts, method: 'GET', path: '/ws', body: '' }) }; };

      // wrong secret is refused
      const evil = await connect();
      const evilMsgs = inbox(evil);
      evil.send(JSON.stringify(authMsg('not-the-secret')));
      expect((await until(evilMsgs, (m) => m.type === 'error')).code).toBe('AUTH_FAILED');
      evil.close();

      const bot = await connect();
      const msgs = inbox(bot);
      const closed = new Promise<number>((res) => bot.once('close', (code) => res(code)));
      bot.send(JSON.stringify(authMsg(key.secret)));
      expect((await until(msgs, (m) => m.type === 'authed')).permissions.sort()).toEqual(['read', 'trade']);
      bot.send(JSON.stringify({ op: 'subscribe', channel: 'orders' }));
      await until(msgs, (m) => m.type === 'snapshot' && m.channel === 'orders');

      const place = (id: string, extra: object = {}) => bot.send(JSON.stringify({ op: 'order.place', id, market: 'BTC_IDR', side: 'buy', type: 'limit', price: '900000000', qty: '10000000', idempotencyKey: 'bot-order-0001', ...extra }));
      place('b1');
      const ack = await until(msgs, (m) => m.type === 'order.ack' && m.id === 'b1');
      expect(ack.order).toMatchObject({ status: 'new', side: 'buy', price: '900000000' });
      expect(JSON.stringify(ack)).not.toMatch(/requestHash|userId|idempotencyKey/);
      expect((await until(msgs, (m) => m.type === 'update' && m.channel === 'orders')).data.id).toBe(ack.order.id);

      place('b2'); // same idempotency key: the same order comes back, nothing is locked twice
      expect((await until(msgs, (m) => m.type === 'order.ack' && m.id === 'b2')).order.id).toBe(ack.order.id);
      expect(await Order.countDocuments({})).toBe(1);

      place('b3', { idempotencyKey: 'bot-order-0002', qty: '10000500' }); // not a lot multiple
      expect((await until(msgs, (m) => m.type === 'order.error' && m.id === 'b3')).code).toBe('VALIDATION');
      place('b4', { idempotencyKey: 'bot-order-0003', qty: '90000000000' }); // far more than the balance
      expect((await until(msgs, (m) => m.type === 'order.error' && m.id === 'b4')).code).toBe('INSUFFICIENT_FUNDS');

      bot.send(JSON.stringify({ op: 'order.cancel', id: 'b5', orderId: ack.order.id }));
      await until(msgs, (m) => m.type === 'order.ack' && m.id === 'b5');
      await until(msgs, (m) => m.type === 'update' && m.channel === 'orders' && m.data.status === 'canceled');

      // revoke the key from the web session: the bot is disconnected on the next heartbeat
      expect((await request(app).delete(`/v1/api-keys/${key.keyId}`).set(bearer)).status).toBe(204);
      expect((await until(msgs, (m) => m.code === 'KEY_REVOKED', 4000)).type).toBe('error');
      expect(await closed).toBe(1008);
    } finally {
      await wsSrv.close();
      await new Promise<void>((r) => http.close(() => r()));
    }
  });
});
