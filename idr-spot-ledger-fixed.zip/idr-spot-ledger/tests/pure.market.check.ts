// Dependency-free: node --experimental-strip-types tests/pure.market.check.ts
import assert from 'node:assert/strict';
import { INTERVALS, applyTrade, bucketStart, candleToWire, computeTicker, fillGaps, isInterval } from '../src/marketdata/candles.ts';
import type { Candle, TradeTick } from '../src/marketdata/candles.ts';
import { Coalescer, Hub } from '../src/marketdata/hub.ts';
import { Connection } from '../src/ws/connection.ts';
import type { ConnDeps } from '../src/ws/connection.ts';
import { hubKey, parseChannel, parseClientMessage } from '../src/ws/protocol.ts';
import { TokenBucket } from '../src/security/ratelimit.ts';

let passed = 0;
const t = async (name: string, fn: () => void | Promise<void>) => { await fn(); passed++; console.log('ok -', name); };
const tick = (price: number, qty: number, seq: number, time: number): TradeTick => ({ price: BigInt(price), qty: BigInt(qty), quoteQty: BigInt(price * qty), seq, time });

// ---------------------------------------------------------------- candles
await t('bucketStart aligns to UTC boundaries', () => {
  const ts = Date.UTC(2026, 9, 22, 13, 47, 31, 123);
  assert.equal(bucketStart(ts, '1m'), Date.UTC(2026, 9, 22, 13, 47));
  assert.equal(bucketStart(ts, '15m'), Date.UTC(2026, 9, 22, 13, 45));
  assert.equal(bucketStart(ts, '4h'), Date.UTC(2026, 9, 22, 12, 0));
  assert.equal(bucketStart(ts, '1d'), Date.UTC(2026, 9, 22));
  assert.ok(isInterval('1h') && !isInterval('2h') && !isInterval('constructor') && !isInterval('toString'));
});
await t('OHLCV folds correctly and is idempotent per seq', () => {
  const base = Date.UTC(2026, 0, 1, 0, 0, 10);
  let c = applyTrade(null, tick(100, 2, 1, base), '1m');
  c = applyTrade(c, tick(110, 3, 2, base + 5000), '1m');
  c = applyTrade(c, tick(90, 1, 3, base + 9000), '1m');
  c = applyTrade(c, tick(95, 4, 4, base + 20000), '1m');
  assert.deepEqual([c.open, c.high, c.low, c.close, c.volume, c.trades, c.lastSeq], [100n, 110n, 90n, 95n, 10n, 4, 4]);
  assert.equal(c.quoteVolume, 200n + 330n + 90n + 380n);
  const again = applyTrade(c, tick(999, 9, 3, base + 9000), '1m'); // replay of an old seq
  assert.equal(again, c);
  assert.throws(() => applyTrade(c, tick(100, 1, 5, base + 61_000), '1m')); // wrong bucket
  assert.deepEqual(candleToWire(c), { t: Date.UTC(2026, 0, 1, 0, 0), o: '100', h: '110', l: '90', c: '95', v: '10', qv: '1000', n: 4 });
});
await t('higher intervals aggregate the same trades consistently with 1m', () => {
  const t0 = Date.UTC(2026, 0, 1, 10, 0, 0);
  const trades = Array.from({ length: 200 }, (_, i) => tick(1000 + ((i * 37) % 50), 1 + (i % 5), i + 1, t0 + i * 17_000));
  const byIv = (iv: '1m' | '1h') => {
    const m = new Map<number, Candle>();
    for (const tr of trades) { const k = bucketStart(tr.time, iv); m.set(k, applyTrade(m.get(k) ?? null, tr, iv)); }
    return [...m.values()].sort((a, b) => a.openTime - b.openTime);
  };
  const m1 = byIv('1m'), h1 = byIv('1h');
  for (const h of h1) {
    const inside = m1.filter((c) => bucketStart(c.openTime, '1h') === h.openTime);
    assert.equal(inside.reduce((s, c) => s + c.volume, 0n), h.volume);
    assert.equal(inside.reduce((s, c) => s + c.quoteVolume, 0n), h.quoteVolume);
    assert.equal(inside.reduce((s, c) => s + c.trades, 0), h.trades);
    assert.equal(inside[0].open, h.open);
    assert.equal(inside[inside.length - 1].close, h.close);
    assert.equal(inside.reduce((m, c) => (c.high > m ? c.high : m), 0n), h.high);
  }
});
await t('fillGaps: flat candles at previous close, no fabricated leading history', () => {
  const t0 = Date.UTC(2026, 0, 1, 0, 0);
  const a = applyTrade(null, tick(100, 1, 1, t0 + 1000), '1m');
  const b = applyTrade(null, tick(120, 1, 2, t0 + 4 * 60_000 + 1000), '1m');
  const f = fillGaps([a, b], t0 - 2 * 60_000, t0 + 5 * 60_000, '1m');
  assert.deepEqual(f.map((c) => [c.openTime - t0, c.close, c.volume]), [[0, 100n, 1n], [60_000, 100n, 0n], [120_000, 100n, 0n], [180_000, 100n, 0n], [240_000, 120n, 1n], [300_000, 120n, 0n]]);
  assert.equal(fillGaps([], t0, t0 + 120_000, '1m').length, 0);
  assert.equal(fillGaps([], t0, t0 + 120_000, '1m', 77n).length, 3); // seeded from the candle before the range
  assert.equal(fillGaps([], 0, 10 ** 15, '1m', 1n).length, 5000); // bounded
});
await t('ticker 24h: window edges, change in bps, empty market', () => {
  const now = Date.UTC(2026, 5, 10, 12, 0, 30);
  assert.deepEqual(computeTicker([], now), { last: null, open: null, high: null, low: null, volume: '0', quoteVolume: '0', trades: 0, changeBps: null });
  const mk = (minsAgo: number, p: number, q: number, seq: number) => applyTrade(null, tick(p, q, seq, now - minsAgo * 60_000), '1m');
  const cs = [mk(25 * 60, 50, 9, 1), mk(23 * 60, 100, 2, 2), mk(600, 130, 1, 3), mk(300, 80, 3, 4), mk(5, 110, 4, 5)];
  const k = computeTicker(cs, now);
  assert.deepEqual([k.open, k.high, k.low, k.last, k.volume, k.trades, k.changeBps], ['100', '130', '80', '110', '10', 4, 1000]); // 25h-old candle excluded
  const down = computeTicker([mk(10, 200, 1, 1), mk(1, 150, 1, 2)], now);
  assert.equal(down.changeBps, -2500);
  assert.equal(computeTicker([mk(10, 3, 1, 1), mk(1, 4, 1, 2)], now).changeBps, 3333); // truncated, not rounded
});

// ---------------------------------------------------------------- hub / coalescer
await t('hub: delivery, unsubscribe, listener isolation', () => {
  const hub = new Hub();
  const got: number[] = [];
  const off = hub.subscribe('x', (m) => got.push(m.data));
  hub.subscribe('x', () => { throw new Error('bad listener'); });
  hub.subscribe('x', (m) => got.push(m.data * 10));
  assert.equal(hub.publish('x', { data: 1 }), 2); // the throwing listener does not count and does not break others
  off();
  hub.publish('x', { data: 2 });
  assert.deepEqual(got, [1, 10, 20]);
  assert.equal(hub.publish('nobody', { data: 1 }), 0);
  assert.equal(hub.hasSubscribers('x'), true);
});
await t('coalescer: latest job wins, one run per window, reschedules after run', async () => {
  const queue: Array<() => void> = [];
  const c = new Coalescer(100, (fn) => { queue.push(fn); });
  const ran: string[] = [];
  c.request('book:A', () => { ran.push('1'); });
  c.request('book:A', () => { ran.push('2'); });
  c.request('book:A', () => { ran.push('3'); });
  c.request('book:B', () => { ran.push('B'); });
  assert.equal(queue.length, 2);
  for (const f of queue.splice(0)) await (f as any)();
  assert.deepEqual(ran, ['3', 'B']);
  c.request('book:A', () => { ran.push('4'); });
  assert.equal(queue.length, 1);
  const errs: unknown[] = [];
  const c2 = new Coalescer(1, (fn) => { queue.push(fn); }, (e) => errs.push(e));
  c2.request('k', () => { throw new Error('boom'); });
  await (queue[queue.length - 1] as any)();
  assert.equal(errs.length, 1);
});

// ---------------------------------------------------------------- protocol
await t('channel + message parsing is strict', () => {
  assert.deepEqual(parseChannel('book:BTC_IDR'), { kind: 'book', market: 'BTC_IDR' });
  assert.deepEqual(parseChannel('candles:ETH_IDR:4h'), { kind: 'candles', market: 'ETH_IDR', interval: '4h' });
  assert.deepEqual(parseChannel('orders'), { kind: 'orders' });
  for (const bad of ['book', 'book:btc_idr', 'book:BTC_IDR:1m', 'candles:BTC_IDR:2h', 'orders:5', '__proto__', 'ticker:BTC_IDR\n', 'x'.repeat(100), 5 as any, '']) assert.throws(() => parseChannel(bad), (e: any) => e.code === 'INVALID_CHANNEL');
  assert.equal(hubKey({ kind: 'orders' }, 'u1'), 'orders:u1');
  assert.equal(hubKey({ kind: 'candles', market: 'BTC_IDR', interval: '1m' }), 'candles:BTC_IDR:1m');
  assert.deepEqual(parseClientMessage('{"op":"ping"}'), { op: 'ping' });
  assert.deepEqual(parseClientMessage('{"op":"subscribe","channel":"orders","extra":1}'), { op: 'subscribe', channel: 'orders' });
  for (const bad of ['', 'nope', '[]', '{"op":"x"}', '{"op":"auth"}', '{"op":"auth","token":"short"}', '{"op":"subscribe"}', JSON.stringify({ op: 'ping', pad: 'x'.repeat(5000) })]) assert.throws(() => parseClientMessage(bad));
});

// ---------------------------------------------------------------- connection state machine
function rig(over: Partial<ConnDeps> = {}) {
  const sent: any[] = [];
  const hub = new Hub();
  let closed: [number, string] | null = null;
  let now = 1_000_000;
  const snapshots: Array<{ ch: string; resolve: (v: any) => void }> = [];
  const deps: ConnDeps = {
    hub,
    authenticate: async (token) => { if (token === 'good-token-123') return { userId: 'u1', expiresAt: now + 60_000 }; throw new Error('nope'); },
    snapshot: (ch) => new Promise((resolve) => snapshots.push({ ch: JSON.stringify(ch), resolve })),
    send: (o) => sent.push(o),
    close: (code, reason) => { closed = [code, reason]; },
    now: () => now,
    limiter: new TokenBucket(1000, 1000),
    ...over,
  };
  const conn = new Connection(deps);
  return { conn, sent, hub, snapshots, closed: () => closed, advance: (ms: number) => { now += ms; } };
}
const flush = () => new Promise((r) => setImmediate(r));

await t('subscribe: snapshot first, updates queued during load, duplicates (seq <= snapshot) dropped', async () => {
  const r = rig();
  const p = r.conn.handleRaw('{"op":"subscribe","channel":"trades:BTC_IDR"}');
  await flush();
  r.hub.publish('trades:BTC_IDR', { seq: 5, data: 'old' });
  r.hub.publish('trades:BTC_IDR', { seq: 6, data: 'in-snapshot' });
  r.hub.publish('trades:BTC_IDR', { seq: 7, data: 'new' });
  assert.deepEqual(r.sent, []); // nothing leaks before the snapshot
  r.snapshots[0].resolve({ data: ['a', 'b'], seq: 6 });
  await p;
  assert.deepEqual(r.sent.map((m) => [m.type, m.seq ?? null]), [['subscribed', null], ['snapshot', 6], ['update', 7]]);
  r.hub.publish('trades:BTC_IDR', { seq: 8, data: 'live' });
  assert.equal(r.sent.at(-1).data, 'live');
  r.conn.dispose();
  r.hub.publish('trades:BTC_IDR', { seq: 9, data: 'after-close' });
  assert.equal(r.sent.length, 4);
  assert.equal(r.hub.hasSubscribers('trades:BTC_IDR'), false);
});
await t('private channels need auth; the hub key comes from the authenticated user, not the client', async () => {
  const r = rig({ snapshot: async () => ({ data: [], seq: 0 }) });
  await r.conn.handleRaw('{"op":"subscribe","channel":"orders"}');
  assert.equal(r.sent.at(-1).code, 'AUTH_REQUIRED');
  await r.conn.handleRaw('{"op":"auth","token":"bad-token-1234"}');
  assert.equal(r.sent.at(-1).code, 'AUTH_FAILED');
  await r.conn.handleRaw('{"op":"auth","token":"good-token-123"}');
  assert.equal(r.sent.at(-1).type, 'authed');
  await r.conn.handleRaw('{"op":"subscribe","channel":"orders"}');
  assert.equal(r.hub.hasSubscribers('orders:u1'), true);
  assert.equal(r.hub.hasSubscribers('orders'), false);
  r.hub.publish('orders:u2', { data: 'someone else' }); // another user's stream never reaches this socket
  r.hub.publish('orders:u1', { data: 'mine', seq: 1 });
  assert.deepEqual(r.sent.filter((m) => m.type === 'update').map((m) => m.data), ['mine']);
  await r.conn.handleRaw('{"op":"auth","token":"good-token-123"}');
  assert.equal(r.sent.at(-1).code, 'ALREADY_AUTHED');
});
await t('token expiry stops private streams; public streams continue', async () => {
  const r = rig({ snapshot: async () => ({ data: [], seq: 0 }) });
  await r.conn.handleRaw('{"op":"auth","token":"good-token-123"}');
  await r.conn.handleRaw('{"op":"subscribe","channel":"orders"}');
  await r.conn.handleRaw('{"op":"subscribe","channel":"ticker:BTC_IDR"}');
  r.advance(61_000);
  r.conn.tick();
  assert.equal(r.sent.at(-1).code, 'TOKEN_EXPIRED');
  assert.equal(r.hub.hasSubscribers('orders:u1'), false);
  assert.equal(r.hub.hasSubscribers('ticker:BTC_IDR'), true);
  await r.conn.handleRaw('{"op":"subscribe","channel":"balances"}');
  assert.equal(r.sent.at(-1).code, 'AUTH_REQUIRED');
});
await t('limits: max subscriptions, protocol-error strikes close the socket, auth failures close, rate limit', async () => {
  const r = rig({ snapshot: async () => ({ data: [], seq: 0 }) });
  for (let i = 0; i < 20; i++) await r.conn.handleRaw(JSON.stringify({ op: 'subscribe', channel: `ticker:AB${String.fromCharCode(65 + i)}_IDR` }));
  await r.conn.handleRaw('{"op":"subscribe","channel":"ticker:ZZZ_IDR"}');
  assert.equal(r.sent.at(-1).code, 'TOO_MANY_SUBSCRIPTIONS');

  const r2 = rig();
  for (let i = 0; i < 5; i++) await r2.conn.handleRaw('garbage');
  assert.deepEqual(r2.closed(), [1008, 'too many errors']);
  const before = r2.sent.length;
  await r2.conn.handleRaw('{"op":"ping"}');
  assert.equal(r2.sent.length, before); // closed connections ignore input

  const r3 = rig();
  for (let i = 0; i < 3; i++) await r3.conn.handleRaw('{"op":"auth","token":"bad-token-1234"}');
  assert.deepEqual(r3.closed(), [1008, 'authentication failed']);

  const r4 = rig({ limiter: new TokenBucket(3, 0.001) });
  for (let i = 0; i < 4; i++) await r4.conn.handleRaw('{"op":"ping"}');
  assert.equal(r4.sent.filter((m) => m.type === 'pong').length, 3);
  assert.equal(r4.sent.at(-1).code, 'RATE_LIMITED');
});
await t('snapshot failure cleans up; unsubscribe during load is respected', async () => {
  const r = rig({ snapshot: async () => { throw new Error('db down'); } });
  await r.conn.handleRaw('{"op":"subscribe","channel":"book:BTC_IDR"}');
  assert.equal(r.sent.at(-1).code, 'SNAPSHOT_FAILED');
  assert.equal(r.hub.hasSubscribers('book:BTC_IDR'), false);
  const r2 = rig();
  const p = r2.conn.handleRaw('{"op":"subscribe","channel":"book:BTC_IDR"}');
  await flush();
  await r2.conn.handleRaw('{"op":"unsubscribe","channel":"book:BTC_IDR"}');
  r2.snapshots[0].resolve({ data: [], seq: 1 });
  await p;
  assert.deepEqual(r2.sent.map((m) => m.type), ['unsubscribed']); // no stray snapshot for a cancelled subscription
});

console.log(`\nall ${passed} market-data checks passed`);
void INTERVALS;
