// Dependency-free: node --experimental-strip-types tests/pure.signer.check.ts
import assert from 'node:assert/strict';
import { createHash, createPublicKey, randomBytes, verify, createECDH } from 'node:crypto';
import { mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { N, addressFromPrivate, decodeEip1559, hexBuf, keccak256, publicKey, recoverPublic, rlp, rlpDecode, rlpInt, sign, signEip1559, toChecksumAddress, txHash } from '../src/chain/evmCrypto.ts';
import { EvmRpcChain, hexToBig, pad32, toHex } from '../src/chain/evmRpc.ts';
import { checkTransfer, SignerError } from '../src/signer/policy.ts';
import { FileStore, MemoryStore } from '../src/signer/store.ts';
import { EvmSigner } from '../src/signer/evmSigner.ts';
import { SignerClient, createHandler, startSignerServer } from '../src/signer/http.ts';
import { signedHeaders } from '../src/payments/webhook.ts';

let passed = 0;
const t = async (name: string, fn: () => void | Promise<void>) => { await fn(); passed++; console.log('ok -', name); };
const hx = (b: Buffer) => b.toString('hex');
const B = (s: string) => Buffer.from(s);

// ------------------------------------------------------------------ primitives
await t('keccak-256: published vectors (and it is NOT sha3-256)', () => {
  assert.equal(hx(keccak256(Buffer.alloc(0))), 'c5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470');
  assert.equal(hx(keccak256(B('abc'))), '4e03657aea45a94fc7d47ba826c8d667c0d1e6e33a64a036ec44f58fa12d6c45');
  assert.equal(hx(keccak256(B('The quick brown fox jumps over the lazy dog'))), '4d741b6f1eb29cb2a9b9911c82f56fa8d73b04959d3d9d222895df6c0b28aa15');
  assert.notEqual(hx(keccak256(B('abc'))), createHash('sha3-256').update('abc').digest('hex'));
  for (const len of [135, 136, 137, 272, 500]) assert.equal(keccak256(Buffer.alloc(len, 7)).length, 32); // padding at/around the 136-byte rate boundary
  assert.notEqual(hx(keccak256(Buffer.alloc(135, 7))), hx(keccak256(Buffer.alloc(136, 7))));
});
await t('addresses: known key->address, EIP-55 checksums, public keys match Node ECDH', () => {
  const k1 = Buffer.alloc(32); k1[31] = 1;
  assert.equal(addressFromPrivate(k1), '0x7e5f4552091a69125d5dfcb7b8c2659029395bdf');
  for (const a of ['0x5aAeb6053F3E94C9b9A09f33669435E7Ef1BeAed', '0xfB6916095ca1df60bB79Ce92cE3Ea74c37c5d359', '0xdbF03B407c01E7cD3CBea99509d93f8DDDC8C6FB', '0xD1220A0cf47c7B9Be7A2E6BA89F429762e7b9aDb']) assert.equal(toChecksumAddress(a.toLowerCase()), a);
  for (let i = 0; i < 12; i++) {
    const k = randomBytes(32);
    const e = createECDH('secp256k1'); e.setPrivateKey(k);
    assert.equal(hx(publicKey(k)), hx(e.getPublicKey().subarray(1)));
  }
  assert.throws(() => publicKey(Buffer.alloc(32)));
  assert.throws(() => publicKey(Buffer.from(N.toString(16).padStart(64, '0'), 'hex')));
});
await t('ECDSA: signatures verify with NODE\'s own implementation, are deterministic, low-S, and recover the signer', () => {
  for (let i = 0; i < 12; i++) {
    const k = randomBytes(32), msg = randomBytes(40 + i);
    const digest = createHash('sha256').update(msg).digest();
    const sig = sign(digest, k);
    assert.ok(sig.s <= N / 2n, 'low-S');
    const pub = publicKey(k);
    const jwk = createPublicKey({ key: { kty: 'EC', crv: 'secp256k1', x: pub.subarray(0, 32).toString('base64url'), y: pub.subarray(32).toString('base64url') }, format: 'jwk' });
    const rs = Buffer.concat([Buffer.from(sig.r.toString(16).padStart(64, '0'), 'hex'), Buffer.from(sig.s.toString(16).padStart(64, '0'), 'hex')]);
    assert.equal(verify('sha256', msg, { key: jwk, dsaEncoding: 'ieee-p1363' }, rs), true, 'node accepts our signature');
    assert.equal(verify('sha256', Buffer.concat([msg, B('x')]), { key: jwk, dsaEncoding: 'ieee-p1363' }, rs), false);
    assert.deepEqual(sign(digest, k), sig); // RFC 6979: deterministic
    assert.equal(hx(recoverPublic(digest, sig)), hx(pub));
  }
});
await t('RLP: Ethereum wiki vectors, long strings, nested lists, round trip', () => {
  assert.equal(hx(rlp(B('dog'))), '83646f67');
  assert.equal(hx(rlp([B('cat'), B('dog')])), 'c88363617483646f67');
  assert.equal(hx(rlp(Buffer.alloc(0))), '80');
  assert.equal(hx(rlp([])), 'c0');
  assert.equal(hx(rlp(rlpInt(0n))), '80');
  assert.equal(hx(rlp(rlpInt(15n))), '0f');
  assert.equal(hx(rlp(rlpInt(1024n))), '820400');
  assert.equal(hx(rlp([[], [[]], [[], [[]]]])), 'c7c0c1c0c3c0c1c0');
  const lorem = B('Lorem ipsum dolor sit amet, consectetur adipisicing elit');
  assert.equal(hx(rlp(lorem)), 'b838' + hx(lorem));
  const big = randomBytes(1000);
  assert.deepEqual(rlpDecode(rlp(big)), big);
  const nested = [randomBytes(3), [randomBytes(60), []], randomBytes(1)] as any;
  assert.equal(hx(rlp(rlpDecode(rlp(nested)))), hx(rlp(nested)));
});
await t('EIP-155 specification example reproduces exactly (signing hash, r, s, v)', () => {
  const key = Buffer.from('46'.repeat(32), 'hex');
  const fields = [rlpInt(9n), rlpInt(20_000_000_000n), rlpInt(21_000n), hexBuf('0x' + '35'.repeat(20)), rlpInt(10n ** 18n), Buffer.alloc(0), rlpInt(1n), Buffer.alloc(0), Buffer.alloc(0)];
  const digest = keccak256(rlp(fields));
  assert.equal(hx(digest), 'daf5a779ae972f972197303d7b574746c7ef83eadac0f2791ad23db92e4c8e53');
  const sig = sign(digest, key);
  assert.equal(sig.r.toString(), '18515461264373351373200002665853028612451056578545711640558177340181847433846');
  assert.equal(sig.s.toString(), '46948507304638947509940763649030358759909902576025900602547168820602576006531');
  assert.equal(sig.recovery + 35 + 2 * 1, 37);
  assert.equal(addressFromPrivate(key), '0x9d8a62f656a8d1615c1294fd71e9cfb3e4855a4f');
});
await t('EIP-1559 transactions: sign -> decode recovers the sender and every field; tampering changes the sender', () => {
  const key = randomBytes(32);
  const tx = { chainId: 11155111n, nonce: 7n, maxPriorityFeePerGas: 1_500_000_000n, maxFeePerGas: 3_500_000_000n, gasLimit: 21_000n, to: '0x' + 'ab'.repeat(20), value: 12345n, data: '0x' };
  const s = signEip1559(tx, key);
  assert.ok(s.raw.startsWith('0x02'));
  const d = decodeEip1559(s.raw);
  assert.equal(d.from, addressFromPrivate(key));
  assert.deepEqual({ ...d, from: undefined }, { ...tx, from: undefined });
  assert.equal(s.hash, txHash(s.raw));
  const tampered = '0x' + hx(Buffer.from(hexBuf(s.raw).map((b, i) => (i === 20 ? b ^ 1 : b))));
  let other: string | null = null;
  try { other = decodeEip1559(tampered).from; } catch { other = null; }
  assert.notEqual(other, addressFromPrivate(key));
  assert.equal(decodeEip1559(signEip1559({ ...tx, value: 0n, data: '0xa9059cbb' + '00'.repeat(64) }, key).raw).data.length, 2 + 2 * 68);
});

// ------------------------------------------------------------------ policy and stores
const HOT = '0x' + '11'.repeat(20);
const TOK = '0x' + '77'.repeat(20);
const LIM = { perTx: { ETH: 10n ** 18n, USDT: 1_000_000_000n }, perDay: { ETH: 3n * 10n ** 18n, USDT: 2_000_000_000n } };
const req = (o: object = {}) => ({ reference: 'wd-0001', asset: 'ETH', to: '0x' + 'ab'.repeat(20), amount: 5n * 10n ** 17n, ...o });
const bad = (o: object, code: string, spent = 0n) => assert.throws(() => checkTransfer(req(o), LIM, spent, HOT, { USDT: TOK }, 'ETH'), (e: any) => e instanceof SignerError && e.code === code, code + JSON.stringify(o, (_k, v) => (typeof v === 'bigint' ? v.toString() : v)));

await t('policy: fails closed on every unsafe request', () => {
  checkTransfer(req(), LIM, 0n, HOT, { USDT: TOK }, 'ETH');
  bad({ reference: 'x' }, 'BAD_REQUEST'); bad({ amount: 0n }, 'BAD_REQUEST'); bad({ amount: -1n }, 'BAD_REQUEST');
  bad({ asset: 'DOGE' }, 'UNKNOWN_ASSET'); bad({ to: '0x123' }, 'BAD_ADDRESS'); bad({ to: '0x' + '0'.repeat(40) }, 'BAD_ADDRESS');
  bad({ to: HOT.toUpperCase().replace('0X', '0x') }, 'BAD_ADDRESS'); bad({ to: TOK, asset: 'USDT' }, 'BAD_ADDRESS');
  bad({ amount: 10n ** 18n + 1n }, 'OVER_TX_LIMIT');
  bad({}, 'OVER_DAILY_LIMIT', 25n * 10n ** 17n + 1n);
  assert.throws(() => checkTransfer(req({ asset: 'USDT' }), { perTx: {}, perDay: {} }, 0n, HOT, { USDT: TOK }, 'ETH'), (e: any) => e.code === 'NO_LIMIT');
});
await t('stores: durable atomic file store reloads, rejects duplicate references, tracks nonce and 24h spend', () => {
  const dir = mkdtempSync(join(tmpdir(), 'signer-'));
  try {
    const path = join(dir, 'state.json');
    const a = new FileStore(path);
    const rec = (reference: string, nonce: number, amount: string, createdAt: number) => ({ reference, asset: 'ETH', to: '0x' + 'ab'.repeat(20), amount, nonce, txHash: '0x' + reference, raw: '0x02', chainId: '1', createdAt });
    assert.equal(a.maxNonce('1'), -1);
    a.put(rec('r1', 0, '5', 1000)); a.put(rec('r2', 1, '7', 2000));
    assert.throws(() => a.put(rec('r1', 9, '1', 3000)));
    const b = new FileStore(path); // "process restart"
    assert.equal(b.get('r2')!.nonce, 1);
    assert.equal(b.maxNonce('1'), 1);
    assert.equal(b.maxNonce('999'), -1);
    assert.equal(b.spentSince('ETH', 1500), 7n);
    assert.equal(b.spentSince('ETH', 0), 12n);
    assert.equal(b.spentSince('USDT', 0), 0n);
    assert.equal(JSON.parse(readFileSync(path, 'utf8')).length, 2);
  } finally { rmSync(dir, { recursive: true, force: true }); }
});

// ------------------------------------------------------------------ the signer against a fake node that validates signatures like a real one
class FakeNode {
  hot: string; chainId: bigint;
  count = 0; ethBalance = 100n * 10n ** 18n; tokenBalance = 1_000_000_000_000n;
  txs: Map<string, ReturnType<typeof decodeEip1559>> = new Map();
  failSend: 'none' | 'before' | 'after' = 'none';
  tipUnsupported = false; estimateFails = false;
  calls: Array<{ method: string; params: any[] }> = [];
  constructor(hot: string, chainId: bigint) { this.hot = hot; this.chainId = chainId; }
  rpc = async (method: string, params: any[]): Promise<any> => {
    this.calls.push({ method, params });
    switch (method) {
      case 'eth_getBlockByNumber': return { baseFeePerGas: toHex(1_000_000_000n) };
      case 'eth_maxPriorityFeePerGas': if (this.tipUnsupported) throw new Error('method not found'); return toHex(1_500_000_000n);
      case 'eth_getTransactionCount': return toHex(this.count);
      case 'eth_estimateGas': if (this.estimateFails) throw new Error('execution reverted'); return toHex(50_000n);
      case 'eth_getBalance': return toHex(this.ethBalance);
      case 'eth_call': return toHex(this.tokenBalance);
      case 'eth_getTransactionByHash': return this.txs.has(params[0]) ? { hash: params[0] } : null;
      case 'eth_sendRawTransaction': {
        if (this.failSend === 'before') { this.failSend = 'none'; throw new Error('connection reset'); }
        const tx = decodeEip1559(params[0]);
        const h = txHash(params[0]);
        if (this.txs.has(h)) throw new Error('already known');
        if (tx.from !== this.hot) throw new Error('invalid sender');
        if (tx.chainId !== this.chainId) throw new Error('invalid chain id');
        if (tx.nonce < BigInt(this.count)) throw new Error('nonce too low');
        if (tx.nonce > BigInt(this.count)) throw new Error('nonce too high');
        this.txs.set(h, tx); this.count++;
        if (this.failSend === 'after') { this.failSend = 'none'; throw new Error('timeout waiting for response'); }
        return h;
      }
      default: throw new Error('unsupported ' + method);
    }
  };
}
const KEY = randomBytes(32);
const HOTADDR = addressFromPrivate(KEY);
const DEST = '0x' + 'ab'.repeat(20);
function signerRig(over: Partial<ConstructorParameters<typeof EvmSigner>[0]> = {}) {
  const node = new FakeNode(HOTADDR, 11155111n);
  let clock = 1_700_000_000_000;
  const store = new MemoryStore();
  const signer = new EvmSigner({ privateKey: KEY, chainId: 11155111n, rpc: node.rpc, nativeAsset: 'ETH', tokens: { USDT: TOK }, limits: LIM, store, now: () => clock, ...over });
  return { node, signer, store, advance: (ms: number) => { clock += ms; } };
}
const ETH = (n: number) => BigInt(Math.round(n * 1000)) * 10n ** 15n;

await t('signer: a native payout is a valid, correctly priced EIP-1559 transaction from the hot wallet', async () => {
  const r = signerRig();
  const hash = await r.signer.sendTransfer({ reference: 'wd-1000', asset: 'ETH', to: DEST, amount: ETH(0.25) });
  assert.equal(r.signer.hotAddress, HOTADDR);
  const tx = [...r.node.txs.values()][0];
  assert.deepEqual([tx.from, tx.to, tx.value, tx.nonce, tx.gasLimit, tx.chainId, tx.data], [HOTADDR, DEST, ETH(0.25), 0n, 21_000n, 11155111n, '0x']);
  assert.deepEqual([tx.maxPriorityFeePerGas, tx.maxFeePerGas], [1_500_000_000n, 3_500_000_000n]); // 2 x baseFee + tip
  assert.equal(hash, [...r.node.txs.keys()][0]);
});
await t('signer: an ERC-20 payout encodes transfer(to, amount) to the token contract with value 0', async () => {
  const r = signerRig();
  await r.signer.sendTransfer({ reference: 'wd-2000', asset: 'USDT', to: DEST, amount: 250_000_000n });
  const tx = [...r.node.txs.values()][0];
  assert.equal(tx.to, TOK);
  assert.equal(tx.value, 0n);
  assert.equal(tx.data, '0xa9059cbb' + pad32(DEST).slice(2) + (250_000_000n).toString(16).padStart(64, '0'));
  assert.equal(tx.gasLimit, 65_000n); // 1.3 x the node's estimate
});
await t('signer: retries are idempotent: same reference -> same transaction, same nonce, never a second payment', async () => {
  const r = signerRig();
  const a = await r.signer.sendTransfer({ reference: 'wd-3000', asset: 'ETH', to: DEST, amount: ETH(0.1) });
  const b = await r.signer.sendTransfer({ reference: 'wd-3001', asset: 'ETH', to: DEST, amount: ETH(0.1) });
  const again = await r.signer.sendTransfer({ reference: 'wd-3000', asset: 'ETH', to: DEST, amount: ETH(0.1) });
  assert.equal(again, a);
  assert.notEqual(a, b);
  assert.equal(r.node.count, 2);
  assert.deepEqual([...r.node.txs.values()].map((x) => x.nonce), [0n, 1n]);
  await assert.rejects(() => r.signer.sendTransfer({ reference: 'wd-3000', asset: 'ETH', to: DEST, amount: ETH(0.2) }), (e: any) => e.code === 'REFERENCE_CONFLICT');
  await assert.rejects(() => r.signer.sendTransfer({ reference: 'wd-3000', asset: 'ETH', to: '0x' + 'cd'.repeat(20), amount: ETH(0.1) }), (e: any) => e.code === 'REFERENCE_CONFLICT');
  assert.equal(r.node.count, 2);
});
await t('signer: crash/network safety: stored BEFORE broadcast; nonces stay reserved; recovery in any order ends with the exact transactions', async () => {
  const r = signerRig();
  r.node.failSend = 'before';
  await assert.rejects(() => r.signer.sendTransfer({ reference: 'wd-4000', asset: 'ETH', to: DEST, amount: ETH(0.1) }), /connection reset/);
  assert.equal(r.node.count, 0);
  assert.equal(r.store.get('wd-4000')!.nonce, 0); // nonce 0 is reserved for this payout...
  await assert.rejects(() => r.signer.sendTransfer({ reference: 'wd-4001', asset: 'ETH', to: DEST, amount: ETH(0.1) }), /nonce too high/); // ...so the next one queues behind it
  assert.equal(r.store.get('wd-4001')!.nonce, 1); // never reuses nonce 0, never leaves a gap
  assert.equal(r.node.count, 0);
  const h1 = await r.signer.sendTransfer({ reference: 'wd-4001', asset: 'ETH', to: DEST, amount: ETH(0.1) }).catch(() => null); // out of order: still blocked
  assert.equal(h1, null);
  const h0 = await r.signer.sendTransfer({ reference: 'wd-4000', asset: 'ETH', to: DEST, amount: ETH(0.1) }); // recover in order
  const h1b = await r.signer.sendTransfer({ reference: 'wd-4001', asset: 'ETH', to: DEST, amount: ETH(0.1) });
  assert.deepEqual([h0, h1b], [r.store.get('wd-4000')!.txHash, r.store.get('wd-4001')!.txHash]);
  assert.deepEqual([...r.node.txs.values()].map((x) => Number(x.nonce)), [0, 1]);
});
await t('signer: after a failed first send the retry delivers exactly the stored transaction', async () => {
  const r = signerRig();
  r.node.failSend = 'before';
  await assert.rejects(() => r.signer.sendTransfer({ reference: 'wd-4100', asset: 'ETH', to: DEST, amount: ETH(0.1) }));
  const hash = await r.signer.sendTransfer({ reference: 'wd-4100', asset: 'ETH', to: DEST, amount: ETH(0.1) });
  assert.equal(hash, r.store.get('wd-4100')!.txHash);
  assert.equal(r.node.count, 1);
  const r2 = signerRig();
  r2.node.failSend = 'after'; // the node accepted it but the answer never arrived
  await assert.rejects(() => r2.signer.sendTransfer({ reference: 'wd-4200', asset: 'ETH', to: DEST, amount: ETH(0.1) }), /timeout/);
  assert.equal(r2.node.count, 1);
  assert.equal(await r2.signer.sendTransfer({ reference: 'wd-4200', asset: 'ETH', to: DEST, amount: ETH(0.1) }), r2.store.get('wd-4200')!.txHash); // "already known" is success
  assert.equal(r2.node.count, 1);
});
await t('signer: limits and address rules are enforced and nothing is stored for refused requests; the 24h window rolls', async () => {
  const r = signerRig();
  await assert.rejects(() => r.signer.sendTransfer({ reference: 'wd-5000', asset: 'ETH', to: DEST, amount: ETH(1.5) }), (e: any) => e.code === 'OVER_TX_LIMIT');
  await assert.rejects(() => r.signer.sendTransfer({ reference: 'wd-5001', asset: 'ETH', to: HOTADDR, amount: ETH(0.1) }), (e: any) => e.code === 'BAD_ADDRESS');
  assert.equal(r.store.rows.size, 0);
  for (const i of [1, 2, 3]) await r.signer.sendTransfer({ reference: `wd-510${i}`, asset: 'ETH', to: DEST, amount: ETH(1) }); // 3 ETH = the daily cap
  await assert.rejects(() => r.signer.sendTransfer({ reference: 'wd-5104', asset: 'ETH', to: DEST, amount: ETH(0.01) }), (e: any) => e.code === 'OVER_DAILY_LIMIT');
  r.advance(25 * 3600_000);
  await r.signer.sendTransfer({ reference: 'wd-5105', asset: 'ETH', to: DEST, amount: ETH(0.01) });
  assert.equal(r.store.rows.size, 4);
});
await t('signer: refuses when the hot wallet cannot pay (amount + gas, tokens) or the token transfer would revert', async () => {
  const r = signerRig();
  r.node.ethBalance = ETH(0.1);
  await assert.rejects(() => r.signer.sendTransfer({ reference: 'wd-6000', asset: 'ETH', to: DEST, amount: ETH(0.1) }), (e: any) => e.code === 'INSUFFICIENT_HOT_FUNDS'); // no money left for gas
  r.node.ethBalance = 100n * 10n ** 18n; r.node.tokenBalance = 10n;
  await assert.rejects(() => r.signer.sendTransfer({ reference: 'wd-6001', asset: 'USDT', to: DEST, amount: 100n }), (e: any) => e.code === 'INSUFFICIENT_HOT_FUNDS');
  r.node.tokenBalance = 10n ** 12n; r.node.estimateFails = true;
  await assert.rejects(() => r.signer.sendTransfer({ reference: 'wd-6002', asset: 'USDT', to: DEST, amount: 100n }), (e: any) => e.code === 'ESTIMATE_FAILED');
  assert.equal(r.store.rows.size, 0);
});
await t('signer: concurrent payouts get unique consecutive nonces; chain-side activity is respected; tip falls back when unsupported', async () => {
  const r = signerRig({ limits: { perTx: { ETH: 10n ** 18n }, perDay: { ETH: 100n * 10n ** 18n } } });
  r.node.count = 5; r.node.tipUnsupported = true; // other transactions already used nonces 0-4
  const hashes: string[] = [];
  // the fake node only accepts the next nonce in order, which the signer's mutex guarantees
  await Promise.all(Array.from({ length: 8 }, (_, i) => r.signer.sendTransfer({ reference: `wd-700${i}`, asset: 'ETH', to: DEST, amount: ETH(0.01) }).then((h) => hashes.push(h))));
  assert.deepEqual([...r.node.txs.values()].map((x) => Number(x.nonce)), [5, 6, 7, 8, 9, 10, 11, 12]);
  assert.equal(new Set(hashes).size, 8);
  assert.equal([...r.node.txs.values()][0].maxPriorityFeePerGas, 1_500_000_000n);
});
await t('signer: "nonce too low" counts as success only if our transaction really is on chain', async () => {
  const r = signerRig();
  const h = await r.signer.sendTransfer({ reference: 'wd-8000', asset: 'ETH', to: DEST, amount: ETH(0.1) });
  r.node.txs.delete(h); // pretend the node forgot the hash but already used the nonce
  r.node.count = 1;
  await assert.rejects(() => r.signer.sendTransfer({ reference: 'wd-8000', asset: 'ETH', to: DEST, amount: ETH(0.1) }), (e: any) => e.code === 'NONCE_CONFLICT');
});

// ------------------------------------------------------------------ the HTTP boundary and the EVM adapter
await t('http handler: requires a fresh HMAC, validates the shape, maps policy errors, hides internals', async () => {
  const r = signerRig();
  let clock = 1_700_000_000_000;
  const h = createHandler({ signer: r.signer, secret: 's3cret', now: () => clock });
  const body = JSON.stringify({ reference: 'wd-9000', asset: 'ETH', to: DEST, amount: ETH(0.1).toString() });
  const hd = (b: string, ts = clock, secret = 's3cret') => signedHeaders(secret, b, ts);
  assert.equal((await h('POST', '/v1/transfer', {}, body)).status, 401);
  assert.equal((await h('POST', '/v1/transfer', hd(body, clock, 'wrong'), body)).status, 401);
  assert.equal((await h('POST', '/v1/transfer', hd(body, clock - 120_000), body)).status, 401); // replay window is 60 s
  assert.equal((await h('POST', '/v1/transfer', hd(body), body + ' ')).status, 401);
  assert.equal((await h('GET', '/v1/transfer', hd(body), body)).status, 404);
  const ok = await h('POST', '/v1/transfer', hd(body), body);
  assert.equal(ok.status, 200);
  assert.equal(((await h('POST', '/v1/transfer', hd(body), body)).body as any).txHash, (ok.body as any).txHash); // idempotent over HTTP
  for (const b of ['nope', JSON.stringify({ reference: 'x' }), JSON.stringify({ reference: 'wd-9001', asset: 'ETH', to: DEST, amount: '1.5' }), JSON.stringify({ reference: 'wd-9001', asset: 'ETH', to: DEST, amount: 5 })]) {
    assert.equal((await h('POST', '/v1/transfer', hd(b), b)).status, 400, b);
  }
  const big = JSON.stringify({ reference: 'wd-9002', asset: 'ETH', to: DEST, amount: (5n * 10n ** 18n).toString() });
  assert.deepEqual((await h('POST', '/v1/transfer', hd(big), big)).body, { error: 'OVER_TX_LIMIT', message: 'amount exceeds the per-transfer limit of 1000000000000000000' });
  r.node.failSend = 'before';
  const boom = JSON.stringify({ reference: 'wd-9003', asset: 'ETH', to: DEST, amount: '1000' });
  const res = await h('POST', '/v1/transfer', hd(boom), boom);
  assert.equal(res.status, 502);
  assert.ok(!JSON.stringify(res.body).includes('connection reset')); // internals stay inside
});
await t('real HTTP round trip: SignerClient -> signer server -> chain; wrong secret and policy refusals surface as typed errors', async () => {
  const r = signerRig();
  const server = await startSignerServer(createHandler({ signer: r.signer, secret: 'topsecret' }), 0);
  const port = (server.address() as any).port;
  try {
    const client = new SignerClient({ url: `http://127.0.0.1:${port}`, secret: 'topsecret', fetch });
    const hash = await client.sendTransfer({ reference: 'wd-9100', asset: 'ETH', to: DEST, amount: ETH(0.1) });
    assert.equal(hash, r.store.get('wd-9100')!.txHash);
    assert.equal(await client.sendTransfer({ reference: 'wd-9100', asset: 'ETH', to: DEST, amount: ETH(0.1) }), hash);
    assert.equal(r.node.count, 1);
    await assert.rejects(() => new SignerClient({ url: `http://127.0.0.1:${port}`, secret: 'wrong', fetch }).sendTransfer({ reference: 'wd-9101', asset: 'ETH', to: DEST, amount: 1n }), (e: any) => e.code === 'UNAUTHORIZED');
    await assert.rejects(() => client.sendTransfer({ reference: 'wd-9102', asset: 'ETH', to: DEST, amount: 5n * 10n ** 18n }), (e: any) => e.code === 'OVER_TX_LIMIT');
    // the exchange-side adapter plugs this in as its Signer
    const chain = new EvmRpcChain({ chain: 'ETH', rpcUrl: 'x', fetch: async () => ({ ok: true, status: 200, json: async () => ({}) }), nativeAsset: 'ETH', tokens: {}, signer: client });
    assert.deepEqual(await chain.broadcast({ reference: 'wd-9103', asset: 'ETH', to: DEST, amount: ETH(0.05) }), { txHash: r.store.get('wd-9103')!.txHash });
  } finally { await new Promise<void>((res) => server.close(() => res())); }
});

void hexToBig;
console.log(`\nall ${passed} signer checks passed`);
