import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { startDb, stopDb, resetData, createUser, fund, bal, uniq } from './helpers.ts';
import { AuditLog, LedgerTransaction, Order, Withdrawal } from '../src/db/models.ts';
import { withTxn } from '../src/db/txn.ts';
import { placeOrder } from '../src/services/orders.ts';
import { requestWithdraw } from '../src/services/wallet.ts';
import { runIdempotent } from '../src/services/idempotency.ts';
import { reconcile } from '../src/services/reconcile.ts';

beforeAll(startDb);
afterAll(stopDb);
beforeEach(resetData);

const base = (u: any, key: string, extra: any = {}) => ({
  userId: String(u._id), market: 'BTC_IDR', side: 'buy' as const, type: 'limit' as const, price: '1000000000', qty: '10000000', idempotencyKey: key, ...extra,
});

describe('idempotency', () => {
  it('placeOrder: same key twice => same order, funds locked once', async () => {
    const U = await createUser('u');
    await fund(U._id, 'IDR', '600000000');
    const a = await placeOrder(base(U, 'key-12345678'));
    const b = await placeOrder(base(U, 'key-12345678'));
    expect(b.id).toBe(a.id);
    expect(await Order.countDocuments({})).toBe(1);
    expect((await bal(U._id, 'IDR')).locked).toBe(100_200_000n);
    expect(await LedgerTransaction.countDocuments({ type: 'order_lock' })).toBe(1);
  });

  it('placeOrder: same key with a different request is refused', async () => {
    const U = await createUser('u');
    await fund(U._id, 'IDR', '600000000');
    await placeOrder(base(U, 'key-12345678'));
    await expect(placeOrder(base(U, 'key-12345678', { qty: '20000000' }))).rejects.toMatchObject({ code: 'IDEMPOTENCY_MISMATCH' });
    expect(await Order.countDocuments({})).toBe(1);
  });

  it('placeOrder: 10 concurrent submissions of the same key create ONE order', async () => {
    const U = await createUser('u');
    await fund(U._id, 'IDR', '600000000');
    const rs = await Promise.all(Array.from({ length: 10 }, () => placeOrder(base(U, 'same-key-1234'))));
    expect(new Set(rs.map((r) => r.id)).size).toBe(1);
    expect(await Order.countDocuments({})).toBe(1);
    expect((await bal(U._id, 'IDR')).locked).toBe(100_200_000n);
    expect(await reconcile()).toEqual([]);
  });

  it('clientOrderId cannot be reused under a new idempotency key', async () => {
    const U = await createUser('u');
    await fund(U._id, 'IDR', '600000000');
    await placeOrder(base(U, uniq(), { clientOrderId: 'mine-1' }));
    await expect(placeOrder(base(U, uniq(), { clientOrderId: 'mine-1' }))).rejects.toMatchObject({ code: 'CONFLICT' });
  });

  it('requestWithdraw: replay returns the same withdrawal; concurrent replays lock once', async () => {
    const U = await createUser('u');
    await fund(U._id, 'BTC', '1000000');
    const input = { userId: String(U._id), asset: 'BTC', address: 'bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq', amount: '100000', idempotencyKey: 'wd-key-12345' };
    const rs: any[] = await Promise.all(Array.from({ length: 8 }, () => requestWithdraw(input)));
    expect(new Set(rs.map((r) => r._id.toString())).size).toBe(1);
    expect(await Withdrawal.countDocuments({})).toBe(1);
    expect((await bal(U._id, 'BTC')).locked).toBe(110_000n);
    await expect(requestWithdraw({ ...input, amount: '200000' })).rejects.toMatchObject({ code: 'IDEMPOTENCY_MISMATCH' });
  });

  it('runIdempotent: work happens once, response is replayed, concurrent duplicates collapse', async () => {
    const run = (body: any) =>
      withTxn((s) =>
        runIdempotent(s, { scope: 'test', key: 'abcdefgh-1', body }, async () => {
          await AuditLog.create([{ action: 'side-effect' }], { session: s });
          return { ok: true, n: 1 };
        }),
      );
    const rs = await Promise.all(Array.from({ length: 6 }, () => run({ a: 1, b: 2 })));
    for (const r of rs) expect(r).toEqual({ ok: true, n: 1 });
    expect(await AuditLog.countDocuments({ action: 'side-effect' })).toBe(1);
    expect(await run({ b: 2, a: 1 })).toEqual({ ok: true, n: 1 }); // key order does not matter
    await expect(run({ a: 1, b: 3 })).rejects.toMatchObject({ code: 'IDEMPOTENCY_MISMATCH' });
    expect(await AuditLog.countDocuments({ action: 'side-effect' })).toBe(1);
  });
});
