// Dependency-free: node --experimental-strip-types tests/pure.pay.check.ts
import assert from 'node:assert/strict';
import { nameMatches, nameTokens } from '../src/payments/names.ts';
import { H_SIG, H_TS, signWebhook, signedHeaders, verifyWebhook } from '../src/payments/webhook.ts';
import { SimProvider, parsePaymentEvent } from '../src/payments/provider.ts';
import { SimChain } from '../src/chain/simChain.ts';
import { EvmRpcChain, TRANSFER_TOPIC, chunk, hexToBig, pad32, toHex, topicToAddress } from '../src/chain/evmRpc.ts';
import { validateAddress } from '../src/security/policy.ts';

let passed = 0;
const t = async (name: string, fn: () => void | Promise<void>) => { await fn(); passed++; console.log('ok -', name); };

// ------------------------------------------------------------------ name matching
await t('names: titles, order, truncation and case are tolerated', () => {
  assert.deepEqual(nameTokens('Bpk. Budi  Santoso, S.E.'), ['BPK', 'BUDI', 'SANTOSO', 'S', 'E']);
  for (const [a, b] of [['BUDI SANTOSO', 'Budi Santoso'], ['SANTOSO BUDI', 'Budi Santoso'], ['BPK BUDI SANTOSO', 'Budi Santoso'], ['Budi Santoso SE', 'Budi Santoso'], ['BUDI SANTOS', 'Budi Santoso'], ['BUDI SANTOSO WIJAYA', 'Budi Santoso'], ['Siti Nur Aisyah', 'SITI NURAISYAH'.replace('NURAISYAH', 'NUR AISYAH')], ['Éka Pūtri', 'EKA PUTRI']]) {
    assert.equal(nameMatches(a, b), true, `${a} ~ ${b}`);
  }
});
await t('names: strangers, companies, single words and too-short prefixes never match', () => {
  for (const [a, b] of [['ANDI SANTOSO', 'Budi Santoso'], ['BUDI', 'Budi Santoso'], ['BUDI S', 'Budi Santoso'], ['PT BUDI SANTOSO', 'Budi Santoso'], ['BUDI SANTOSO', 'CV Budi Santoso'], ['', 'Budi Santoso'], ['BPK', 'Budi Santoso'], ['BUDI SANTOSO', 'BAPAK'], ['BUDI WIJAYA', 'Budi Santoso'], ['12345', 'Budi Santoso']]) {
    assert.equal(nameMatches(a, b), false, `${a} !~ ${b}`);
  }
  assert.equal(nameMatches('BUDI', 'BUDI'), true); // identical single word is fine
  assert.equal(nameMatches('BUDI', 'BUDIMAN'), false);
});

// ------------------------------------------------------------------ webhook signing
await t('webhook: signature binds timestamp and exact body; replay window enforced', () => {
  const body = '{"type":"deposit.paid","amount":"100000"}';
  const now = 1_700_000_000_000;
  const h = signedHeaders('s3cret', body, now);
  assert.equal(verifyWebhook('s3cret', h, body, now), true);
  assert.equal(verifyWebhook('s3cret', h, body, now + 299_000), true);
  assert.equal(verifyWebhook('s3cret', h, body, now + 301_000), false); // too old
  assert.equal(verifyWebhook('s3cret', h, body, now - 301_000), false); // from the future
  assert.equal(verifyWebhook('s3cret', h, body + ' ', now), false); // one byte changed
  assert.equal(verifyWebhook('other', h, body, now), false);
  assert.equal(verifyWebhook('s3cret', { ...h, [H_TS]: String(now + 1) }, body, now), false); // timestamp is signed
  assert.equal(verifyWebhook('s3cret', { ...h, [H_SIG]: 'zz' }, body, now), false);
  assert.equal(verifyWebhook('s3cret', { [H_TS]: h[H_TS] }, body, now), false);
  assert.equal(signWebhook('k', 1, 'x'), signWebhook('k', '1', 'x'));
});
await t('payment events: strict shapes; junk is rejected', () => {
  const ok = { type: 'deposit.paid', providerRef: 'PAY-123456', vaNumber: '39123456789', amount: '250000', senderName: 'BUDI SANTOSO', paidAt: '2026-10-23T10:00:00Z' };
  assert.equal((parsePaymentEvent(JSON.stringify(ok)) as any).amount, '250000');
  for (const patch of [{ amount: '0' }, { amount: '-5' }, { amount: '1.5' }, { amount: 100 }, { vaNumber: 'abc' }, { providerRef: 'x' }, { senderName: '' }, { paidAt: 'yesterday' }, { type: 'deposit.refunded' }]) {
    assert.throws(() => parsePaymentEvent(JSON.stringify({ ...ok, ...patch })), (e: any) => e.code === 'VALIDATION', JSON.stringify(patch));
  }
  assert.throws(() => parsePaymentEvent('nope'));
  assert.deepEqual(parsePaymentEvent(JSON.stringify({ type: 'payout.failed', providerRef: 'SIMPO-1-ab', reference: 'WD-abc123', reason: 'invalid account' })), { type: 'payout.failed', providerRef: 'SIMPO-1-ab', reference: 'WD-abc123', reason: 'invalid account' });
});

// ------------------------------------------------------------------ sim provider
await t('sim provider: signed deliveries verify; duplicate delivery; payout is idempotent per reference', async () => {
  const delivered: Array<{ raw: string; headers: Record<string, string> }> = [];
  let clock = 1_700_000_000_000;
  const p = new SimProvider({ secret: 'sim-secret', now: () => clock, deliver: async (raw, headers) => { delivered.push({ raw, headers }); } });
  const va = await p.createVirtualAccount({ userId: 'u1', displayName: 'Budi', bank: 'BCA' });
  assert.match(va.vaNumber, /^39\d{10}$/);
  assert.match((await p.createVirtualAccount({ userId: 'u1', displayName: 'Budi', bank: 'MANDIRI' })).vaNumber, /^88\d{10}$/);

  const ref = await p.simulateTransfer({ vaNumber: va.vaNumber, amount: '250000', senderName: 'BUDI SANTOSO', duplicate: true });
  assert.equal(delivered.length, 2);
  assert.equal(delivered[0].raw, delivered[1].raw); // the same payment id twice
  for (const d of delivered) {
    assert.equal(p.verifyWebhook(d.headers, d.raw, clock), true);
    assert.equal((p.parseWebhook(d.raw) as any).providerRef, ref);
  }
  assert.equal(p.verifyWebhook(delivered[0].headers, delivered[0].raw + 'x', clock), false);
  clock += 10 * 60_000;
  assert.equal(p.verifyWebhook(delivered[0].headers, delivered[0].raw, clock), false); // replayed 10 minutes later

  const a = await p.createPayout({ reference: 'WD-1', amount: '100000', bank: 'BCA', accountNumber: '1234567890', accountName: 'BUDI SANTOSO' });
  const b = await p.createPayout({ reference: 'WD-1', amount: '100000', bank: 'BCA', accountNumber: '1234567890', accountName: 'BUDI SANTOSO' });
  assert.equal(a.gatewayRef, b.gatewayRef);
  assert.equal(p.payouts.size, 1);
  delivered.length = 0;
  await p.simulatePayoutResult('WD-1', 'failed', 'rekening tidak valid');
  assert.deepEqual(p.parseWebhook(delivered[0].raw), { type: 'payout.failed', providerRef: a.gatewayRef, reference: 'WD-1', reason: 'rekening tidak valid' });
  await assert.rejects(() => p.simulatePayoutResult('NOPE', 'completed'), (e: any) => e.code === 'NOT_FOUND');
});
await t('sim provider refuses to exist in production', () => {
  const prev = process.env.NODE_ENV;
  process.env.NODE_ENV = 'production';
  assert.throws(() => new SimProvider({ secret: 'x' }), (e: any) => e.code === 'CONFIG');
  process.env.NODE_ENV = prev;
});

// ------------------------------------------------------------------ sim chain
await t('sim chain: faucet -> mempool -> mined, confirmations grow, scan finds only watched addresses', async () => {
  const c = new SimChain('ETH');
  const a = c.newAddress(), other = c.newAddress();
  assert.match(a, /^0x[0-9a-f]{40}$/);
  assert.equal(validateAddress('ETH', a), true);
  const h = c.faucet(a, 'ETH', 5n);
  c.faucet(other, 'ETH', 7n);
  assert.deepEqual(await c.getTx(h), { blockHeight: null, blockHash: null, confirmations: 0 });
  assert.equal(await c.getTx('nope'), null);
  assert.equal(await c.custodyBalance('ETH'), 0n); // unconfirmed funds are not counted
  c.mine();
  assert.equal((await c.getTx(h))!.confirmations, 1);
  c.mine(4);
  assert.equal((await c.getTx(h))!.confirmations, 5);
  const found = await c.scanDeposits([a], 0, c.height);
  assert.deepEqual(found.map((x) => [x.asset, x.amount, x.txHash, x.blockHeight]), [['ETH', 5n, h, 1]]);
  assert.deepEqual(await c.scanDeposits([a], 2, c.height), []);
  assert.equal(await c.custodyBalance('ETH'), 12n);
  assert.equal(c.newAddress() !== c.newAddress(), true);
});
await t('sim chain: address formats are valid for BTC testnet and TRON; mainnet validators reject them', () => {
  const btc = new SimChain('BTC').newAddress(), tron = new SimChain('TRON').newAddress();
  assert.equal(validateAddress('BTC', btc, true), true);
  assert.equal(validateAddress('BTC', btc, false), false);
  assert.equal(validateAddress('TRON', tron), true);
  assert.equal(validateAddress('BTC', 'bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq', true), false); // a mainnet address is refused in testnet mode
});
await t('sim chain: reorg moves txs back to the mempool (or drops them) and changes block hashes', async () => {
  const c = new SimChain('BTC');
  const a = c.newAddress();
  const h = c.faucet(a, 'BTC', 100n);
  c.mine(3);
  const before = (await c.getTx(h))!;
  assert.equal(before.confirmations, 3);
  c.reorg(3);
  assert.deepEqual(await c.getTx(h), { blockHeight: null, blockHash: null, confirmations: 0 });
  assert.equal(await c.custodyBalance('BTC'), 0n);
  c.mine(2);
  const after = (await c.getTx(h))!;
  assert.equal(after.confirmations, 2);
  assert.notEqual(after.blockHash, before.blockHash);
  c.reorg(2, { dropTxs: true });
  assert.equal(await c.getTx(h), null); // gone for good
  assert.throws(() => c.reorg(99));
});
await t('sim chain: payouts are idempotent per reference, need funds, and reduce custody immediately', async () => {
  const c = new SimChain('ETH');
  const a = c.newAddress();
  await assert.rejects(() => c.broadcast({ reference: 'w1', asset: 'ETH', to: '0x' + 'ab'.repeat(20), amount: 1n }), (e: any) => e.code === 'CONFLICT');
  c.faucet(a, 'ETH', 100n); c.mine();
  const x = await c.broadcast({ reference: 'w1', asset: 'ETH', to: '0x' + 'ab'.repeat(20), amount: 60n });
  const y = await c.broadcast({ reference: 'w1', asset: 'ETH', to: '0x' + 'ab'.repeat(20), amount: 60n });
  assert.equal(x.txHash, y.txHash);
  assert.equal(await c.custodyBalance('ETH'), 40n);
  await assert.rejects(() => c.broadcast({ reference: 'w2', asset: 'ETH', to: '0x' + 'cd'.repeat(20), amount: 41n }));
  c.mine();
  assert.equal((await c.getTx(x.txHash))!.confirmations, 1);
});

// ------------------------------------------------------------------ EVM JSON-RPC adapter against a fake node
class FakeEvm {
  blocks: Array<{ hash: string; txs: Array<{ hash: string; to: string; value: string; from: string }>; logs: any[] }> = [{ hash: '0xg', txs: [], logs: [] }];
  pending = new Set<string>();
  failed = new Set<string>();
  calls: Array<{ method: string; params: any[] }> = [];
  balances: Record<string, bigint> = {};
  tokenBalances: Record<string, bigint> = {};
  salt = 0;
  mine(txs: FakeEvm['blocks'][0]['txs'] = [], logs: any[] = []) {
    const n = this.blocks.length;
    const hash = `0xb${n}s${this.salt}`;
    this.blocks.push({ hash, txs, logs: logs.map((l, i) => ({ ...l, blockNumber: toHex(n), blockHash: hash, logIndex: toHex(i), removed: l.removed ?? false })) });
    for (const tx of txs) this.pending.delete(tx.hash);
  }
  reorg(depth: number) { this.salt++; for (let i = 0; i < depth; i++) this.blocks.pop(); }
  fetch = async (_url: string, init: any) => {
    const { method, params, id } = JSON.parse(init.body);
    this.calls.push({ method, params });
    const result = this.handle(method, params);
    return { ok: true, status: 200, json: async () => ({ jsonrpc: '2.0', id, result }) };
  };
  handle(method: string, p: any[]): any {
    const tip = this.blocks.length - 1;
    switch (method) {
      case 'eth_blockNumber': return toHex(tip);
      case 'eth_getBlockByNumber': {
        const n = Number(hexToBig(p[0]));
        const b = this.blocks[n];
        if (!b) return null;
        return { hash: b.hash, transactions: p[1] ? b.txs : b.txs.map((t) => t.hash) };
      }
      case 'eth_getLogs': {
        const f = p[0], from = Number(hexToBig(f.fromBlock)), to = Number(hexToBig(f.toBlock));
        const wanted = new Set((f.topics[2] as string[]).map((x) => x.toLowerCase()));
        const out: any[] = [];
        for (let n = from; n <= to && n < this.blocks.length; n++) for (const l of this.blocks[n].logs) {
          if (l.address.toLowerCase() === f.address.toLowerCase() && l.topics[0] === f.topics[0] && wanted.has(l.topics[2].toLowerCase())) out.push(l);
        }
        return out;
      }
      case 'eth_getTransactionReceipt': {
        for (let n = 0; n < this.blocks.length; n++) {
          const b = this.blocks[n];
          if (b.txs.some((t) => t.hash === p[0]) || b.logs.some((l) => l.transactionHash === p[0])) return { blockNumber: toHex(n), blockHash: b.hash, status: this.failed.has(p[0]) ? '0x0' : '0x1' };
        }
        return null;
      }
      case 'eth_getTransactionByHash': return this.pending.has(p[0]) ? { hash: p[0] } : null;
      case 'eth_getBalance': return toHex(this.balances[p[0].toLowerCase()] ?? 0n);
      case 'eth_call': return toHex(this.tokenBalances[('0x' + p[0].data.slice(-40)).toLowerCase()] ?? 0n);
      default: throw new Error('unsupported ' + method);
    }
  }
}
const TOKEN = '0x' + 'aa'.repeat(20);
const mkLog = (to: string, amount: bigint, txHash: string) => ({ address: TOKEN, topics: [TRANSFER_TOPIC, pad32('0x' + '11'.repeat(20)), pad32(to)], data: toHex(amount), transactionHash: txHash });
const evm = (node: FakeEvm, extra: object = {}) => new EvmRpcChain({ chain: 'ETH', rpcUrl: 'http://rpc', fetch: node.fetch, nativeAsset: 'ETH', tokens: { USDT: TOKEN }, ...extra });

await t('evm: helpers (hex, padding, topics, chunking)', () => {
  assert.equal(hexToBig('0x'), 0n);
  assert.equal(hexToBig('0xde0b6b3a7640000'), 10n ** 18n);
  assert.equal(toHex(255n), '0xff');
  assert.equal(pad32('0xAbC'), '0x' + '0'.repeat(61) + 'abc');
  assert.equal(topicToAddress(pad32('0x' + 'AB'.repeat(20))), '0x' + 'ab'.repeat(20));
  assert.deepEqual(chunk([1, 2, 3, 4, 5], 2), [[1, 2], [3, 4], [5]]);
});
await t('evm: detects native ETH and ERC-20 deposits to OUR addresses only (case-insensitive), skips removed logs', async () => {
  const node = new FakeEvm();
  const mineAddr = '0x' + 'Ab'.repeat(20), other = '0x' + 'cd'.repeat(20);
  node.mine([{ hash: '0xt1', from: '0x1', to: mineAddr.toLowerCase(), value: toHex(10n ** 18n) }, { hash: '0xt2', from: '0x1', to: other, value: toHex(5n) }, { hash: '0xt3', from: '0x1', to: mineAddr, value: '0x0' }]);
  node.mine([], [mkLog(mineAddr, 25_000_000n, '0xt4'), mkLog(other, 1n, '0xt5'), { ...mkLog(mineAddr, 9n, '0xt6'), removed: true }]);
  const c = evm(node);
  assert.deepEqual(await c.getTip(), { height: 2, hash: '0xb2s0' });
  const found = await c.scanDeposits([mineAddr], 1, 2);
  assert.deepEqual(found.map((f) => [f.asset, f.amount, f.txHash, f.to, f.blockHeight]), [['ETH', 10n ** 18n, '0xt1', mineAddr.toLowerCase(), 1], ['USDT', 25_000_000n, '0xt4', mineAddr.toLowerCase(), 2]]);
  assert.equal(found[1].vout, 0); // log index
  assert.deepEqual(await c.scanDeposits([], 1, 2), []);
  assert.deepEqual(await c.scanDeposits([mineAddr], 3, 2), []);
});
await t('evm: getLogs queries are chunked to 50 recipient topics', async () => {
  const node = new FakeEvm();
  node.mine();
  const addrs = Array.from({ length: 120 }, (_, i) => '0x' + i.toString(16).padStart(40, '0'));
  await evm(node).scanDeposits(addrs, 1, 1);
  const logCalls = node.calls.filter((c) => c.method === 'eth_getLogs');
  assert.deepEqual(logCalls.map((c) => c.params[0].topics[2].length), [50, 50, 20]);
  assert.equal(logCalls[0].params[0].topics[1], null);
});
await t('evm: transaction status covers pending, mined, failed, unknown and reorged-out', async () => {
  const node = new FakeEvm();
  const c = evm(node);
  node.pending.add('0xp');
  assert.deepEqual(await c.getTx('0xp'), { blockHeight: null, blockHash: null, confirmations: 0 });
  assert.equal(await c.getTx('0xnone'), null);
  node.mine([{ hash: '0xm', from: '0x1', to: '0x2', value: '0x1' }]);
  node.mine(); node.mine();
  assert.deepEqual(await c.getTx('0xm'), { blockHeight: 1, blockHash: '0xb1s0', confirmations: 3, failed: false });
  node.failed.add('0xm');
  assert.equal((await c.getTx('0xm'))!.failed, true);
  node.reorg(3);
  assert.equal(await c.getTx('0xm'), null); // the chain forgot it
});
await t('evm: payouts need a signer (no keys in this adapter); custody balance sums native and token balances; rpc errors surface', async () => {
  const node = new FakeEvm();
  const a = '0x' + '01'.repeat(20), b = '0x' + '02'.repeat(20);
  node.balances[a] = 3n; node.balances[b] = 4n; node.tokenBalances[a] = 100n; node.tokenBalances[b] = 50n;
  const c = evm(node, { custodyAddresses: async () => [a, b] });
  assert.equal(await c.custodyBalance('ETH'), 7n);
  assert.equal(await c.custodyBalance('USDT'), 150n);
  await assert.rejects(() => c.broadcast({ reference: 'r', asset: 'ETH', to: a, amount: 1n }), (e: any) => e.code === 'NOT_CONFIGURED');
  const calls: any[] = [];
  const s = evm(node, { signer: { sendTransfer: async (p: any) => { calls.push(p); return '0xsigned'; } } });
  assert.deepEqual(await s.broadcast({ reference: 'r', asset: 'USDT', to: a, amount: 5n }), { txHash: '0xsigned' });
  assert.deepEqual(calls, [{ asset: 'USDT', to: a, amount: 5n, reference: 'r' }]);
  const broken = new EvmRpcChain({ chain: 'ETH', rpcUrl: 'x', nativeAsset: 'ETH', tokens: {}, fetch: async () => ({ ok: true, status: 200, json: async () => ({ error: { message: 'rate limited' } }) }) });
  await assert.rejects(() => broken.getTip(), (e: any) => e.code === 'CHAIN_RPC');
  const down = new EvmRpcChain({ chain: 'ETH', rpcUrl: 'x', nativeAsset: 'ETH', tokens: {}, fetch: async () => ({ ok: false, status: 503, json: async () => ({}) }) });
  await assert.rejects(() => down.getTip(), (e: any) => e.code === 'CHAIN_RPC');
});

console.log(`\nall ${passed} payment/chain checks passed`);
