// Dependency-free: node --experimental-strip-types tests/pure.ws.check.ts
import assert from 'node:assert/strict';
import { BookSync, applyDelta, diffBook, emptyBook, isEmptyDelta } from '../shared/bookDelta.ts';
import type { BookView, Level } from '../shared/bookDelta.ts';
import { Hub } from '../src/marketdata/hub.ts';
import { Connection } from '../src/ws/connection.ts';
import type { ConnDeps } from '../src/ws/connection.ts';
import { parseClientMessage } from '../src/ws/protocol.ts';
import { TokenBucket } from '../src/security/ratelimit.ts';
import { AppError, InsufficientFunds, InvariantViolation } from '../src/errors.ts';

let passed = 0;
const t = async (name: string, fn: () => void | Promise<void>) => { await fn(); passed++; console.log('ok -', name); };
const L = (...xs: Array<[number, number]>): Level[] => xs.map(([p, q]) => [String(p), String(q)]);

// ------------------------------------------------------------------ book delta
await t('diff/apply: add, change, remove on both sides; empty diff for identical books', () => {
  const prev: BookView = { bids: L([100, 5], [99, 2]), asks: L([101, 3], [102, 1]) };
  const next: BookView = { bids: L([100, 7], [98, 4]), asks: L([102, 1]) };
  const d = diffBook(prev, next);
  assert.deepEqual(d.bids, [['100', '7'], ['98', '4'], ['99', '0']]);
  assert.deepEqual(d.asks, [['101', '0']]);
  assert.deepEqual(applyDelta(prev, d, 50), next);
  assert.equal(isEmptyDelta(diffBook(next, next)), true);
  assert.deepEqual(applyDelta(emptyBook(), diffBook(emptyBook(), prev), 50), prev);
});
await t('property: for random book sequences, applying every delta reproduces the next top-N exactly', () => {
  let s = 12345;
  const rnd = (n: number) => { s = (s * 1103515245 + 12345) & 0x7fffffff; return s % n; };
  const randomSide = (desc: boolean, depth: number): Level[] => {
    const prices = new Set<number>();
    const n = rnd(depth + 1);
    while (prices.size < n) prices.add(1000 + rnd(60));
    const arr = [...prices].sort((a, b) => (desc ? b - a : a - b));
    return arr.map((p) => [String(p), String(1 + rnd(9))] as Level);
  };
  const depth = 10;
  let client: BookView = emptyBook();
  let prev: BookView = emptyBook();
  for (let i = 0; i < 400; i++) {
    const next: BookView = { bids: randomSide(true, depth), asks: randomSide(false, depth) };
    const d = diffBook(prev, next);
    client = applyDelta(client, d, depth);
    assert.deepEqual(client, next, `step ${i}`);
    prev = next;
  }
});
await t('BookSync: snapshot, in-order deltas, stale ignored, gap and pre-snapshot deltas demand a resync', () => {
  const b = new BookSync(5);
  assert.equal(b.update({ bids: L([1, 1]), asks: [] }, 1), 'gap'); // delta before snapshot
  b.snapshot({ bids: L([100, 5]), asks: L([101, 5]) }, 10);
  assert.equal(b.update({ bids: L([100, 6]), asks: [] }, 11), 'ok');
  assert.equal(b.update({ bids: L([100, 99]), asks: [] }, 11), 'stale');
  assert.equal(b.update({ bids: L([100, 99]), asks: [] }, 10), 'stale');
  assert.deepEqual(b.view.bids, L([100, 6])); // stale updates changed nothing
  assert.equal(b.update({ bids: L([99, 1]), asks: [] }, 13), 'gap'); // 12 was lost
  assert.equal(b.seq, 11);
  b.snapshot({ bids: L([100, 6], [99, 1]), asks: L([101, 5]) }, 13); // resync
  assert.equal(b.update({ bids: [], asks: [['101', '0']] }, 14), 'ok');
  assert.deepEqual(b.view.asks, []);
});

// ------------------------------------------------------------------ protocol additions
await t('protocol: api-key auth and order messages are strictly validated', () => {
  const sig = 'a'.repeat(64);
  assert.deepEqual(parseClientMessage(JSON.stringify({ op: 'auth', apiKey: 'ak_abcdefghijkl', timestamp: '1700000000000', signature: sig })), { op: 'auth', apiKey: 'ak_abcdefghijkl', timestamp: '1700000000000', signature: sig });
  for (const bad of [{ apiKey: 'nope', timestamp: '1700000000000', signature: sig }, { apiKey: 'ak_abcdefghijkl', timestamp: 'x', signature: sig }, { apiKey: 'ak_abcdefghijkl', timestamp: '1700000000000', signature: 'zz' }]) {
    assert.throws(() => parseClientMessage(JSON.stringify({ op: 'auth', ...bad })));
  }
  const ok = { op: 'order.place', id: 'c-1', market: 'BTC_IDR', side: 'buy', type: 'limit', price: '1000000000', qty: '10000000', idempotencyKey: 'idem-key-0001' };
  assert.equal((parseClientMessage(JSON.stringify(ok)) as any).idempotencyKey, 'idem-key-0001');
  for (const patch of [{ side: 'hold' }, { type: 'stop' }, { qty: '1.5' }, { qty: '-1' }, { price: '1e9' }, { market: 'btc_idr' }, { idempotencyKey: 'short' }, { id: 'has space' }, { tif: 'FOK' }]) {
    assert.throws(() => parseClientMessage(JSON.stringify({ ...ok, ...patch })), (e: any) => e.code === 'BAD_MESSAGE', JSON.stringify(patch));
  }
  assert.throws(() => parseClientMessage(JSON.stringify({ ...ok, idempotencyKey: undefined })));
  assert.deepEqual(parseClientMessage(JSON.stringify({ op: 'order.cancel', id: 'c-2', orderId: 'a'.repeat(24) })), { op: 'order.cancel', id: 'c-2', orderId: 'a'.repeat(24) });
  assert.throws(() => parseClientMessage(JSON.stringify({ op: 'order.cancel', id: 'c-2', orderId: 'xyz' })));
});

// ------------------------------------------------------------------ bot connection
function rig(over: Partial<ConnDeps> = {}, perms = ['read', 'trade']) {
  const sent: any[] = [];
  const hub = new Hub();
  const calls: any[] = [];
  let closed: [number, string] | null = null;
  let valid = true;
  let now = 1_000_000;
  const deps: ConnDeps = {
    hub,
    authenticate: async () => ({ userId: 'u-session', expiresAt: now + 60_000 }),
    authenticateKey: async (p) => {
      if (p.signature !== 'a'.repeat(64)) throw new Error('bad sig');
      return { userId: 'u-bot', permissions: perms, revalidate: async () => valid };
    },
    placeOrder: async (uid, m) => { calls.push(['place', uid, m.id, m.idempotencyKey]); if (m.qty === '999') throw new InsufficientFunds('insufficient available IDR'); if (m.qty === '666') throw new InvariantViolation('internal ledger detail u:abc'); if (m.qty === '555') throw new Error('mongo ECONNREFUSED 10.0.0.5'); return { id: 'o1', status: 'new' }; },
    cancelOrder: async (uid, oid) => { calls.push(['cancel', uid, oid]); return { status: 'cancel_requested' }; },
    snapshot: async () => ({ data: [], seq: 0 }),
    send: (o) => sent.push(o),
    close: (c, r) => { closed = [c, r]; },
    now: () => now,
    limiter: new TokenBucket(1000, 1000),
    tradeLimiter: new TokenBucket(1000, 1000),
    ...over,
  };
  return { conn: new Connection(deps), sent, hub, calls, closed: () => closed, setValid: (v: boolean) => { valid = v; }, advance: (ms: number) => { now += ms; } };
}
const AUTH = JSON.stringify({ op: 'auth', apiKey: 'ak_abcdefghijkl', timestamp: '1700000000000', signature: 'a'.repeat(64) });
const PLACE = (extra: object = {}) => JSON.stringify({ op: 'order.place', id: 'c1', market: 'BTC_IDR', side: 'buy', type: 'limit', price: '1000000000', qty: '10000000', idempotencyKey: 'idem-key-0001', ...extra });

await t('bot: signed auth, private streams, order entry returns ack/error for the SAME client id', async () => {
  const r = rig();
  await r.conn.handleRaw(PLACE());
  assert.deepEqual([r.sent.at(-1).type, r.sent.at(-1).code], ['order.error', 'FORBIDDEN']); // not authenticated
  await r.conn.handleRaw(JSON.stringify({ op: 'auth', apiKey: 'ak_abcdefghijkl', timestamp: '1700000000000', signature: 'b'.repeat(64) }));
  assert.equal(r.sent.at(-1).code, 'AUTH_FAILED');
  await r.conn.handleRaw(AUTH);
  assert.deepEqual(r.sent.at(-1), { type: 'authed', kind: 'apikey', permissions: ['read', 'trade'] });
  await r.conn.handleRaw('{"op":"subscribe","channel":"orders"}');
  assert.equal(r.hub.hasSubscribers('orders:u-bot'), true);
  await r.conn.handleRaw(PLACE());
  assert.deepEqual(r.sent.at(-1), { type: 'order.ack', id: 'c1', order: { id: 'o1', status: 'new' } });
  await r.conn.handleRaw(JSON.stringify({ op: 'order.cancel', id: 'c2', orderId: 'a'.repeat(24) }));
  assert.deepEqual(r.sent.at(-1), { type: 'order.ack', id: 'c2', order: { status: 'cancel_requested' } });
  assert.deepEqual(r.calls, [['place', 'u-bot', 'c1', 'idem-key-0001'], ['cancel', 'u-bot', 'a'.repeat(24)]]); // always the authenticated user, never a client-supplied one
  await r.conn.handleRaw(PLACE({ id: 'c3', qty: '999' }));
  assert.deepEqual(r.sent.at(-1), { type: 'order.error', id: 'c3', code: 'INSUFFICIENT_FUNDS', message: 'insufficient available IDR' });
});
await t('bot: internal errors never leak; permissions and auth kind are enforced', async () => {
  const r = rig();
  await r.conn.handleRaw(AUTH);
  await r.conn.handleRaw(PLACE({ id: 'c4', qty: '666' }));
  assert.deepEqual(r.sent.at(-1), { type: 'order.error', id: 'c4', code: 'INTERNAL', message: 'internal error' });
  await r.conn.handleRaw(PLACE({ id: 'c5', qty: '555' }));
  assert.equal(r.sent.at(-1).message, 'internal error');
  assert.ok(!JSON.stringify(r.sent).includes('ECONNREFUSED') && !JSON.stringify(r.sent).includes('u:abc'));

  const ro = rig({}, ['read']);
  await ro.conn.handleRaw(AUTH);
  await ro.conn.handleRaw(PLACE());
  assert.equal(ro.sent.at(-1).code, 'FORBIDDEN');
  assert.equal(ro.calls.length, 0);
  await ro.conn.handleRaw('{"op":"subscribe","channel":"balances"}'); // read is enough for private streams
  assert.equal(ro.hub.hasSubscribers('balances:u-bot'), true);

  const noRead = rig({}, []);
  await noRead.conn.handleRaw(AUTH);
  await noRead.conn.handleRaw('{"op":"subscribe","channel":"orders"}');
  assert.equal(noRead.sent.at(-1).code, 'FORBIDDEN');

  const browser = rig();
  await browser.conn.handleRaw('{"op":"auth","token":"session-token-123"}'); // browser sessions cannot trade over WS
  await browser.conn.handleRaw(PLACE());
  assert.deepEqual([browser.sent.at(-1).type, browser.sent.at(-1).code], ['order.error', 'FORBIDDEN']);
  assert.equal(browser.calls.length, 0);

  const off = rig({ placeOrder: undefined, cancelOrder: undefined });
  await off.conn.handleRaw(AUTH);
  await off.conn.handleRaw(PLACE());
  assert.equal(off.sent.at(-1).code, 'NOT_SUPPORTED');
});
await t('bot: order rate limit answers per id; bot connections do not expire but a revoked key is kicked on heartbeat', async () => {
  const r = rig({ tradeLimiter: new TokenBucket(2, 0.001) });
  await r.conn.handleRaw(AUTH);
  for (const id of ['a1', 'a2', 'a3']) await r.conn.handleRaw(PLACE({ id }));
  assert.deepEqual(r.sent.slice(-3).map((m) => [m.id, m.type, m.code ?? null]), [['a1', 'order.ack', null], ['a2', 'order.ack', null], ['a3', 'order.error', 'RATE_LIMITED']]);

  const k = rig();
  await k.conn.handleRaw(AUTH);
  await k.conn.handleRaw('{"op":"subscribe","channel":"orders"}');
  k.advance(3 * 3600_000);
  await k.conn.heartbeat();
  assert.equal(k.closed(), null); // no token expiry for bots
  assert.equal(k.hub.hasSubscribers('orders:u-bot'), true);
  k.setValid(false);
  await k.conn.heartbeat();
  assert.deepEqual(k.closed(), [1008, 'api key revoked']);
  assert.equal(k.sent.at(-1).code, 'KEY_REVOKED');
  assert.equal(k.hub.hasSubscribers('orders:u-bot'), false);

  const flaky = rig();
  await flaky.conn.handleRaw(AUTH);
  (flaky.conn as any).revalidate = async () => { throw new Error('db blip'); };
  await flaky.conn.heartbeat();
  assert.equal(flaky.closed(), null); // a DB outage must not disconnect every bot
});
await t('book channel snapshots carry seq: queued deltas older than the snapshot are dropped, newer ones applied in order', async () => {
  let release!: (v: any) => void;
  const r = rig({ snapshot: () => new Promise((res) => { release = res; }) });
  const p = r.conn.handleRaw('{"op":"subscribe","channel":"book:BTC_IDR"}');
  await new Promise((res) => setImmediate(res));
  r.hub.publish('book:BTC_IDR', { seq: 8, data: { bids: [['1', '0']], asks: [] } });
  r.hub.publish('book:BTC_IDR', { seq: 9, data: { bids: [['2', '5']], asks: [] } });
  r.hub.publish('book:BTC_IDR', { seq: 10, data: { bids: [['3', '5']], asks: [] } });
  release({ data: { bids: [['2', '5']], asks: [] }, seq: 9 });
  await p;
  assert.deepEqual(r.sent.map((m) => [m.type, m.seq ?? null]), [['subscribed', null], ['snapshot', 9], ['update', 10]]);
  const client = new BookSync();
  for (const m of r.sent) {
    if (m.type === 'snapshot') client.snapshot(m.data, m.seq);
    if (m.type === 'update') assert.equal(client.update(m.data, m.seq), 'ok');
  }
  assert.deepEqual(client.view, { bids: [['3', '5'], ['2', '5']], asks: [] });
});

void AppError;
console.log(`\nall ${passed} ws/delta checks passed`);
