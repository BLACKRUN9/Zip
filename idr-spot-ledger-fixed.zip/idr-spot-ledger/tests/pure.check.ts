// Dependency-free checks (no MongoDB, no npm install needed):
//   node --experimental-strip-types tests/pure.check.ts
import assert from 'node:assert/strict';
import { feeCeil, feeFloor, parseAmount, quoteAmount } from '../src/money.ts';
import { OrderBook, outputToEvent, replayLog } from '../src/engine/orderbook.ts';
import type { BookOutput, LogEvent, OrderInput } from '../src/engine/orderbook.ts';

let passed = 0;
const t = (name: string, fn: () => void) => { fn(); passed++; console.log('ok -', name); };

// ---------- money ----------
t('parseAmount rejects floats, negatives, leading zeros, non-strings', () => {
  for (const bad of ['1.5', '-1', '01', '', ' 1', '1e3', 5 as any, null as any]) assert.throws(() => parseAmount(bad));
  assert.equal(parseAmount('0'), 0n);
  assert.equal(parseAmount('123456789012345678901234567890'), 123456789012345678901234567890n);
});
t('quoteAmount floors; BTC example', () => {
  assert.equal(quoteAmount(1_000_000_000n, 50_000_000n, 8), 500_000_000n);
  assert.equal(quoteAmount(3n, 1n, 1), 0n); // floor
  assert.equal(quoteAmount(1_000_000_001n, 1n, 8), 10n);
});
t('fees: floor vs ceil', () => {
  assert.equal(feeFloor(500_000_000n, 20), 1_000_000n);
  assert.equal(feeFloor(999n, 10), 0n);
  assert.equal(feeCeil(999n, 10), 1n);
  assert.equal(feeCeil(0n, 10), 0n);
});

// ---------- order book ----------
const o = (id: string, user: string, side: 'buy' | 'sell', price: bigint, qty: bigint, type: 'limit' | 'market' = 'limit', tif: 'GTC' | 'IOC' = 'GTC'): OrderInput =>
  ({ id, userId: user, side, type, tif, price, qty });

t('price-time priority and maker price execution', () => {
  const b = new OrderBook();
  b.accept(o('a1', 'A', 'sell', 100n, 5n), 1);
  b.accept(o('a2', 'B', 'sell', 100n, 5n), 2); // same price, later
  b.accept(o('a3', 'C', 'sell', 99n, 2n), 3); // better price
  const out = b.accept(o('b1', 'D', 'buy', 100n, 9n), 4);
  const trades = out.filter((x) => x.type === 'trade') as Extract<BookOutput, { type: 'trade' }>[];
  assert.deepEqual(trades.map((x) => [x.makerOrderId, x.price, x.qty]), [['a3', 99n, 2n], ['a1', 100n, 5n], ['a2', 100n, 2n]]);
  assert.equal(b.asks.length, 1);
  assert.equal(b.asks[0].qty, 3n);
});
t('limit remainder rests; IOC remainder cancels; market sell works with price 0', () => {
  const b = new OrderBook();
  b.accept(o('s1', 'A', 'sell', 100n, 3n), 1);
  let out = b.accept(o('b1', 'B', 'buy', 100n, 5n), 2);
  assert.equal(b.bids[0].qty, 2n);
  assert.equal(out.length, 1);
  out = b.accept(o('s2', 'C', 'sell', 0n, 10n, 'market', 'IOC'), 3);
  assert.deepEqual(out.map((x) => x.type), ['trade', 'canceled']);
  assert.equal(b.bids.length, 0);
});
t('self-trade prevention cancels the incoming remainder, resting order untouched', () => {
  const b = new OrderBook();
  b.accept(o('s1', 'A', 'sell', 100n, 3n), 1);
  const out = b.accept(o('b1', 'A', 'buy', 100n, 3n), 2);
  assert.deepEqual(out, [{ type: 'canceled', orderId: 'b1', reason: 'self_trade' }]);
  assert.equal(b.asks[0].qty, 3n);
  assert.equal(b.bids.length, 0);
});
t('duplicate accept is a no-op (idempotent submit)', () => {
  const b = new OrderBook();
  b.accept(o('s1', 'A', 'sell', 100n, 3n), 1);
  assert.deepEqual(b.accept(o('s1', 'A', 'sell', 100n, 3n), 2), []);
  assert.equal(b.asks.length, 1);
});
t('cancel resting vs unknown', () => {
  const b = new OrderBook();
  b.accept(o('s1', 'A', 'sell', 100n, 3n), 1);
  assert.deepEqual(b.cancel('nope'), []);
  assert.deepEqual(b.cancel('s1'), [{ type: 'canceled', orderId: 's1', reason: 'user' }]);
  assert.equal(b.asks.length, 0);
});

// ---------- randomized: invariants + deterministic replay ----------
function mulberry32(a: number) {
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let x = Math.imul(a ^ (a >>> 15), 1 | a);
    x = (x + Math.imul(x ^ (x >>> 7), 61 | x)) ^ x;
    return ((x ^ (x >>> 14)) >>> 0) / 4294967296;
  };
}

for (const seed of [1, 7, 42, 1337, 99999]) {
  t(`random commands seed=${seed}: uncrossed book, maker-price fills, replay == live`, () => {
    const rnd = mulberry32(seed);
    const pick = (n: number) => Math.floor(rnd() * n);
    const live = new OrderBook();
    const log: LogEvent[] = [];
    let seq = 0;
    const ids: string[] = [];
    let totalTradedBuy = 0n, totalTradedSell = 0n;
    for (let i = 0; i < 600; i++) {
      if (rnd() < 0.2 && ids.length > 0) {
        const id = ids[pick(ids.length)];
        if (!live.isResting(id)) continue;
        const outs = live.cancel(id);
        log.push({ seq: ++seq, type: 'cancel_requested', payload: { orderId: id } });
        for (const x of outs) log.push({ seq: ++seq, ...outputToEvent(x) });
        continue;
      }
      const side = rnd() < 0.5 ? 'buy' : 'sell';
      const type = rnd() < 0.2 ? 'market' : 'limit';
      const tif = type === 'market' || rnd() < 0.25 ? 'IOC' : 'GTC';
      const price = type === 'market' ? (side === 'buy' ? 110n : 0n) : BigInt(90 + pick(21));
      const ord = o(`o${i}`, `u${pick(5)}`, side, price, BigInt(1 + pick(20)), type, tif);
      ids.push(ord.id);
      const restingBefore = new Map([...live.bids, ...live.asks].map((r) => [r.id, r.price]));
      const accSeq = ++seq;
      const outs = live.accept(ord, accSeq);
      log.push({ seq: accSeq, type: 'order_accepted', payload: { ...ord, price: ord.price.toString(), qty: ord.qty.toString() } });
      for (const x of outs) {
        log.push({ seq: ++seq, ...outputToEvent(x) });
        if (x.type === 'trade') {
          assert.equal(x.price, restingBefore.get(x.makerOrderId)); // executes at maker price
          assert.notEqual(x.makerUserId, x.takerUserId); // no self-trades
          totalTradedBuy += x.qty; totalTradedSell += x.qty;
        }
      }
      if (live.bids.length && live.asks.length) assert.ok(live.bids[0].price < live.asks[0].price, 'book crossed');
      for (const r of [...live.bids, ...live.asks]) assert.ok(r.qty > 0n);
    }
    assert.equal(totalTradedBuy, totalTradedSell);
    // simulate crash: log round-trips through JSON (as it would through the database)
    const restored = JSON.parse(JSON.stringify(log)) as LogEvent[];
    const { book, mismatches, lastSeq } = replayLog(restored);
    assert.deepEqual(mismatches, []);
    assert.equal(lastSeq, seq);
    assert.deepEqual(book.snapshot(), live.snapshot());
  });
}

t('replay detects a tampered log', () => {
  const b = new OrderBook();
  const log: LogEvent[] = [];
  log.push({ seq: 1, type: 'order_accepted', payload: { id: 's1', userId: 'A', side: 'sell', type: 'limit', tif: 'GTC', price: '100', qty: '5' } });
  log.push({ seq: 2, type: 'order_accepted', payload: { id: 'b1', userId: 'B', side: 'buy', type: 'limit', tif: 'GTC', price: '100', qty: '5' } });
  log.push({ seq: 3, type: 'trade', payload: { makerOrderId: 's1', takerOrderId: 'b1', makerUserId: 'A', takerUserId: 'B', price: '100', qty: '4' } }); // wrong qty
  assert.equal(replayLog(log).mismatches.length, 1);
  void b;
});

console.log(`\nall ${passed} pure checks passed`);
