import mongoose from 'mongoose';
import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { startDb, stopDb, resetData, createUser, fund, bal, sysBal, uniq } from './helpers.ts';
import { Account, Deposit, FiatTransaction, LedgerEntry, LedgerTransaction, User, Withdrawal } from '../src/db/models.ts';
import { withTxn } from '../src/db/txn.ts';
import { getAccount, post } from '../src/services/ledger.ts';
import { reconcile } from '../src/services/reconcile.ts';
import {
  approveWithdraw, completeWithdrawal, creditDeposit, creditFiatDeposit, registerDeposit,
  rejectWithdrawal, requestWithdraw, reverseDeposit,
} from '../src/services/wallet.ts';

beforeAll(startDb);
afterAll(stopDb);
beforeEach(resetData);

describe('deposits', () => {
  it('credits once, keeps the books balanced, and is idempotent', async () => {
    const u = await createUser('a');
    await fund(u._id, 'BTC', '1000000');
    expect(await bal(u._id, 'BTC')).toEqual({ available: 1_000_000n, locked: 0n });
    expect((await sysBal('hot_wallet', 'BTC')).available).toBe(1_000_000n);

    const dep: any = await Deposit.findOne({});
    const again = await creditDeposit(dep._id.toString());
    expect(again.credited).toBe(false);
    expect(await bal(u._id, 'BTC')).toEqual({ available: 1_000_000n, locked: 0n });
    expect(await LedgerTransaction.countDocuments({ type: 'deposit' })).toBe(1);
    expect(await reconcile()).toEqual([]);
  });

  it('the same chain tx registered twice is ONE deposit; confirmations only go up', async () => {
    const u = await createUser('a');
    const ev = { userId: String(u._id), asset: 'BTC', chain: 'BTC', address: 'x', txHash: 'h1', amount: '50000', confirmations: 1 };
    await registerDeposit(ev);
    await registerDeposit({ ...ev, confirmations: 5 });
    await registerDeposit({ ...ev, confirmations: 2 });
    expect(await Deposit.countDocuments({})).toBe(1);
    expect(((await Deposit.findOne({}).lean()) as any).confirmations).toBe(5);
  });

  it('refuses to credit before enough confirmations', async () => {
    const u = await createUser('a');
    const d: any = await registerDeposit({ userId: String(u._id), asset: 'BTC', chain: 'BTC', address: 'x', txHash: 'h2', amount: '50000', confirmations: 1 });
    await expect(creditDeposit(d._id.toString())).rejects.toMatchObject({ code: 'CONFLICT' });
    expect((await bal(u._id, 'BTC')).available).toBe(0n);
  });

  it('below-minimum deposits are rejected, not credited', async () => {
    const u = await createUser('a');
    const d: any = await registerDeposit({ userId: String(u._id), asset: 'BTC', chain: 'BTC', address: 'x', txHash: 'h3', amount: '5', confirmations: 9 });
    expect((await creditDeposit(d._id.toString())).status).toBe('rejected');
    expect((await bal(u._id, 'BTC')).available).toBe(0n);
  });

  it('fiat deposit with a name mismatch goes to manual review; an admin can credit it', async () => {
    const u = await createUser('a');
    const admin = await createUser('boss', { role: 'admin' });
    await FiatTransaction.create({ userId: u._id, type: 'deposit', method: 'VA', providerRef: 'P1', amount: '100000', nameMatch: false });
    expect((await creditFiatDeposit('P1')).status).toBe('manual_review');
    expect((await bal(u._id, 'IDR')).available).toBe(0n);
    await expect(creditFiatDeposit('P1', { adminId: String(u._id) })).rejects.toMatchObject({ code: 'FORBIDDEN' });
    expect((await creditFiatDeposit('P1', { adminId: String(admin._id) })).credited).toBe(true);
    expect((await bal(u._id, 'IDR')).available).toBe(100_000n);
    expect(await reconcile()).toEqual([]);
  });

  it('reorg: reversal takes back what is left; the spent part goes to suspense and the user is frozen', async () => {
    const u = await createUser('a');
    const depId = (await fund(u._id, 'BTC', '1000000'))!;
    await requestWithdraw({ userId: String(u._id), asset: 'BTC', address: 'bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq', amount: '700000', idempotencyKey: uniq() }); // locks 710000
    const r = await reverseDeposit(depId, 'reorg');
    expect(r.shortfall).toBe(710_000n);
    expect(await bal(u._id, 'BTC')).toEqual({ available: 0n, locked: 710_000n });
    expect((await sysBal('suspense', 'BTC')).available).toBe(710_000n);
    expect(((await User.findById(u._id).lean()) as any).status).toBe('frozen');
    expect(await reconcile()).toEqual([]);
  });
});

describe('ledger invariants', () => {
  it('rejects an unbalanced transaction', async () => {
    const u = await createUser('a');
    await fund(u._id, 'IDR', '100000');
    await expect(
      withTxn(async (s) => {
        const user = await getAccount(s, { userId: String(u._id) }, 'IDR');
        const hot = await getAccount(s, { system: 'hot_wallet' }, 'IDR');
        return post(s, { idempotencyKey: uniq(), type: 'adjustment', legs: [
          { accountId: user._id, bucket: 'available', direction: 'credit', amount: 100n },
          { accountId: hot._id, bucket: 'available', direction: 'debit', amount: 90n },
        ] });
      }),
    ).rejects.toMatchObject({ code: 'INVARIANT' });
    expect((await bal(u._id, 'IDR')).available).toBe(100_000n);
  });

  it('never lets a balance go negative, and a failed request leaves no trace', async () => {
    const u = await createUser('a');
    await fund(u._id, 'BTC', '100000');
    await expect(
      requestWithdraw({ userId: String(u._id), asset: 'BTC', address: 'bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq', amount: '95000', idempotencyKey: uniq() }), // + fee 10000 > 100000
    ).rejects.toMatchObject({ code: 'INSUFFICIENT_FUNDS' });
    expect(await Withdrawal.countDocuments({})).toBe(0); // the Withdrawal row rolled back with the failed lock
    expect(await bal(u._id, 'BTC')).toEqual({ available: 100_000n, locked: 0n });
  });

  it('ledger collections are append-only (app guard)', async () => {
    const u = await createUser('a');
    await fund(u._id, 'IDR', '100000');
    await expect(LedgerEntry.updateOne({}, { $set: { amount: '1' } }).exec()).rejects.toMatchObject({ code: 'APPEND_ONLY' });
    await expect(LedgerEntry.deleteMany({}).exec()).rejects.toMatchObject({ code: 'APPEND_ONLY' });
    await expect(LedgerTransaction.deleteOne({}).exec()).rejects.toMatchObject({ code: 'APPEND_ONLY' });
  });

  it('MongoDB itself rejects non-integer / negative amount strings (validator)', async () => {
    const u = await createUser('a');
    const coll = mongoose.connection.db!.collection('accounts');
    for (const bad of ['1.5', '-5', '01', '1e3', ' 7']) {
      await expect(coll.updateOne({ owner: `u:${u._id}`, asset: 'IDR' }, { $set: { available: bad } })).rejects.toThrow();
    }
    await expect(coll.updateOne({ owner: `u:${u._id}`, asset: 'IDR' }, { $set: { available: 5 as any } })).rejects.toThrow(); // a Number is not allowed
  });

  it('reconcile detects tampering with a balance', async () => {
    const u = await createUser('a');
    await fund(u._id, 'IDR', '100000');
    await mongoose.connection.db!.collection('accounts').updateOne({ owner: `u:${u._id}`, asset: 'IDR' }, { $set: { available: '999999' } });
    const d = await reconcile();
    const kinds = d.map((x) => x.kind);
    expect(kinds).toContain('account_balance_mismatch');
    expect(kinds).toContain('accounting_equation');
  });
});

describe('withdrawals', () => {
  it('request -> approve (four-eyes) -> complete moves funds, fee goes to revenue', async () => {
    const u = await createUser('a');
    const admin = await createUser('boss', { role: 'admin' });
    await fund(u._id, 'BTC', '1000000');
    const w: any = await requestWithdraw({ userId: String(u._id), asset: 'BTC', address: 'bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq', amount: '500000', idempotencyKey: uniq() });
    expect(await bal(u._id, 'BTC')).toEqual({ available: 490_000n, locked: 510_000n });

    await expect(approveWithdraw(w._id.toString(), String(u._id))).rejects.toMatchObject({ code: 'FORBIDDEN' }); // not an admin
    const selfAdmin = await createUser('selfadmin', { role: 'admin' });
    await fund(selfAdmin._id, 'BTC', '1000000');
    const w2: any = await requestWithdraw({ userId: String(selfAdmin._id), asset: 'BTC', address: 'bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq', amount: '100000', idempotencyKey: uniq() });
    await expect(approveWithdraw(w2._id.toString(), String(selfAdmin._id))).rejects.toMatchObject({ code: 'FORBIDDEN' }); // own withdrawal

    await approveWithdraw(w._id.toString(), String(admin._id));
    await completeWithdrawal(w._id.toString(), '0xabc');
    await completeWithdrawal(w._id.toString(), '0xabc'); // idempotent
    expect(await bal(u._id, 'BTC')).toEqual({ available: 490_000n, locked: 0n });
    expect((await sysBal('fee_revenue', 'BTC')).available).toBe(10_000n);
    expect((await sysBal('hot_wallet', 'BTC')).available).toBe(2_000_000n - 500_000n);
    expect(await reconcile()).toEqual([]);
  });

  it('reject returns the locked funds', async () => {
    const u = await createUser('a');
    const admin = await createUser('boss', { role: 'admin' });
    await fund(u._id, 'BTC', '1000000');
    const w: any = await requestWithdraw({ userId: String(u._id), asset: 'BTC', address: 'bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq', amount: '500000', idempotencyKey: uniq() });
    await rejectWithdrawal(w._id.toString(), String(admin._id), 'suspicious');
    await rejectWithdrawal(w._id.toString(), String(admin._id), 'suspicious'); // idempotent
    expect(await bal(u._id, 'BTC')).toEqual({ available: 1_000_000n, locked: 0n });
    expect(await reconcile()).toEqual([]);
  });

  it('unverified users cannot withdraw', async () => {
    const u = await createUser('a', { kycLevel: 0 });
    await fund(u._id, 'BTC', '1000000');
    await expect(requestWithdraw({ userId: String(u._id), asset: 'BTC', address: 'bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq', amount: '50000', idempotencyKey: uniq() })).rejects.toMatchObject({ code: 'FORBIDDEN' });
  });
});
