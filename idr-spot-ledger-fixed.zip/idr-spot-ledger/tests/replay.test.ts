import mongoose from 'mongoose';
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import { startDb, stopDb, resetData, createUser, fund, makeHarness, uniq } from './helpers.ts';
import { EngineEvent, Market } from '../src/db/models.ts';
import { MatchingEngine } from '../src/engine/engine.ts';
import { cancelOrder, placeOrder } from '../src/services/orders.ts';
import { reconcile } from '../src/services/reconcile.ts';

beforeAll(startDb);
afterAll(stopDb);
beforeEach(resetData);

const marketId = async () => String(((await Market.findOne({ symbol: 'BTC_IDR' }).lean()) as any)._id);
const order = (h: any, u: any, side: 'buy' | 'sell', price: string, qty: string, extra: any = {}) =>
  placeOrder({ userId: String(u._id), market: 'BTC_IDR', side, type: 'limit', price, qty, idempotencyKey: uniq(), ...extra }, h.gateway);

async function busyMarket() {
  const h = makeHarness();
  const users = [await createUser('a'), await createUser('b'), await createUser('c')];
  for (const u of users) { await fund(u._id, 'BTC', '500000000'); await fund(u._id, 'IDR', '20000000000'); }
  const ids: string[] = [];
  const px = (n: number) => String(BigInt(n) * 10_000_000n);
  const spec: Array<[number, 'buy' | 'sell', number, string]> = [
    [0, 'sell', 101, '30000000'], [1, 'sell', 102, '20000000'], [2, 'buy', 99, '10000000'], [1, 'buy', 100, '40000000'],
    [2, 'buy', 102, '45000000'], [0, 'sell', 99, '25000000'], [1, 'sell', 100, '5000000'], [2, 'buy', 98, '12000000'],
  ];
  for (const [u, side, p, q] of spec) ids.push((await order(h, users[u], side, px(p), q)).id);
  await cancelOrder(String(users[2]._id), ids[7], h.gateway);
  return { h, users, ids };
}

describe('event-sourced engine', () => {
  it('a fresh engine rebuilt from the log has the identical order book', async () => {
    const { h } = await busyMarket();
    const mid = await marketId();
    const live = h.engine.snapshot(mid)!;
    expect(live.bids.length + live.asks.length).toBeGreaterThan(0);
    const e2 = new MatchingEngine();
    await e2.recover(mid);
    expect(e2.snapshot(mid)).toEqual(live);
    expect(e2.nextSeq.get(mid)).toBe(h.engine.nextSeq.get(mid));
    expect(await reconcile()).toEqual([]);
  });

  it('after recovery the engine keeps matching correctly (and re-submits stay idempotent)', async () => {
    const { h, users } = await busyMarket();
    const mid = await marketId();
    const h2 = makeHarness();
    await h2.engine.recover(mid);
    const before = JSON.stringify(h2.engine.snapshot(mid));
    const o = await order(h2, users[0], 'sell', '990000000', '5000000');
    expect(o.id).toBeTruthy();
    // replaying the same order into the old and new engine is a no-op
    const again = await h2.engine.submit({ id: o.id, marketId: mid, userId: String(users[0]._id), side: 'sell', type: 'limit', tif: 'GTC', price: '990000000', qty: '5000000' });
    expect(again).toEqual([]);
    expect(JSON.stringify(h2.engine.snapshot(mid))).not.toBe(before);
    void h;
    expect(await reconcile()).toEqual([]);
  });

  it('a log that was tampered with fails recovery loudly', async () => {
    await busyMarket();
    const mid = await marketId();
    const coll = mongoose.connection.db!.collection('engine_events');
    const trade: any = await coll.findOne({ type: 'trade' });
    expect(trade).toBeTruthy();
    await coll.updateOne({ _id: trade._id }, { $set: { 'payload.qty': '1' } });
    await expect(new MatchingEngine().recover(mid)).rejects.toMatchObject({ code: 'INVARIANT' });
  });

  it('a log with a missing event (gap) fails recovery', async () => {
    await busyMarket();
    const mid = await marketId();
    await mongoose.connection.db!.collection('engine_events').deleteOne({ seq: 2 });
    await expect(new MatchingEngine().recover(mid)).rejects.toMatchObject({ code: 'INVARIANT' });
  });

  it('if persisting the log fails, memory is discarded: the book never runs ahead of the log', async () => {
    const h = makeHarness();
    const A = await createUser('a'), B = await createUser('b');
    await fund(A._id, 'BTC', '500000000');
    await fund(B._id, 'IDR', '20000000000');
    await order(h, A, 'sell', '1000000000', '10000000');
    const mid = await marketId();

    const spy = vi.spyOn(EngineEvent, 'insertMany').mockRejectedValueOnce(new Error('disk on fire'));
    // order is committed in the DB but the engine could not log it -> gateway fails -> stays pending_submit
    const bo = await order(h, B, 'buy', '1000000000', '10000000');
    spy.mockRestore();
    expect(((await mongoose.connection.db!.collection('orders').findOne({ _id: new mongoose.Types.ObjectId(bo.id) })) as any).engineStatus).toBe('pending_submit');

    // engine state == log: the failed order is NOT in the book and nothing was traded
    const snap = (h.engine.snapshot(mid) ?? (await h.engine.recover(mid)).snapshot());
    expect(snap.asks.length).toBe(1);
    expect(await EngineEvent.countDocuments({ type: 'trade' })).toBe(0);

    // the sweeper-style retry then succeeds and trades exactly once
    await h.gateway.submit({ id: bo.id, marketId: mid, userId: String(B._id), side: 'buy', type: 'limit', tif: 'GTC', price: '1000000000', qty: '10000000' });
    expect(await EngineEvent.countDocuments({ type: 'trade' })).toBe(1);
    expect(await reconcile()).toEqual([]);
  });
});
