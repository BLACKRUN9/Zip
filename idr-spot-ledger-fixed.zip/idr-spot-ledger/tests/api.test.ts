import { randomBytes } from 'node:crypto';
import request from 'supertest';
import { afterAll, afterEach, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { startDb, stopDb, resetData, fund, makeHarness, bal } from './helpers.ts';
import { createApp } from '../src/api/app.ts';
import { Order, User, Withdrawal } from '../src/db/models.ts';
import { configureSecurity, signRequest } from '../src/security/crypto.ts';
import { totp } from '../src/security/totp.ts';
import { setClock } from '../src/services/auth.ts';
import { completeWithdrawal } from '../src/services/wallet.ts';

const BIG: [number, number] = [100000, 100000];
const mailer = { sent: [] as Array<{ email: string; token: string }>, async sendPasswordReset(email: string, token: string) { this.sent.push({ email, token }); } };
const storage = { async presignUpload(key: string) { return { url: `https://storage.test/${key}` }; }, async presignDownload(key: string) { return `https://storage.test/dl/${key}?sig=x`; } };
const BTC_ADDR = 'bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq';
const NIK = '3201011203900001';
const PW = 'Correct-Horse-Battery-9';
const IPS = ['::ffff:127.0.0.1', '127.0.0.1', '::1'];

let h: ReturnType<typeof makeHarness>;
let app: any;
let n = 0;
let tnow = Date.now();

beforeAll(async () => {
  configureSecurity(randomBytes(32).toString('base64'), randomBytes(32).toString('base64'));
  await startDb();
});
afterAll(stopDb);
beforeEach(async () => {
  await resetData();
  mailer.sent.length = 0;
  h = makeHarness();
  tnow = Date.now();
  setClock(() => tnow);
  app = createApp({ gateway: h.gateway, engine: h.engine, mailer, storage, limits: { global: BIG, authIp: BIG, login: BIG, trade: BIG, withdraw: BIG, forgot: BIG } });
});
afterEach(() => setClock(() => Date.now()));

const nextCode = (secret: string) => { tnow += 30_000; return totp(secret, tnow); }; // each call = a fresh 30s step (TOTP codes are single-use)

async function signup(label = 'u') {
  const email = `${label}${++n}@test.id`;
  const r = await request(app).post('/v1/auth/register').send({ email, password: PW });
  expect(r.status).toBe(201);
  const l = await request(app).post('/v1/auth/login').send({ email, password: PW });
  expect(l.status).toBe(200);
  const token = l.body.accessToken as string;
  return { id: r.body.id as string, email, token, refreshToken: l.body.refreshToken as string, as: (req: any) => req.set('Authorization', `Bearer ${token}`) };
}
type U = Awaited<ReturnType<typeof signup>>;
const get = (u: U, path: string) => u.as(request(app).get(path));
const post = (u: U, path: string, body?: any, key?: string) => { const r = u.as(request(app).post(path)); if (key) r.set('Idempotency-Key', key); return r.send(body); };

async function enable2FA(u: U) {
  const s = await post(u, '/v1/auth/2fa/setup');
  expect(s.status).toBe(200);
  const c = await post(u, '/v1/auth/2fa/confirm', { code: nextCode(s.body.secret) });
  expect(c.status).toBe(200);
  return { secret: s.body.secret as string, recoveryCodes: c.body.recoveryCodes as string[] };
}
async function makeAdmin() {
  const a = await signup('admin');
  await User.updateOne({ _id: a.id }, { $set: { role: 'admin' } });
  const tf = await enable2FA(a);
  return { ...a, ...tf };
}
const verified = (u: U) => User.updateOne({ _id: u.id }, { $set: { kycLevel: 1 } });

describe('registration and login', () => {
  it('validates input, rejects unknown fields and duplicates, never returns secrets', async () => {
    expect((await request(app).post('/v1/auth/register').send({ email: 'a@b.id', password: 'short' })).body.error).toBe('VALIDATION');
    expect((await request(app).post('/v1/auth/register').send({ email: 'a@b.id', password: PW, role: 'admin' })).status).toBe(400); // strict schema: no mass-assignment
    const ok = await request(app).post('/v1/auth/register').send({ email: 'dup@b.id', password: PW });
    expect(ok.status).toBe(201);
    expect(JSON.stringify(ok.body)).not.toMatch(/hash|password/i);
    expect((await request(app).post('/v1/auth/register').send({ email: 'DUP@b.id', password: PW })).status).toBe(409);
  });

  it('failures are generic; 5 bad attempts lock the account until the lock expires', async () => {
    const u = await signup();
    const wrong = await request(app).post('/v1/auth/login').send({ email: u.email, password: 'nope-nope-nope' });
    const unknown = await request(app).post('/v1/auth/login').send({ email: 'ghost@test.id', password: 'nope-nope-nope' });
    expect([wrong.status, unknown.status]).toEqual([401, 401]);
    expect(wrong.body.message).toBe(unknown.body.message); // no user enumeration
    for (let i = 0; i < 4; i++) await request(app).post('/v1/auth/login').send({ email: u.email, password: 'nope-nope-nope' });
    const locked = await request(app).post('/v1/auth/login').send({ email: u.email, password: PW });
    expect([locked.status, locked.body.error]).toEqual([423, 'ACCOUNT_LOCKED']); // even the right password is refused
    tnow += 16 * 60_000;
    expect((await request(app).post('/v1/auth/login').send({ email: u.email, password: PW })).status).toBe(200);
  });

  it('protected routes need a valid token; /me exposes no secrets', async () => {
    expect((await request(app).get('/v1/me')).body.error).toBe('UNAUTHENTICATED');
    expect((await request(app).get('/v1/me').set('Authorization', 'Bearer garbage')).body.error).toBe('INVALID_TOKEN');
    const u = await signup();
    const me = await get(u, '/v1/me');
    expect(me.body.email).toBe(u.email);
    expect(JSON.stringify(me.body)).not.toMatch(/passwordHash|secretEnc|recoveryHashes/);
  });

  it('access tokens expire after 15 minutes', async () => {
    const u = await signup();
    tnow += 16 * 60_000;
    expect((await get(u, '/v1/me')).status).toBe(401);
  });
});

describe('sessions', () => {
  it('refresh rotates; reusing an old refresh token kills the whole family', async () => {
    const u = await signup();
    const r1 = await request(app).post('/v1/auth/refresh').send({ refreshToken: u.refreshToken });
    expect(r1.status).toBe(200);
    expect((await get(u, '/v1/me')).status).toBe(401); // old access token died at rotation
    const fresh = await request(app).get('/v1/me').set('Authorization', `Bearer ${r1.body.accessToken}`);
    expect(fresh.status).toBe(200);
    const reuse = await request(app).post('/v1/auth/refresh').send({ refreshToken: u.refreshToken }); // stolen/replayed
    expect(reuse.status).toBe(401);
    expect((await request(app).get('/v1/me').set('Authorization', `Bearer ${r1.body.accessToken}`)).status).toBe(401); // family revoked
    expect((await request(app).post('/v1/auth/refresh').send({ refreshToken: r1.body.refreshToken })).status).toBe(401);
  });

  it('logout and per-session revoke work; sessions list shows no tokens', async () => {
    const u = await signup();
    const second = await request(app).post('/v1/auth/login').send({ email: u.email, password: PW });
    const list = await get(u, '/v1/auth/sessions');
    expect(list.body.items.length).toBe(2);
    expect(JSON.stringify(list.body)).not.toMatch(/accessHash|refreshHash|accessToken/);
    const other = list.body.items.find((s: any) => s.id !== list.body.currentSessionId);
    expect((await u.as(request(app).delete(`/v1/auth/sessions/${other.id}`))).status).toBe(204);
    expect((await request(app).get('/v1/me').set('Authorization', `Bearer ${second.body.accessToken}`)).status).toBe(401);
    expect((await post(u, '/v1/auth/logout')).status).toBe(204);
    expect((await get(u, '/v1/me')).status).toBe(401);
  });
});

describe('passwords', () => {
  it('forgot/reset: no enumeration, weak password keeps the token, success revokes sessions, token is single-use', async () => {
    const u = await signup();
    const a = await request(app).post('/v1/auth/password/forgot').send({ email: u.email });
    const b = await request(app).post('/v1/auth/password/forgot').send({ email: 'ghost@test.id' });
    expect([a.status, b.status]).toEqual([202, 202]);
    expect(a.body).toEqual(b.body);
    expect(mailer.sent.length).toBe(1);
    const token = mailer.sent[0].token;
    expect((await request(app).post('/v1/auth/password/reset').send({ token, password: 'weak' })).status).toBe(400);
    const NEW = 'A-Brand-New-Passphrase-42';
    expect((await request(app).post('/v1/auth/password/reset').send({ token, password: NEW })).status).toBe(204);
    expect((await request(app).post('/v1/auth/password/reset').send({ token, password: NEW })).status).toBe(401);
    expect((await get(u, '/v1/me')).status).toBe(401);
    expect((await request(app).post('/v1/auth/login').send({ email: u.email, password: PW })).status).toBe(401);
    expect((await request(app).post('/v1/auth/login').send({ email: u.email, password: NEW })).status).toBe(200);
  });

  it('change password keeps the current session, revokes the others', async () => {
    const u = await signup();
    const other = await request(app).post('/v1/auth/login').send({ email: u.email, password: PW });
    expect((await post(u, '/v1/auth/password/change', { currentPassword: 'wrong-wrong-1', newPassword: 'Another-Good-Pass-77' })).status).toBe(401);
    expect((await post(u, '/v1/auth/password/change', { currentPassword: PW, newPassword: 'Another-Good-Pass-77' })).status).toBe(204);
    expect((await get(u, '/v1/me')).status).toBe(200);
    expect((await request(app).get('/v1/me').set('Authorization', `Bearer ${other.body.accessToken}`)).status).toBe(401);
  });
});

describe('2FA', () => {
  it('login needs a fresh code; codes are single-use; recovery codes work once', async () => {
    const u = await signup();
    const { secret, recoveryCodes } = await enable2FA(u);
    expect(recoveryCodes.length).toBe(10);
    const login = (code?: string) => request(app).post('/v1/auth/login').send({ email: u.email, password: PW, code });
    expect((await login()).body.error).toBe('TWOFA_REQUIRED');
    expect((await login('000000')).body.error).toBe('INVALID_CREDENTIALS');
    const code = nextCode(secret);
    expect((await login(code)).status).toBe(200);
    expect((await login(code)).status).toBe(401); // replay of the same code
    expect((await login(recoveryCodes[0])).status).toBe(200);
    expect((await login(recoveryCodes[0])).status).toBe(401); // recovery code already spent
  });

  it('disabling 2FA needs password + code and starts the 24h withdrawal cooldown', async () => {
    const u = await signup();
    const { secret } = await enable2FA(u);
    expect((await post(u, '/v1/auth/2fa/disable', { password: 'bad-bad-bad-1', code: nextCode(secret) })).status).toBe(401);
    expect((await post(u, '/v1/auth/2fa/disable', { password: PW, code: nextCode(secret) })).status).toBe(204);
    const row: any = await User.findById(u.id).lean();
    expect(row.twoFA.enabled).toBe(false);
    expect(new Date(row.withdrawLockedUntil).getTime()).toBeGreaterThan(Date.now());
  });
});

describe('KYC -> trading flow', () => {
  it('unverified users cannot trade; submit KYC, admin approves, then they can', async () => {
    const u = await signup('trader');
    await fund(u.id, 'IDR', '600000000');
    const body = { market: 'BTC_IDR', side: 'buy', type: 'limit', price: '1000000000', qty: '10000000' };
    expect((await post(u, '/v1/orders', body, 'order-key-0001')).body.error).toBe('FORBIDDEN');

    const doc = await post(u, '/v1/kyc/upload-url', { kind: 'doc', contentType: 'image/jpeg' });
    const selfie = await post(u, '/v1/kyc/upload-url', { kind: 'selfie', contentType: 'image/png' });
    expect(doc.body.key.startsWith(`kyc/${u.id}/doc-`)).toBe(true);
    expect((await post(u, '/v1/kyc/upload-url', { kind: 'doc', contentType: 'application/pdf' })).status).toBe(400);
    const bad = await post(u, '/v1/kyc', { fullName: 'Budi Santoso', nik: NIK, dob: '1990-03-12', address: 'Jl. Merdeka 1, Jakarta', docKeys: ['kyc/someone-else/doc-x'], selfieKey: selfie.body.key });
    expect(bad.status).toBe(400); // cannot reference another user's files
    const minor = await post(u, '/v1/kyc', { fullName: 'Budi Santoso', nik: NIK, dob: '2015-03-12', address: 'Jl. Merdeka 1, Jakarta', docKeys: [doc.body.key], selfieKey: selfie.body.key });
    expect(minor.status).toBe(400);
    const sub = await post(u, '/v1/kyc', { fullName: 'Budi Santoso', nik: NIK, dob: '1990-03-12', address: 'Jl. Merdeka 1, Jakarta', docKeys: [doc.body.key], selfieKey: selfie.body.key });
    expect(sub.status).toBe(202);
    const st = await get(u, '/v1/kyc');
    expect(st.body).toMatchObject({ status: 'pending', nik: '3201********0001' }); // masked

    // a second account cannot reuse the same identity
    const v = await signup('dupe');
    const d2 = await post(v, '/v1/kyc/upload-url', { kind: 'doc', contentType: 'image/jpeg' });
    const s2 = await post(v, '/v1/kyc/upload-url', { kind: 'selfie', contentType: 'image/jpeg' });
    expect((await post(v, '/v1/kyc', { fullName: 'Someone Else', nik: NIK, dob: '1990-03-12', address: 'Jl. Lain 2, Bandung', docKeys: [d2.body.key], selfieKey: s2.body.key })).status).toBe(409);

    const admin = await makeAdmin();
    const pend = await get(admin, '/v1/admin/kyc/pending');
    expect(pend.body.items.map((x: any) => x.userId)).toContain(u.id);
    const view = await get(admin, `/v1/admin/kyc/${u.id}`);
    expect(view.body.nik).toBe(NIK); // reviewer sees the real NIK (audited)
    expect(view.body.files.length).toBe(2); // short-lived download links for the document + selfie
    expect((await post(admin, `/v1/admin/kyc/${u.id}/review`, { decision: 'rejected' })).status).toBe(400); // reason required
    expect((await post(admin, `/v1/admin/kyc/${u.id}/review`, { decision: 'approved' })).status).toBe(200);

    const placed = await post(u, '/v1/orders', body, 'order-key-0002');
    expect(placed.status).toBe(201);
    expect(placed.body.status).toBe('new');
  });

  it('orders: idempotency header required, replay returns the same order, isolation between users, cancel works', async () => {
    const u = await signup('t'), other = await signup('o');
    await verified(u); await verified(other);
    await fund(u.id, 'IDR', '600000000');
    const body = { market: 'BTC_IDR', side: 'buy', type: 'limit', price: '1000000000', qty: '10000000' };
    expect((await post(u, '/v1/orders', body)).body.error).toBe('IDEMPOTENCY_KEY_REQUIRED');
    expect((await post(u, '/v1/orders', { ...body, userId: other.id }, 'order-key-0003')).status).toBe(400); // unknown field
    const a = await post(u, '/v1/orders', body, 'order-key-0004');
    const b = await post(u, '/v1/orders', body, 'order-key-0004');
    expect(b.body.id).toBe(a.body.id);
    expect(await Order.countDocuments({})).toBe(1);
    expect((await post(u, '/v1/orders', { ...body, qty: '20000000' }, 'order-key-0004')).body.error).toBe('IDEMPOTENCY_MISMATCH');

    const bals = await get(u, '/v1/balances');
    expect(bals.body.items.find((x: any) => x.asset === 'IDR').locked).toBe('100200000');
    const book = await request(app).get('/v1/markets/BTC_IDR/book'); // public
    expect(book.body.bids).toEqual([['1000000000', '10000000']]);
    expect(JSON.stringify(book.body)).not.toContain(u.id);
    expect((await get(other, `/v1/orders/${a.body.id}`)).status).toBe(404);

    const del = await u.as(request(app).delete(`/v1/orders/${a.body.id}`));
    expect(del.status).toBe(202);
    expect((await get(u, `/v1/orders/${a.body.id}`)).body.status).toBe('canceled');
    expect((await get(u, '/v1/ledger?asset=IDR')).body.items.length).toBeGreaterThan(0);
    expect((await bal(u.id, 'IDR')).locked).toBe(0n);
  });
});

describe('API keys', () => {
  it('signed requests work; bad/stale signatures, missing permissions and sensitive routes are refused', async () => {
    const u = await signup('k');
    await verified(u);
    await fund(u.id, 'IDR', '600000000');
    expect((await post(u, '/v1/api-keys', { permissions: ['read'] })).body.error).toBe('TWOFA_SETUP_REQUIRED');
    await enable2FA(u);
    expect((await post(u, '/v1/api-keys', { permissions: ['trade'] })).status).toBe(400); // trade keys need an IP whitelist
    const readKey = (await post(u, '/v1/api-keys', { permissions: ['read'] })).body;
    const tradeKey = (await post(u, '/v1/api-keys', { permissions: ['read', 'trade'], ipWhitelist: IPS })).body;
    expect(readKey.secret).toBeTruthy();
    expect(JSON.stringify((await get(u, '/v1/api-keys')).body)).not.toContain(readKey.secret);

    const call = (key: any, method: 'get' | 'post', path: string, bodyObj?: any, over: any = {}) => {
      const body = bodyObj ? JSON.stringify(bodyObj) : '';
      const ts = over.ts ?? Date.now();
      const sig = over.sig ?? signRequest(key.secret, { timestamp: ts, method: method.toUpperCase(), path, body });
      const r = (request(app) as any)[method](path).set('X-API-Key', key.keyId).set('X-API-Timestamp', String(ts)).set('X-API-Signature', sig);
      return bodyObj ? r.set('Content-Type', 'application/json').set('Idempotency-Key', over.idem ?? 'api-order-0001').send(body) : r;
    };
    expect((await call(readKey, 'get', '/v1/balances')).status).toBe(200);
    expect((await call(readKey, 'get', '/v1/balances', undefined, { sig: 'f'.repeat(64) })).status).toBe(401);
    expect((await call(readKey, 'get', '/v1/balances', undefined, { ts: Date.now() - 120_000 })).status).toBe(401); // stale
    const order = { market: 'BTC_IDR', side: 'buy', type: 'limit', price: '1000000000', qty: '10000000' };
    expect((await call(readKey, 'post', '/v1/orders', order)).status).toBe(403); // read-only key
    expect((await call(tradeKey, 'post', '/v1/orders', order)).status).toBe(201);
    expect((await call(tradeKey, 'post', '/v1/orders', order)).status).toBe(201); // same idempotency key: replay, not a second order
    expect(await Order.countDocuments({})).toBe(1);
    expect((await call(tradeKey, 'post', '/v1/withdrawals', { asset: 'BTC' })).status).toBe(403); // API keys can never withdraw
    expect((await call(tradeKey, 'post', '/v1/auth/2fa/setup', {})).status).toBe(403);
    expect((await u.as(request(app).delete(`/v1/api-keys/${tradeKey.keyId}`))).status).toBe(204);
    expect((await call(tradeKey, 'get', '/v1/balances')).status).toBe(401);
  });
});

describe('withdrawals', () => {
  it('needs 2FA + a valid code; retries are idempotent; admin approval; cooldown after a password change', async () => {
    const u = await signup('w');
    await verified(u);
    await fund(u.id, 'BTC', '1000000');
    const body = { asset: 'BTC', address: BTC_ADDR, amount: '100000' };
    expect((await post(u, '/v1/withdrawals', { ...body, totp: '123456' }, 'wd-key-00001')).body.error).toBe('TWOFA_SETUP_REQUIRED');
    const { secret } = await enable2FA(u);
    expect((await post(u, '/v1/withdrawals', { ...body, address: 'not-an-address-at-all', totp: nextCode(secret) }, 'wd-key-00002')).status).toBe(400);
    expect((await post(u, '/v1/withdrawals', { ...body, totp: '000000' }, 'wd-key-00003')).body.error).toBe('TWOFA_INVALID');

    const code = nextCode(secret);
    const w1 = await post(u, '/v1/withdrawals', { ...body, totp: code }, 'wd-key-00004');
    expect(w1.status).toBe(201);
    const w2 = await post(u, '/v1/withdrawals', { ...body, totp: code }, 'wd-key-00004'); // network retry with the already-used code
    expect([w2.status, w2.body.id]).toEqual([200, w1.body.id]);
    expect(await Withdrawal.countDocuments({})).toBe(1);
    expect((await bal(u.id, 'BTC')).locked).toBe(110_000n);
    expect((await post(u, '/v1/withdrawals', { ...body, totp: nextCode(secret) }, 'wd-key-00005')).status).toBe(201);

    const admin = await makeAdmin();
    expect((await post(u, `/v1/admin/withdrawals/${w1.body.id}/approve`)).status).toBe(403); // normal users are not admins
    expect((await get(admin, '/v1/admin/withdrawals?status=pending')).body.items.length).toBe(2);
    expect((await post(admin, `/v1/admin/withdrawals/${w1.body.id}/approve`)).status).toBe(200);
    await completeWithdrawal(w1.body.id, 'chain-tx-1');
    expect((await get(u, '/v1/withdrawals')).body.items.map((x: any) => x.status).sort()).toEqual(['completed', 'pending']);

    expect((await post(u, '/v1/auth/password/change', { currentPassword: PW, newPassword: 'Yet-Another-Strong-Pass-5' })).status).toBe(204);
    expect((await post(u, '/v1/withdrawals', { ...body, totp: nextCode(secret) }, 'wd-key-00006')).body.error).toBe('FORBIDDEN'); // 24h cooldown
  });
});

describe('admin controls', () => {
  it('only 2FA-protected admins pass; freezing revokes sessions; halting a market blocks orders; reconcile is clean', async () => {
    const u = await signup('v'), plain = await signup('p');
    await verified(u);
    await fund(u.id, 'IDR', '600000000');
    expect((await get(plain, '/v1/admin/kyc/pending')).status).toBe(403);
    await User.updateOne({ _id: plain.id }, { $set: { role: 'admin' } });
    expect((await get(plain, '/v1/admin/kyc/pending')).body.error).toBe('FORBIDDEN'); // admin without 2FA

    const admin = await makeAdmin();
    const order = { market: 'BTC_IDR', side: 'buy', type: 'limit', price: '1000000000', qty: '10000000' };
    expect((await post(admin, '/v1/admin/markets/BTC_IDR/status', { status: 'halted', reason: 'incident' })).status).toBe(200);
    expect((await post(u, '/v1/orders', order, 'halt-key-0001')).body.error).toBe('MARKET_NOT_ACTIVE');
    expect((await post(admin, '/v1/admin/markets/BTC_IDR/status', { status: 'active', reason: 'resolved' })).status).toBe(200);
    expect((await post(u, '/v1/orders', order, 'halt-key-0002')).status).toBe(201);

    expect((await post(admin, `/v1/admin/users/${u.id}/status`, { status: 'frozen', reason: 'fraud review' })).status).toBe(200);
    expect((await get(u, '/v1/me')).status).toBe(401); // sessions revoked
    expect((await get(admin, '/v1/admin/reconcile')).body.ok).toBe(true);
  });
});

describe('public metadata', () => {
  it('assets expose decimals (the UI needs them) and nothing internal', async () => {
    const r = await request(app).get('/v1/assets');
    expect(r.status).toBe(200);
    const by = Object.fromEntries(r.body.items.map((a: any) => [a.symbol, a]));
    expect([by.IDR.decimals, by.BTC.decimals, by.ETH.decimals, by.USDT.decimals]).toEqual([0, 8, 18, 6]);
    expect(by.BTC.withdrawFee).toBe('10000');
    expect(JSON.stringify(r.body)).not.toMatch(/_id|createdAt|enabled/);
  });
});

describe('transport hygiene', () => {
  it('malformed JSON -> 400, unknown route -> 404, oversized body -> 413, errors carry a requestId and no internals', async () => {
    const bad = await request(app).post('/v1/auth/login').set('Content-Type', 'application/json').send('{"email":');
    expect([bad.status, bad.body.error]).toEqual([400, 'VALIDATION']);
    const nf = await request(app).get('/v1/nope');
    expect([nf.status, nf.body.error]).toEqual([404, 'NOT_FOUND']);
    expect(nf.body.requestId).toBeTruthy();
    expect((await request(app).post('/v1/auth/login').set('Content-Type', 'application/json').send(JSON.stringify({ email: 'a@b.id', password: 'x'.repeat(200_000) }))).status).toBe(413);
    expect(JSON.stringify(nf.body)).not.toMatch(/at .*\.ts|mongo/i);
    expect(nf.headers['cache-control']).toBe('no-store');
    expect(nf.headers['x-powered-by']).toBeUndefined();
  });

  it('default rate limits: the 6th login attempt for one ip+email gets 429 with Retry-After', async () => {
    const tight = createApp({ gateway: h.gateway, engine: h.engine, mailer });
    const codes: number[] = [];
    let last: any;
    for (let i = 0; i < 6; i++) { last = await request(tight).post('/v1/auth/login').send({ email: 'ghost@test.id', password: 'whatever-whatever' }); codes.push(last.status); }
    expect(codes).toEqual([401, 401, 401, 401, 401, 429]);
    expect(Number(last.headers['retry-after'])).toBeGreaterThan(0);
  });
});
