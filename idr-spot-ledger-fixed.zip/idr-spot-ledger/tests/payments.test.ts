import { randomBytes } from 'node:crypto';
import request from 'supertest';
import { afterAll, afterEach, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { startDb, stopDb, resetData, createUser, fund, bal, sysBal, makeHarness, uniq } from './helpers.ts';
import { createApp } from '../src/api/app.ts';
import { SimChain } from '../src/chain/simChain.ts';
import { CHAIN_CONFIRMATIONS } from '../src/config.ts';
import { BankAccount, Deposit, FiatTransaction, KycProfile, LedgerTransaction, User, Withdrawal } from '../src/db/models.ts';
import { SimProvider } from '../src/payments/provider.ts';
import { signedHeaders } from '../src/payments/webhook.ts';
import { configureSecurity } from '../src/security/crypto.ts';
import { totp } from '../src/security/totp.ts';
import { setClock } from '../src/services/auth.ts';
import { ChainWorker, assignDepositAddress, faucet, importAddresses } from '../src/services/chain.ts';
import { addBankAccount, approveFiatWithdraw, dispatchApprovedPayouts, getOrCreateVirtualAccount, handlePaymentWebhook, rejectFiatWithdraw, requestFiatWithdraw } from '../src/services/fiat.ts';
import { reconcile } from '../src/services/reconcile.ts';
import { approveWithdraw, requestWithdraw } from '../src/services/wallet.ts';

const SECRET = 'test-webhook-secret';
const BIG: [number, number] = [100000, 100000];
let sim: SimProvider;
let n = 0;

beforeAll(async () => {
  configureSecurity(randomBytes(32).toString('base64'), randomBytes(32).toString('base64'));
  await startDb();
});
afterAll(stopDb);
beforeEach(async () => {
  await resetData();
  sim = new SimProvider({ secret: SECRET, deliver: (raw, headers) => handlePaymentWebhook(sim, headers, raw) });
});

/** A fully verified customer: KYC approved under `fullName`. */
async function kycUser(label: string, fullName = 'Budi Santoso') {
  const u: any = await createUser(label);
  await KycProfile.create({ userId: u._id, fullName, nik: 'enc', nikHash: `h${++n}${Date.now()}`, status: 'approved', dob: new Date('1990-01-01') });
  return u;
}
const admin = () => createUser('boss', { role: 'admin' });
const idr = async (u: any) => (await bal(u._id, 'IDR')).available;
const pay = (u: any, amount: string, senderName = 'BUDI SANTOSO', extra: object = {}) =>
  getOrCreateVirtualAccount(sim, String(u._id), 'BCA').then((va) => sim.simulateTransfer({ vaNumber: va.vaNumber, amount, senderName, ...extra }));

describe('IDR deposits through the simulated gateway', () => {
  it('virtual accounts need KYC, are stable per user+bank, and differ per bank', async () => {
    const plain = await createUser('nokyc');
    await expect(getOrCreateVirtualAccount(sim, String(plain._id), 'BCA')).rejects.toMatchObject({ code: 'FORBIDDEN' });
    const u = await kycUser('a');
    const a1 = await getOrCreateVirtualAccount(sim, String(u._id), 'BCA');
    const a2 = await getOrCreateVirtualAccount(sim, String(u._id), 'BCA');
    const m = await getOrCreateVirtualAccount(sim, String(u._id), 'MANDIRI');
    expect(a1.vaNumber).toBe(a2.vaNumber);
    expect(m.vaNumber).not.toBe(a1.vaNumber);
    expect(a1.name).toBe('Budi Santoso');
    await expect(getOrCreateVirtualAccount(sim, String(u._id), 'CITIBANK')).rejects.toMatchObject({ code: 'VALIDATION' });
  });

  it('a matching transfer credits exactly once even when the webhook is delivered twice', async () => {
    const u = await kycUser('a');
    await pay(u, '250000', 'BUDI SANTOSO', { duplicate: true });
    expect(await idr(u)).toBe(250_000n);
    expect(await LedgerTransaction.countDocuments({ type: 'deposit' })).toBe(1);
    expect(await FiatTransaction.countDocuments({ type: 'deposit' })).toBe(1);
    expect((await sysBal('hot_wallet', 'IDR')).available).toBe(250_000n);
    expect(await reconcile()).toEqual([]);
  });

  it('a replay of the same payment id with a different amount cannot change what was credited', async () => {
    const u = await kycUser('a');
    const va = await getOrCreateVirtualAccount(sim, String(u._id), 'BCA');
    await sim.simulateTransfer({ vaNumber: va.vaNumber, amount: '100000', senderName: 'Budi Santoso', paymentId: 'PAY-FIXED-1' });
    await sim.simulateTransfer({ vaNumber: va.vaNumber, amount: '900000', senderName: 'Budi Santoso', paymentId: 'PAY-FIXED-1' });
    expect(await idr(u)).toBe(100_000n);
  });

  it('a payer whose name differs goes to manual review; only an admin can release it', async () => {
    const u = await kycUser('a');
    const boss = await admin();
    const ref = await pay(u, '300000', 'ANDI WIJAYA');
    expect(await idr(u)).toBe(0n);
    expect(((await FiatTransaction.findOne({ providerRef: ref }).lean()) as any).status).toBe('manual_review');
    const { creditFiatDeposit } = await import('../src/services/wallet.ts');
    await expect(creditFiatDeposit(ref, { adminId: String(u._id) })).rejects.toMatchObject({ code: 'FORBIDDEN' });
    await creditFiatDeposit(ref, { adminId: String(boss._id) });
    expect(await idr(u)).toBe(300_000n);
    expect(await reconcile()).toEqual([]);
  });

  it('below-minimum payments are parked as rejected (never credited); unknown virtual accounts are ignored', async () => {
    const u = await kycUser('a');
    const ref = await pay(u, '5000');
    expect(((await FiatTransaction.findOne({ providerRef: ref }).lean()) as any)).toMatchObject({ status: 'rejected', reason: 'below_min_deposit' });
    expect(await idr(u)).toBe(0n);
    await sim.simulateTransfer({ vaNumber: '39999999999', amount: '100000', senderName: 'X Y' });
    expect(await FiatTransaction.countDocuments({})).toBe(1);
  });

  it('webhooks need a valid, fresh, untampered signature', async () => {
    const u = await kycUser('a');
    const va = await getOrCreateVirtualAccount(sim, String(u._id), 'BCA');
    const raw = JSON.stringify({ type: 'deposit.paid', providerRef: 'PAY-SIG-0001', vaNumber: va.vaNumber, amount: '100000', senderName: 'Budi Santoso', paidAt: new Date().toISOString() });
    const good = signedHeaders(SECRET, raw, Date.now());
    await expect(handlePaymentWebhook(sim, { ...good, 'x-webhook-signature': 'a'.repeat(64) }, raw)).rejects.toMatchObject({ code: 'INVALID_SIGNATURE' });
    await expect(handlePaymentWebhook(sim, signedHeaders('wrong-secret', raw, Date.now()), raw)).rejects.toMatchObject({ code: 'INVALID_SIGNATURE' });
    await expect(handlePaymentWebhook(sim, signedHeaders(SECRET, raw, Date.now() - 10 * 60_000), raw)).rejects.toMatchObject({ code: 'INVALID_SIGNATURE' }); // replay window
    await expect(handlePaymentWebhook(sim, good, raw.replace('100000', '900000'))).rejects.toMatchObject({ code: 'INVALID_SIGNATURE' }); // tampered amount
    expect(await idr(u)).toBe(0n);
    expect((await handlePaymentWebhook(sim, good, raw)).result).toBe('credited');
    expect(await idr(u)).toBe(100_000n);
  });
});

describe('payout bank account and IDR withdrawals', () => {
  async function ready(label = 'a') {
    const u = await kycUser(label);
    await pay(u, '1000000');
    await addBankAccount(String(u._id), { bank: 'BCA', accountNumber: '1234567890', holderName: 'Budi Santoso' });
    return u;
  }

  it('the payout account must be in the customer\'s own name, is stored encrypted, and replacing it starts a 24h lock', async () => {
    const u = await kycUser('a');
    await expect(addBankAccount(String(u._id), { bank: 'BCA', accountNumber: '1234567890', holderName: 'Andi Wijaya' })).rejects.toMatchObject({ code: 'KYC_NAME_MISMATCH' });
    await expect(addBankAccount(String(u._id), { bank: 'BCA', accountNumber: '12ab', holderName: 'Budi Santoso' })).rejects.toMatchObject({ code: 'VALIDATION' });
    const first = await addBankAccount(String(u._id), { bank: 'BCA', accountNumber: '1234567890', holderName: 'BPK BUDI SANTOSO' });
    expect(first).toMatchObject({ last4: '7890', withdrawalsLockedHours: 0 });
    const row: any = await BankAccount.findOne({ userId: u._id, active: true }).lean();
    expect(JSON.stringify(row)).not.toContain('1234567890');
    const second = await addBankAccount(String(u._id), { bank: 'MANDIRI', accountNumber: '9988776655', holderName: 'Budi Santoso' });
    expect(second.withdrawalsLockedHours).toBe(24);
    expect(await BankAccount.countDocuments({ userId: u._id, active: true })).toBe(1);
    expect(new Date(((await User.findById(u._id).lean()) as any).withdrawLockedUntil).getTime()).toBeGreaterThan(Date.now());
    await pay(u, '500000');
    await expect(requestFiatWithdraw({ userId: String(u._id), amount: '100000', idempotencyKey: uniq() })).rejects.toMatchObject({ code: 'FORBIDDEN' });
  });

  it('request validates, locks amount+fee, is idempotent, and refuses bad input', async () => {
    const u = await kycUser('a');
    await pay(u, '1000000');
    await expect(requestFiatWithdraw({ userId: String(u._id), amount: '100000', idempotencyKey: uniq() })).rejects.toMatchObject({ code: 'NO_BANK_ACCOUNT' });
    await addBankAccount(String(u._id), { bank: 'BCA', accountNumber: '1234567890', holderName: 'Budi Santoso' });
    await expect(requestFiatWithdraw({ userId: String(u._id), amount: '1000', idempotencyKey: uniq() })).rejects.toMatchObject({ code: 'VALIDATION' }); // below minimum
    await expect(requestFiatWithdraw({ userId: String(u._id), amount: '5000000', idempotencyKey: uniq() })).rejects.toMatchObject({ code: 'INSUFFICIENT_FUNDS' });
    expect(await FiatTransaction.countDocuments({ type: 'withdraw' })).toBe(0);
    const a: any = await requestFiatWithdraw({ userId: String(u._id), amount: '100000', idempotencyKey: 'fw-key-0001' });
    const b: any = await requestFiatWithdraw({ userId: String(u._id), amount: '100000', idempotencyKey: 'fw-key-0001' });
    expect(String(b._id)).toBe(String(a._id));
    await expect(requestFiatWithdraw({ userId: String(u._id), amount: '200000', idempotencyKey: 'fw-key-0001' })).rejects.toMatchObject({ code: 'IDEMPOTENCY_MISMATCH' });
    expect(await bal(u._id, 'IDR')).toEqual({ available: 1_000_000n - 106_500n, locked: 106_500n });
    expect(await reconcile()).toEqual([]);
  });

  it('request -> admin approval -> payout (to the decrypted own-name account) -> completed webhook settles the books', async () => {
    const u = await ready();
    const boss = await admin();
    const w: any = await requestFiatWithdraw({ userId: String(u._id), amount: '200000', idempotencyKey: uniq() });
    await expect(approveFiatWithdraw(sim, String(w._id), String(u._id))).rejects.toMatchObject({ code: 'FORBIDDEN' }); // not an admin
    expect((await approveFiatWithdraw(sim, String(w._id), String(boss._id))).status).toBe('approved');
    expect((await approveFiatWithdraw(sim, String(w._id), String(boss._id))).status).toBe('processing'); // idempotent, no second payout
    const po = sim.payouts.get(w.providerRef)!;
    expect(po).toMatchObject({ amount: '200000', bank: 'BCA', accountNumber: '1234567890', accountName: 'Budi Santoso' });
    expect(sim.payouts.size).toBe(1);
    expect(((await FiatTransaction.findById(w._id).lean()) as any).status).toBe('processing');

    await sim.simulatePayoutResult(w.providerRef, 'completed');
    await sim.simulatePayoutResult(w.providerRef, 'completed'); // duplicate webhook
    expect(((await FiatTransaction.findById(w._id).lean()) as any).status).toBe('completed');
    expect(await bal(u._id, 'IDR')).toEqual({ available: 1_000_000n - 206_500n, locked: 0n });
    expect((await sysBal('fee_revenue', 'IDR')).available).toBe(6_500n);
    expect((await sysBal('hot_wallet', 'IDR')).available).toBe(800_000n);
    expect(await reconcile()).toEqual([]);
  });

  it('a failed payout returns the money; a failure notice after completion is refused', async () => {
    const u = await ready();
    const boss = await admin();
    const w: any = await requestFiatWithdraw({ userId: String(u._id), amount: '200000', idempotencyKey: uniq() });
    await approveFiatWithdraw(sim, String(w._id), String(boss._id));
    await sim.simulatePayoutResult(w.providerRef, 'failed', 'rekening tidak valid');
    expect(((await FiatTransaction.findById(w._id).lean()) as any)).toMatchObject({ status: 'failed', reason: 'rekening tidak valid' });
    expect(await bal(u._id, 'IDR')).toEqual({ available: 1_000_000n, locked: 0n });

    const w2: any = await requestFiatWithdraw({ userId: String(u._id), amount: '100000', idempotencyKey: uniq() });
    await approveFiatWithdraw(sim, String(w2._id), String(boss._id));
    await sim.simulatePayoutResult(w2.providerRef, 'completed');
    await expect(sim.simulatePayoutResult(w2.providerRef, 'failed')).rejects.toMatchObject({ code: 'CONFLICT' });
    expect(((await FiatTransaction.findById(w2._id).lean()) as any).status).toBe('completed'); // not unlocked twice
    expect(await reconcile()).toEqual([]);
  });

  it('admin rejection returns the money; non-pending requests cannot be rejected', async () => {
    const u = await ready();
    const boss = await admin();
    const w: any = await requestFiatWithdraw({ userId: String(u._id), amount: '200000', idempotencyKey: uniq() });
    await rejectFiatWithdraw(String(w._id), String(boss._id), 'rekening mencurigakan');
    await rejectFiatWithdraw(String(w._id), String(boss._id), 'rekening mencurigakan'); // idempotent
    expect(await bal(u._id, 'IDR')).toEqual({ available: 1_000_000n, locked: 0n });
    const w2: any = await requestFiatWithdraw({ userId: String(u._id), amount: '100000', idempotencyKey: uniq() });
    await approveFiatWithdraw(sim, String(w2._id), String(boss._id));
    await expect(rejectFiatWithdraw(String(w2._id), String(boss._id), 'terlambat')).rejects.toMatchObject({ code: 'CONFLICT' });
  });

  it('if the gateway is down at approval time the payout stays "approved" and the sweeper retries it exactly once', async () => {
    const u = await ready();
    const boss = await admin();
    let down = true;
    const flaky: any = Object.create(sim);
    flaky.createPayout = async (i: any) => { if (down) throw new Error('gateway 503'); return sim.createPayout(i); };
    const w: any = await requestFiatWithdraw({ userId: String(u._id), amount: '200000', idempotencyKey: uniq() });
    await approveFiatWithdraw(flaky, String(w._id), String(boss._id));
    expect(((await FiatTransaction.findById(w._id).lean()) as any).status).toBe('approved');
    expect(sim.payouts.size).toBe(0);
    down = false;
    expect(await dispatchApprovedPayouts(flaky, 0)).toBe(1);
    expect(await dispatchApprovedPayouts(flaky, 0)).toBe(0);
    expect(sim.payouts.size).toBe(1);
    expect(((await FiatTransaction.findById(w._id).lean()) as any).status).toBe('processing');
  });

  it('a fast gateway that confirms before our status update still settles correctly', async () => {
    const u = await ready();
    const boss = await admin();
    const w: any = await requestFiatWithdraw({ userId: String(u._id), amount: '200000', idempotencyKey: uniq() });
    const fast: any = Object.create(sim);
    fast.createPayout = async (i: any) => { const r = await sim.createPayout(i); await sim.simulatePayoutResult(i.reference, 'completed'); return r; }; // webhook lands inside the call
    await approveFiatWithdraw(fast, String(w._id), String(boss._id));
    expect(((await FiatTransaction.findById(w._id).lean()) as any).status).toBe('completed'); // not regressed to "processing"
    expect(await reconcile()).toEqual([]);
  });
});

describe('simulated testnet: deposits, reorgs and payouts', () => {
  let chain: SimChain;
  let worker: ChainWorker;
  const logs: any[] = [];
  const saved = { ...CHAIN_CONFIRMATIONS };
  beforeEach(() => {
    CHAIN_CONFIRMATIONS.ETH = 2;
    chain = new SimChain('ETH');
    worker = new ChainWorker(chain, { log: (m) => logs.push(m) });
    logs.length = 0;
  });
  afterEach(() => { Object.assign(CHAIN_CONFIRMATIONS, saved); });
  const custody = (asset: string) => chain.custodyBalance(asset);
  const solvent = () => reconcile({ custodyBalance: custody });

  it('addresses: one per user per chain, pool first, generator fallback, bad addresses rejected on import', async () => {
    const u1 = await createUser('a'), u2 = await createUser('b');
    const pool = ['0x' + '11'.repeat(20), '0x' + '22'.repeat(20)];
    expect(await importAddresses('ETH', [...pool, 'not-an-address', pool[0]])).toEqual({ added: 2, duplicates: 1, invalid: ['not-an-address'] });
    const a1 = await assignDepositAddress(String(u1._id), 'ETH');
    expect(a1.address).toBe(pool[0]);
    expect((await assignDepositAddress(String(u1._id), 'ETH')).address).toBe(pool[0]);
    expect((await assignDepositAddress(String(u2._id), 'ETH')).address).toBe(pool[1]);
    const u3 = await createUser('c');
    await expect(assignDepositAddress(String(u3._id), 'ETH')).rejects.toMatchObject({ code: 'NO_ADDRESS_AVAILABLE' });
    const gen = (await Promise.all(Array.from({ length: 8 }, () => assignDepositAddress(String(u3._id), 'ETH', () => chain.newAddress())))).map((x) => x.address);
    expect(new Set(gen).size).toBe(1); // concurrent requests for one user collapse to one address
  });

  it('faucet -> mine -> scan -> confirmations -> credited exactly once; custody stays solvent', async () => {
    const u = await kycUser('a');
    const f = await faucet(chain, String(u._id), 'ETH', 10n ** 18n);
    await worker.tick();
    expect(await Deposit.countDocuments({})).toBe(0); // not mined yet: nothing to see
    chain.mine();
    await worker.tick();
    expect(((await Deposit.findOne({}).lean()) as any)).toMatchObject({ status: 'pending', confirmations: 1, txHash: f.txHash });
    expect((await bal(u._id, 'ETH')).available).toBe(0n);
    chain.mine();
    await worker.tick();
    await worker.tick(); // idempotent
    expect(((await Deposit.findOne({}).lean()) as any).status).toBe('credited');
    expect(await bal(u._id, 'ETH')).toEqual({ available: 10n ** 18n, locked: 0n });
    expect(await LedgerTransaction.countDocuments({ type: 'deposit' })).toBe(1);
    expect(await solvent()).toEqual([]);
  });

  it('a reorg BEFORE crediting resets confirmations; the deposit is credited once after it is re-mined', async () => {
    const u = await kycUser('a');
    await faucet(chain, String(u._id), 'ETH', 10n ** 18n);
    chain.mine(); await worker.tick();
    chain.reorg(1); await worker.tick(); // the block vanished, the tx is back in the mempool
    expect(((await Deposit.findOne({}).lean()) as any)).toMatchObject({ status: 'pending', confirmations: 0 });
    chain.mine(); await worker.tick();
    expect((await bal(u._id, 'ETH')).available).toBe(0n);
    chain.mine(); await worker.tick();
    expect((await bal(u._id, 'ETH')).available).toBe(10n ** 18n);
    expect(await LedgerTransaction.countDocuments({ type: 'deposit' })).toBe(1);
  });

  it('a reorg AFTER crediting that erases the transaction reverses the credit and keeps the books balanced', async () => {
    const u = await kycUser('a');
    await faucet(chain, String(u._id), 'ETH', 10n ** 18n);
    chain.mine(2); await worker.tick();
    expect((await bal(u._id, 'ETH')).available).toBe(10n ** 18n);
    chain.reorg(2, { dropTxs: true }); await worker.tick();
    expect(((await Deposit.findOne({}).lean()) as any).status).toBe('reversed');
    expect(await bal(u._id, 'ETH')).toEqual({ available: 0n, locked: 0n });
    expect(logs.some((l) => String(l.msg).includes('vanished'))).toBe(true);
    expect(await solvent()).toEqual([]);
  });

  it('crypto withdrawals: approve -> broadcast -> confirmations -> completed, solvent at every step', async () => {
    const u = await kycUser('a');
    const boss = await admin();
    await faucet(chain, String(u._id), 'ETH', 10n ** 18n);
    chain.mine(2); await worker.tick();
    const dest = new SimChain('ETH').newAddress();
    const w: any = await requestWithdraw({ userId: String(u._id), asset: 'ETH', address: dest, amount: (10n ** 17n).toString(), idempotencyKey: uniq() });
    await approveWithdraw(String(w._id), String(boss._id));
    await worker.tick();
    const sent: any = await Withdrawal.findById(w._id).lean();
    expect(sent.status).toBe('broadcast');
    expect(await solvent()).toEqual([]); // money has left the chain but the ledger has not caught up yet: counted as in-flight
    await worker.tick(); // never broadcasts twice
    expect(((await Withdrawal.findById(w._id).lean()) as any).txHash).toBe(sent.txHash);
    chain.mine(); await worker.tick();
    expect(((await Withdrawal.findById(w._id).lean()) as any).status).toBe('broadcast');
    chain.mine(); await worker.tick();
    expect(((await Withdrawal.findById(w._id).lean()) as any).status).toBe('completed');
    expect((await sysBal('fee_revenue', 'ETH')).available).toBe(10n ** 15n);
    expect(await custody('ETH')).toBe(9n * 10n ** 17n);
    expect(await solvent()).toEqual([]);
  });

  it('the solvency check catches a ledger that owes more than the chain holds', async () => {
    const u = await createUser('a');
    await fund(u._id, 'ETH', (10n ** 18n).toString()); // ledger credit without any coins on chain
    const found = await reconcile({ custodyBalance: custody });
    expect(found.map((d) => d.kind)).toEqual(['wallet_mismatch']);
    expect(found[0].detail).toContain('INSOLVENT');
  });

  it('a failing chain connection never throws out of the worker and is reported', async () => {
    const broken = new ChainWorker({ ...chain, chain: 'ETH', getTip: async () => { throw new Error('rpc down'); }, scanDeposits: chain.scanDeposits.bind(chain), getTx: chain.getTx.bind(chain), broadcast: chain.broadcast.bind(chain) } as any, { log: (m) => logs.push(m) });
    await expect(broken.tick()).resolves.toBeUndefined();
    expect(logs.some((l) => l.level === 'error' && String(l.err).includes('rpc down'))).toBe(true);
  });
});

describe('HTTP: webhook endpoint and the simulator panel', () => {
  let app: any;
  let chain: SimChain;
  beforeEach(() => {
    const h = makeHarness();
    chain = new SimChain('ETH');
    app = createApp({ gateway: h.gateway, engine: h.engine, mailer: { async sendPasswordReset() {} }, payments: { provider: sim, sim }, chains: { ETH: chain }, simChains: { ETH: chain }, limits: { global: BIG, authIp: BIG, login: BIG, trade: BIG, withdraw: BIG, forgot: BIG } });
  });
  afterEach(() => setClock(() => Date.now()));

  it('the public webhook accepts only correctly signed requests; duplicates are harmless', async () => {
    const u = await kycUser('a');
    const va = await getOrCreateVirtualAccount(sim, String(u._id), 'BCA');
    const raw = JSON.stringify({ type: 'deposit.paid', providerRef: 'PAY-HTTP-0001', vaNumber: va.vaNumber, amount: '120000', senderName: 'Budi Santoso', paidAt: new Date().toISOString() });
    const send = (headers: Record<string, string>, body = raw, provider = 'sim') => request(app).post(`/v1/webhooks/payments/${provider}`).set(headers).send(body);
    expect((await send({ 'content-type': 'application/json' })).status).toBe(401); // unsigned
    expect((await send(signedHeaders('bad', raw, Date.now()))).status).toBe(401);
    expect((await send(signedHeaders(SECRET, raw, Date.now()), raw, 'otherpay')).status).toBe(404);
    expect(await idr(u)).toBe(0n);
    const ok = signedHeaders(SECRET, raw, Date.now());
    expect((await send(ok)).body).toMatchObject({ ok: true, result: 'credited' });
    expect((await send(ok)).status).toBe(200);
    expect(await idr(u)).toBe(120_000n);
    expect((await send(signedHeaders(SECRET, '{"type":"bogus"}', Date.now()), '{"type":"bogus"}')).status).toBe(400);
  });

  it('the simulator endpoints do not exist when no simulator is configured', async () => {
    const h = makeHarness();
    const plain = createApp({ gateway: h.gateway, engine: h.engine, mailer: { async sendPasswordReset() {} } });
    expect((await request(plain).get('/v1/sim/status')).status).toBe(404);
    expect((await request(plain).post('/v1/sim/faucet').send({})).status).toBe(404);
    expect((await request(app).get('/v1/sim/status')).body).toMatchObject({ enabled: true, bank: true, chains: ['ETH'] });
  });

  it('end to end: top up via the bank simulator, add a bank account, withdraw with 2FA, admin approves, bank settles', async () => {
    let tnow = Date.now();
    setClock(() => tnow);
    const nextCode = (secret: string) => { tnow += 30_000; return totp(secret, tnow); };
    const signup = async (label: string) => {
      const email = `${label}${++n}@test.id`;
      await request(app).post('/v1/auth/register').send({ email, password: 'Correct-Horse-Battery-9' });
      const login = await request(app).post('/v1/auth/login').send({ email, password: 'Correct-Horse-Battery-9' });
      const token = login.body.accessToken as string;
      const id = (await request(app).get('/v1/me').set('Authorization', `Bearer ${token}`)).body.id as string;
      const h = { Authorization: `Bearer ${token}` };
      const s = await request(app).post('/v1/auth/2fa/setup').set(h);
      await request(app).post('/v1/auth/2fa/confirm').set(h).send({ code: nextCode(s.body.secret) });
      return { id, h, secret: s.body.secret as string };
    };
    const user = await signup('cust');
    const boss = await signup('boss');
    await User.updateOne({ _id: boss.id }, { $set: { role: 'admin' } });
    await KycProfile.create({ userId: user.id, fullName: 'Budi Santoso', nik: 'enc', nikHash: `hh${Date.now()}`, status: 'approved', dob: new Date('1990-01-01') });
    await User.updateOne({ _id: user.id }, { $set: { kycLevel: 1 } });

    const va = await request(app).get('/v1/fiat/deposit-va?bank=BCA').set(user.h);
    expect(va.status).toBe(200);
    expect(va.body.vaNumber).toMatch(/^39\d{10}$/);
    const top = await request(app).post('/v1/sim/bank/transfer').set(user.h).send({ bank: 'BCA', amount: '500000', senderName: 'Budi Santoso' });
    expect(top.status).toBe(201);
    expect((await request(app).get('/v1/balances').set(user.h)).body.items.find((b: any) => b.asset === 'IDR').available).toBe('500000');

    const bank = { bank: 'BCA', accountNumber: '1234567890', holderName: 'Budi Santoso' };
    expect((await request(app).post('/v1/fiat/bank-account').set(user.h).send({ ...bank, holderName: 'Orang Lain', totp: nextCode(user.secret) })).body.error).toBe('KYC_NAME_MISMATCH');
    expect((await request(app).post('/v1/fiat/bank-account').set(user.h).send({ ...bank, totp: nextCode(user.secret) })).status).toBe(201);
    expect((await request(app).get('/v1/fiat/bank-account').set(user.h)).body.account).toMatchObject({ bank: 'BCA', last4: '7890' });

    const wd = (key: string, totpCode: string) => request(app).post('/v1/fiat/withdrawals').set(user.h).set('Idempotency-Key', key).send({ amount: '100000', totp: totpCode });
    expect((await request(app).post('/v1/fiat/withdrawals').set(user.h).send({ amount: '100000', totp: '123456' })).body.error).toBe('IDEMPOTENCY_KEY_REQUIRED');
    expect((await wd('fiat-wd-0001', '000000')).body.error).toBe('TWOFA_INVALID');
    const code = nextCode(user.secret);
    const w1 = await wd('fiat-wd-0002', code);
    expect([w1.status, w1.body.status, w1.body.fee]).toEqual([201, 'pending', '6500']);
    const w2 = await wd('fiat-wd-0002', code); // network retry with the already-used code
    expect([w2.status, w2.body.id]).toEqual([200, w1.body.id]);

    expect((await request(app).post(`/v1/admin/fiat/withdrawals/${w1.body.id}/approve`).set(user.h)).status).toBe(403);
    const q = await request(app).get('/v1/admin/fiat/withdrawals?status=pending').set(boss.h);
    expect(q.body.items.map((x: any) => x.id)).toEqual([w1.body.id]);
    expect((await request(app).post(`/v1/admin/fiat/withdrawals/${w1.body.id}/approve`).set(boss.h)).body.status).toBe('approved');
    const reference = q.body.items[0].reference as string;
    expect((await request(app).post(`/v1/sim/payout/${reference}`).set(user.h).send({ outcome: 'completed' })).status).toBe(403); // only admins steer the pretend bank
    expect((await request(app).post(`/v1/sim/payout/${reference}`).set(boss.h).send({ outcome: 'completed' })).status).toBe(200);

    const list = await request(app).get('/v1/fiat/transactions').set(user.h);
    expect(list.body.items.map((x: any) => [x.type, x.status]).sort()).toEqual([['deposit', 'credited'], ['withdraw', 'completed']]);
    expect((await request(app).get('/v1/balances').set(user.h)).body.items.find((b: any) => b.asset === 'IDR')).toMatchObject({ available: '393500', locked: '0' });
    expect((await request(app).get('/v1/admin/reconcile').set(boss.h)).body.ok).toBe(true);
  });
});
