import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { startDb, stopDb, resetData, createUser, fund, bal, uniq } from './helpers.ts';
import { Order, Withdrawal } from '../src/db/models.ts';
import { placeOrder } from '../src/services/orders.ts';
import { requestWithdraw } from '../src/services/wallet.ts';
import { reconcile } from '../src/services/reconcile.ts';

beforeAll(startDb);
afterAll(stopDb);
beforeEach(resetData);

describe('concurrency: one account, 100 parallel requests', () => {
  it('100 parallel buy orders never overspend: exactly floor(funds/lock) succeed, balance never negative', async () => {
    const U = await createUser('u');
    // every order: price 1e8, qty 1e6 sat => reserve 1,000,000 + ceil(0.2%) 2,000 = 1,002,000
    const LOCK = 1_002_000n;
    await fund(U._id, 'IDR', (10n * LOCK + (LOCK - 1n)).toString()); // enough for exactly 10
    const results = await Promise.allSettled(
      Array.from({ length: 100 }, () =>
        placeOrder({ userId: String(U._id), market: 'BTC_IDR', side: 'buy', type: 'limit', price: '100000000', qty: '1000000', idempotencyKey: uniq() }),
      ),
    );
    const ok = results.filter((r) => r.status === 'fulfilled');
    const failed = results.filter((r) => r.status === 'rejected') as PromiseRejectedResult[];
    expect(ok.length).toBe(10);
    expect(failed.length).toBe(90);
    for (const f of failed) expect(f.reason.code).toBe('INSUFFICIENT_FUNDS');

    expect(await Order.countDocuments({})).toBe(10);
    expect(await bal(U._id, 'IDR')).toEqual({ available: LOCK - 1n, locked: 10n * LOCK });
    expect(await reconcile()).toEqual([]);
  });

  it('100 parallel withdrawals never overdraw', async () => {
    const U = await createUser('u');
    await fund(U._id, 'BTC', (7n * 110_000n + 109_999n).toString()); // enough for exactly 7 x (100,000 + 10,000 fee)
    const results = await Promise.allSettled(
      Array.from({ length: 100 }, () => requestWithdraw({ userId: String(U._id), asset: 'BTC', address: 'bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq', amount: '100000', idempotencyKey: uniq() })),
    );
    expect(results.filter((r) => r.status === 'fulfilled').length).toBe(7);
    for (const r of results) if (r.status === 'rejected') expect((r.reason as any).code).toBe('INSUFFICIENT_FUNDS');
    expect(await Withdrawal.countDocuments({})).toBe(7);
    expect(await bal(U._id, 'BTC')).toEqual({ available: 109_999n, locked: 770_000n });
    expect(await reconcile()).toEqual([]);
  });

  it('30 parallel withdrawals against funds for exactly 3', async () => {
    const U = await createUser('u');
    await fund(U._id, 'BTC', '330000'); // exactly 3 withdrawals of 110,000
    const results = await Promise.allSettled(
      Array.from({ length: 30 }, () => requestWithdraw({ userId: String(U._id), asset: 'BTC', address: 'bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq', amount: '100000', idempotencyKey: uniq() })),
    );
    expect(results.filter((r) => r.status === 'fulfilled').length).toBe(3);
    expect((await bal(U._id, 'BTC')).available).toBe(0n);
  });
});
