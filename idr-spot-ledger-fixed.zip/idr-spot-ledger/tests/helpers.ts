import mongoose from 'mongoose';
import { MongoMemoryReplSet } from 'mongodb-memory-server';
import { initDb } from '../src/db/init.ts';
import { seedBasics } from '../src/seed.ts';
import { Account, Deposit, FiatTransaction, User } from '../src/db/models.ts';
import { ensureUserAccounts } from '../src/services/ledger.ts';
import { creditDeposit, creditFiatDeposit, registerDeposit } from '../src/services/wallet.ts';
import { MatchingEngine } from '../src/engine/engine.ts';
import { applyEngineEvent } from '../src/services/settlement.ts';
import type { EngineGateway } from '../src/services/orders.ts';

let rs: MongoMemoryReplSet;
let counter = 0;
export const uniq = (p = 'x') => `${p}-${Date.now()}-${++counter}`;

export async function startDb() {
  rs = await MongoMemoryReplSet.create({ replSet: { count: 1, storageEngine: 'wiredTiger' } });
  await mongoose.connect(rs.getUri(), { dbName: 'exchange_test' });
  await initDb();
}
export async function stopDb() {
  await mongoose.disconnect();
  await rs.stop();
}
/** Wipe all data (raw driver: bypasses the append-only guards on purpose) and re-seed. */
export async function resetData() {
  const db = mongoose.connection.db!;
  for (const c of await db.collections()) await c.deleteMany({});
  await seedBasics();
}

export async function createUser(name: string, o: { kycLevel?: number; role?: 'user' | 'admin' } = {}) {
  const u: any = await User.create({ email: `${name}-${uniq()}@test.id`, passwordHash: 'x', kycLevel: o.kycLevel ?? 1, role: o.role ?? 'user' });
  await ensureUserAccounts(u._id);
  return u;
}

const CHAIN: Record<string, string> = { BTC: 'BTC', ETH: 'ETH', USDT: 'TRON' };
/** Fund through the REAL deposit paths (so the ledger, hot_wallet and reconcile all stay coherent). */
export async function fund(userId: unknown, asset: string, amount: string) {
  if (asset === 'IDR') {
    const ref = uniq('va');
    await FiatTransaction.create({ userId, type: 'deposit', method: 'VA', providerRef: ref, amount, nameMatch: true });
    await creditFiatDeposit(ref);
    return undefined;
  }
  const dep: any = await registerDeposit({
    userId: String(userId), asset, chain: CHAIN[asset], address: 'addr-' + userId, txHash: uniq('tx'), amount, confirmations: 100,
  });
  await creditDeposit(dep._id.toString());
  return dep._id.toString() as string;
}

export async function bal(userId: unknown, asset: string) {
  const a: any = await Account.findOne({ owner: `u:${userId}`, asset }).lean();
  return { available: BigInt(a.available), locked: BigInt(a.locked) };
}
export async function sysBal(system: string, asset: string) {
  const a: any = await Account.findOne({ owner: `s:${system}`, asset }).lean();
  return { available: BigInt(a.available), locked: BigInt(a.locked) };
}

/** Engine + synchronous settlement consumer wired as an EngineGateway. */
export function makeHarness() {
  const engine = new MatchingEngine();
  const gateway: EngineGateway = {
    async submit(o) { for (const e of await engine.submit(o)) await applyEngineEvent(e); },
    async cancel(marketId, orderId) { for (const e of await engine.cancel(marketId, orderId)) await applyEngineEvent(e); },
  };
  return { engine, gateway };
}

export const depositCount = () => Deposit.countDocuments({});
