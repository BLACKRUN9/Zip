/** Pure candle + ticker maths (no I/O). All prices/volumes are BigInt in smallest units. */
export const INTERVALS = { '1m': 60_000, '5m': 300_000, '15m': 900_000, '1h': 3_600_000, '4h': 14_400_000, '1d': 86_400_000 } as const;
export type Interval = keyof typeof INTERVALS;
export const INTERVAL_NAMES = Object.keys(INTERVALS) as Interval[];
export const isInterval = (s: string): s is Interval => Object.prototype.hasOwnProperty.call(INTERVALS, s);
/** Buckets are aligned to UTC (1d candles open at 00:00 UTC = 07:00 WIB). */
export const bucketStart = (ts: number, interval: Interval): number => ts - (ts % INTERVALS[interval]);

export interface Candle {
  openTime: number;
  open: bigint; high: bigint; low: bigint; close: bigint;
  volume: bigint; // base units
  quoteVolume: bigint; // quote units
  trades: number;
  lastSeq: number; // highest trade seq folded in: makes applyTrade idempotent
}
export interface TradeTick { price: bigint; qty: bigint; quoteQty: bigint; seq: number; time: number }

/** Fold one trade into its candle. Re-applying a trade (seq <= lastSeq) is a no-op, so replays are safe. */
export function applyTrade(c: Candle | null, t: TradeTick, interval: Interval): Candle {
  const openTime = bucketStart(t.time, interval);
  if (!c) {
    return { openTime, open: t.price, high: t.price, low: t.price, close: t.price, volume: t.qty, quoteVolume: t.quoteQty, trades: 1, lastSeq: t.seq };
  }
  if (c.openTime !== openTime) throw new Error('trade does not belong to this candle');
  if (t.seq <= c.lastSeq) return c;
  return {
    ...c,
    high: t.price > c.high ? t.price : c.high,
    low: t.price < c.low ? t.price : c.low,
    close: t.price,
    volume: c.volume + t.qty,
    quoteVolume: c.quoteVolume + t.quoteQty,
    trades: c.trades + 1,
    lastSeq: t.seq,
  };
}

export const candleToWire = (c: Candle) => ({
  t: c.openTime, o: c.open.toString(), h: c.high.toString(), l: c.low.toString(), c: c.close.toString(),
  v: c.volume.toString(), qv: c.quoteVolume.toString(), n: c.trades,
});

/**
 * Charts want a continuous series. Empty buckets become flat candles at the previous close with zero volume.
 * Leading buckets before the first known price are skipped. `seedClose` = close of the candle just before `fromOpen`.
 */
export function fillGaps(candles: Candle[], fromOpen: number, toOpen: number, interval: Interval, seedClose?: bigint, maxBuckets = 5000): Candle[] {
  const step = INTERVALS[interval];
  const byTime = new Map(candles.map((c) => [c.openTime, c]));
  const out: Candle[] = [];
  let prev = seedClose;
  let n = 0;
  for (let t = fromOpen; t <= toOpen && n < maxBuckets; t += step, n++) {
    const c = byTime.get(t);
    if (c) { out.push(c); prev = c.close; }
    else if (prev !== undefined) out.push({ openTime: t, open: prev, high: prev, low: prev, close: prev, volume: 0n, quoteVolume: 0n, trades: 0, lastSeq: 0 });
  }
  return out;
}

export interface Ticker24h {
  last: string | null; open: string | null; high: string | null; low: string | null;
  volume: string; quoteVolume: string; trades: number; changeBps: number | null;
}
const DAY = 86_400_000;
/** Rolling 24h stats from 1m candles (ascending). changeBps = (last-open)/open in basis points, truncated toward zero. */
export function computeTicker(candles1m: Candle[], now: number): Ticker24h {
  const start = bucketStart(now - DAY, '1m');
  const win = candles1m.filter((c) => c.openTime >= start && c.openTime <= now);
  if (!win.length) return { last: null, open: null, high: null, low: null, volume: '0', quoteVolume: '0', trades: 0, changeBps: null };
  let high = win[0].high, low = win[0].low, vol = 0n, qv = 0n, n = 0;
  for (const c of win) {
    if (c.high > high) high = c.high;
    if (c.low < low) low = c.low;
    vol += c.volume; qv += c.quoteVolume; n += c.trades;
  }
  const open = win[0].open, last = win[win.length - 1].close;
  return {
    last: last.toString(), open: open.toString(), high: high.toString(), low: low.toString(),
    volume: vol.toString(), quoteVolume: qv.toString(), trades: n, changeBps: open > 0n ? Number(((last - open) * 10000n) / open) : 0,
  };
}
