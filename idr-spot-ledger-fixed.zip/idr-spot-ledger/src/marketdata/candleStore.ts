import type { ClientSession } from 'mongoose';
import { Candle } from '../db/models.ts';
import { updateVersioned } from '../db/txn.ts';
import { INTERVALS, INTERVAL_NAMES, applyTrade, bucketStart, computeTicker, fillGaps } from './candles.ts';
import type { Candle as C, Interval, TradeTick } from './candles.ts';

export const docToCandle = (d: any): C => ({
  openTime: d.openTime, open: BigInt(d.open), high: BigInt(d.high), low: BigInt(d.low), close: BigInt(d.close),
  volume: BigInt(d.volume), quoteVolume: BigInt(d.quoteVolume), trades: d.trades, lastSeq: d.lastSeq,
});
const fields = (c: C) => ({
  open: c.open.toString(), high: c.high.toString(), low: c.low.toString(), close: c.close.toString(),
  volume: c.volume.toString(), quoteVolume: c.quoteVolume.toString(), trades: c.trades, lastSeq: c.lastSeq,
});

/**
 * Fold a trade into every interval. MUST run inside the trade's own transaction (settleTrade does that), so the
 * chart can neither miss a trade nor count it twice. The per-candle lastSeq makes a repeated call a no-op.
 */
export async function applyTradeToCandles(session: ClientSession, market: string, t: TradeTick): Promise<void> {
  for (const interval of INTERVAL_NAMES) {
    const openTime = bucketStart(t.time, interval);
    const doc: any = await Candle.findOne({ marketSymbol: market, interval, openTime }).session(session);
    const next = applyTrade(doc ? docToCandle(doc) : null, t, interval);
    if (!doc) await Candle.create([{ marketSymbol: market, interval, openTime, ...fields(next), version: 0 }], { session });
    else if (next.lastSeq !== doc.lastSeq) await updateVersioned(Candle, doc, fields(next), session);
  }
}

export async function loadCandles(market: string, interval: Interval, opts: { limit: number; before?: number; fill?: boolean; now?: number }): Promise<C[]> {
  const f: any = { marketSymbol: market, interval };
  if (opts.before !== undefined) f.openTime = { $lt: opts.before };
  const rows: any[] = await Candle.find(f).sort({ openTime: -1 }).limit(opts.limit).lean();
  rows.reverse();
  const candles = rows.map(docToCandle);
  if (!opts.fill || candles.length === 0) return candles;
  const step = INTERVALS[interval];
  const to = opts.before !== undefined ? bucketStart(opts.before - 1, interval) : bucketStart(opts.now ?? Date.now(), interval);
  const from = Math.max(candles[0].openTime, to - (opts.limit - 1) * step);
  const seed = [...candles].reverse().find((c) => c.openTime < from)?.close;
  return fillGaps(candles, from, to, interval, seed).slice(-opts.limit);
}

export async function loadTicker(market: string, now = Date.now()) {
  const start = bucketStart(now - 86_400_000, '1m');
  const rows: any[] = await Candle.find({ marketSymbol: market, interval: '1m', openTime: { $gte: start } }).sort({ openTime: 1 }).lean();
  return computeTicker(rows.map(docToCandle), now);
}
