import { Account, Market, Order, Trade } from '../db/models.ts';
import type { MatchingEngine } from '../engine/engine.ts';
import { levels, ser } from '../api/serializers.ts';
import type { EngineEventLike } from '../services/settlement.ts';
import type { Channel } from '../ws/protocol.ts';
import { INTERVAL_NAMES, candleToWire } from './candles.ts';
import { loadCandles, loadTicker } from './candleStore.ts';
import { Coalescer, Hub } from './hub.ts';
import { diffBook, isEmptyDelta } from '../../shared/bookDelta.ts';
import type { BookView } from '../../shared/bookDelta.ts';

const BOOK_DEPTH = 50;

/**
 * Turns engine events (after they were applied to the ledger) into real-time publications:
 * public: trades / ticker / book / candles; private: orders / balances (namespaced by owner id).
 * High-frequency streams are coalesced so a burst of trades costs a few pushes, not one per trade.
 * It NEVER throws into the trading path: market data is best-effort, the ledger is the truth.
 */
export class MarketFeed {
  hub: Hub;
  engine: MatchingEngine;
  coalescer: Coalescer;
  symbolById: Map<string, string> = new Map();
  idBySymbol: Map<string, string> = new Map();
  loadedAt = 0;
  bookState: Map<string, { seq: number; view: BookView }> = new Map();
  bookChain: Map<string, Promise<unknown>> = new Map();

  constructor(engine: MatchingEngine, hub: Hub = new Hub(), delayMs = 100) {
    this.engine = engine;
    this.hub = hub;
    this.coalescer = new Coalescer(delayMs, (fn, ms) => setTimeout(fn, ms), (e) => console.error(JSON.stringify({ level: 'error', msg: 'feed job failed', err: String(e) })));
  }

  async _markets(): Promise<void> {
    if (Date.now() - this.loadedAt < 60_000 && this.symbolById.size) return;
    const ms: any[] = await Market.find({}).lean();
    this.symbolById = new Map(ms.map((m) => [String(m._id), m.symbol]));
    this.idBySymbol = new Map(ms.map((m) => [m.symbol, String(m._id)]));
    this.loadedAt = Date.now();
  }

  async onEngineEvents(events: EngineEventLike[]): Promise<void> {
    try {
      await this._markets();
      const touched = new Set<string>(); // marketIds whose book may have changed
      const traded = new Set<string>(); // marketIds with new trades
      const orderIds = new Set<string>();
      for (const e of events) {
        const mid = String(e.marketId);
        touched.add(mid);
        if (e.type === 'trade') {
          traded.add(mid);
          orderIds.add(e.payload.takerOrderId);
          orderIds.add(e.payload.makerOrderId);
          const sym = this.symbolById.get(mid);
          const t: any = await Trade.findOne({ marketId: mid, seq: e.seq }).lean();
          if (sym && t) this.hub.publish(`trades:${sym}`, { seq: e.seq, data: { ...ser.publicTrade(t), seq: e.seq } });
        } else if (e.type === 'order_canceled') orderIds.add(e.payload.orderId);
        else if (e.type === 'order_accepted') orderIds.add(e.payload.id);
      }
      const users = new Set<string>();
      for (const id of orderIds) {
        const o: any = await Order.findById(id).lean();
        if (!o) continue;
        users.add(String(o.userId));
        this.hub.publish(`orders:${o.userId}`, { data: ser.order(o) });
      }
      for (const uid of users) this.coalescer.request(`bal:${uid}`, () => this._publishBalances(uid));
      for (const mid of touched) this.coalescer.request(`book:${mid}`, () => this._publishBook(mid));
      for (const mid of traded) this.coalescer.request(`mkt:${mid}`, () => this._publishMarketStats(mid));
    } catch (e) {
      console.error(JSON.stringify({ level: 'error', msg: 'feed failed', err: String(e) }));
    }
  }

  /**
   * Recompute the top-N book, publish ONLY the difference (seq increments by exactly 1 per non-empty delta) and keep
   * the latest view. Serialised per market so the stored view and the published sequence can never disagree.
   * Subscribers can therefore resync from a snapshot taken here at any time.
   */
  _refreshBook(mid: string): Promise<{ seq: number; view: BookView }> {
    const prev = this.bookChain.get(mid) ?? Promise.resolve();
    const run = prev.catch(() => undefined).then(async () => {
      const snap = await this.engine.book(mid);
      const next: BookView = { bids: levels(snap.bids as any, BOOK_DEPTH), asks: levels(snap.asks as any, BOOK_DEPTH) };
      const st = this.bookState.get(mid);
      if (!st) {
        const fresh = { seq: 0, view: next };
        this.bookState.set(mid, fresh);
        return fresh;
      }
      const d = diffBook(st.view, next);
      if (!isEmptyDelta(d)) {
        st.seq += 1;
        st.view = next;
        const sym = this.symbolById.get(mid);
        if (sym) this.hub.publish(`book:${sym}`, { seq: st.seq, data: d });
      }
      return st;
    });
    this.bookChain.set(mid, run.catch(() => undefined));
    return run;
  }

  async _publishBook(mid: string): Promise<void> {
    await this._refreshBook(mid);
  }

  async _publishMarketStats(mid: string): Promise<void> {
    const sym = this.symbolById.get(mid);
    if (!sym) return;
    if (this.hub.hasSubscribers(`ticker:${sym}`)) this.hub.publish(`ticker:${sym}`, { data: await loadTicker(sym) });
    for (const iv of INTERVAL_NAMES) {
      if (!this.hub.hasSubscribers(`candles:${sym}:${iv}`)) continue;
      const [latest] = await loadCandles(sym, iv, { limit: 1 });
      if (latest) this.hub.publish(`candles:${sym}:${iv}`, { data: candleToWire(latest) });
    }
  }

  /** Refresh all currently subscribed private balance channels from the ledger. This also covers deposits/credits
   * that happen outside the matching engine (bank webhook, simulated faucet, admin adjustments). */
  async publishSubscribedBalances(): Promise<void> {
    const channels = [...this.hub.subs.keys()].filter((key) => key.startsWith("balances:"));
    for (const channel of channels) {
      const uid = channel.slice("balances:".length);
      if (uid) await this._publishBalances(uid);
    }
  }

  async _publishBalances(uid: string): Promise<void> {
    if (!this.hub.hasSubscribers(`balances:${uid}`)) return;
    this.hub.publish(`balances:${uid}`, { data: (await Account.find({ userId: uid }).sort({ asset: 1 }).lean()).map(ser.account) });
  }

  /** Initial state for a new subscription (see Connection: snapshot first, then only newer updates). */
  async snapshot(channel: Channel, userId?: string): Promise<{ data: any; seq?: number }> {
    await this._markets();
    if (channel.kind === 'orders') {
      const rows = await Order.find({ userId, status: { $in: ['new', 'partial'] } }).sort({ _id: -1 }).limit(200).lean();
      return { data: rows.map(ser.order) };
    }
    if (channel.kind === 'balances') {
      return { data: (await Account.find({ userId }).sort({ asset: 1 }).lean()).map(ser.account) };
    }
    const mid = this.idBySymbol.get(channel.market);
    if (!mid) throw new Error('unknown market');
    switch (channel.kind) {
      case 'ticker': return { data: await loadTicker(channel.market) };
      case 'trades': {
        const rows: any[] = await Trade.find({ marketId: mid }).sort({ seq: -1 }).limit(50).lean();
        return { data: rows.map((t) => ({ ...ser.publicTrade(t), seq: t.seq })), seq: rows[0]?.seq ?? 0 };
      }
      case 'book': {
        const st = await this._refreshBook(mid);
        return { data: { bids: st.view.bids, asks: st.view.asks }, seq: st.seq };
      }
      case 'candles': return { data: (await loadCandles(channel.market, channel.interval, { limit: 200, fill: true })).map(candleToWire) };
    }
  }
}
