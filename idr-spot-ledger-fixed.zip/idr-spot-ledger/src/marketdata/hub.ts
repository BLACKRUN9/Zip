export interface HubMessage { data: any; seq?: number }
export type Listener = (msg: HubMessage) => void;

/** In-process pub/sub. One bad listener never affects the others. */
export class Hub {
  subs: Map<string, Set<Listener>> = new Map();
  subscribe(channel: string, fn: Listener): () => void {
    let s = this.subs.get(channel);
    if (!s) { s = new Set(); this.subs.set(channel, s); }
    s.add(fn);
    return () => {
      const cur = this.subs.get(channel);
      if (!cur) return;
      cur.delete(fn);
      if (cur.size === 0) this.subs.delete(channel);
    };
  }
  publish(channel: string, msg: HubMessage): number {
    const s = this.subs.get(channel);
    if (!s) return 0;
    let delivered = 0;
    for (const fn of [...s]) {
      try { fn(msg); delivered++; } catch { /* isolate listener failures */ }
    }
    return delivered;
  }
  hasSubscribers(channel: string): boolean { return this.subs.has(channel); }
  count(channel: string): number { return this.subs.get(channel)?.size ?? 0; }
}

type Scheduler = (fn: () => void, ms: number) => unknown;
/**
 * Latest-wins debounce per key: many requests inside one window => the job runs ONCE, with the newest job.
 * Used so a burst of 500 trades produces a handful of order-book pushes, not 500.
 */
export class Coalescer {
  pending: Map<string, () => Promise<void> | void> = new Map();
  delayMs: number;
  schedule: Scheduler;
  onError: (e: unknown) => void;
  constructor(delayMs: number, schedule: Scheduler = (fn, ms) => setTimeout(fn, ms), onError: (e: unknown) => void = () => {}) {
    this.delayMs = delayMs;
    this.schedule = schedule;
    this.onError = onError;
  }
  request(key: string, job: () => Promise<void> | void): void {
    if (this.pending.has(key)) { this.pending.set(key, job); return; }
    this.pending.set(key, job);
    this.schedule(async () => {
      const j = this.pending.get(key)!;
      this.pending.delete(key); // anything requested while the job runs schedules a fresh run
      try { await j(); } catch (e) { this.onError(e); }
    }, this.delayMs);
  }
}
