import { createCipheriv, createDecipheriv, createHash, createHmac, randomBytes, scrypt, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';
import { AppError } from '../errors.ts';

const scryptAsync = promisify(scrypt) as (pw: string, salt: Buffer, keylen: number, opts: object) => Promise<Buffer>;

// ---------------------------------------------------------------- passwords (scrypt, memory-hard, built into Node)
export interface ScryptCost { N: number; r: number; p: number }
export const DEFAULT_COST: ScryptCost = { N: 32768, r: 8, p: 1 }; // ~32 MiB, ~100 ms. Raise over time.
const KEYLEN = 64;
const MAXMEM = 128 * 1024 * 1024;

export async function hashPassword(password: string, cost: ScryptCost = DEFAULT_COST): Promise<string> {
  const salt = randomBytes(16);
  const dk = await scryptAsync(password.normalize('NFKC'), salt, KEYLEN, { N: cost.N, r: cost.r, p: cost.p, maxmem: MAXMEM });
  return ['scrypt', cost.N, cost.r, cost.p, salt.toString('base64'), dk.toString('base64')].join('$');
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const parts = stored.split('$');
  if (parts.length !== 6 || parts[0] !== 'scrypt') return false;
  const N = Number(parts[1]), r = Number(parts[2]), p = Number(parts[3]);
  if (![N, r, p].every((x) => Number.isInteger(x) && x > 0)) return false;
  const salt = Buffer.from(parts[4], 'base64');
  const want = Buffer.from(parts[5], 'base64');
  const got = await scryptAsync(password.normalize('NFKC'), salt, want.length, { N, r, p, maxmem: MAXMEM });
  return got.length === want.length && timingSafeEqual(got, want);
}

export function needsRehash(stored: string, cost: ScryptCost = DEFAULT_COST): boolean {
  const parts = stored.split('$');
  return parts.length !== 6 || Number(parts[1]) < cost.N || Number(parts[2]) < cost.r || Number(parts[3]) < cost.p;
}

let dummy: Promise<string> | null = null;
/** Verified against when the email is unknown, so "no such user" costs the same time as "wrong password". */
export function dummyHash(): Promise<string> {
  return (dummy ??= hashPassword('dummy-password-for-timing-equalisation'));
}

// ---------------------------------------------------------------- tokens
export const newToken = (bytes = 32): string => randomBytes(bytes).toString('base64url');
export const sha256Hex = (s: string): string => createHash('sha256').update(s).digest('hex');
export function safeEqual(a: string, b: string): boolean {
  const x = Buffer.from(a), y = Buffer.from(b);
  return x.length === y.length && timingSafeEqual(x, y);
}

// ---------------------------------------------------------------- field encryption (AES-256-GCM, AAD-bound)
export interface Box {
  encrypt(plain: string, aad: string): string;
  decrypt(blob: string, aad: string): string;
  blindIndex(value: string): string;
}

/** dataKeyB64 encrypts sensitive fields; blindKeyB64 makes searchable-but-unreadable hashes (e.g. duplicate NIK detection). */
export function makeBox(dataKeyB64: string, blindKeyB64: string): Box {
  const key = Buffer.from(dataKeyB64, 'base64');
  const bkey = Buffer.from(blindKeyB64, 'base64');
  if (key.length !== 32 || bkey.length !== 32) throw new AppError('CONFIG', 'encryption keys must be 32 bytes, base64-encoded');
  if (key.equals(bkey)) throw new AppError('CONFIG', 'data key and blind-index key must differ');
  return {
    encrypt(plain, aad) {
      const iv = randomBytes(12);
      const c = createCipheriv('aes-256-gcm', key, iv);
      c.setAAD(Buffer.from(aad));
      const ct = Buffer.concat([c.update(plain, 'utf8'), c.final()]);
      return ['v1', iv.toString('base64url'), c.getAuthTag().toString('base64url'), ct.toString('base64url')].join('.');
    },
    decrypt(blob, aad) {
      const parts = blob.split('.');
      if (parts.length !== 4 || parts[0] !== 'v1') throw new AppError('DECRYPT_FAILED', 'unknown ciphertext format');
      try {
        const d = createDecipheriv('aes-256-gcm', key, Buffer.from(parts[1], 'base64url'));
        d.setAAD(Buffer.from(aad));
        d.setAuthTag(Buffer.from(parts[2], 'base64url'));
        return Buffer.concat([d.update(Buffer.from(parts[3], 'base64url')), d.final()]).toString('utf8');
      } catch {
        throw new AppError('DECRYPT_FAILED', 'ciphertext failed authentication');
      }
    },
    blindIndex: (value) => createHmac('sha256', bkey).update(value).digest('hex'),
  };
}

let current: Box | null = null;
export function configureSecurity(dataKeyB64: string, blindKeyB64: string): void {
  current = makeBox(dataKeyB64, blindKeyB64);
}
export function box(): Box {
  if (!current) throw new AppError('CONFIG', 'security not configured: call configureSecurity() at boot (DATA_ENCRYPTION_KEY, BLIND_INDEX_KEY)');
  return current;
}

// ---------------------------------------------------------------- request signing (API keys)
export function signRequest(secret: string, r: { timestamp: number | string; method: string; path: string; body: string }): string {
  const bodyHash = createHash('sha256').update(r.body ?? '').digest('hex');
  return createHmac('sha256', secret).update(`${r.timestamp}\n${r.method.toUpperCase()}\n${r.path}\n${bodyHash}`).digest('hex');
}
export function verifySignature(secret: string, r: { timestamp: number | string; method: string; path: string; body: string }, signature: string): boolean {
  return safeEqual(signRequest(secret, r), signature.toLowerCase());
}
