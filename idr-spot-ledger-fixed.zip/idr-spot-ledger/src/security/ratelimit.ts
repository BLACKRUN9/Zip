/** In-process token bucket. Per-instance only: put the same logic in Redis when running more than one API instance. */
export class TokenBucket {
  capacity: number;
  refillPerSec: number;
  buckets: Map<string, { tokens: number; at: number }> = new Map();
  constructor(capacity: number, refillPerSec: number) {
    this.capacity = capacity;
    this.refillPerSec = refillPerSec;
  }
  consume(key: string, now = Date.now(), cost = 1): { ok: boolean; retryAfterMs: number } {
    let b = this.buckets.get(key);
    if (!b) { b = { tokens: this.capacity, at: now }; this.buckets.set(key, b); }
    b.tokens = Math.min(this.capacity, b.tokens + ((now - b.at) / 1000) * this.refillPerSec);
    b.at = now;
    if (b.tokens >= cost) { b.tokens -= cost; return { ok: true, retryAfterMs: 0 }; }
    return { ok: false, retryAfterMs: Math.ceil(((cost - b.tokens) / this.refillPerSec) * 1000) };
  }
  sweep(now = Date.now(), idleMs = 10 * 60_000): void {
    for (const [k, b] of this.buckets) if (now - b.at > idleMs) this.buckets.delete(k);
  }
}
