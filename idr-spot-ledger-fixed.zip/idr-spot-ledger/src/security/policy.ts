import { ValidationError } from '../errors.ts';

const EMAIL_RE = /^[^\s@]{1,64}@[^\s@]{1,255}\.[^\s@]{2,}$/;
export function normalizeEmail(email: unknown): string {
  if (typeof email !== 'string') throw new ValidationError('email required');
  const e = email.trim().toLowerCase();
  if (e.length > 254 || !EMAIL_RE.test(e)) throw new ValidationError('invalid email');
  return e;
}

const COMMON = new Set(['password', 'password1', 'password123', '1234567890', '12345678910', 'qwertyuiop', 'iloveyou123', 'admin12345', 'letmein1234', 'indonesia123', 'bitcoin1234', 'kriptoindo1']);
export function validatePassword(password: unknown, email?: string): string {
  if (typeof password !== 'string') throw new ValidationError('password required');
  if (password.length < 10) throw new ValidationError('password must be at least 10 characters');
  if (password.length > 128) throw new ValidationError('password must be at most 128 characters');
  const low = password.toLowerCase();
  if (COMMON.has(low)) throw new ValidationError('password is too common');
  if (email && (low === email.toLowerCase() || low.includes(email.split('@')[0].toLowerCase()) && email.split('@')[0].length >= 4)) {
    throw new ValidationError('password must not contain your email name');
  }
  if (/^(.)\1+$/.test(password)) throw new ValidationError('password is too repetitive');
  return password;
}

/** Indonesian NIK: 16 digits, province/regency code, DDMMYY (women: DD + 40), serial. */
export function validateNik(nik: unknown): string {
  if (typeof nik !== 'string' || !/^\d{16}$/.test(nik)) throw new ValidationError('NIK must be 16 digits');
  if (nik.startsWith('000000')) throw new ValidationError('invalid NIK region code');
  let dd = Number(nik.slice(6, 8));
  if (dd > 40) dd -= 40;
  const mm = Number(nik.slice(8, 10));
  if (dd < 1 || dd > 31 || mm < 1 || mm > 12) throw new ValidationError('invalid NIK birth date');
  if (nik.slice(12) === '0000') throw new ValidationError('invalid NIK serial');
  return nik;
}
export const maskNik = (nik: string): string => `${nik.slice(0, 4)}${'*'.repeat(8)}${nik.slice(-4)}`;

export function ageInYears(dob: Date, now = new Date()): number {
  let age = now.getUTCFullYear() - dob.getUTCFullYear();
  const m = now.getUTCMonth() - dob.getUTCMonth();
  if (m < 0 || (m === 0 && now.getUTCDate() < dob.getUTCDate())) age--;
  return age;
}

// Format-level destination checks (cannot detect a wrong-but-well-formed address; checksum validation is a TODO).
const ADDRESS_RE: Record<string, RegExp> = {
  BTC: /^(bc1[02-9ac-hj-np-z]{11,87}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})$/,
  ETH: /^0x[0-9a-fA-F]{40}$/,
  TRON: /^T[1-9A-HJ-NP-Za-km-z]{33}$/,
};
const ADDRESS_RE_TESTNET: Record<string, RegExp> = {
  ...ADDRESS_RE,
  BTC: /^(tb1[02-9ac-hj-np-z]{11,87}|[mn2][a-km-zA-HJ-NP-Z1-9]{25,34})$/, // BTC testnet; ETH (Sepolia) and TRON (Nile) keep the same formats
};
export function validateAddress(chain: string, address: string, testnet = false): boolean {
  const re = (testnet ? ADDRESS_RE_TESTNET : ADDRESS_RE)[chain];
  return !!re && re.test(address);
}
