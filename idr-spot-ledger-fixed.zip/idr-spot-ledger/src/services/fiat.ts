import { createHash } from 'node:crypto';
import { Types } from 'mongoose';
import { Asset, BankAccount, FiatTransaction, KycProfile, User, VirtualAccount } from '../db/models.ts';
import { isDuplicateKey, updateVersioned, withTxn } from '../db/txn.ts';
import { AppError, Conflict, Forbidden, IdempotencyMismatch, NotFound, ValidationError } from '../errors.ts';
import { MIN_KYC_LEVEL_TO_WITHDRAW } from '../config.ts';
import { parsePositive } from '../money.ts';
import { nameMatches } from '../payments/names.ts';
import { BANKS, isBank } from '../payments/provider.ts';
import type { Bank, PaymentEvent, PaymentProvider } from '../payments/provider.ts';
import { box } from '../security/crypto.ts';
import { writeAudit } from './audit.ts';
import { ensureAccount, getAccount, lockFunds, ownerKey, post, unlockFunds } from './ledger.ts';
import { FIAT_ASSET, creditFiatDeposit, requireAdmin } from './wallet.ts';

const sha = (x: unknown) => createHash('sha256').update(JSON.stringify(x)).digest('hex');
const userKey = (userId: unknown) => `acct:${ownerKey({ userId: String(userId) })}:${FIAT_ASSET}`;
const WD_COOLDOWN_MS = 24 * 3600_000;

// ------------------------------------------------------------------ virtual accounts (deposits)
export async function getOrCreateVirtualAccount(provider: PaymentProvider, userId: string, bankInput: string) {
  if (!isBank(bankInput)) throw new ValidationError(`bank must be one of ${BANKS.join(', ')}`);
  const user: any = await User.findById(userId).lean();
  if (!user) throw new NotFound('user not found');
  if (user.status !== 'active') throw new Forbidden('account is not active');
  const kyc: any = await KycProfile.findOne({ userId, status: 'approved' }).lean();
  if (!kyc) throw new Forbidden('KYC must be approved before IDR deposits'); // the VA belongs to a verified name
  const find = () => VirtualAccount.findOne({ userId, bank: bankInput, provider: provider.name }).lean() as Promise<any>;
  const hit = await find();
  if (hit) return { bank: hit.bank as Bank, vaNumber: hit.vaNumber as string, name: kyc.fullName as string };
  for (let attempt = 0; attempt < 5; attempt++) {
    const va = await provider.createVirtualAccount({ userId, displayName: kyc.fullName, bank: bankInput });
    try {
      await VirtualAccount.create({ userId, bank: bankInput, provider: provider.name, vaNumber: va.vaNumber });
      return { bank: bankInput, vaNumber: va.vaNumber, name: kyc.fullName as string };
    } catch (e) {
      if (!isDuplicateKey(e)) throw e;
      const again = await find(); // lost a race for the same user+bank: use the winner
      if (again) return { bank: again.bank as Bank, vaNumber: again.vaNumber as string, name: kyc.fullName as string };
      // otherwise the random VA number collided with someone else's: draw another
    }
  }
  throw new AppError('CONFLICT', 'could not allocate a virtual account');
}

// ------------------------------------------------------------------ webhooks
/**
 * Entry point for ALL gateway callbacks. Order matters: authenticate the raw bytes first, then parse, then act.
 * Every handler below is idempotent, because gateways deliver at-least-once and out of order.
 */
export async function handlePaymentWebhook(provider: PaymentProvider, headers: Record<string, string | undefined>, rawBody: string): Promise<{ result: string }> {
  if (!provider.verifyWebhook(headers, rawBody)) throw new AppError('INVALID_SIGNATURE', 'invalid webhook signature');
  const ev: PaymentEvent = provider.parseWebhook(rawBody);
  if (ev.type === 'deposit.paid') return { result: await onDepositPaid(ev) };
  if (ev.type === 'payout.completed') return { result: await completeFiatWithdrawal(ev.reference) };
  return { result: await failFiatWithdrawal(ev.reference, ev.reason ?? 'payout failed') };
}

async function onDepositPaid(ev: Extract<PaymentEvent, { type: 'deposit.paid' }>): Promise<string> {
  const va: any = await VirtualAccount.findOne({ vaNumber: ev.vaNumber }).lean();
  if (!va) {
    // Not ours / unknown: answer 200 so the gateway stops retrying, but make it loud for operations.
    console.warn(JSON.stringify({ level: 'warn', msg: 'payment to unknown virtual account', providerRef: ev.providerRef, amount: ev.amount }));
    return 'ignored_unknown_va';
  }
  const [kyc, asset]: any[] = await Promise.all([KycProfile.findOne({ userId: va.userId, status: 'approved' }).lean(), Asset.findOne({ symbol: FIAT_ASSET }).lean()]);
  const nameMatch = !!kyc && nameMatches(ev.senderName, kyc.fullName);
  const tooSmall = BigInt(ev.amount) < BigInt(asset.minDeposit);
  try {
    await FiatTransaction.updateOne(
      { providerRef: ev.providerRef },
      { $setOnInsert: {
        userId: va.userId, type: 'deposit', method: 'VA', amount: ev.amount, fee: '0', lockedAmount: '0', nameMatch, senderName: ev.senderName,
        status: tooSmall ? 'rejected' : 'pending', ...(tooSmall ? { reason: 'below_min_deposit' } : {}), bankAccount: { bank: va.bank, name: ev.senderName }, version: 0,
      } },
      { upsert: true },
    );
  } catch (e) { if (!isDuplicateKey(e)) throw e; } // concurrent duplicate delivery: the row exists now
  if (tooSmall) return 'rejected_below_minimum';
  const r = await creditFiatDeposit(ev.providerRef); // credits, or parks in manual_review on a name mismatch
  return r.status;
}

// ------------------------------------------------------------------ payout bank account
export async function addBankAccount(userId: string, input: { bank: unknown; accountNumber: unknown; holderName: unknown }) {
  if (typeof input.bank !== 'string' || !isBank(input.bank)) throw new ValidationError(`bank must be one of ${BANKS.join(', ')}`);
  const number = String(input.accountNumber ?? '');
  if (!/^\d{5,20}$/.test(number)) throw new ValidationError('account number must be 5-20 digits');
  const holder = String(input.holderName ?? '').trim();
  if (holder.length < 2 || holder.length > 100) throw new ValidationError('holder name is required');
  const user: any = await User.findById(userId).lean();
  if (!user || user.status !== 'active') throw new Forbidden('account is not active');
  const kyc: any = await KycProfile.findOne({ userId, status: 'approved' }).lean();
  if (!kyc) throw new Forbidden('KYC must be approved first');
  // payouts only ever go to an account in the customer's OWN name: a core anti-laundering / anti-takeover control
  if (!nameMatches(holder, kyc.fullName)) throw new AppError('KYC_NAME_MISMATCH', 'the bank account must be in your own name');
  const replacing = await withTxn(async (session) => {
    const old = await BankAccount.updateMany({ userId, active: true }, { $set: { active: false, disabledAt: new Date() } }, { session });
    await BankAccount.create([{ userId, bank: input.bank, numberEnc: box().encrypt(number, `bank:${userId}`), last4: number.slice(-4), holderName: holder, active: true }], { session });
    return old.modifiedCount > 0;
  });
  // changing the destination is exactly what an account-takeover attacker does: freeze withdrawals for 24h
  if (replacing) await User.updateOne({ _id: userId }, { $set: { withdrawLockedUntil: new Date(Date.now() + WD_COOLDOWN_MS) } });
  await writeAudit(userId, 'bank_account.set', userId, undefined, { bank: input.bank, last4: number.slice(-4), replacing });
  return { bank: input.bank, last4: number.slice(-4), holderName: holder, withdrawalsLockedHours: replacing ? 24 : 0 };
}

export async function getBankAccount(userId: string) {
  const b: any = await BankAccount.findOne({ userId, active: true }).lean();
  return b ? { bank: b.bank as string, last4: b.last4 as string, holderName: b.holderName as string } : null;
}

// ------------------------------------------------------------------ IDR withdrawals
export async function requestFiatWithdraw(input: { userId: string; amount: string; idempotencyKey: string }) {
  if (!input.idempotencyKey) throw new ValidationError('idempotencyKey required');
  const amount = parsePositive(input.amount, 'amount');
  const [asset, user, bank]: any[] = await Promise.all([Asset.findOne({ symbol: FIAT_ASSET }).lean(), User.findById(input.userId).lean(), BankAccount.findOne({ userId: input.userId, active: true }).lean()]);
  if (!user || user.status !== 'active') throw new Forbidden('account is not active');
  if (user.kycLevel < MIN_KYC_LEVEL_TO_WITHDRAW) throw new Forbidden('KYC required to withdraw');
  if (user.withdrawLockedUntil && new Date(user.withdrawLockedUntil) > new Date()) throw new Forbidden('withdrawals are locked for 24 hours after a security change');
  if (!bank) throw new AppError('NO_BANK_ACCOUNT', 'add a bank account in your own name first');
  if (amount < BigInt(asset.minWithdraw)) throw new ValidationError(`amount below minWithdraw ${asset.minWithdraw}`);
  const fee = BigInt(asset.withdrawFee);
  const total = amount + fee;
  const requestHash = sha({ a: amount.toString(), b: String(bank._id) });
  await ensureAccount({ userId: input.userId }, FIAT_ASSET);
  return withTxn(async (session) => {
    const existing: any = await FiatTransaction.findOne({ userId: input.userId, idempotencyKey: input.idempotencyKey }).session(session).lean();
    if (existing) {
      if (existing.requestHash !== requestHash) throw new IdempotencyMismatch('idempotency key reused with a different request');
      return existing;
    }
    const _id = new Types.ObjectId();
    const doc = {
      _id, userId: new Types.ObjectId(input.userId), type: 'withdraw', method: 'bank', providerRef: `WD-${_id}`, amount: amount.toString(), fee: fee.toString(), lockedAmount: total.toString(),
      bankAccount: { bank: bank.bank, number: bank.numberEnc, last4: bank.last4, name: bank.holderName }, status: 'pending', nameMatch: true, idempotencyKey: input.idempotencyKey, requestHash, version: 0,
    };
    await FiatTransaction.create([doc], { session });
    await lockFunds(input.userId, FIAT_ASSET, total, _id.toString(), { session, refType: 'fiat_withdrawal', type: 'withdraw', idempotencyKey: `fiat-wd-lock:${_id}` });
    return doc;
  }, { lockKeys: [userKey(input.userId)] });
}

export async function approveFiatWithdraw(provider: PaymentProvider, id: string, adminId: string) {
  const status = await withTxn(async (session) => {
    const f: any = await FiatTransaction.findOne({ _id: id, type: 'withdraw' }).session(session);
    if (!f) throw new NotFound('withdrawal not found');
    await requireAdmin(session, adminId, f.userId); // role + four-eyes (cannot approve your own)
    if (f.status === 'approved' || f.status === 'processing' || f.status === 'completed') return f.status as string; // idempotent
    if (f.status !== 'pending') throw new Conflict(`withdrawal is ${f.status}`);
    await updateVersioned(FiatTransaction, f, { status: 'approved', approvedBy: new Types.ObjectId(adminId) }, session);
    return 'approved';
  });
  await writeAudit(adminId, 'fiat_withdrawal.approve', id);
  if (status === 'approved') await dispatchPayout(provider, id);
  return { status };
}

/** Send one approved withdrawal to the gateway. Safe to repeat: the gateway dedupes on our reference. */
export async function dispatchPayout(provider: PaymentProvider, id: string): Promise<boolean> {
  const f: any = await FiatTransaction.findById(id).lean();
  if (!f || f.status !== 'approved') return false;
  try {
    const r = await provider.createPayout({
      reference: f.providerRef, amount: f.amount, bank: f.bankAccount.bank as Bank,
      accountNumber: box().decrypt(f.bankAccount.number, `bank:${f.userId}`), accountName: f.bankAccount.name,
    });
    // a fast gateway may already have settled it via webhook (status moved on): only advance from 'approved'
    await FiatTransaction.updateOne({ _id: id, status: 'approved' }, { $set: { status: 'processing', gatewayRef: r.gatewayRef } });
    return true;
  } catch (e) {
    console.error(JSON.stringify({ level: 'error', msg: 'payout dispatch failed; will retry', id, err: String(e) }));
    return false;
  }
}

export async function dispatchApprovedPayouts(provider: PaymentProvider, olderThanMs = 30_000, limit = 50): Promise<number> {
  const rows: any[] = await FiatTransaction.find({ type: 'withdraw', status: 'approved', updatedAt: { $lte: new Date(Date.now() - olderThanMs) } }).limit(limit).lean();
  let n = 0;
  for (const f of rows) if (await dispatchPayout(provider, String(f._id))) n++;
  return n;
}

export async function rejectFiatWithdraw(id: string, adminId: string, reason: string) {
  if (!reason?.trim()) throw new ValidationError('a reason is required');
  const pre: any = await FiatTransaction.findOne({ _id: id, type: 'withdraw' }).lean();
  if (!pre) throw new NotFound('withdrawal not found');
  const out = await withTxn(async (session) => {
    const f: any = await FiatTransaction.findById(id).session(session);
    await requireAdmin(session, adminId, f.userId);
    if (f.status === 'rejected') return 'rejected';
    if (f.status !== 'pending') throw new Conflict(`withdrawal is ${f.status} and can no longer be rejected`);
    await unlockFunds(f.userId, FIAT_ASSET, BigInt(f.lockedAmount), id, { session, refType: 'fiat_withdrawal', type: 'withdraw', idempotencyKey: `fiat-wd-unlock:${id}` });
    await updateVersioned(FiatTransaction, f, { status: 'rejected', reason, lockedAmount: '0' }, session);
    return 'rejected';
  }, { lockKeys: [userKey(pre.userId)] });
  await writeAudit(adminId, 'fiat_withdrawal.reject', id, undefined, { reason });
  return { status: out };
}

/** The bank paid out: burn the user's locked funds, reduce treasury, book the fee. Idempotent. */
export async function completeFiatWithdrawal(reference: string): Promise<string> {
  const pre: any = await FiatTransaction.findOne({ providerRef: reference, type: 'withdraw' }).lean();
  if (!pre) { console.warn(JSON.stringify({ level: 'warn', msg: 'payout.completed for unknown reference', reference })); return 'ignored_unknown_reference'; }
  await ensureAccount({ system: 'hot_wallet' }, FIAT_ASSET);
  await ensureAccount({ system: 'fee_revenue' }, FIAT_ASSET);
  return withTxn(async (session) => {
    const f: any = await FiatTransaction.findById(pre._id).session(session);
    if (f.status === 'completed') return 'completed';
    if (f.status !== 'processing' && f.status !== 'approved') throw new Conflict(`cannot complete a withdrawal that is ${f.status}`);
    const amount = BigInt(f.amount), fee = BigInt(f.fee);
    const user = await getAccount(session, { userId: String(f.userId) }, FIAT_ASSET);
    const hot = await getAccount(session, { system: 'hot_wallet' }, FIAT_ASSET);
    const rev = await getAccount(session, { system: 'fee_revenue' }, FIAT_ASSET);
    await post(session, { idempotencyKey: `fiat-wd-complete:${f._id}`, type: 'withdraw', refType: 'fiat_withdrawal', refId: String(f._id), legs: [
      { accountId: user._id, bucket: 'locked', direction: 'debit', amount: amount + fee },
      { accountId: hot._id, bucket: 'available', direction: 'credit', amount },
      { accountId: rev._id, bucket: 'available', direction: 'credit', amount: fee },
    ] });
    await updateVersioned(FiatTransaction, f, { status: 'completed', lockedAmount: '0' }, session);
    return 'completed';
  }, { lockKeys: [userKey(pre.userId)] });
}

/** The bank rejected the payout: give the money back. Idempotent. */
export async function failFiatWithdrawal(reference: string, reason: string): Promise<string> {
  const pre: any = await FiatTransaction.findOne({ providerRef: reference, type: 'withdraw' }).lean();
  if (!pre) { console.warn(JSON.stringify({ level: 'warn', msg: 'payout.failed for unknown reference', reference })); return 'ignored_unknown_reference'; }
  return withTxn(async (session) => {
    const f: any = await FiatTransaction.findById(pre._id).session(session);
    if (f.status === 'failed') return 'failed';
    if (f.status === 'completed') throw new Conflict('payout already completed; failure notice ignored (investigate)');
    if (f.status !== 'processing' && f.status !== 'approved') throw new Conflict(`cannot fail a withdrawal that is ${f.status}`);
    await unlockFunds(f.userId, FIAT_ASSET, BigInt(f.lockedAmount), String(f._id), { session, refType: 'fiat_withdrawal', type: 'withdraw', idempotencyKey: `fiat-wd-unlock:${f._id}` });
    await updateVersioned(FiatTransaction, f, { status: 'failed', reason: reason.slice(0, 200), lockedAmount: '0' }, session);
    return 'failed';
  }, { lockKeys: [userKey(pre.userId)] });
}

export async function listFiatTransactions(userId: string, limit = 30) {
  const rows: any[] = await FiatTransaction.find({ userId }).sort({ _id: -1 }).limit(Math.min(limit, 100)).lean();
  return rows.map((f) => ({ id: String(f._id), type: f.type, amount: f.amount, fee: f.fee, status: f.status, reason: f.reason, bank: f.bankAccount?.bank, last4: f.bankAccount?.last4, createdAt: f.createdAt }));
}
