import { randomUUID } from 'node:crypto';
import { Types } from 'mongoose';
import type { ClientSession } from 'mongoose';
import { Account, Asset, LedgerEntry, LedgerTransaction } from '../db/models.ts';
import { Conflict, InsufficientFunds, InvariantViolation, NotFound } from '../errors.ts';
import { isDuplicateKey, runIn } from '../db/txn.ts';

export type Bucket = 'available' | 'locked';
export type Direction = 'debit' | 'credit';
export type LedgerType = 'deposit' | 'withdraw' | 'order_lock' | 'order_unlock' | 'trade' | 'fee' | 'adjustment';
export type SystemName = 'fee_revenue' | 'hot_wallet' | 'suspense';
export type Owner = { userId: string | Types.ObjectId } | { system: SystemName };

/** fee_revenue is a liability-side (credit-normal) account; hot_wallet & suspense are asset-side (debit-normal). */
export const SYSTEM_NORMAL_SIDE: Record<SystemName, Direction> = {
  fee_revenue: 'credit',
  hot_wallet: 'debit',
  suspense: 'debit',
};
export const SYSTEM_NAMES = Object.keys(SYSTEM_NORMAL_SIDE) as SystemName[];

export interface Leg {
  accountId: Types.ObjectId;
  bucket: Bucket;
  direction: Direction;
  amount: bigint;
}
export interface PostInput {
  idempotencyKey: string;
  type: LedgerType;
  refType?: string;
  refId?: string;
  legs: Leg[];
}

export const ownerKey = (o: Owner): string => ('userId' in o ? `u:${o.userId}` : `s:${o.system}`);

/**
 * Create the account if missing. Run this OUTSIDE (before) the money transaction so concurrent
 * transactions never race on upserts. Safe to call repeatedly / concurrently.
 */
export async function ensureAccount(owner: Owner, asset: string) {
  const key = ownerKey(owner);
  const filter = { owner: key, asset };
  const insert = {
    available: '0',
    locked: '0',
    version: 0,
    normalSide: 'userId' in owner ? 'credit' : SYSTEM_NORMAL_SIDE[owner.system],
    userId: 'userId' in owner ? new Types.ObjectId(String(owner.userId)) : null,
    systemName: 'system' in owner ? owner.system : null,
  };
  try {
    return await Account.findOneAndUpdate(filter, { $setOnInsert: insert }, { upsert: true, new: true, setDefaultsOnInsert: false });
  } catch (e) {
    if (isDuplicateKey(e)) return Account.findOne(filter); // lost the upsert race; it exists now
    throw e;
  }
}

export async function ensureUserAccounts(userId: string | Types.ObjectId): Promise<void> {
  const assets = await Asset.find({ enabled: true }).lean();
  for (const a of assets) await ensureAccount({ userId }, a.symbol);
}

export async function ensureSystemAccounts(): Promise<void> {
  const assets = await Asset.find({}).lean();
  for (const a of assets) for (const s of SYSTEM_NAMES) await ensureAccount({ system: s }, a.symbol);
}

export async function getAccount(session: ClientSession, owner: Owner, asset: string) {
  const acc = await Account.findOne({ owner: ownerKey(owner), asset }).session(session);
  if (!acc) throw new NotFound(`account ${ownerKey(owner)}/${asset} does not exist`);
  return acc;
}

/**
 * Post ONE balanced, atomic, idempotent ledger transaction. Must run inside a MongoDB transaction.
 *
 *  - Per asset, sum(debits) must equal sum(credits).
 *  - A leg whose direction equals the account's normalSide increases that bucket, otherwise decreases it.
 *  - No bucket may ever go negative (checked after EVERY leg, so order debits before credits per account).
 *  - Same idempotencyKey => no-op, returns the original txId.
 *  - Every touched account is updated with an optimistic version check.
 */
export async function post(session: ClientSession, input: PostInput): Promise<{ txId: string; replayed: boolean }> {
  const existing = await LedgerTransaction.findOne({ idempotencyKey: input.idempotencyKey }).session(session).lean();
  if (existing) return { txId: existing.txId, replayed: true };

  const legs = input.legs.filter((l) => l.amount !== 0n);
  for (const l of legs) if (l.amount < 0n) throw new InvariantViolation('negative leg amount');
  if (legs.length < 2) throw new InvariantViolation('a ledger transaction needs at least two non-zero legs');

  const ids = [...new Set(legs.map((l) => l.accountId.toString()))];
  const docs = await Account.find({ _id: { $in: ids } }).session(session);
  const byId = new Map<string, any>(docs.map((d: any) => [d._id.toString(), d]));
  for (const id of ids) if (!byId.has(id)) throw new NotFound(`account ${id} not found`);

  // 1) balanced per asset
  const sums = new Map<string, { debit: bigint; credit: bigint }>();
  for (const l of legs) {
    const asset = byId.get(l.accountId.toString()).asset as string;
    const s = sums.get(asset) ?? { debit: 0n, credit: 0n };
    s[l.direction] += l.amount;
    sums.set(asset, s);
  }
  for (const [asset, s] of sums) {
    if (s.debit !== s.credit) throw new InvariantViolation(`unbalanced ledger tx for ${asset}: debit ${s.debit} != credit ${s.credit}`);
  }

  // 2) apply legs sequentially, never allowing a negative bucket
  const state = new Map<string, { available: bigint; locked: bigint }>();
  for (const id of ids) {
    const d = byId.get(id);
    state.set(id, { available: BigInt(d.available), locked: BigInt(d.locked) });
  }
  const txId = randomUUID();
  const entries: any[] = [];
  legs.forEach((l, legIndex) => {
    const id = l.accountId.toString();
    const acc = byId.get(id);
    const st = state.get(id)!;
    st[l.bucket] += l.direction === acc.normalSide ? l.amount : -l.amount;
    if (st[l.bucket] < 0n) {
      throw new InsufficientFunds(`insufficient ${l.bucket} ${acc.asset} on account ${acc.owner} (would be ${st[l.bucket]})`);
    }
    entries.push({
      txId,
      legIndex,
      accountId: l.accountId,
      userId: acc.userId ?? null,
      asset: acc.asset,
      bucket: l.bucket,
      direction: l.direction,
      amount: l.amount.toString(),
      balanceAfterAvailable: st.available.toString(),
      balanceAfterLocked: st.locked.toString(),
      type: input.type,
      refType: input.refType,
      refId: input.refId,
      idempotencyKey: input.idempotencyKey,
    });
  });

  // 3) persist account balances (optimistic lock), then the immutable records
  for (const id of ids) {
    const doc = byId.get(id);
    const st = state.get(id)!;
    const r = await Account.updateOne(
      { _id: doc._id, version: doc.version },
      { $set: { available: st.available.toString(), locked: st.locked.toString() }, $inc: { version: 1 } },
      { session },
    );
    if (r.matchedCount !== 1) throw new Conflict(`concurrent modification on account ${doc.owner}/${doc.asset}`);
  }
  await LedgerTransaction.create(
    [{ txId, idempotencyKey: input.idempotencyKey, type: input.type, refType: input.refType, refId: input.refId }],
    { session },
  );
  await LedgerEntry.insertMany(entries, { session });
  return { txId, replayed: false };
}

/** Move funds available -> locked on the same account. */
export async function lockFunds(
  userId: string | Types.ObjectId,
  asset: string,
  amount: bigint,
  refId: string,
  opts: { session?: ClientSession; refType?: string; type?: LedgerType; idempotencyKey?: string } = {},
) {
  return runIn(opts.session, async (session) => {
    const acc = await getAccount(session, { userId }, asset);
    return post(session, {
      idempotencyKey: opts.idempotencyKey ?? `lock:${opts.refType ?? 'ref'}:${refId}:${asset}`,
      type: opts.type ?? 'order_lock',
      refType: opts.refType ?? 'order',
      refId,
      legs: [
        { accountId: acc._id, bucket: 'available', direction: 'debit', amount },
        { accountId: acc._id, bucket: 'locked', direction: 'credit', amount },
      ],
    });
  }, { lockKeys: [`acct:${ownerKey({ userId })}:${asset}`] });
}

/** Move funds locked -> available on the same account. */
export async function unlockFunds(
  userId: string | Types.ObjectId,
  asset: string,
  amount: bigint,
  refId: string,
  opts: { session?: ClientSession; refType?: string; type?: LedgerType; idempotencyKey?: string } = {},
) {
  return runIn(opts.session, async (session) => {
    const acc = await getAccount(session, { userId }, asset);
    return post(session, {
      idempotencyKey: opts.idempotencyKey ?? `unlock:${opts.refType ?? 'ref'}:${refId}:${asset}`,
      type: opts.type ?? 'order_unlock',
      refType: opts.refType ?? 'order',
      refId,
      legs: [
        { accountId: acc._id, bucket: 'locked', direction: 'debit', amount },
        { accountId: acc._id, bucket: 'available', direction: 'credit', amount },
      ],
    });
  }, { lockKeys: [`acct:${ownerKey({ userId })}:${asset}`] });
}
