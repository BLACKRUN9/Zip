import { AuditLog } from '../db/models.ts';

/** Fire-and-record. Audit failures must never block a security action, but must be visible. */
export async function writeAudit(actorId: unknown, action: string, target?: string, before?: unknown, after?: unknown, meta: { ip?: string; userAgent?: string } = {}) {
  try {
    await AuditLog.create([{ actorId: actorId ?? null, action, target, before, after, ip: meta.ip, userAgent: meta.userAgent }]);
  } catch (e) {
    console.error(JSON.stringify({ level: 'error', msg: 'audit write failed', action, err: String(e) }));
  }
}
