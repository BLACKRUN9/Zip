import { Types } from 'mongoose';
import { KycProfile, User } from '../db/models.ts';
import { isDuplicateKey, withTxn } from '../db/txn.ts';
import { Conflict, Forbidden, NotFound, ValidationError } from '../errors.ts';
import { box, newToken } from '../security/crypto.ts';
import { ageInYears, maskNik, validateNik } from '../security/policy.ts';
import { writeAudit } from './audit.ts';

export const KYC_MIN_AGE = 18;
export const KYC_MAX_UPLOAD_BYTES = 5 * 1024 * 1024;
const IMAGE_TYPES = ['image/jpeg', 'image/png'];

/** Implement with S3/GCS presigned PUT. Objects must be private, encrypted at rest, with a size limit enforced by the signed policy. */
export interface ObjectStorage {
  presignUpload(key: string, contentType: string, maxBytes: number): Promise<{ url: string; headers?: Record<string, string> }>;
  /** Short-lived (<= 2 min) read URL for the admin reviewer. Without it the review screen shows keys only. */
  presignDownload?(key: string, ttlSeconds: number): Promise<string>;
}

export async function createKycUploadUrl(storage: ObjectStorage, userId: string, kind: 'doc' | 'selfie', contentType: string) {
  if (kind !== 'doc' && kind !== 'selfie') throw new ValidationError('kind must be doc|selfie');
  if (!IMAGE_TYPES.includes(contentType)) throw new ValidationError('only image/jpeg or image/png');
  const key = `kyc/${userId}/${kind}-${newToken(12)}`;
  return { key, ...(await storage.presignUpload(key, contentType, KYC_MAX_UPLOAD_BYTES)) };
}

export interface KycInput { fullName: unknown; nik: unknown; dob: unknown; address: unknown; docKeys: unknown; selfieKey: unknown }

export async function submitKyc(userId: string, input: KycInput, now = new Date()) {
  const fullName = String(input.fullName ?? '').trim();
  const address = String(input.address ?? '').trim();
  if (fullName.length < 2 || fullName.length > 100) throw new ValidationError('fullName must be 2-100 characters');
  if (address.length < 5 || address.length > 300) throw new ValidationError('address must be 5-300 characters');
  const nik = validateNik(input.nik);
  const dob = new Date(String(input.dob));
  if (Number.isNaN(dob.getTime())) throw new ValidationError('invalid dob');
  if (ageInYears(dob, now) < KYC_MIN_AGE) throw new ValidationError(`you must be at least ${KYC_MIN_AGE} years old`);
  const docKeys = Array.isArray(input.docKeys) ? (input.docKeys as unknown[]).map(String) : [];
  const selfieKey = String(input.selfieKey ?? '');
  if (docKeys.length < 1 || docKeys.length > 3) throw new ValidationError('1-3 document images required');
  // object keys must be the caller's own uploads (stops referencing someone else's files)
  if (!docKeys.every((k) => k.startsWith(`kyc/${userId}/doc-`)) || !selfieKey.startsWith(`kyc/${userId}/selfie-`)) {
    throw new ValidationError('invalid upload keys');
  }
  const nikHash = box().blindIndex(nik);
  const dup = await KycProfile.findOne({ nikHash, userId: { $ne: userId }, status: { $in: ['pending', 'approved'] } }).lean();
  if (dup) throw new Conflict('KYC_DUPLICATE_IDENTITY: this identity document is already in use');
  const existing: any = await KycProfile.findOne({ userId }).lean();
  if (existing?.status === 'approved') throw new Conflict('KYC already approved');
  await KycProfile.updateOne(
    { userId },
    { $set: { fullName, nik: box().encrypt(nik, `kyc:${userId}`), nikHash, dob, address, docImages: docKeys, selfieKey, status: 'pending', reason: null, reviewedBy: null }, $setOnInsert: { version: 0 } },
    { upsert: true },
  );
  await writeAudit(userId, 'kyc.submitted', userId);
  return { status: 'pending' };
}

export async function getKycStatus(userId: string) {
  const p: any = await KycProfile.findOne({ userId }).lean();
  if (!p) return { status: 'none' };
  return { status: p.status, reason: p.reason ?? undefined, fullName: p.fullName, nik: maskNik(box().decrypt(p.nik, `kyc:${userId}`)) };
}

export async function assertAdmin(adminId: string) {
  const a: any = await User.findById(adminId).lean();
  if (!a || a.role !== 'admin' || a.status !== 'active') throw new Forbidden('admin role required');
  if (!a.twoFA?.enabled) throw new Forbidden('admin accounts must have 2FA enabled');
  return a;
}

export async function listPendingKyc(adminId: string, limit = 50) {
  await assertAdmin(adminId);
  const rows: any[] = await KycProfile.find({ status: 'pending' }).sort({ updatedAt: 1 }).limit(Math.min(limit, 100)).lean();
  return rows.map((p) => ({ userId: String(p.userId), fullName: p.fullName, submittedAt: p.updatedAt }));
}

/** Reviewer view with decrypted NIK. Every access is written to the audit log (PII access trail). */
export async function viewKycForReview(adminId: string, userId: string) {
  await assertAdmin(adminId);
  const p: any = await KycProfile.findOne({ userId }).lean();
  if (!p) throw new NotFound('no KYC submission');
  await writeAudit(adminId, 'kyc.pii_viewed', userId);
  return { userId, status: p.status, fullName: p.fullName, nik: box().decrypt(p.nik, `kyc:${userId}`), dob: p.dob, address: p.address, docImages: p.docImages, selfieKey: p.selfieKey };
}

export async function reviewKyc(adminId: string, userId: string, decision: 'approved' | 'rejected', reason?: string) {
  await assertAdmin(adminId);
  if (adminId === userId) throw new Forbidden('cannot review your own KYC');
  if (decision !== 'approved' && decision !== 'rejected') throw new ValidationError('decision must be approved|rejected');
  if (decision === 'rejected' && !reason?.trim()) throw new ValidationError('a rejection needs a reason');
  try {
    await withTxn(async (session) => {
      const p: any = await KycProfile.findOne({ userId }).session(session);
      if (!p) throw new NotFound('no KYC submission');
      if (p.status === decision) return; // idempotent
      if (p.status !== 'pending') throw new Conflict(`KYC is already ${p.status}`);
      await KycProfile.updateOne({ _id: p._id, version: p.version }, { $set: { status: decision, reason: reason ?? null, reviewedBy: new Types.ObjectId(adminId) }, $inc: { version: 1 } }, { session });
      if (decision === 'approved') await User.updateOne({ _id: userId, kycLevel: { $lt: 1 } }, { $set: { kycLevel: 1 }, $inc: { version: 1 } }, { session });
    });
  } catch (e) {
    if (isDuplicateKey(e)) throw new Conflict('KYC_DUPLICATE_IDENTITY: another account with this identity is already approved');
    throw e;
  }
  await writeAudit(adminId, `kyc.${decision}`, userId, undefined, { reason });
  return { status: decision };
}
