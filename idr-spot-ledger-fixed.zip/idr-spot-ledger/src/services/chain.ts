import { Asset, ChainState, Deposit, DepositAddress, Withdrawal } from '../db/models.ts';
import { AppError, Conflict, ValidationError } from '../errors.ts';
import { CHAIN_CONFIRMATIONS, CHAIN_FINALITY, DEFAULT_CONFIRMATIONS, network } from '../config.ts';
import { validateAddress } from '../security/policy.ts';
import type { ChainAdapter } from '../chain/types.ts';
import type { SimChain } from '../chain/simChain.ts';
import { creditDeposit, markBroadcast, completeWithdrawal, registerDeposit, reverseDeposit } from './wallet.ts';

// ------------------------------------------------------------------ deposit addresses
const key = (a: string) => a.toLowerCase();

/** Admin: load PUBLIC addresses (generated offline / by your wallet service). The server never needs their private keys. */
export async function importAddresses(chain: string, addresses: string[]) {
  const ok: string[] = [], invalid: string[] = [];
  for (const a of addresses) (validateAddress(chain, a, network.testnet) ? ok : invalid).push(a);
  let added = 0;
  for (const a of ok) {
    const r = await DepositAddress.updateOne({ chain, address: a }, { $setOnInsert: { userId: null } }, { upsert: true });
    if (r.upsertedCount) added++;
  }
  return { added, duplicates: ok.length - added, invalid };
}

/** One address per user per chain (shared by every asset on that chain, e.g. ETH + ERC-20). Never reassigned. */
export async function assignDepositAddress(userId: string, chain: string, generate?: () => string) {
  const have: any = await DepositAddress.findOne({ chain, userId }).lean();
  if (have) return { address: have.address as string };
  const claimed: any = await DepositAddress.findOneAndUpdate({ chain, userId: null }, { $set: { userId, assignedAt: new Date() } }, { sort: { _id: 1 }, new: true });
  if (claimed) return { address: claimed.address as string };
  if (!generate) throw new AppError('NO_ADDRESS_AVAILABLE', 'no deposit address available right now');
  const address = generate();
  try {
    await DepositAddress.create({ chain, address, userId, assignedAt: new Date() });
    return { address };
  } catch {
    const again: any = await DepositAddress.findOne({ chain, userId }).lean(); // concurrent request for the same user
    if (again) return { address: again.address as string };
    throw new AppError('NO_ADDRESS_AVAILABLE', 'could not allocate an address');
  }
}

// ------------------------------------------------------------------ the chain worker
export interface WorkerOptions { reorgBuffer?: number; lookback?: number; log?: (m: object) => void }

/**
 * One worker per chain. Each tick: (1) scan new blocks for deposits to our addresses, (2) re-check every open deposit
 * against the chain (confirmations, reorgs), crediting at the required depth, (3) broadcast approved withdrawals and
 * complete them when confirmed. Everything is idempotent, so a crashed or overlapping tick can never double-credit or double-pay.
 */
export class ChainWorker {
  adapter: ChainAdapter;
  opts: Required<WorkerOptions>;
  running = false;

  constructor(adapter: ChainAdapter, o: WorkerOptions = {}) {
    this.adapter = adapter;
    this.opts = { reorgBuffer: o.reorgBuffer ?? 12, lookback: o.lookback ?? 1000, log: o.log ?? ((m) => console.log(JSON.stringify(m))) };
  }
  get required(): number { return CHAIN_CONFIRMATIONS[this.adapter.chain] ?? DEFAULT_CONFIRMATIONS; }

  async tick(): Promise<void> {
    if (this.running) return; // a slow tick must not overlap the next one
    this.running = true;
    try {
      for (const step of [() => this.syncDeposits(), () => this.trackDeposits(), () => this.processWithdrawals()]) {
        try { await step(); } catch (e) { this.opts.log({ level: 'error', msg: 'chain worker step failed', chain: this.adapter.chain, err: String(e) }); }
      }
    } finally { this.running = false; }
  }

  async syncDeposits(): Promise<number> {
    const chain = this.adapter.chain;
    const tip = await this.adapter.getTip();
    const state: any = await ChainState.findOne({ chain }).lean();
    const from = state ? Math.max(0, state.lastScanned - this.opts.reorgBuffer + 1) : Math.max(0, tip.height - this.opts.lookback);
    const to = Math.min(tip.height, from + (this.adapter.maxScan ?? 1000) - 1);
    if (to < from) return 0;
    const rows: any[] = await DepositAddress.find({ chain, userId: { $ne: null } }).lean();
    const owner = new Map(rows.map((r) => [key(r.address), String(r.userId)]));
    const transfers = await this.adapter.scanDeposits(rows.map((r) => r.address), from, to);
    const assets = new Set((await Asset.find({ chain, type: 'crypto', enabled: true }).lean()).map((a: any) => a.symbol));
    let n = 0;
    for (const t of transfers) {
      const userId = owner.get(key(t.to));
      if (!userId || !assets.has(t.asset)) continue; // not ours / not a supported asset on this chain
      await registerDeposit({ userId, asset: t.asset, chain, address: t.to, txHash: t.txHash, vout: t.vout, amount: t.amount.toString(), confirmations: Math.max(0, tip.height - t.blockHeight + 1), blockHash: t.blockHash });
      n++;
    }
    await ChainState.updateOne({ chain }, { $set: { lastScanned: to, lastHash: to === tip.height ? tip.hash : undefined } }, { upsert: true });
    return n;
  }

  async trackDeposits(): Promise<void> {
    const chain = this.adapter.chain;
    const finality = CHAIN_FINALITY[chain] ?? this.required * 2;
    const open: any[] = await Deposit.find({ chain, status: { $in: ['pending', 'credited'] }, $or: [{ status: 'pending' }, { confirmations: { $lt: finality } }] }).limit(500).lean();
    for (const d of open) {
      const st = await this.adapter.getTx(d.txHash);
      if (st && st.blockHeight !== null && !st.failed) {
        // on chain: record its real depth (it may have been re-mined into a different block)
        await Deposit.updateOne({ _id: d._id, status: d.status }, { $set: { confirmations: st.confirmations, blockHash: st.blockHash } });
        if (d.status === 'pending' && st.confirmations >= this.required) {
          try { await creditDeposit(String(d._id), { requiredConfirmations: this.required }); }
          catch (e) { if (!(e instanceof Conflict)) throw e; }
        }
        continue;
      }
      // not in any block right now: unknown to the chain, still unmined, or failed
      if (d.status === 'pending') { await Deposit.updateOne({ _id: d._id, status: 'pending' }, { $set: { confirmations: 0 } }); continue; }
      if (!st || st.failed) {
        this.opts.log({ level: 'warn', msg: 'credited deposit vanished from chain: reversing', depositId: String(d._id), txHash: d.txHash });
        await reverseDeposit(String(d._id), st?.failed ? 'transaction failed on chain' : 'reorg: transaction no longer on chain');
      } else {
        this.opts.log({ level: 'warn', msg: 'credited deposit is back in the mempool after a reorg: watching', depositId: String(d._id) });
        await Deposit.updateOne({ _id: d._id }, { $set: { confirmations: 0 } });
      }
    }
  }

  async processWithdrawals(): Promise<void> {
    const chain = this.adapter.chain;
    const symbols = (await Asset.find({ chain, type: 'crypto' }).lean()).map((a: any) => a.symbol);
    if (!symbols.length) return;
    const approved: any[] = await Withdrawal.find({ status: 'approved', asset: { $in: symbols } }).sort({ _id: 1 }).limit(50).lean();
    for (const w of approved) {
      try {
        const r = await this.adapter.broadcast({ reference: String(w._id), asset: w.asset, to: w.address, amount: BigInt(w.amount), memo: w.memo }); // idempotent per reference
        await markBroadcast(String(w._id), r.txHash);
      } catch (e) {
        this.opts.log({ level: 'error', msg: 'payout broadcast failed; will retry', withdrawalId: String(w._id), err: String(e) });
      }
    }
    const sent: any[] = await Withdrawal.find({ status: 'broadcast', asset: { $in: symbols } }).limit(100).lean();
    for (const w of sent) {
      const st = await this.adapter.getTx(w.txHash);
      if (!st || st.failed) { this.opts.log({ level: 'error', msg: 'broadcast withdrawal not found or failed on chain: needs a human', withdrawalId: String(w._id), txHash: w.txHash }); continue; }
      if (st.confirmations >= this.required) await completeWithdrawal(String(w._id), w.txHash);
    }
  }
}

// ------------------------------------------------------------------ simulated testnet helpers
export const FAUCET_MAX: Record<string, bigint> = { BTC: 100_000_000n, ETH: 10n ** 19n, USDT: 10_000_000_000n };

/** Dev only: "mint" test coins to the user's deposit address on the simulated chain. */
export async function faucet(sim: SimChain, userId: string, asset: string, amount: bigint) {
  const a: any = await Asset.findOne({ symbol: asset, type: 'crypto', enabled: true }).lean();
  if (!a) throw new ValidationError('unknown crypto asset');
  const max = FAUCET_MAX[asset] ?? 0n;
  if (amount <= 0n || amount > max) throw new ValidationError(`faucet amount must be between 1 and ${max} (smallest units)`);
  const { address } = await assignDepositAddress(userId, a.chain, () => sim.newAddress());
  return { address, txHash: sim.faucet(address, asset, amount) };
}
