import { Market, User, Withdrawal } from '../db/models.ts';
import { Conflict, NotFound, ValidationError } from '../errors.ts';
import { assertAdmin } from './kyc.ts';
import { revokeAllSessions } from './auth.ts';
import { writeAudit } from './audit.ts';

export async function setUserStatus(adminId: string, userId: string, status: 'active' | 'frozen', reason: string) {
  await assertAdmin(adminId);
  if (status !== 'active' && status !== 'frozen') throw new ValidationError('status must be active|frozen');
  if (!reason?.trim()) throw new ValidationError('a reason is required');
  if (adminId === userId) throw new Conflict('cannot change your own status');
  const u: any = await User.findOneAndUpdate({ _id: userId, status: { $ne: 'closed' } }, { $set: { status }, $inc: { version: 1 } });
  if (!u) throw new NotFound('user not found');
  if (status === 'frozen') await revokeAllSessions(userId);
  await writeAudit(adminId, `user.${status}`, userId, { status: u.status }, { status, reason });
  return { status };
}

export async function setMarketStatus(adminId: string, symbol: string, status: 'active' | 'halted' | 'cancel_only', reason: string) {
  await assertAdmin(adminId);
  if (!['active', 'halted', 'cancel_only'].includes(status)) throw new ValidationError('invalid market status');
  if (!reason?.trim()) throw new ValidationError('a reason is required');
  const m: any = await Market.findOneAndUpdate({ symbol: symbol.toUpperCase() }, { $set: { status } });
  if (!m) throw new NotFound('market not found');
  await writeAudit(adminId, 'market.status', m.symbol, { status: m.status }, { status, reason });
  return { status };
}

export async function listWithdrawals(adminId: string, status: string, limit = 50) {
  await assertAdmin(adminId);
  return Withdrawal.find({ status }).sort({ createdAt: 1 }).limit(Math.min(limit, 100)).lean();
}
