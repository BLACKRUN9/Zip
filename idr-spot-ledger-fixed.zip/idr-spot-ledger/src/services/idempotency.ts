import { createHash } from 'node:crypto';
import type { NextFunction, Request, Response } from 'express';
import type { ClientSession } from 'mongoose';
import { IdempotencyKey } from '../db/models.ts';
import { AppError, IdempotencyMismatch } from '../errors.ts';

const KEY_RE = /^[A-Za-z0-9_\-:.]{8,128}$/;

function stable(x: any): any {
  if (Array.isArray(x)) return x.map(stable);
  if (x && typeof x === 'object') return Object.fromEntries(Object.keys(x).sort().map((k) => [k, stable(x[k])]));
  return x;
}
export const hashRequest = (body: unknown): string => createHash('sha256').update(JSON.stringify(stable(body ?? null))).digest('hex');

/** Express middleware: every mutating endpoint must carry an Idempotency-Key header. */
export function requireIdempotencyKey(req: Request, res: Response, next: NextFunction) {
  const key = req.header('idempotency-key');
  if (!key || !KEY_RE.test(key)) {
    res.status(400).json({ error: 'IDEMPOTENCY_KEY_REQUIRED', message: 'send an Idempotency-Key header (8-128 chars: A-Z a-z 0-9 _ - : .)' });
    return;
  }
  (req as any).idempotencyKey = key;
  next();
}

/**
 * Exactly-once wrapper for a unit of work that runs INSIDE the caller's transaction.
 * Same key + same body => stored response, work not repeated.
 * Same key + different body => IDEMPOTENCY_MISMATCH.
 * A concurrent duplicate loses on the unique index; withTxn() retries it and it then sees the stored response.
 */
export async function runIdempotent<T>(session: ClientSession, p: { scope: string; key: string; body: unknown }, work: () => Promise<T>): Promise<T> {
  const requestHash = hashRequest(p.body);
  const hit: any = await IdempotencyKey.findOne({ scope: p.scope, key: p.key }).session(session).lean();
  if (hit) {
    if (hit.requestHash !== requestHash) throw new IdempotencyMismatch('idempotency key reused with a different request');
    return hit.response as T;
  }
  const result = await work();
  const response = JSON.parse(JSON.stringify(result ?? null));
  await IdempotencyKey.create([{ scope: p.scope, key: p.key, requestHash, response }], { session });
  return response as T;
}

export const isAppError = (e: unknown): e is AppError => e instanceof AppError;
