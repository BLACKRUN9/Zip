import { S3Client, PutObjectCommand, GetObjectCommand, HeadObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import type { ObjectStorage } from './kyc.ts';

/** Filebase S3-compatible private object storage for KYC uploads. */
export class FilebaseStorage implements ObjectStorage {
  private client: S3Client;
  private bucket: string;
  constructor(env: NodeJS.ProcessEnv = process.env) {
    const accessKeyId = env.FILEBASE_ACCESS_KEY;
    const secretAccessKey = env.FILEBASE_SECRET_KEY;
    this.bucket = env.FILEBASE_BUCKET ?? '';
    if (!accessKeyId || !secretAccessKey || !this.bucket) throw new Error('Filebase KYC storage requires FILEBASE_ACCESS_KEY, FILEBASE_SECRET_KEY, and FILEBASE_BUCKET');
    this.client = new S3Client({ region: 'us-east-1', endpoint: env.FILEBASE_S3_ENDPOINT ?? 'https://s3.filebase.com', forcePathStyle: true, credentials: { accessKeyId, secretAccessKey } });
  }
  async presignUpload(key: string, contentType: string, maxBytes: number) {
    // S3 presigned PUT cannot reliably enforce Content-Length across browsers; submit endpoint checks key ownership,
    // and the bucket must remain private. Use short expiry and fixed MIME type.
    const command = new PutObjectCommand({ Bucket: this.bucket, Key: key, ContentType: contentType, Metadata: { 'max-bytes': String(maxBytes) } });
    return { url: await getSignedUrl(this.client, command, { expiresIn: 300 }), headers: { 'Content-Type': contentType } };
  }
  async presignDownload(key: string, ttlSeconds: number) {
    await this.client.send(new HeadObjectCommand({ Bucket: this.bucket, Key: key }));
    return getSignedUrl(this.client, new GetObjectCommand({ Bucket: this.bucket, Key: key }), { expiresIn: Math.max(1, Math.min(ttlSeconds, 120)) });
  }
}
