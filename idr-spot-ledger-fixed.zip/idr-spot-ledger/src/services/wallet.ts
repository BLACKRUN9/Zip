import { createHash } from 'node:crypto';
import { Types } from 'mongoose';
import type { ClientSession } from 'mongoose';
import { Asset, AuditLog, Deposit, FiatTransaction, User, Withdrawal } from '../db/models.ts';
import { runIn, updateVersioned, withTxn } from '../db/txn.ts';
import { Conflict, Forbidden, IdempotencyMismatch, NotFound, ValidationError } from '../errors.ts';
import { CHAIN_CONFIRMATIONS, DEFAULT_CONFIRMATIONS, MIN_KYC_LEVEL_TO_WITHDRAW, network } from '../config.ts';
import { minBig, parsePositive } from '../money.ts';
import { validateAddress } from '../security/policy.ts';
import { ensureAccount, getAccount, lockFunds, ownerKey, post, unlockFunds } from './ledger.ts';
import type { Leg } from './ledger.ts';

export const FIAT_ASSET = 'IDR';
const sha = (x: unknown) => createHash('sha256').update(JSON.stringify(x)).digest('hex');
const userKey = (userId: unknown, asset: string) => `acct:${ownerKey({ userId: String(userId) })}:${asset}`;
const audit = (session: ClientSession, actorId: unknown, action: string, target: string, before?: unknown, after?: unknown) =>
  AuditLog.create([{ actorId: actorId ?? null, action, target, before, after }], { session });

// ------------------------------------------------------------------ crypto deposits
export interface DepositEvent {
  userId: string;
  asset: string;
  chain: string;
  address: string;
  txHash: string;
  vout?: number;
  amount: string;
  confirmations: number;
  blockHash?: string;
}

/** Chain-listener entry point. Idempotent per (chain, txHash, vout); confirmations only ever increase. */
export async function registerDeposit(ev: DepositEvent) {
  const amount = parsePositive(ev.amount, 'amount');
  if (!ev.address || !ev.txHash) throw new ValidationError('address and txHash are required');
  const asset: any = await Asset.findOne({ symbol: ev.asset }).lean();
  if (!asset || asset.type !== 'crypto') throw new NotFound(`crypto asset ${ev.asset} not found`);
  return Deposit.findOneAndUpdate(
    { chain: ev.chain, txHash: ev.txHash, vout: ev.vout ?? 0 },
    {
      $setOnInsert: {
        userId: new Types.ObjectId(ev.userId), asset: ev.asset, address: ev.address,
        amount: amount.toString(), status: 'pending', shortfall: '0', version: 0,
      },
      $max: { confirmations: ev.confirmations },
      ...(ev.blockHash ? { $set: { blockHash: ev.blockHash } } : {}),
    },
    { upsert: true, new: true, setDefaultsOnInsert: false },
  );
}

async function creditExternal(session: ClientSession, userId: unknown, asset: string, amount: bigint, key: string, refType: string, refId: string) {
  const hot = await getAccount(session, { system: 'hot_wallet' }, asset);
  const user = await getAccount(session, { userId: String(userId) }, asset);
  const legs: Leg[] = [
    { accountId: hot._id, bucket: 'available', direction: 'debit', amount }, // treasury asset increases
    { accountId: user._id, bucket: 'available', direction: 'credit', amount }, // customer liability increases
  ];
  await post(session, { idempotencyKey: key, type: 'deposit', refType, refId, legs });
}

export async function creditDeposit(depositId: string, opts: { session?: ClientSession; requiredConfirmations?: number } = {}) {
  const pre: any = await Deposit.findById(depositId).lean();
  if (!pre) throw new NotFound('deposit not found');
  await ensureAccount({ userId: String(pre.userId) }, pre.asset);
  await ensureAccount({ system: 'hot_wallet' }, pre.asset);
  return runIn(opts.session, async (session) => {
    const d: any = await Deposit.findById(depositId).session(session);
    if (d.status === 'credited') return { credited: false, status: d.status }; // idempotent
    if (d.status !== 'pending') throw new Conflict(`deposit is ${d.status}`);
    const required = opts.requiredConfirmations ?? CHAIN_CONFIRMATIONS[d.chain] ?? DEFAULT_CONFIRMATIONS;
    if (d.confirmations < required) throw new Conflict(`NOT_ENOUGH_CONFIRMATIONS: ${d.confirmations}/${required}`);
    const asset: any = await Asset.findOne({ symbol: d.asset }).session(session).lean();
    if (!asset?.enabled) throw new Conflict(`asset ${d.asset} disabled`);
    const amount = BigInt(d.amount);
    if (amount < BigInt(asset.minDeposit)) {
      await updateVersioned(Deposit, d, { status: 'rejected', reason: 'below_min_deposit' }, session);
      return { credited: false, status: 'rejected' };
    }
    await creditExternal(session, d.userId, d.asset, amount, `deposit:${d.chain}:${d.txHash}:${d.vout}`, 'deposit', d._id.toString());
    await updateVersioned(Deposit, d, { status: 'credited', creditedAt: new Date() }, session);
    return { credited: true, status: 'credited' };
  }, { lockKeys: [userKey(pre.userId, pre.asset)] });
}

/**
 * Chain reorg after crediting. Takes back what the user still has; any part already spent goes to the
 * `suspense` receivable and the account is frozen for review. Books stay balanced either way.
 */
export async function reverseDeposit(depositId: string, reason: string, adminId?: string, opts: { session?: ClientSession } = {}) {
  const pre: any = await Deposit.findById(depositId).lean();
  if (!pre) throw new NotFound('deposit not found');
  await ensureAccount({ system: 'suspense' }, pre.asset);
  return runIn(opts.session, async (session) => {
    const d: any = await Deposit.findById(depositId).session(session);
    if (d.status === 'reversed' || d.status === 'rejected') return { shortfall: BigInt(d.shortfall) };
    if (d.status === 'pending') {
      await updateVersioned(Deposit, d, { status: 'rejected', reason }, session);
      return { shortfall: 0n };
    }
    const amount = BigInt(d.amount);
    const hot = await getAccount(session, { system: 'hot_wallet' }, d.asset);
    const user = await getAccount(session, { userId: String(d.userId) }, d.asset);
    const suspense = await getAccount(session, { system: 'suspense' }, d.asset);
    const taken = minBig(amount, BigInt(user.available));
    const shortfall = amount - taken;
    const legs: Leg[] = [
      { accountId: user._id, bucket: 'available', direction: 'debit', amount: taken },
      { accountId: suspense._id, bucket: 'available', direction: 'debit', amount: shortfall },
      { accountId: hot._id, bucket: 'available', direction: 'credit', amount },
    ];
    await post(session, { idempotencyKey: `deposit-reverse:${d._id}`, type: 'adjustment', refType: 'deposit', refId: d._id.toString(), legs });
    await updateVersioned(Deposit, d, { status: 'reversed', reason, shortfall: shortfall.toString() }, session);
    if (shortfall > 0n) await User.updateOne({ _id: d.userId }, { $set: { status: 'frozen' }, $inc: { version: 1 } }, { session });
    await audit(session, adminId, 'deposit.reverse', d._id.toString(), { status: 'credited' }, { status: 'reversed', shortfall: shortfall.toString(), reason });
    return { shortfall };
  }, { lockKeys: [userKey(pre.userId, pre.asset)] });
}

// ------------------------------------------------------------------ IDR (fiat) deposits
export async function creditFiatDeposit(providerRef: string, opts: { adminId?: string; session?: ClientSession } = {}) {
  const pre: any = await FiatTransaction.findOne({ providerRef }).lean();
  if (!pre || pre.type !== 'deposit') throw new NotFound('fiat deposit not found');
  await ensureAccount({ userId: String(pre.userId) }, FIAT_ASSET);
  await ensureAccount({ system: 'hot_wallet' }, FIAT_ASSET);
  return runIn(opts.session, async (session) => {
    const f: any = await FiatTransaction.findOne({ providerRef }).session(session);
    if (f.status === 'credited') return { credited: false, status: 'credited' };
    if (f.status !== 'pending' && f.status !== 'manual_review') throw new Conflict(`fiat deposit is ${f.status}`);
    if (!f.nameMatch && !opts.adminId) {
      // sender name != KYC name: never auto-credit
      await updateVersioned(FiatTransaction, f, { status: 'manual_review' }, session);
      return { credited: false, status: 'manual_review' };
    }
    if (opts.adminId) await requireAdmin(session, opts.adminId, f.userId);
    await creditExternal(session, f.userId, FIAT_ASSET, BigInt(f.amount), `fiat-deposit:${providerRef}`, 'fiat_transaction', f._id.toString());
    await updateVersioned(FiatTransaction, f, { status: 'credited' }, session);
    if (opts.adminId) await audit(session, opts.adminId, 'fiat_deposit.manual_credit', providerRef);
    return { credited: true, status: 'credited' };
  }, { lockKeys: [userKey(pre.userId, FIAT_ASSET)] });
}

// ------------------------------------------------------------------ crypto withdrawals
export interface WithdrawInput {
  userId: string;
  asset: string;
  address: string;
  memo?: string;
  amount: string;
  idempotencyKey: string;
}

export async function requestWithdraw(input: WithdrawInput) {
  if (!input.idempotencyKey) throw new ValidationError('idempotencyKey required');
  if (!input.address?.trim()) throw new ValidationError('address required');
  const amount = parsePositive(input.amount, 'amount');
  const asset: any = await Asset.findOne({ symbol: input.asset }).lean();
  if (!asset?.enabled || asset.type !== 'crypto') throw new NotFound(`withdrawable asset ${input.asset} not found`);
  if (amount < BigInt(asset.minWithdraw)) throw new ValidationError(`amount below minWithdraw ${asset.minWithdraw}`);
  const user: any = await User.findById(input.userId).lean();
  if (!user) throw new NotFound('user not found');
  if (user.status !== 'active') throw new Forbidden('account is not active');
  if (user.kycLevel < MIN_KYC_LEVEL_TO_WITHDRAW) throw new Forbidden('KYC required to withdraw');
  if (user.withdrawLockedUntil && new Date(user.withdrawLockedUntil) > new Date()) {
    throw new Forbidden('withdrawals are locked for 24 hours after a password or 2FA change');
  }
  if (!validateAddress(asset.chain, input.address.trim(), network.testnet)) throw new ValidationError(`invalid ${asset.chain} address`);
  const fee = BigInt(asset.withdrawFee);
  const total = amount + fee;
  const requestHash = sha({ a: input.asset, ad: input.address, m: input.memo ?? null, am: amount.toString() });
  await ensureAccount({ userId: input.userId }, input.asset);

  return withTxn(async (session) => {
    const existing: any = await Withdrawal.findOne({ userId: input.userId, idempotencyKey: input.idempotencyKey }).session(session).lean();
    if (existing) {
      if (existing.requestHash !== requestHash) throw new IdempotencyMismatch('idempotency key reused with a different request');
      return existing;
    }
    const _id = new Types.ObjectId();
    const doc = {
      _id, userId: new Types.ObjectId(input.userId), asset: input.asset, address: input.address.trim(), memo: input.memo,
      amount: amount.toString(), fee: fee.toString(), lockedAmount: total.toString(), status: 'pending',
      riskFlags: [], idempotencyKey: input.idempotencyKey, requestHash, version: 0,
    };
    await Withdrawal.create([doc], { session });
    await lockFunds(input.userId, input.asset, total, _id.toString(), {
      session, refType: 'withdrawal', type: 'withdraw', idempotencyKey: `withdraw-lock:${_id}`,
    });
    return doc;
  }, { lockKeys: [userKey(input.userId, input.asset)] });
}

export async function requireAdmin(session: ClientSession, adminId: string, ownerId: unknown) {
  const admin: any = await User.findById(adminId).session(session).lean();
  if (!admin || admin.role !== 'admin' || admin.status !== 'active') throw new Forbidden('admin role required');
  if (String(ownerId) === adminId) throw new Forbidden('cannot approve your own withdrawal'); // four-eyes
}

export async function approveWithdraw(withdrawalId: string, adminId: string) {
  return withTxn(async (session) => {
    const w: any = await Withdrawal.findById(withdrawalId).session(session);
    if (!w) throw new NotFound('withdrawal not found');
    await requireAdmin(session, adminId, w.userId);
    if (w.status === 'approved') return { status: 'approved' }; // idempotent
    if (w.status !== 'pending') throw new Conflict(`withdrawal is ${w.status}`);
    if (w.riskFlags?.length) throw new Conflict(`withdrawal has risk flags: ${w.riskFlags.join(',')}`);
    await updateVersioned(Withdrawal, w, { status: 'approved', approvedBy: new Types.ObjectId(adminId), approvedAt: new Date() }, session);
    await audit(session, adminId, 'withdrawal.approve', withdrawalId, { status: 'pending' }, { status: 'approved' });
    return { status: 'approved' };
  });
}

export async function markBroadcast(withdrawalId: string, txHash: string) {
  return withTxn(async (session) => {
    const w: any = await Withdrawal.findById(withdrawalId).session(session);
    if (!w) throw new NotFound('withdrawal not found');
    if (w.status === 'broadcast') return { status: 'broadcast' };
    if (w.status !== 'approved') throw new Conflict(`withdrawal is ${w.status}`);
    await updateVersioned(Withdrawal, w, { status: 'broadcast', txHash }, session);
    return { status: 'broadcast' };
  });
}

/** Chain confirmed the payout: burn the user's locked funds, reduce treasury, book the fee. */
export async function completeWithdrawal(withdrawalId: string, txHash?: string) {
  const pre: any = await Withdrawal.findById(withdrawalId).lean();
  if (!pre) throw new NotFound('withdrawal not found');
  await ensureAccount({ system: 'hot_wallet' }, pre.asset);
  await ensureAccount({ system: 'fee_revenue' }, pre.asset);
  return withTxn(async (session) => {
    const w: any = await Withdrawal.findById(withdrawalId).session(session);
    if (w.status === 'completed') return { status: 'completed' };
    if (w.status !== 'approved' && w.status !== 'broadcast') throw new Conflict(`withdrawal is ${w.status}`);
    const amount = BigInt(w.amount);
    const fee = BigInt(w.fee);
    const user = await getAccount(session, { userId: String(w.userId) }, w.asset);
    const hot = await getAccount(session, { system: 'hot_wallet' }, w.asset);
    const feeRev = await getAccount(session, { system: 'fee_revenue' }, w.asset);
    await post(session, {
      idempotencyKey: `withdraw-complete:${withdrawalId}`,
      type: 'withdraw',
      refType: 'withdrawal',
      refId: withdrawalId,
      legs: [
        { accountId: user._id, bucket: 'locked', direction: 'debit', amount: amount + fee },
        { accountId: hot._id, bucket: 'available', direction: 'credit', amount }, // treasury asset decreases
        { accountId: feeRev._id, bucket: 'available', direction: 'credit', amount: fee },
      ],
    });
    await updateVersioned(Withdrawal, w, { status: 'completed', lockedAmount: '0', txHash: txHash ?? w.txHash }, session);
    return { status: 'completed' };
  }, { lockKeys: [userKey(pre.userId, pre.asset)] });
}

export async function rejectWithdrawal(withdrawalId: string, adminId: string, reason: string) {
  const pre: any = await Withdrawal.findById(withdrawalId).lean();
  if (!pre) throw new NotFound('withdrawal not found');
  return withTxn(async (session) => {
    const w: any = await Withdrawal.findById(withdrawalId).session(session);
    await requireAdmin(session, adminId, w.userId);
    if (w.status === 'rejected') return { status: 'rejected' };
    if (w.status !== 'pending' && w.status !== 'approved') throw new Conflict(`withdrawal is ${w.status} and can no longer be rejected`);
    await unlockFunds(w.userId, w.asset, BigInt(w.lockedAmount), withdrawalId, {
      session, refType: 'withdrawal', type: 'withdraw', idempotencyKey: `withdraw-unlock:${withdrawalId}`,
    });
    await updateVersioned(Withdrawal, w, { status: 'rejected', rejectReason: reason, lockedAmount: '0' }, session);
    await audit(session, adminId, 'withdrawal.reject', withdrawalId, { status: w.status }, { status: 'rejected', reason });
    return { status: 'rejected' };
  }, { lockKeys: [userKey(pre.userId, pre.asset)] });
}
