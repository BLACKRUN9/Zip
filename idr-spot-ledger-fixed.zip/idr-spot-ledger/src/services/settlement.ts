import { Types } from 'mongoose';
import type { ClientSession } from 'mongoose';
import { Asset, Market, Order, Trade } from '../db/models.ts';
import { runIn, updateVersioned } from '../db/txn.ts';
import { Conflict, InvariantViolation, NotFound } from '../errors.ts';
import { feeFloor, parsePositive, quoteAmount } from '../money.ts';
import { ensureAccount, getAccount, ownerKey, post, unlockFunds } from './ledger.ts';
import type { Leg } from './ledger.ts';
import { applyOrderCanceled } from './orders.ts';
import { applyTradeToCandles } from '../marketdata/candleStore.ts';

export interface TradeInput {
  marketId: string;
  seq: number; // engine event sequence of the trade; (marketId, seq) is the idempotency key
  price: string;
  qty: string;
  takerOrderId: string;
  makerOrderId: string;
}

/**
 * Settle ONE fill atomically: ledger legs, both orders, and the trade record commit together or not at all.
 *
 *  Fees are charged in the QUOTE asset (IDR) on both sides, floored per fill.
 *    buyer  pays   quoteQty + buyerFee   (from the order's locked reserve)
 *    seller gets   quoteQty - sellerFee
 *    fee_revenue   buyerFee + sellerFee
 *  Same input twice => same trade, no double movement.
 */
export async function settleTrade(input: TradeInput, opts: { session?: ClientSession } = {}) {
  const price = parsePositive(input.price, 'price');
  const qty = parsePositive(input.qty, 'qty');

  // pre-read (immutable fields only) so accounts exist and in-process locks can be taken before the transaction
  const [takerPre, makerPre]: any[] = await Promise.all([Order.findById(input.takerOrderId).lean(), Order.findById(input.makerOrderId).lean()]);
  if (!takerPre || !makerPre) throw new NotFound('order not found for trade');
  const marketPre: any = await Market.findById(input.marketId).lean();
  if (!marketPre) throw new NotFound('market not found for trade');
  const buyPre = takerPre.side === 'buy' ? takerPre : makerPre;
  const sellPre = takerPre.side === 'buy' ? makerPre : takerPre;
  const buyerId = buyPre.userId.toString();
  const sellerId = sellPre.userId.toString();
  await ensureAccount({ userId: buyerId }, marketPre.base);
  await ensureAccount({ userId: sellerId }, marketPre.quote);
  await ensureAccount({ system: 'fee_revenue' }, marketPre.quote);

  const lockKeys = [
    `acct:${ownerKey({ userId: buyerId })}:${marketPre.quote}`,
    `acct:${ownerKey({ userId: buyerId })}:${marketPre.base}`,
    `acct:${ownerKey({ userId: sellerId })}:${marketPre.quote}`,
    `acct:${ownerKey({ userId: sellerId })}:${marketPre.base}`,
    `acct:${ownerKey({ system: 'fee_revenue' })}:${marketPre.quote}`,
  ];

  return runIn(
    opts.session,
    async (session) => {
      const existing = await Trade.findOne({ marketId: input.marketId, seq: input.seq }).session(session).lean();
      if (existing) return existing; // idempotent replay

      const market: any = await Market.findById(input.marketId).session(session).lean();
      const taker: any = await Order.findById(input.takerOrderId).session(session);
      const maker: any = await Order.findById(input.makerOrderId).session(session);
      if (!market || !taker || !maker) throw new NotFound('market/order vanished');
      if (taker.marketId.toString() !== input.marketId || maker.marketId.toString() !== input.marketId) throw new InvariantViolation('order/market mismatch');
      for (const o of [taker, maker]) {
        if (o.status !== 'new' && o.status !== 'partial') throw new Conflict(`order ${o._id} is ${o.status}, cannot fill`);
        if (BigInt(o.filledQty) + qty > BigInt(o.qty)) throw new InvariantViolation(`fill exceeds order ${o._id} quantity`);
      }
      if (taker.side === maker.side) throw new InvariantViolation('both orders on the same side');
      if (taker.userId.toString() === maker.userId.toString()) throw new InvariantViolation('self-trade must be prevented by the engine');
      if (maker.type !== 'limit' || BigInt(maker.price) !== price) throw new InvariantViolation('fills must execute at the maker limit price');

      const buy = taker.side === 'buy' ? taker : maker;
      const sell = taker.side === 'buy' ? maker : taker;
      if (price > BigInt(buy.price)) throw new InvariantViolation('fill price above buyer limit/cap');
      if (sell.type === 'limit' && price < BigInt(sell.price)) throw new InvariantViolation('fill price below seller limit');

      const base: any = await Asset.findOne({ symbol: market.base }).session(session).lean();
      const quoteQty = quoteAmount(price, qty, base.decimals);
      if (quoteQty < 1n) throw new InvariantViolation('zero-value fill (misconfigured lot/tick)');

      const buyerFee = feeFloor(quoteQty, buy._id.equals(taker._id) ? taker.takerFeeBps : maker.makerFeeBps);
      const sellerFee = feeFloor(quoteQty, sell._id.equals(taker._id) ? taker.takerFeeBps : maker.makerFeeBps);
      const buyerPays = quoteQty + buyerFee;
      if (BigInt(buy.lockedAmount) < buyerPays) throw new InvariantViolation(`buyer reserve ${buy.lockedAmount} < ${buyerPays}`);
      if (BigInt(sell.lockedAmount) < qty) throw new InvariantViolation(`seller reserve ${sell.lockedAmount} < ${qty}`);

      const buyerQuote = await getAccount(session, { userId: buyerId }, market.quote);
      const buyerBase = await getAccount(session, { userId: buyerId }, market.base);
      const sellerQuote = await getAccount(session, { userId: sellerId }, market.quote);
      const sellerBase = await getAccount(session, { userId: sellerId }, market.base);
      const feeRev = await getAccount(session, { system: 'fee_revenue' }, market.quote);

      const legs: Leg[] = [
        // quote asset: debit == credit == quoteQty + buyerFee
        { accountId: buyerQuote._id, bucket: 'locked', direction: 'debit', amount: buyerPays },
        { accountId: sellerQuote._id, bucket: 'available', direction: 'credit', amount: quoteQty - sellerFee },
        { accountId: feeRev._id, bucket: 'available', direction: 'credit', amount: buyerFee + sellerFee },
        // base asset
        { accountId: sellerBase._id, bucket: 'locked', direction: 'debit', amount: qty },
        { accountId: buyerBase._id, bucket: 'available', direction: 'credit', amount: qty },
      ];
      await post(session, {
        idempotencyKey: `trade:${input.marketId}:${input.seq}`,
        type: 'trade',
        refType: 'trade',
        refId: `${input.marketId}:${input.seq}`,
        legs,
      });

      const takerFee = taker._id.equals(buy._id) ? buyerFee : sellerFee;
      const makerFee = maker._id.equals(buy._id) ? buyerFee : sellerFee;
      const executedAt = new Date();
      const [trade] = await Trade.create(
        [{
          marketId: market._id,
          marketSymbol: market.symbol,
          price: price.toString(),
          qty: qty.toString(),
          quoteQty: quoteQty.toString(),
          takerOrderId: taker._id,
          makerOrderId: maker._id,
          takerUserId: taker.userId,
          makerUserId: maker.userId,
          takerSide: taker.side,
          takerFee: takerFee.toString(),
          makerFee: makerFee.toString(),
          seq: input.seq,
          executedAt,
        }],
        { session },
      );
      // candles commit atomically with the trade: a trade is in the chart exactly once, even across crashes/replays
      await applyTradeToCandles(session, market.symbol, { price, qty, quoteQty, seq: input.seq, time: executedAt.getTime() });

      for (const o of [buy, sell]) {
        const isBuy = o._id.equals(buy._id);
        const consumed = isBuy ? buyerPays : qty;
        const filled = BigInt(o.filledQty) + qty;
        const fullyFilled = filled === BigInt(o.qty);
        const lockedLeft = BigInt(o.lockedAmount) - consumed;
        await updateVersioned(Order, o, {
          filledQty: filled.toString(),
          quoteFilled: (BigInt(o.quoteFilled) + quoteQty).toString(),
          feePaid: (BigInt(o.feePaid) + (isBuy ? buyerFee : sellerFee)).toString(),
          lockedAmount: (fullyFilled ? 0n : lockedLeft).toString(),
          status: fullyFilled ? 'filled' : 'partial',
        }, session);
        if (fullyFilled && lockedLeft > 0n) {
          // release the unused part of the reserve (price improvement + unused fee buffer)
          await unlockFunds(o.userId, o.lockAsset, lockedLeft, o._id.toString(), {
            session, refType: 'order', type: 'order_unlock', idempotencyKey: `order-unlock:${o._id}`,
          });
        }
      }
      return trade.toObject();
    },
    { lockKeys },
  );
}

export interface EngineEventLike {
  marketId: string | Types.ObjectId;
  seq: number;
  type: string;
  payload: any;
}

/**
 * Consume one engine event. Every branch is idempotent, so a consumer may replay events after a crash.
 * (Events must be applied in seq order per market.)
 */
export async function applyEngineEvent(ev: EngineEventLike): Promise<void> {
  switch (ev.type) {
    case 'order_accepted':
      await Order.updateOne({ _id: ev.payload.id, seq: null }, { $set: { seq: ev.seq, engineStatus: 'submitted' } });
      return;
    case 'trade':
      await settleTrade({
        marketId: ev.marketId.toString(),
        seq: ev.seq,
        price: ev.payload.price,
        qty: ev.payload.qty,
        takerOrderId: ev.payload.takerOrderId,
        makerOrderId: ev.payload.makerOrderId,
      });
      return;
    case 'order_canceled':
      await applyOrderCanceled(ev.payload.orderId, 'canceled');
      return;
    default:
      return; // cancel_requested etc. need no ledger action
  }
}
