import { ApiKey, User } from '../db/models.ts';
import { AppError, Conflict, Forbidden, NotFound, ValidationError } from '../errors.ts';
import { box, newToken, verifySignature } from '../security/crypto.ts';
import { writeAudit } from './audit.ts';

export const MAX_ACTIVE_KEYS = 10;
export const SIGNATURE_WINDOW_MS = 30_000;
const PERMS = ['read', 'trade'];

export async function createApiKey(userId: string, input: { label?: string; permissions: unknown; ipWhitelist?: unknown }) {
  const permissions = Array.isArray(input.permissions) ? [...new Set(input.permissions.map(String))] : [];
  if (!permissions.length || !permissions.every((p) => PERMS.includes(p))) throw new ValidationError('permissions must be a non-empty subset of read, trade (withdraw is never allowed on API keys)');
  const ipWhitelist = Array.isArray(input.ipWhitelist) ? input.ipWhitelist.map(String).slice(0, 20) : [];
  if (permissions.includes('trade') && ipWhitelist.length === 0) throw new ValidationError('trade keys require an IP whitelist');
  if ((await ApiKey.countDocuments({ userId, revokedAt: null })) >= MAX_ACTIVE_KEYS) throw new Conflict(`at most ${MAX_ACTIVE_KEYS} active API keys`);
  const keyId = `ak_${newToken(12)}`;
  const secret = newToken(32);
  await ApiKey.create({ userId, keyId, label: String(input.label ?? '').slice(0, 50), secretEnc: box().encrypt(secret, `apikey:${keyId}`), permissions, ipWhitelist });
  await writeAudit(userId, 'apikey.created', keyId, undefined, { permissions, ipWhitelist });
  return { keyId, secret, permissions, ipWhitelist }; // the secret is shown exactly once
}

export async function listApiKeys(userId: string) {
  const rows: any[] = await ApiKey.find({ userId, revokedAt: null }).sort({ _id: -1 }).lean();
  return rows.map((k) => ({ keyId: k.keyId, label: k.label, permissions: k.permissions, ipWhitelist: k.ipWhitelist, lastUsedAt: k.lastUsedAt, createdAt: k.createdAt }));
}

export async function revokeApiKey(userId: string, keyId: string) {
  const r = await ApiKey.updateOne({ userId, keyId, revokedAt: null }, { $set: { revokedAt: new Date() } });
  if (r.matchedCount !== 1) throw new NotFound('api key not found');
  await writeAudit(userId, 'apikey.revoked', keyId);
}

/**
 * Signature = HMAC-SHA256(secret, "<ts>\n<METHOD>\n<path+query>\n<sha256(body)>").
 * Replay is bounded by the 30s timestamp window, and every money-moving endpoint also needs an Idempotency-Key.
 */
export async function authenticateApiRequest(p: {
  keyId: string; timestamp?: string; signature?: string; method: string; path: string; body: string; ip?: string; now?: number;
}) {
  const bad = () => new AppError('INVALID_TOKEN', 'invalid API credentials');
  const ts = Number(p.timestamp);
  if (!p.keyId || !p.signature || !Number.isFinite(ts)) throw bad();
  if (Math.abs((p.now ?? Date.now()) - ts) > SIGNATURE_WINDOW_MS) throw bad();
  const key: any = await ApiKey.findOne({ keyId: p.keyId, revokedAt: null }).lean();
  if (!key) throw bad();
  const secret = box().decrypt(key.secretEnc, `apikey:${key.keyId}`);
  if (!verifySignature(secret, { timestamp: p.timestamp!, method: p.method, path: p.path, body: p.body }, p.signature)) throw bad();
  if (key.ipWhitelist?.length && !key.ipWhitelist.includes(p.ip)) throw new Forbidden('IP not whitelisted for this API key');
  const user: any = await User.findById(key.userId).lean();
  if (!user || user.status === 'closed') throw bad();
  void ApiKey.updateOne({ _id: key._id }, { $set: { lastUsedAt: new Date() } }).exec();
  return { user, permissions: key.permissions as string[], keyId: key.keyId as string };
}
