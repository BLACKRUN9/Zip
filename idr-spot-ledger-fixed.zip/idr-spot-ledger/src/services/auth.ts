import { randomBytes } from 'node:crypto';
import { Types } from 'mongoose';
import { PasswordReset, Session, User } from '../db/models.ts';
import { isDuplicateKey } from '../db/txn.ts';
import { AppError, Conflict, Forbidden, NotFound } from '../errors.ts';
import { box, dummyHash, hashPassword, needsRehash, newToken, sha256Hex, verifyPassword } from '../security/crypto.ts';
import { normalizeEmail, validatePassword } from '../security/policy.ts';
import { generateTotpSecret, otpauthUri, verifyTotp } from '../security/totp.ts';
import { ensureUserAccounts } from './ledger.ts';
import { writeAudit } from './audit.ts';

export const ACCESS_TTL_MS = 15 * 60_000;
export const REFRESH_TTL_MS = 30 * 24 * 3600_000;
export const MAX_FAILED_LOGINS = 5;
export const LOCK_MS = 15 * 60_000;
export const SECURITY_COOLDOWN_MS = 24 * 3600_000;
export const RESET_TTL_MS = 30 * 60_000;
export const ISSUER = 'IDR Exchange';

let clock: () => number = () => Date.now();
/** Test hook. */
export function setClock(fn: () => number) { clock = fn; }

export interface Mailer { sendPasswordReset(email: string, token: string): Promise<void> }
export interface ClientMeta { ip?: string; userAgent?: string }
export interface Tokens { sessionId: string; accessToken: string; refreshToken: string; accessExpiresAt: Date; refreshExpiresAt: Date }

const invalidCreds = () => new AppError('INVALID_CREDENTIALS', 'invalid email, password or code');
const invalidToken = () => new AppError('INVALID_TOKEN', 'invalid or expired token');

// ------------------------------------------------------------------ registration
export async function register(input: { email: unknown; password: unknown; phone?: string }) {
  const email = normalizeEmail(input.email);
  const password = validatePassword(input.password, email);
  const passwordHash = await hashPassword(password);
  try {
    const u: any = await User.create({ email, phone: input.phone, passwordHash, status: 'active', kycLevel: 0, role: 'user', passwordChangedAt: new Date(clock()) });
    await ensureUserAccounts(u._id);
    return { id: u._id.toString(), email };
  } catch (e) {
    if (isDuplicateKey(e)) throw new Conflict('email already registered');
    throw e;
  }
}

// ------------------------------------------------------------------ sessions
async function createSession(userId: Types.ObjectId | string, meta: ClientMeta, familyId?: string): Promise<Tokens> {
  const access = newToken(), refresh = newToken(), now = clock();
  const s: any = await Session.create({
    userId, familyId: familyId ?? newToken(12), accessHash: sha256Hex(access), refreshHash: sha256Hex(refresh),
    accessExpiresAt: new Date(now + ACCESS_TTL_MS), refreshExpiresAt: new Date(now + REFRESH_TTL_MS), ip: meta.ip, userAgent: meta.userAgent,
  });
  return { sessionId: s._id.toString(), accessToken: access, refreshToken: refresh, accessExpiresAt: s.accessExpiresAt, refreshExpiresAt: s.refreshExpiresAt };
}

export async function authenticateAccess(accessToken: string) {
  const s: any = await Session.findOne({ accessHash: sha256Hex(accessToken), revokedAt: null, accessExpiresAt: { $gt: new Date(clock()) } }).lean();
  if (!s) throw invalidToken();
  const user: any = await User.findById(s.userId).lean();
  if (!user || user.status === 'closed') throw invalidToken();
  return { user, session: s };
}

/** Rotating refresh tokens with reuse detection: presenting an already-used refresh token revokes the whole login family. */
export async function refresh(refreshToken: string, meta: ClientMeta = {}): Promise<Tokens> {
  const s: any = await Session.findOne({ refreshHash: sha256Hex(refreshToken) }).lean();
  if (!s) throw invalidToken();
  if (s.rotatedAt || s.revokedAt) {
    await Session.updateMany({ familyId: s.familyId, revokedAt: null }, { $set: { revokedAt: new Date(clock()) } });
    await writeAudit(s.userId, 'auth.refresh_reuse_detected', String(s._id), undefined, { familyId: s.familyId }, meta);
    throw invalidToken();
  }
  if (new Date(s.refreshExpiresAt).getTime() <= clock()) throw invalidToken();
  const user: any = await User.findById(s.userId).lean();
  if (!user || user.status === 'closed') throw invalidToken();
  const now = new Date(clock());
  // claim atomically: of two concurrent refreshes only one wins
  const claimed = await Session.findOneAndUpdate({ _id: s._id, rotatedAt: null, revokedAt: null }, { $set: { rotatedAt: now, revokedAt: now } });
  if (!claimed) {
    await Session.updateMany({ familyId: s.familyId, revokedAt: null }, { $set: { revokedAt: now } });
    throw invalidToken();
  }
  return createSession(s.userId, meta, s.familyId);
}

export async function logout(sessionId: string) {
  await Session.updateOne({ _id: sessionId, revokedAt: null }, { $set: { revokedAt: new Date(clock()) } });
}
export async function revokeAllSessions(userId: string, exceptSessionId?: string) {
  const f: any = { userId, revokedAt: null };
  if (exceptSessionId) f._id = { $ne: exceptSessionId };
  await Session.updateMany(f, { $set: { revokedAt: new Date(clock()) } });
}
export async function listSessions(userId: string) {
  const rows: any[] = await Session.find({ userId, revokedAt: null, refreshExpiresAt: { $gt: new Date(clock()) } }).sort({ _id: -1 }).lean();
  return rows.map((s) => ({ id: String(s._id), ip: s.ip, userAgent: s.userAgent, createdAt: s.createdAt, lastUsedAt: s.lastUsedAt }));
}
export async function revokeSession(userId: string, sessionId: string) {
  const r = await Session.updateOne({ _id: sessionId, userId, revokedAt: null }, { $set: { revokedAt: new Date(clock()) } });
  if (r.matchedCount !== 1) throw new NotFound('session not found');
}

// ------------------------------------------------------------------ second factor
const RECOVERY_RE = /^[0-9a-f]{5}-[0-9a-f]{5}$/;
/**
 * TOTP codes are single-use per 30s step (replay protection). Recovery codes are single-use forever.
 * Returns true/false; never throws on a wrong code.
 */
export async function verifySecondFactor(userId: string | Types.ObjectId, code: unknown, opts: { allowRecovery?: boolean } = {}): Promise<boolean> {
  if (typeof code !== 'string') return false;
  const u: any = await User.findById(userId).lean();
  if (!u?.twoFA?.enabled || !u.twoFA.secretEnc) return false;
  if (/^\d{6}$/.test(code)) {
    const secret = box().decrypt(u.twoFA.secretEnc, `totp:${u._id}`);
    const counter = verifyTotp(secret, code, clock());
    if (counter === null) return false;
    const r = await User.updateOne({ _id: u._id, 'twoFA.lastCounter': { $lt: counter } }, { $set: { 'twoFA.lastCounter': counter } });
    return r.modifiedCount === 1; // 0 => this step (or a later one) was already used: replay
  }
  if (opts.allowRecovery && RECOVERY_RE.test(code)) {
    const h = sha256Hex(code);
    const r = await User.updateOne({ _id: u._id, 'twoFA.recoveryHashes': h }, { $pull: { 'twoFA.recoveryHashes': h } });
    return r.modifiedCount === 1;
  }
  return false;
}

// ------------------------------------------------------------------ login
export async function login(input: { email: unknown; password: unknown; code?: string } & ClientMeta): Promise<Tokens> {
  let email: string;
  try { email = normalizeEmail(input.email); } catch { throw invalidCreds(); }
  const password = typeof input.password === 'string' ? input.password : '';
  const user: any = await User.findOne({ email }).lean();
  if (!user) {
    await verifyPassword(password, await dummyHash()); // equalise timing with the real path
    throw invalidCreds();
  }
  if (user.lockedUntil && new Date(user.lockedUntil).getTime() > clock()) {
    throw new AppError('ACCOUNT_LOCKED', 'too many failed attempts, try again later');
  }
  const fail = async (): Promise<never> => {
    const u: any = await User.findOneAndUpdate({ _id: user._id }, { $inc: { failedLogins: 1 } }, { new: true });
    if (u.failedLogins >= MAX_FAILED_LOGINS) {
      await User.updateOne({ _id: user._id }, { $set: { lockedUntil: new Date(clock() + LOCK_MS), failedLogins: 0 } });
      await writeAudit(user._id, 'auth.account_locked', String(user._id), undefined, undefined, input);
    }
    throw invalidCreds();
  };
  if (user.status === 'closed' || !(await verifyPassword(password, user.passwordHash))) return fail();
  if (user.twoFA?.enabled) {
    if (!input.code) throw new AppError('TWOFA_REQUIRED', 'two-factor code required');
    if (!(await verifySecondFactor(user._id, input.code, { allowRecovery: true }))) return fail();
  }
  const set: any = { failedLogins: 0, lockedUntil: null, lastLoginAt: new Date(clock()) };
  if (needsRehash(user.passwordHash)) set.passwordHash = await hashPassword(password);
  await User.updateOne({ _id: user._id }, { $set: set });
  await writeAudit(user._id, 'auth.login', String(user._id), undefined, undefined, input);
  return createSession(user._id, input);
}

// ------------------------------------------------------------------ 2FA management
export async function begin2FASetup(userId: string) {
  const u: any = await User.findById(userId).lean();
  if (!u) throw new NotFound('user not found');
  if (u.twoFA?.enabled) throw new Conflict('2FA already enabled');
  const secret = generateTotpSecret();
  await User.updateOne({ _id: userId }, { $set: { 'twoFA.secretEnc': box().encrypt(secret, `totp:${userId}`), 'twoFA.lastCounter': 0 } });
  return { secret, otpauthUri: otpauthUri(u.email, secret, ISSUER) };
}

export async function confirm2FA(userId: string, code: string) {
  const u: any = await User.findById(userId).lean();
  if (!u) throw new NotFound('user not found');
  if (u.twoFA?.enabled) throw new Conflict('2FA already enabled');
  if (!u.twoFA?.secretEnc) throw new Conflict('start 2FA setup first');
  const secret = box().decrypt(u.twoFA.secretEnc, `totp:${userId}`);
  const counter = verifyTotp(secret, String(code), clock());
  if (counter === null) throw new AppError('TWOFA_INVALID', 'invalid code');
  const recoveryCodes = Array.from({ length: 10 }, () => { const h = randomBytes(5).toString('hex'); return `${h.slice(0, 5)}-${h.slice(5)}`; }); // 40 bits each, single use
  await User.updateOne({ _id: userId }, { $set: { 'twoFA.enabled': true, 'twoFA.lastCounter': counter, 'twoFA.recoveryHashes': recoveryCodes.map(sha256Hex) } });
  await writeAudit(userId, '2fa.enabled', userId);
  return { recoveryCodes }; // shown once
}

export async function disable2FA(userId: string, password: string, code: string, keepSessionId?: string) {
  const u: any = await User.findById(userId).lean();
  if (!u?.twoFA?.enabled) throw new Conflict('2FA is not enabled');
  if (!(await verifyPassword(String(password), u.passwordHash))) throw invalidCreds();
  if (!(await verifySecondFactor(userId, code, { allowRecovery: true }))) throw new AppError('TWOFA_INVALID', 'invalid code');
  await User.updateOne({ _id: userId }, {
    $set: { 'twoFA.enabled': false, 'twoFA.recoveryHashes': [], withdrawLockedUntil: new Date(clock() + SECURITY_COOLDOWN_MS) },
    $unset: { 'twoFA.secretEnc': '' },
  });
  await revokeAllSessions(userId, keepSessionId);
  await writeAudit(userId, '2fa.disabled', userId);
}

// ------------------------------------------------------------------ passwords
export async function changePassword(userId: string, current: string, next: string, keepSessionId?: string) {
  const u: any = await User.findById(userId).lean();
  if (!u) throw new NotFound('user not found');
  if (!(await verifyPassword(String(current), u.passwordHash))) throw invalidCreds();
  const pw = validatePassword(next, u.email);
  await User.updateOne({ _id: userId }, { $set: { passwordHash: await hashPassword(pw), passwordChangedAt: new Date(clock()), withdrawLockedUntil: new Date(clock() + SECURITY_COOLDOWN_MS) } });
  await revokeAllSessions(userId, keepSessionId);
  await writeAudit(userId, 'password.changed', userId);
}

/** Always resolves the same way whether or not the email exists (no account enumeration). */
export async function forgotPassword(emailInput: unknown, mailer: Mailer): Promise<void> {
  let email: string;
  try { email = normalizeEmail(emailInput); } catch { return; }
  const u: any = await User.findOne({ email }).lean();
  if (!u || u.status === 'closed') return;
  await PasswordReset.updateMany({ userId: u._id, usedAt: null }, { $set: { usedAt: new Date(clock()) } }); // invalidate older links
  const token = newToken();
  await PasswordReset.create({ userId: u._id, tokenHash: sha256Hex(token), expiresAt: new Date(clock() + RESET_TTL_MS) });
  try { await mailer.sendPasswordReset(email, token); } catch (e) { console.error(JSON.stringify({ level: 'error', msg: 'reset mail failed', err: String(e) })); }
}

export async function resetPassword(token: string, newPassword: unknown) {
  const hash = sha256Hex(String(token));
  const pre: any = await PasswordReset.findOne({ tokenHash: hash, usedAt: null, expiresAt: { $gt: new Date(clock()) } }).lean();
  if (!pre) throw invalidToken();
  const u: any = await User.findById(pre.userId).lean();
  const pw = validatePassword(newPassword, u?.email); // validate BEFORE burning the token
  const claimed = await PasswordReset.findOneAndUpdate({ _id: pre._id, usedAt: null }, { $set: { usedAt: new Date(clock()) } });
  if (!claimed) throw invalidToken();
  await User.updateOne({ _id: pre.userId }, {
    $set: { passwordHash: await hashPassword(pw), passwordChangedAt: new Date(clock()), failedLogins: 0, lockedUntil: null, withdrawLockedUntil: new Date(clock() + SECURITY_COOLDOWN_MS) },
  });
  await revokeAllSessions(String(pre.userId));
  await writeAudit(pre.userId, 'password.reset', String(pre.userId));
}

export const requireActive = (user: any) => {
  if (user.status !== 'active') throw new Forbidden('account is not active');
};
