import { Account, FiatTransaction, LedgerEntry, Order, Withdrawal } from '../db/models.ts';

export interface Discrepancy {
  kind:
    | 'account_balance_mismatch'
    | 'balance_after_mismatch'
    | 'unbalanced_transaction'
    | 'accounting_equation'
    | 'order_lock_mismatch'
    | 'wallet_mismatch'
    | 'negative_balance';
  detail: string;
}

export interface ReconcileOptions {
  /** Real treasury balance per asset (from node / bank API), compared against the hot_wallet account. */
  walletBalance?: (asset: string) => Promise<bigint | undefined> | bigint | undefined;
  /** Funds the exchange really holds per asset (chain custody / bank balance). The ledger must never owe more than this. */
  custodyBalance?: (asset: string) => Promise<bigint | undefined> | bigint | undefined;
  alert?: (d: Discrepancy[]) => void | Promise<void>;
}

/**
 * Independent audit of the books. Recomputes everything from the immutable ledger and compares with
 * the mutable account balances. Run on a schedule (and after incidents); page someone if it returns anything.
 * Loads aggregates in-app (BigInt) because balances are strings; batch/shard this for large datasets.
 */
export async function reconcile(opts: ReconcileOptions = {}): Promise<Discrepancy[]> {
  const out: Discrepancy[] = [];
  const accounts: any[] = await Account.find({}).lean();
  const acc = new Map<string, any>(accounts.map((a) => [a._id.toString(), a]));
  const run = new Map<string, { available: bigint; locked: bigint }>(accounts.map((a) => [a._id.toString(), { available: 0n, locked: 0n }]));
  const txSums = new Map<string, Map<string, { debit: bigint; credit: bigint }>>();

  // 1) replay the ledger in insertion order
  for await (const e of LedgerEntry.find({}).sort({ _id: 1 }).lean().cursor() as any) {
    const a = acc.get(e.accountId.toString());
    const st = run.get(e.accountId.toString());
    if (!a || !st) { out.push({ kind: 'account_balance_mismatch', detail: `entry ${e._id} references unknown account` }); continue; }
    const amount = BigInt(e.amount);
    st[e.bucket as 'available' | 'locked'] += e.direction === a.normalSide ? amount : -amount;
    if (st.available < 0n || st.locked < 0n) out.push({ kind: 'negative_balance', detail: `${a.owner}/${a.asset} negative after entry ${e._id}` });
    if (st.available.toString() !== e.balanceAfterAvailable || st.locked.toString() !== e.balanceAfterLocked) {
      out.push({ kind: 'balance_after_mismatch', detail: `entry ${e._id} (${a.owner}/${a.asset}) snapshot differs from replay` });
    }
    const perAsset = txSums.get(e.txId) ?? new Map();
    const s = perAsset.get(e.asset) ?? { debit: 0n, credit: 0n };
    s[e.direction as 'debit' | 'credit'] += amount;
    perAsset.set(e.asset, s);
    txSums.set(e.txId, perAsset);
  }
  for (const [txId, perAsset] of txSums) {
    for (const [asset, s] of perAsset) {
      if (s.debit !== s.credit) out.push({ kind: 'unbalanced_transaction', detail: `tx ${txId} ${asset}: debit ${s.debit} != credit ${s.credit}` });
    }
  }

  // 2) account balances == replay
  for (const a of accounts) {
    const st = run.get(a._id.toString())!;
    if (st.available.toString() !== a.available || st.locked.toString() !== a.locked) {
      out.push({ kind: 'account_balance_mismatch', detail: `${a.owner}/${a.asset}: stored ${a.available}/${a.locked} vs ledger ${st.available}/${st.locked}` });
    }
  }

  // 3) accounting equation per asset: debit-normal accounts (treasury, suspense) == credit-normal (customers, fee revenue)
  const eq = new Map<string, { assets: bigint; liabilities: bigint }>();
  for (const a of accounts) {
    const e = eq.get(a.asset) ?? { assets: 0n, liabilities: 0n };
    const total = BigInt(a.available) + BigInt(a.locked);
    if (a.normalSide === 'debit') e.assets += total; else e.liabilities += total;
    eq.set(a.asset, e);
  }
  for (const [asset, e] of eq) {
    if (e.assets !== e.liabilities) out.push({ kind: 'accounting_equation', detail: `${asset}: assets ${e.assets} != liabilities ${e.liabilities}` });
  }

  // 4) every locked unit is explained by an open order or an in-flight withdrawal
  const expectedLocked = new Map<string, bigint>();
  const add = (userId: unknown, asset: string, v: bigint) => {
    const k = `u:${userId}|${asset}`;
    expectedLocked.set(k, (expectedLocked.get(k) ?? 0n) + v);
  };
  for await (const o of Order.find({ status: { $in: ['new', 'partial'] } }).lean().cursor() as any) add(o.userId, o.lockAsset, BigInt(o.lockedAmount));
  for await (const w of Withdrawal.find({ status: { $in: ['pending', 'approved', 'broadcast'] } }).lean().cursor() as any) add(w.userId, w.asset, BigInt(w.lockedAmount));
  for await (const f of FiatTransaction.find({ type: 'withdraw', status: { $in: ['pending', 'approved', 'processing'] } }).lean().cursor() as any) add(f.userId, 'IDR', BigInt(f.lockedAmount));
  for (const a of accounts) {
    if (a.normalSide !== 'credit' || !a.userId) continue;
    const want = expectedLocked.get(`u:${a.userId}|${a.asset}`) ?? 0n;
    if (BigInt(a.locked) !== want) out.push({ kind: 'order_lock_mismatch', detail: `${a.owner}/${a.asset}: locked ${a.locked} but open orders/withdrawals explain ${want}` });
  }

  // 5) treasury vs the real world
  if (opts.walletBalance) {
    for (const a of accounts.filter((x) => x.systemName === 'hot_wallet')) {
      const real = await opts.walletBalance(a.asset);
      if (real !== undefined && real !== BigInt(a.available)) out.push({ kind: 'wallet_mismatch', detail: `${a.asset}: ledger ${a.available} vs real ${real}` });
    }
  }

  if (opts.custodyBalance) {
    // coins already sent out on chain but whose withdrawal is not yet completed in the ledger are no longer in custody
    const inflight = new Map<string, bigint>();
    for await (const w of Withdrawal.find({ status: 'broadcast' }).lean().cursor() as any) inflight.set(w.asset, (inflight.get(w.asset) ?? 0n) + BigInt(w.amount));
    for (const a of accounts.filter((x) => x.systemName === 'hot_wallet')) {
      const held = await opts.custodyBalance(a.asset);
      const owed = BigInt(a.available);
      if (held !== undefined && held + (inflight.get(a.asset) ?? 0n) < owed) {
        out.push({ kind: 'wallet_mismatch', detail: `${a.asset}: INSOLVENT - ledger holds ${owed} for customers but custody has only ${held} (+${inflight.get(a.asset) ?? 0n} in flight)` });
      }
    }
  }

  if (out.length && opts.alert) await opts.alert(out);
  return out;
}
