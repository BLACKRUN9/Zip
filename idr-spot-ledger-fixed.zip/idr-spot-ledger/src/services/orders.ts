import { createHash } from 'node:crypto';
import { Types } from 'mongoose';
import type { ClientSession } from 'mongoose';
import { Asset, Market, Order, User } from '../db/models.ts';
import { runIn, updateVersioned, withTxn } from '../db/txn.ts';
import { AppError, Conflict, Forbidden, IdempotencyMismatch, NotFound, ValidationError } from '../errors.ts';
import { MIN_KYC_LEVEL_TO_TRADE } from '../config.ts';
import { feeCeil, parsePositive, quoteAmount, toAmountString } from '../money.ts';
import { ensureAccount, lockFunds, ownerKey, unlockFunds } from './ledger.ts';

export interface EngineOrder {
  id: string;
  marketId: string;
  userId: string;
  side: 'buy' | 'sell';
  type: 'limit' | 'market';
  tif: 'GTC' | 'IOC';
  price: string;
  qty: string;
}
/** The matching engine as seen by the order service. submit() MUST be idempotent per order id. */
export interface EngineGateway {
  submit(order: EngineOrder): Promise<void>;
  cancel(marketId: string, orderId: string): Promise<void>;
}

export interface PlaceOrderInput {
  userId: string;
  market: string; // e.g. BTC_IDR
  side: 'buy' | 'sell';
  type: 'limit' | 'market';
  tif?: 'GTC' | 'IOC';
  /** limit: price. market BUY: required protection cap (max price you accept). market SELL: omit. */
  price?: string;
  qty: string;
  clientOrderId?: string;
  idempotencyKey: string;
}

const sha = (x: unknown) => createHash('sha256').update(JSON.stringify(x)).digest('hex');
export const toEngineOrder = (o: any): EngineOrder => ({
  id: o._id.toString(),
  marketId: o.marketId.toString(),
  userId: o.userId.toString(),
  side: o.side,
  type: o.type,
  tif: o.tif,
  price: o.price,
  qty: o.qty,
});

export async function placeOrder(input: PlaceOrderInput, gateway?: EngineGateway) {
  if (!input.idempotencyKey || input.idempotencyKey.length > 128) throw new ValidationError('idempotencyKey required (<=128 chars)');
  if (input.side !== 'buy' && input.side !== 'sell') throw new ValidationError('side must be buy|sell');
  if (input.type !== 'limit' && input.type !== 'market') throw new ValidationError('type must be limit|market');
  const tif = input.type === 'market' ? 'IOC' : (input.tif ?? 'GTC');
  if (tif !== 'GTC' && tif !== 'IOC') throw new ValidationError('tif must be GTC|IOC');

  const market: any = await Market.findOne({ symbol: input.market.toUpperCase() }).lean();
  if (!market) throw new NotFound(`market ${input.market} not found`);
  if (market.status !== 'active') throw new AppError('MARKET_NOT_ACTIVE', `market ${market.symbol} is ${market.status}`);
  const base: any = await Asset.findOne({ symbol: market.base }).lean();
  if (!base) throw new NotFound(`asset ${market.base} not found`);
  const user: any = await User.findById(input.userId).lean();
  if (!user) throw new NotFound('user not found');
  if (user.status !== 'active') throw new Forbidden('account is not active');
  if (user.kycLevel < MIN_KYC_LEVEL_TO_TRADE) throw new Forbidden('KYC required to trade');

  const qty = parsePositive(input.qty, 'qty');
  const lot = BigInt(market.lotSize);
  const tick = BigInt(market.tickSize);
  if (qty % lot !== 0n) throw new ValidationError(`qty must be a multiple of lotSize ${lot}`);
  if (qty < BigInt(market.minQty)) throw new ValidationError(`qty below minQty ${market.minQty}`);

  // price handling
  let price = 0n;
  if (input.type === 'limit' || input.side === 'buy') {
    if (input.price === undefined) throw new ValidationError(input.type === 'limit' ? 'price required' : 'market buy requires a protection price cap');
    price = parsePositive(input.price, 'price');
    if (price % tick !== 0n) throw new ValidationError(`price must be a multiple of tickSize ${tick}`);
    // every lot-multiple fill at this price must be worth at least 1 quote unit (no zero-value fills)
    if (quoteAmount(price, lot, base.decimals) < 1n) throw new ValidationError('price too low for this market lot size');
  } else if (input.price !== undefined && input.price !== '0') {
    throw new ValidationError('market sell takes no price');
  }

  const makerBps: number = market.makerFeeBps;
  const takerBps: number = market.takerFeeBps;
  let lockAsset: string;
  let lockAmount: bigint;
  if (input.side === 'sell') {
    lockAsset = market.base;
    lockAmount = qty;
    if (input.type === 'limit' && quoteAmount(price, qty, base.decimals) < BigInt(market.minNotional)) {
      throw new ValidationError(`order value below minNotional ${market.minNotional}`);
    }
  } else {
    lockAsset = market.quote;
    const reserveQuote = quoteAmount(price, qty, base.decimals); // worst case: fills at the limit/cap price
    if (reserveQuote < BigInt(market.minNotional)) throw new ValidationError(`order value below minNotional ${market.minNotional}`);
    // fee reserve at the higher of maker/taker bps. Per-fill fees are floored, so the sum never exceeds this.
    lockAmount = reserveQuote + feeCeil(reserveQuote, Math.max(makerBps, takerBps));
  }

  const requestHash = sha({ m: market.symbol, s: input.side, t: input.type, tif, p: price.toString(), q: qty.toString(), c: input.clientOrderId ?? null });
  await ensureAccount({ userId: input.userId }, lockAsset); // outside the money transaction

  const { order, replayed } = await withTxn(
    async (session) => {
      const existing = await Order.findOne({ userId: input.userId, idempotencyKey: input.idempotencyKey }).session(session).lean();
      if (existing) {
        if (existing.requestHash !== requestHash) throw new IdempotencyMismatch('idempotency key reused with a different request');
        return { order: existing, replayed: true };
      }
      if (input.clientOrderId) {
        const dup = await Order.exists({ userId: input.userId, clientOrderId: input.clientOrderId }).session(session);
        if (dup) throw new Conflict('clientOrderId already used');
      }
      const _id = new Types.ObjectId();
      const doc = {
        _id,
        userId: new Types.ObjectId(input.userId),
        marketId: market._id,
        marketSymbol: market.symbol,
        side: input.side,
        type: input.type,
        tif,
        price: price.toString(),
        qty: qty.toString(),
        filledQty: '0',
        quoteFilled: '0',
        feePaid: '0',
        lockAsset,
        lockedAmount: lockAmount.toString(),
        makerFeeBps: makerBps,
        takerFeeBps: takerBps,
        status: 'new',
        clientOrderId: input.clientOrderId,
        idempotencyKey: input.idempotencyKey,
        requestHash,
        engineStatus: 'pending_submit',
        cancelRequested: false,
        version: 0,
      };
      await Order.create([doc], { session });
      await lockFunds(input.userId, lockAsset, lockAmount, _id.toString(), {
        session, refType: 'order', type: 'order_lock', idempotencyKey: `order-lock:${_id}`,
      });
      return { order: doc as any, replayed: false };
    },
    { lockKeys: [`acct:${ownerKey({ userId: input.userId })}:${lockAsset}`] },
  );

  if (gateway && order.engineStatus === 'pending_submit') await submitToEngine(order, gateway);
  void replayed;
  return { ...order, id: order._id.toString() };
}

async function submitToEngine(order: any, gateway: EngineGateway): Promise<boolean> {
  try {
    await gateway.submit(toEngineOrder(order));
    await Order.updateOne({ _id: order._id, engineStatus: 'pending_submit' }, { $set: { engineStatus: 'submitted' } });
    return true;
  } catch {
    return false; // stays pending_submit; resubmitPending() retries (engine submit is idempotent per order id)
  }
}

/** Sweeper: re-sends orders that were committed but never confirmed as submitted to the engine. */
export async function resubmitPending(gateway: EngineGateway, olderThanMs = 5000, limit = 100): Promise<number> {
  const rows: any[] = await Order.find({
    engineStatus: 'pending_submit',
    status: 'new',
    createdAt: { $lte: new Date(Date.now() - olderThanMs) },
  }).limit(limit).lean();
  let n = 0;
  for (const o of rows) {
    if (await submitToEngine(o, gateway)) {
      n++;
      if (o.cancelRequested) await gateway.cancel(o.marketId.toString(), o._id.toString());
    }
  }
  return n;
}

/**
 * User-requested cancel. Funds are released only when the ENGINE confirms (order_canceled event ->
 * applyOrderCanceled), so an order that is being matched at this moment can never be double-spent.
 */
export async function cancelOrder(userId: string, orderId: string, gateway: EngineGateway) {
  const order: any = await Order.findById(orderId).lean();
  if (!order || order.userId.toString() !== userId) throw new NotFound('order not found');
  if (order.status !== 'new' && order.status !== 'partial') return { status: order.status };
  await Order.updateOne({ _id: order._id }, { $set: { cancelRequested: true } });
  await gateway.cancel(order.marketId.toString(), orderId);
  return { status: 'cancel_requested' };
}

/** Called when the engine confirms a cancel / expiry / rejection. Idempotent. Releases the remaining reserve. */
export async function applyOrderCanceled(orderId: string, finalStatus: 'canceled' | 'rejected' = 'canceled', opts: { session?: ClientSession } = {}) {
  const pre: any = await Order.findById(orderId).lean();
  if (!pre) throw new NotFound(`order ${orderId} not found`);
  return runIn(
    opts.session,
    async (session) => {
      const order: any = await Order.findById(orderId).session(session);
      if (!order) throw new NotFound(`order ${orderId} not found`);
      if (order.status !== 'new' && order.status !== 'partial') return { changed: false };
      const remaining = BigInt(order.lockedAmount);
      if (remaining > 0n) {
        await unlockFunds(order.userId, order.lockAsset, remaining, orderId, {
          session, refType: 'order', type: 'order_unlock', idempotencyKey: `order-unlock:${orderId}`,
        });
      }
      await updateVersioned(Order, order, { status: finalStatus, lockedAmount: toAmountString(0n) }, session);
      return { changed: true };
    },
    { lockKeys: [`acct:${ownerKey({ userId: pre.userId.toString() })}:${pre.lockAsset}`] },
  );
}

