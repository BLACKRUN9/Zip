export class AppError extends Error {
  code: string;
  constructor(code: string, message: string) {
    super(message);
    this.name = 'AppError';
    this.code = code;
  }
}
export class ValidationError extends AppError {
  constructor(message: string) { super('VALIDATION', message); }
}
export class InsufficientFunds extends AppError {
  constructor(message: string) { super('INSUFFICIENT_FUNDS', message); }
}
export class NotFound extends AppError {
  constructor(message: string) { super('NOT_FOUND', message); }
}
export class Conflict extends AppError {
  constructor(message: string) { super('CONFLICT', message); }
}
export class IdempotencyMismatch extends AppError {
  constructor(message: string) { super('IDEMPOTENCY_MISMATCH', message); }
}
export class InvariantViolation extends AppError {
  constructor(message: string) { super('INVARIANT', message); }
}
export class Forbidden extends AppError {
  constructor(message: string) { super('FORBIDDEN', message); }
}
