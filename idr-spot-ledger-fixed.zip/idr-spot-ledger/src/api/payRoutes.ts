import { Router } from 'express';
import { z } from 'zod';
import { Asset, FiatTransaction } from '../db/models.ts';
import { AppError, NotFound } from '../errors.ts';
import { AMOUNT_RE, parsePositive } from '../money.ts';
import { BANKS } from '../payments/provider.ts';
import { H_SIG, H_TS } from '../payments/webhook.ts';
import { verifySecondFactor } from '../services/auth.ts';
import { addBankAccount, getBankAccount, getOrCreateVirtualAccount, handlePaymentWebhook, listFiatTransactions, requestFiatWithdraw } from '../services/fiat.ts';
import { faucet } from '../services/chain.ts';
import { requireIdempotencyKey } from '../services/idempotency.ts';
import { asyncH, authenticate, limiter, parse, requireAdmin } from './middleware.ts';
import type { Limits } from './middleware.ts';
import type { AppDeps } from './app.ts';
import { ser } from './serializers.ts';

const amount = z.string().regex(AMOUNT_RE, 'must be a non-negative integer string');

export function payRoutes(deps: AppDeps, L: Limits) {
  const r = Router();
  const uid = (req: any): string => String(req.auth.user._id);
  const provider = () => {
    if (!deps.payments) throw new NotFound('payments are not configured');
    return deps.payments.provider;
  };
  const wdLimit = limiter(L.withdraw, (req) => `fwd:${req.auth.user._id}`);
  const simOn = !!(deps.payments?.sim || deps.simChains) && process.env.NODE_ENV !== 'production'; // hard guard: the simulator can never run in production
  const simGuard = (_req: any, _res: any, next: any) => (simOn ? next() : next(new NotFound('route not found')));

  // ------------------------------------------------------------ gateway callbacks (no session: authenticated by HMAC over the raw body)
  r.post('/webhooks/payments/:provider', asyncH(async (req, res) => {
    const p = provider();
    if (p.name !== req.params.provider) throw new NotFound('unknown provider');
    const raw = req.rawBody ? req.rawBody.toString('utf8') : '';
    const out = await handlePaymentWebhook(p, { [H_TS]: req.header(H_TS), [H_SIG]: req.header(H_SIG) }, raw);
    res.json({ ok: true, ...out });
  }));

  // ------------------------------------------------------------ IDR deposits / withdrawals
  r.get('/fiat/banks', (_req, res) => { res.json({ items: BANKS }); });

  r.get('/fiat/deposit-va', authenticate(), asyncH(async (req, res) => {
    res.json(await getOrCreateVirtualAccount(provider(), uid(req), String(req.query.bank ?? 'BCA').toUpperCase()));
  }));

  r.get('/fiat/bank-account', authenticate(), asyncH(async (req, res) => { res.json({ account: await getBankAccount(uid(req)) }); }));

  r.post('/fiat/bank-account', authenticate(), wdLimit, asyncH(async (req, res) => {
    const b = parse(z.object({ bank: z.string().max(20), accountNumber: z.string().max(20), holderName: z.string().max(100), totp: z.string().regex(/^\d{6}$/) }).strict(), req.body);
    if (!req.auth.user.twoFAEnabled && !req.auth.user.twoFA?.enabled) throw new AppError('TWOFA_SETUP_REQUIRED', 'enable 2FA first');
    if (!(await verifySecondFactor(uid(req), b.totp, { allowRecovery: false }))) throw new AppError('TWOFA_INVALID', 'invalid or already-used code');
    res.status(201).json(await addBankAccount(uid(req), { bank: b.bank.toUpperCase(), accountNumber: b.accountNumber, holderName: b.holderName }));
  }));

  r.post('/fiat/withdrawals', authenticate(), wdLimit, requireIdempotencyKey, asyncH(async (req, res) => {
    const b = parse(z.object({ amount, totp: z.string().regex(/^\d{6}$/) }).strict(), req.body);
    if (!req.auth.user.twoFA?.enabled) throw new AppError('TWOFA_SETUP_REQUIRED', 'enable 2FA before withdrawing');
    // a retry of an already-accepted request must not need a fresh code (the TOTP step was consumed the first time)
    const existing = await FiatTransaction.exists({ userId: uid(req), idempotencyKey: req.idempotencyKey });
    if (!existing && !(await verifySecondFactor(uid(req), b.totp, { allowRecovery: false }))) throw new AppError('TWOFA_INVALID', 'invalid or already-used code');
    const f: any = await requestFiatWithdraw({ userId: uid(req), amount: b.amount, idempotencyKey: req.idempotencyKey });
    res.status(existing ? 200 : 201).json({ id: String(f._id), amount: f.amount, fee: f.fee, status: f.status, bank: f.bankAccount?.bank, last4: f.bankAccount?.last4 });
  }));

  r.get('/fiat/transactions', authenticate(), asyncH(async (req, res) => { res.json({ items: await listFiatTransactions(uid(req)) }); }));

  // ------------------------------------------------------------ simulator (development only; absent in production)
  r.get('/sim/status', asyncH(async (_req, res) => {
    if (!simOn) throw new NotFound('route not found');
    res.json({ enabled: true, bank: !!deps.payments?.sim, chains: Object.keys(deps.simChains ?? {}) });
  }));

  r.post('/sim/bank/transfer', simGuard, authenticate(), asyncH(async (req, res) => {
    const b = parse(z.object({ bank: z.string().max(20).optional(), amount: amount, senderName: z.string().min(1).max(100), duplicate: z.boolean().optional() }).strict(), req.body);
    const sim = deps.payments?.sim;
    if (!sim) throw new NotFound('bank simulator is not enabled');
    parsePositive(b.amount, 'amount');
    const va = await getOrCreateVirtualAccount(sim, uid(req), (b.bank ?? 'BCA').toUpperCase());
    const providerRef = await sim.simulateTransfer({ vaNumber: va.vaNumber, amount: b.amount, senderName: b.senderName, duplicate: b.duplicate });
    res.status(201).json({ providerRef, vaNumber: va.vaNumber });
  }));

  r.post('/sim/faucet', simGuard, authenticate(), asyncH(async (req, res) => {
    const b = parse(z.object({ asset: z.string().max(10), amount: amount }).strict(), req.body);
    const a: any = await Asset.findOne({ symbol: b.asset.toUpperCase(), type: 'crypto' }).lean();
    const chain = a && deps.simChains?.[a.chain];
    if (!chain) throw new NotFound('no simulated chain for this asset');
    res.status(201).json(await faucet(chain, uid(req), a.symbol, BigInt(b.amount)));
  }));

  r.post('/sim/chain/mine', simGuard, authenticate(), asyncH(async (req, res) => {
    const b = parse(z.object({ chain: z.string().max(10), blocks: z.number().int().min(1).max(50).default(1) }).strict(), req.body);
    const c = deps.simChains?.[b.chain];
    if (!c) throw new NotFound('unknown chain');
    c.mine(b.blocks);
    res.json({ height: c.height });
  }));

  r.post('/sim/chain/reorg', simGuard, authenticate(), requireAdmin(deps.adminIpAllowlist ?? []), asyncH(async (req, res) => {
    const b = parse(z.object({ chain: z.string().max(10), depth: z.number().int().min(1).max(50), dropTxs: z.boolean().optional() }).strict(), req.body);
    const c = deps.simChains?.[b.chain];
    if (!c) throw new NotFound('unknown chain');
    c.reorg(b.depth, { dropTxs: b.dropTxs });
    res.json({ height: c.height });
  }));

  r.post('/sim/payout/:reference', simGuard, authenticate(), requireAdmin(deps.adminIpAllowlist ?? []), asyncH(async (req, res) => {
    const b = parse(z.object({ outcome: z.enum(['completed', 'failed']), reason: z.string().max(200).optional() }).strict(), req.body);
    const sim = deps.payments?.sim;
    if (!sim) throw new NotFound('bank simulator is not enabled');
    await sim.simulatePayoutResult(String(req.params.reference), b.outcome, b.reason);
    res.json({ ok: true });
  }));

  void ser;
  return r;
}
