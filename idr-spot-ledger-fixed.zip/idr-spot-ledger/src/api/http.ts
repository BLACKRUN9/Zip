import { AppError } from '../errors.ts';

const STATUS: Record<string, number> = {
  VALIDATION: 400,
  INVALID_CREDENTIALS: 401,
  INVALID_TOKEN: 401,
  UNAUTHENTICATED: 401,
  TWOFA_REQUIRED: 401,
  TWOFA_INVALID: 401,
  INVALID_SIGNATURE: 401,
  FORBIDDEN: 403,
  KYC_NAME_MISMATCH: 403,
  NO_BANK_ACCOUNT: 409,
  NO_ADDRESS_AVAILABLE: 503,
  TWOFA_SETUP_REQUIRED: 403,
  NOT_FOUND: 404,
  CONFLICT: 409,
  MARKET_NOT_ACTIVE: 409,
  IDEMPOTENCY_KEY_REQUIRED: 400,
  IDEMPOTENCY_MISMATCH: 422,
  INSUFFICIENT_FUNDS: 422,
  ACCOUNT_LOCKED: 423,
  RATE_LIMITED: 429,
};

export function httpStatusFor(code: string): number {
  return STATUS[code] ?? 500;
}

/** Never leak stack traces, query internals, or invariant details to clients. */
export function toErrorBody(err: unknown, requestId: string): { status: number; body: { error: string; message: string; requestId: string } } {
  if (err instanceof AppError && STATUS[err.code]) {
    return { status: STATUS[err.code], body: { error: err.code, message: err.message, requestId } };
  }
  return { status: 500, body: { error: 'INTERNAL', message: 'internal error', requestId } };
}
