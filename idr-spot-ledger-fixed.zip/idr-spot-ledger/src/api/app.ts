import cors from 'cors';
import express from 'express';
import helmet from 'helmet';
import mongoose from 'mongoose';
import type { MatchingEngine } from '../engine/engine.ts';
import type { ChainAdapter } from '../chain/types.ts';
import type { SimChain } from '../chain/simChain.ts';
import type { PaymentProvider, SimProvider } from '../payments/provider.ts';
import type { Mailer } from '../services/auth.ts';
import type { ObjectStorage } from '../services/kyc.ts';
import type { EngineGateway } from '../services/orders.ts';
import { adminRoutes } from './adminRoutes.ts';
import { apiRoutes } from './apiRoutes.ts';
import { payRoutes } from './payRoutes.ts';
import { authRoutes } from './authRoutes.ts';
import { DEFAULT_LIMITS, errorHandler, limiter, noStore, notFound, requestId } from './middleware.ts';
import type { Limits } from './middleware.ts';

export interface AppDeps {
  gateway: EngineGateway;
  engine?: MatchingEngine;
  mailer: Mailer;
  storage?: ObjectStorage;
  depositAddresses?: { getAddress(userId: string, asset: string): Promise<{ address: string; memo?: string }> };
  corsOrigins?: string[];
  trustProxy?: boolean | number | string;
  adminIpAllowlist?: string[];
  limits?: Partial<Limits>;
  /** IDR gateway. `sim` is the in-process bank simulator (development only). */
  payments?: { provider: PaymentProvider; sim?: SimProvider };
  /** Chains by name ('BTC' | 'ETH' | 'TRON'), used to hand out deposit addresses. */
  chains?: Record<string, ChainAdapter>;
  /** Simulated testnets (development only): faucet + mining + reorg endpoints. */
  simChains?: Record<string, SimChain>;
}

export function createApp(deps: AppDeps) {
  const L: Limits = { ...DEFAULT_LIMITS, ...deps.limits };
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', deps.trustProxy ?? false); // set to the real proxy hop count in production, or req.ip (rate limits!) is wrong
  app.use(helmet());
  app.use(cors({ origin: deps.corsOrigins?.length ? deps.corsOrigins : false })); // false = no CORS headers at all
  app.use(requestId);
  app.use(express.json({ limit: '100kb', verify: (req: any, _res, buf) => { req.rawBody = buf; } })); // raw body is needed to verify API-key signatures

  app.get('/healthz', (_req, res) => { res.json({ ok: true }); });
  app.get('/readyz', (_req, res) => {
    const ok = mongoose.connection.readyState === 1;
    res.status(ok ? 200 : 503).json({ ok });
  });

  app.use('/v1', noStore, limiter(L.global, (req) => `g:${req.ip}`));
  app.use('/v1', authRoutes(deps, L));
  app.use('/v1', payRoutes(deps, L));
  app.use('/v1', apiRoutes(deps, L));
  app.use('/v1/admin', adminRoutes(deps));
  app.use(notFound);
  app.use(errorHandler);
  return app;
}
