import { randomUUID } from 'node:crypto';
import { Types } from 'mongoose';
import { z } from 'zod';
import { AppError, Forbidden, ValidationError } from '../errors.ts';
import { TokenBucket } from '../security/ratelimit.ts';
import { authenticateAccess } from '../services/auth.ts';
import { authenticateApiRequest } from '../services/apikeys.ts';
import { toErrorBody } from './http.ts';

export type Limit = [capacity: number, refillPerSec: number];
export interface Limits { global: Limit; authIp: Limit; login: Limit; trade: Limit; withdraw: Limit; forgot: Limit }
export const DEFAULT_LIMITS: Limits = {
  global: [300, 100],
  authIp: [30, 0.5],
  login: [5, 1 / 12], // per ip+email
  trade: [50, 25],
  withdraw: [5, 1 / 60],
  forgot: [3, 1 / 600],
};

export const asyncH = (fn: (req: any, res: any, next: any) => Promise<unknown>) => (req: any, res: any, next: any) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};

export function parse<T>(schema: z.ZodType<T>, data: unknown): T {
  const r = schema.safeParse(data);
  if (!r.success) throw new ValidationError(r.error.issues.map((i) => `${i.path.join('.') || 'body'}: ${i.message}`).join('; '));
  return r.data;
}

export const objectId = (v: unknown, name = 'id'): string => {
  if (typeof v !== 'string' || !Types.ObjectId.isValid(v) || String(new Types.ObjectId(v)) !== v) throw new ValidationError(`invalid ${name}`);
  return v;
};

export function page(req: any): { limit: number; before?: string } {
  const limit = Math.min(Math.max(parseInt(String(req.query.limit ?? '50'), 10) || 50, 1), 100);
  const before = req.query.before ? objectId(String(req.query.before), 'before') : undefined;
  return { limit, before };
}

export function requestId(req: any, res: any, next: any) {
  req.id = randomUUID();
  res.setHeader('X-Request-Id', req.id);
  next();
}

export function noStore(_req: any, res: any, next: any) {
  res.setHeader('Cache-Control', 'no-store');
  next();
}

export function limiter(limit: Limit, keyFn: (req: any) => string) {
  const bucket = new TokenBucket(limit[0], limit[1]);
  setInterval(() => bucket.sweep(), 5 * 60_000).unref();
  return (req: any, res: any, next: any) => {
    const r = bucket.consume(keyFn(req));
    if (r.ok) return next();
    res.setHeader('Retry-After', String(Math.ceil(r.retryAfterMs / 1000)));
    next(new AppError('RATE_LIMITED', 'too many requests'));
  };
}

/**
 * Session (Bearer) or signed API-key auth. Sensitive routes use allow:['session'] so an API key can never
 * touch passwords, 2FA, API-key management, or withdrawals.
 */
export function authenticate(opts: { allow?: Array<'session' | 'apikey'>; perm?: 'read' | 'trade' } = {}) {
  const allow = opts.allow ?? ['session'];
  return asyncH(async (req, _res, next) => {
    const authz = req.header('authorization');
    if (authz?.startsWith('Bearer ')) {
      if (!allow.includes('session')) throw new Forbidden('session authentication is not allowed here');
      const { user, session } = await authenticateAccess(authz.slice(7));
      req.auth = { kind: 'session', user, sessionId: String(session._id) };
      return next();
    }
    const keyId = req.header('x-api-key');
    if (keyId) {
      if (!allow.includes('apikey')) throw new Forbidden('API keys are not allowed on this endpoint');
      const r = await authenticateApiRequest({
        keyId, timestamp: req.header('x-api-timestamp'), signature: req.header('x-api-signature'),
        method: req.method, path: req.originalUrl, body: req.rawBody ? req.rawBody.toString('utf8') : '', ip: req.ip,
      });
      if (opts.perm && !r.permissions.includes(opts.perm)) throw new Forbidden(`API key lacks the "${opts.perm}" permission`);
      req.auth = { kind: 'apikey', user: r.user, keyId: r.keyId };
      return next();
    }
    throw new AppError('UNAUTHENTICATED', 'authentication required');
  });
}

export function requireAdmin(ipAllowlist: string[] = []) {
  return (req: any, _res: any, next: any) => {
    const u = req.auth?.user;
    if (req.auth?.kind !== 'session' || u?.role !== 'admin' || u.status !== 'active') return next(new Forbidden('admin only'));
    if (!u.twoFA?.enabled) return next(new Forbidden('admin accounts must have 2FA enabled'));
    if (ipAllowlist.length && !ipAllowlist.includes(req.ip)) return next(new Forbidden('admin access is restricted by IP'));
    next();
  };
}

export function notFound(_req: any, _res: any, next: any) {
  next(new AppError('NOT_FOUND', 'route not found'));
}

export function errorHandler(err: any, req: any, res: any, _next: any) {
  if (err?.type === 'entity.parse.failed') err = new ValidationError('malformed JSON body');
  if (err?.type === 'entity.too.large') return res.status(413).json({ error: 'PAYLOAD_TOO_LARGE', message: 'request body too large', requestId: req.id });
  const { status, body } = toErrorBody(err, req.id ?? 'n/a');
  if (status >= 500) console.error(JSON.stringify({ level: 'error', requestId: req.id, path: req.path, err: String(err?.stack ?? err) }));
  res.status(status).json(body);
}
