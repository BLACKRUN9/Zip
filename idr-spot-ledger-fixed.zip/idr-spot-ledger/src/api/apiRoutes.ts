import { Router } from 'express';
import { z } from 'zod';
import { Account, Asset, Deposit, LedgerEntry, Market, Order, Trade, Withdrawal } from '../db/models.ts';
import { AppError, NotFound, ValidationError } from '../errors.ts';
import { AMOUNT_RE } from '../money.ts';
import { cancelOrder, placeOrder } from '../services/orders.ts';
import { requestWithdraw } from '../services/wallet.ts';
import { assignDepositAddress } from '../services/chain.ts';
import { verifySecondFactor } from '../services/auth.ts';
import { createKycUploadUrl, getKycStatus, submitKyc } from '../services/kyc.ts';
import { requireIdempotencyKey } from '../services/idempotency.ts';
import { asyncH, authenticate, limiter, objectId, page, parse } from './middleware.ts';
import type { Limits } from './middleware.ts';
import type { AppDeps } from './app.ts';
import { levels, ser } from './serializers.ts';
import { candleToWire, isInterval } from '../marketdata/candles.ts';
import { loadCandles, loadTicker } from '../marketdata/candleStore.ts';

const amount = z.string().regex(AMOUNT_RE, 'must be a non-negative integer string');
const both = (perm: 'read' | 'trade') => authenticate({ allow: ['session', 'apikey'], perm });
const uid = (req: any): string => String(req.auth.user._id);

export function apiRoutes(deps: AppDeps, L: Limits) {
  const r = Router();
  const tradeLimit = limiter(L.trade, (req) => `trade:${req.auth.user._id}`);
  const withdrawLimit = limiter(L.withdraw, (req) => `wd:${req.auth.user._id}`);

  // ------------------------------------------------------------ public market data
  r.get('/markets', asyncH(async (_req, res) => {
    res.json({ items: (await Market.find({}).sort({ symbol: 1 }).lean()).map(ser.market) });
  }));

  r.get('/assets', asyncH(async (_req, res) => {
    const rows: any[] = await Asset.find({ enabled: true }).sort({ symbol: 1 }).lean();
    res.json({ items: rows.map((a) => ({ symbol: a.symbol, name: a.name, decimals: a.decimals, type: a.type, chain: a.chain, minDeposit: a.minDeposit, minWithdraw: a.minWithdraw, withdrawFee: a.withdrawFee })) });
  }));

  r.get('/markets/:symbol/book', asyncH(async (req, res) => {
    if (!deps.engine) throw new AppError('NOT_FOUND', 'order book not available');
    const m: any = await Market.findOne({ symbol: String(req.params.symbol).toUpperCase() }).lean();
    if (!m) throw new NotFound('market not found');
    const snap = await deps.engine.book(String(m._id));
    const depth = Math.min(parseInt(String(req.query.depth ?? '50'), 10) || 50, 200);
    res.json({ market: m.symbol, bids: levels(snap.bids as any, depth), asks: levels(snap.asks as any, depth) });
  }));

  r.get('/markets/:symbol/trades', asyncH(async (req, res) => {
    const { limit } = page(req);
    const rows = await Trade.find({ marketSymbol: String(req.params.symbol).toUpperCase() }).sort({ seq: -1 }).limit(limit).lean();
    res.json({ items: rows.map(ser.publicTrade) });
  }));

  const tickerCache = new Map<string, { at: number; value: unknown }>();
  const cachedTicker = async (symbol: string) => {
    const hit = tickerCache.get(symbol);
    if (hit && Date.now() - hit.at < 1000) return hit.value; // 1s cache: protects the DB from polling storms
    const value = await loadTicker(symbol);
    tickerCache.set(symbol, { at: Date.now(), value });
    return value;
  };
  const marketOr404 = async (raw: unknown): Promise<string> => {
    const symbol = String(raw).toUpperCase();
    if (!(await Market.exists({ symbol }))) throw new NotFound('market not found');
    return symbol;
  };

  r.get('/markets/:symbol/candles', asyncH(async (req, res) => {
    const symbol = await marketOr404(req.params.symbol);
    const interval = String(req.query.interval ?? '');
    if (!isInterval(interval)) throw new ValidationError('interval must be one of 1m, 5m, 15m, 1h, 4h, 1d');
    const limit = Math.min(Math.max(parseInt(String(req.query.limit ?? '300'), 10) || 300, 1), 1000);
    let before: number | undefined;
    if (req.query.before !== undefined) {
      before = Number(req.query.before);
      if (!Number.isSafeInteger(before) || before <= 0) throw new ValidationError('before must be a millisecond timestamp');
    }
    const candles = await loadCandles(symbol, interval, { limit, before, fill: req.query.fill !== 'false' });
    res.json({ market: symbol, interval, candles: candles.map(candleToWire) });
  }));

  r.get('/markets/:symbol/ticker', asyncH(async (req, res) => {
    const symbol = await marketOr404(req.params.symbol);
    res.json({ market: symbol, ...(await cachedTicker(symbol) as object) });
  }));

  r.get('/tickers', asyncH(async (_req, res) => {
    const ms: any[] = await Market.find({}).sort({ symbol: 1 }).lean();
    res.json({ items: await Promise.all(ms.map(async (m) => ({ market: m.symbol, ...(await cachedTicker(m.symbol) as object) }))) });
  }));

  // ------------------------------------------------------------ account (read)
  r.get('/me', both('read'), (req: any, res) => { res.json(ser.user(req.auth.user)); });

  r.get('/balances', both('read'), asyncH(async (req, res) => {
    const rows = await Account.find({ userId: uid(req) }).sort({ asset: 1 }).lean();
    res.json({ items: rows.map(ser.account) });
  }));

  r.get('/orders', both('read'), asyncH(async (req, res) => {
    const { limit, before } = page(req);
    const f: any = { userId: uid(req) };
    if (req.query.market) f.marketSymbol = String(req.query.market).toUpperCase();
    if (req.query.open === 'true') f.status = { $in: ['new', 'partial'] };
    else if (req.query.status) {
      if (!['new', 'partial', 'filled', 'canceled', 'rejected'].includes(String(req.query.status))) throw new ValidationError('invalid status');
      f.status = String(req.query.status);
    }
    if (before) f._id = { $lt: before };
    const rows = await Order.find(f).sort({ _id: -1 }).limit(limit).lean();
    res.json({ items: rows.map(ser.order), next: rows.length === limit ? String(rows[rows.length - 1]._id) : null });
  }));

  r.get('/orders/:id', both('read'), asyncH(async (req, res) => {
    const o = await Order.findOne({ _id: objectId(req.params.id), userId: uid(req) }).lean();
    if (!o) throw new NotFound('order not found');
    res.json(ser.order(o));
  }));

  r.get('/trades/mine', both('read'), asyncH(async (req, res) => {
    const { limit, before } = page(req);
    const f: any = { $or: [{ takerUserId: uid(req) }, { makerUserId: uid(req) }] };
    if (before) f._id = { $lt: before };
    const rows = await Trade.find(f).sort({ _id: -1 }).limit(limit).lean();
    res.json({ items: rows.map((t) => ser.myTrade(t, uid(req))), next: rows.length === limit ? String(rows[rows.length - 1]._id) : null });
  }));

  r.get('/ledger', both('read'), asyncH(async (req, res) => {
    const { limit, before } = page(req);
    const f: any = { userId: uid(req) };
    if (req.query.asset) f.asset = String(req.query.asset).toUpperCase();
    if (before) f._id = { $lt: before };
    const rows = await LedgerEntry.find(f).sort({ _id: -1 }).limit(limit).lean();
    res.json({ items: rows.map(ser.ledger), next: rows.length === limit ? String(rows[rows.length - 1]._id) : null });
  }));

  // ------------------------------------------------------------ trading
  const orderSchema = z.object({
    market: z.string().min(3).max(20),
    side: z.enum(['buy', 'sell']),
    type: z.enum(['limit', 'market']),
    tif: z.enum(['GTC', 'IOC']).optional(),
    price: amount.optional(),
    qty: amount,
    clientOrderId: z.string().min(1).max(64).regex(/^[\w\-.:]+$/).optional(),
  }).strict();

  r.post('/orders', both('trade'), tradeLimit, requireIdempotencyKey, asyncH(async (req, res) => {
    const b = parse(orderSchema, req.body);
    const o = await placeOrder({ userId: uid(req), ...b, idempotencyKey: req.idempotencyKey }, deps.gateway);
    const fresh = await Order.findById(o.id).lean(); // reflect fills that already happened
    res.status(201).json(ser.order(fresh));
  }));

  r.delete('/orders/:id', both('trade'), tradeLimit, asyncH(async (req, res) => {
    const out = await cancelOrder(uid(req), objectId(req.params.id), deps.gateway);
    const fresh = await Order.findById(req.params.id).lean();
    res.status(202).json({ result: out.status, order: fresh ? ser.order(fresh) : undefined });
  }));

  // ------------------------------------------------------------ wallet (session only)
  r.get('/deposits/address/:asset', authenticate(), asyncH(async (req, res) => {
    const asset: any = await Asset.findOne({ symbol: String(req.params.asset).toUpperCase(), type: 'crypto', enabled: true }).lean();
    if (!asset) throw new NotFound('asset not found');
    if (req.auth.user.kycLevel < 1) throw new AppError('FORBIDDEN', 'complete KYC before depositing');
    if (deps.depositAddresses) { res.json(await deps.depositAddresses.getAddress(uid(req), asset.symbol)); return; }
    if (!deps.chains?.[asset.chain]) throw new NotFound('deposit addresses are not configured');
    const sim = deps.simChains?.[asset.chain];
    const a = await assignDepositAddress(uid(req), asset.chain, sim ? () => sim.newAddress() : undefined);
    res.json({ address: a.address, chain: asset.chain });
  }));

  r.get('/deposits', both('read'), asyncH(async (req, res) => {
    const { limit, before } = page(req);
    const f: any = { userId: uid(req) };
    if (before) f._id = { $lt: before };
    res.json({ items: (await Deposit.find(f).sort({ _id: -1 }).limit(limit).lean()).map(ser.deposit) });
  }));

  r.get('/withdrawals', both('read'), asyncH(async (req, res) => {
    const { limit, before } = page(req);
    const f: any = { userId: uid(req) };
    if (before) f._id = { $lt: before };
    res.json({ items: (await Withdrawal.find(f).sort({ _id: -1 }).limit(limit).lean()).map(ser.withdrawal) });
  }));

  r.post('/withdrawals', authenticate(), withdrawLimit, requireIdempotencyKey, asyncH(async (req, res) => {
    const b = parse(z.object({ asset: z.string().min(2).max(10), address: z.string().min(10).max(128), memo: z.string().max(64).optional(), amount, totp: z.string().regex(/^\d{6}$/) }).strict(), req.body);
    const user = req.auth.user;
    if (!user.twoFA?.enabled) throw new AppError('TWOFA_SETUP_REQUIRED', 'enable 2FA before withdrawing');
    const input = { userId: uid(req), asset: b.asset.toUpperCase(), address: b.address, memo: b.memo, amount: b.amount, idempotencyKey: req.idempotencyKey };
    // A retry of an already-accepted request must not need a fresh code (the TOTP step was consumed the first time).
    const existing = await Withdrawal.exists({ userId: uid(req), idempotencyKey: req.idempotencyKey });
    if (!existing && !(await verifySecondFactor(uid(req), b.totp, { allowRecovery: false }))) {
      throw new AppError('TWOFA_INVALID', 'invalid or already-used code');
    }
    const w = await requestWithdraw(input);
    res.status(existing ? 200 : 201).json(ser.withdrawal(w));
  }));

  // ------------------------------------------------------------ KYC (session only)
  r.post('/kyc/upload-url', authenticate(), asyncH(async (req, res) => {
    if (!deps.storage) throw new AppError('NOT_FOUND', 'uploads are not configured');
    const b = parse(z.object({ kind: z.enum(['doc', 'selfie']), contentType: z.string().max(50) }).strict(), req.body);
    res.json(await createKycUploadUrl(deps.storage, uid(req), b.kind, b.contentType));
  }));
  r.post('/kyc', authenticate(), asyncH(async (req, res) => {
    const b = parse(z.object({ fullName: z.string(), nik: z.string(), dob: z.string(), address: z.string(), docKeys: z.array(z.string().max(200)).max(3), selfieKey: z.string().max(200) }).strict(), req.body);
    res.status(202).json(await submitKyc(uid(req), b));
  }));
  r.get('/kyc', authenticate(), asyncH(async (req, res) => { res.json(await getKycStatus(uid(req))); }));
  return r;
}
