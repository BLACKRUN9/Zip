import { Router } from 'express';
import { z } from 'zod';
import * as auth from '../services/auth.ts';
import * as apikeys from '../services/apikeys.ts';
import { asyncH, authenticate, limiter, objectId, parse } from './middleware.ts';
import type { Limits } from './middleware.ts';
import type { AppDeps } from './app.ts';
import { AppError } from '../errors.ts';

const email = z.string().max(254);
const secret = z.string().max(256);
const tokensOut = (t: auth.Tokens) => ({ sessionId: t.sessionId, accessToken: t.accessToken, refreshToken: t.refreshToken, accessExpiresAt: t.accessExpiresAt, refreshExpiresAt: t.refreshExpiresAt });
const meta = (req: any) => ({ ip: req.ip, userAgent: String(req.header('user-agent') ?? '').slice(0, 200) });

export function authRoutes(deps: AppDeps, L: Limits) {
  const r = Router();
  const ipLimit = limiter(L.authIp, (req) => `authip:${req.ip}`);
  const loginLimit = limiter(L.login, (req) => `login:${req.ip}:${String(req.body?.email ?? '').toLowerCase()}`);
  const forgotLimit = limiter(L.forgot, (req) => `forgot:${req.ip}`);

  r.post('/auth/register', ipLimit, asyncH(async (req, res) => {
    const b = parse(z.object({ email, password: secret, phone: z.string().max(20).optional() }).strict(), req.body);
    res.status(201).json(await auth.register(b));
  }));

  r.post('/auth/login', ipLimit, loginLimit, asyncH(async (req, res) => {
    const b = parse(z.object({ email, password: secret, code: z.string().max(20).optional() }).strict(), req.body);
    res.json(tokensOut(await auth.login({ ...b, ...meta(req) })));
  }));

  r.post('/auth/refresh', ipLimit, asyncH(async (req, res) => {
    const b = parse(z.object({ refreshToken: z.string().min(20).max(200) }).strict(), req.body);
    res.json(tokensOut(await auth.refresh(b.refreshToken, meta(req))));
  }));

  r.post('/auth/logout', authenticate(), asyncH(async (req, res) => {
    await auth.logout(req.auth.sessionId);
    res.status(204).end();
  }));

  r.post('/auth/password/forgot', forgotLimit, asyncH(async (req, res) => {
    const b = parse(z.object({ email }).strict(), req.body);
    await auth.forgotPassword(b.email, deps.mailer);
    res.status(202).json({ message: 'if that email is registered, a reset link has been sent' }); // identical either way
  }));

  r.post('/auth/password/reset', ipLimit, asyncH(async (req, res) => {
    const b = parse(z.object({ token: z.string().min(20).max(200), password: secret }).strict(), req.body);
    await auth.resetPassword(b.token, b.password);
    res.status(204).end();
  }));

  r.post('/auth/password/change', authenticate(), asyncH(async (req, res) => {
    const b = parse(z.object({ currentPassword: secret, newPassword: secret }).strict(), req.body);
    await auth.changePassword(String(req.auth.user._id), b.currentPassword, b.newPassword, req.auth.sessionId);
    res.status(204).end();
  }));

  r.get('/auth/sessions', authenticate(), asyncH(async (req, res) => {
    res.json({ items: await auth.listSessions(String(req.auth.user._id)), currentSessionId: req.auth.sessionId });
  }));

  r.delete('/auth/sessions/:id', authenticate(), asyncH(async (req, res) => {
    await auth.revokeSession(String(req.auth.user._id), objectId(req.params.id));
    res.status(204).end();
  }));

  r.post('/auth/2fa/setup', authenticate(), asyncH(async (req, res) => {
    res.json(await auth.begin2FASetup(String(req.auth.user._id)));
  }));

  r.post('/auth/2fa/confirm', authenticate(), asyncH(async (req, res) => {
    const b = parse(z.object({ code: z.string().regex(/^\d{6}$/) }).strict(), req.body);
    res.json(await auth.confirm2FA(String(req.auth.user._id), b.code));
  }));

  r.post('/auth/2fa/disable', authenticate(), asyncH(async (req, res) => {
    const b = parse(z.object({ password: secret, code: z.string().max(20) }).strict(), req.body);
    await auth.disable2FA(String(req.auth.user._id), b.password, b.code, req.auth.sessionId);
    res.status(204).end();
  }));

  // ---- API keys (session only; creating one needs 2FA to be on)
  r.get('/api-keys', authenticate(), asyncH(async (req, res) => {
    res.json({ items: await apikeys.listApiKeys(String(req.auth.user._id)) });
  }));
  r.post('/api-keys', authenticate(), asyncH(async (req, res) => {
    if (!req.auth.user.twoFA?.enabled) throw new AppError('TWOFA_SETUP_REQUIRED', 'enable 2FA before creating API keys');
    const b = parse(z.object({ label: z.string().max(50).optional(), permissions: z.array(z.enum(['read', 'trade'])).min(1), ipWhitelist: z.array(z.string().max(64)).max(20).optional() }).strict(), req.body);
    res.status(201).json(await apikeys.createApiKey(String(req.auth.user._id), b));
  }));
  r.delete('/api-keys/:keyId', authenticate(), asyncH(async (req, res) => {
    await apikeys.revokeApiKey(String(req.auth.user._id), String(req.params.keyId).slice(0, 64));
    res.status(204).end();
  }));
  return r;
}
