import { Router } from 'express';
import { z } from 'zod';
import { AppError } from '../errors.ts';
import { approveWithdraw, rejectWithdrawal } from '../services/wallet.ts';
import { listPendingKyc, reviewKyc, viewKycForReview } from '../services/kyc.ts';
import { listWithdrawals, setMarketStatus, setUserStatus } from '../services/admin.ts';
import { reconcile } from '../services/reconcile.ts';
import { Asset, FiatTransaction } from '../db/models.ts';
import { approveFiatWithdraw, rejectFiatWithdraw } from '../services/fiat.ts';
import { importAddresses } from '../services/chain.ts';
import { creditFiatDeposit } from '../services/wallet.ts';
import { ser } from './serializers.ts';
import { asyncH, authenticate, objectId, parse, requireAdmin } from './middleware.ts';
import type { AppDeps } from './app.ts';

export function adminRoutes(deps: AppDeps) {
  const r = Router();
  r.use(authenticate(), requireAdmin(deps.adminIpAllowlist ?? []));
  const admin = (req: any): string => String(req.auth.user._id);

  r.get('/kyc/pending', asyncH(async (req, res) => { res.json({ items: await listPendingKyc(admin(req)) }); }));
  r.get('/kyc/:userId', asyncH(async (req, res) => {
    const v = await viewKycForReview(admin(req), objectId(req.params.userId, 'userId'));
    const keys = [...(v.docImages ?? []), v.selfieKey].filter(Boolean) as string[];
    const files = deps.storage?.presignDownload ? await Promise.all(keys.map(async (k) => ({ key: k, url: await deps.storage!.presignDownload!(k, 120) }))) : [];
    res.json({ ...v, files });
  }));
  r.post('/kyc/:userId/review', asyncH(async (req, res) => {
    const b = parse(z.object({ decision: z.enum(['approved', 'rejected']), reason: z.string().max(300).optional() }).strict(), req.body);
    res.json(await reviewKyc(admin(req), objectId(req.params.userId, 'userId'), b.decision, b.reason));
  }));

  r.get('/withdrawals', asyncH(async (req, res) => {
    const status = String(req.query.status ?? 'pending');
    if (!['pending', 'approved', 'broadcast', 'completed', 'rejected'].includes(status)) throw new AppError('VALIDATION', 'invalid status');
    res.json({ items: (await listWithdrawals(admin(req), status)).map((w: any) => ({ ...ser.withdrawal(w), userId: String(w.userId), riskFlags: w.riskFlags })) });
  }));
  r.post('/withdrawals/:id/approve', asyncH(async (req, res) => { res.json(await approveWithdraw(objectId(req.params.id), admin(req))); }));
  r.post('/withdrawals/:id/reject', asyncH(async (req, res) => {
    const b = parse(z.object({ reason: z.string().min(1).max(300) }).strict(), req.body);
    res.json(await rejectWithdrawal(objectId(req.params.id), admin(req), b.reason));
  }));

  r.post('/users/:id/status', asyncH(async (req, res) => {
    const b = parse(z.object({ status: z.enum(['active', 'frozen']), reason: z.string().min(1).max(300) }).strict(), req.body);
    res.json(await setUserStatus(admin(req), objectId(req.params.id), b.status, b.reason));
  }));
  r.post('/markets/:symbol/status', asyncH(async (req, res) => {
    const b = parse(z.object({ status: z.enum(['active', 'halted', 'cancel_only']), reason: z.string().min(1).max(300) }).strict(), req.body);
    res.json(await setMarketStatus(admin(req), String(req.params.symbol), b.status, b.reason));
  }));

  const needProvider = () => { if (!deps.payments) throw new AppError('NOT_FOUND', 'payments are not configured'); return deps.payments.provider; };
  r.get('/fiat/withdrawals', asyncH(async (req, res) => {
    const status = String(req.query.status ?? 'pending');
    if (!['pending', 'approved', 'processing', 'completed', 'failed', 'rejected'].includes(status)) throw new AppError('VALIDATION', 'invalid status');
    const rows: any[] = await FiatTransaction.find({ type: 'withdraw', status }).sort({ createdAt: 1 }).limit(100).lean();
    res.json({ items: rows.map((f) => ({ id: String(f._id), reference: f.providerRef, userId: String(f.userId), amount: f.amount, fee: f.fee, status: f.status, bank: f.bankAccount?.bank, last4: f.bankAccount?.last4, holder: f.bankAccount?.name, reason: f.reason, createdAt: f.createdAt })) });
  }));
  r.post('/fiat/withdrawals/:id/approve', asyncH(async (req, res) => { res.json(await approveFiatWithdraw(needProvider(), objectId(req.params.id), admin(req))); }));
  r.post('/fiat/withdrawals/:id/reject', asyncH(async (req, res) => {
    const b = parse(z.object({ reason: z.string().min(1).max(300) }).strict(), req.body);
    res.json(await rejectFiatWithdraw(objectId(req.params.id), admin(req), b.reason));
  }));
  r.get('/fiat/deposits/review', asyncH(async (_req, res) => {
    const rows: any[] = await FiatTransaction.find({ type: 'deposit', status: 'manual_review' }).sort({ createdAt: 1 }).limit(100).lean();
    res.json({ items: rows.map((f) => ({ reference: f.providerRef, userId: String(f.userId), amount: f.amount, senderName: f.senderName, bank: f.bankAccount?.bank, createdAt: f.createdAt })) });
  }));
  r.post('/fiat/deposits/:ref/credit', asyncH(async (req, res) => { res.json(await creditFiatDeposit(String(req.params.ref).slice(0, 64), { adminId: admin(req) })); }));
  r.post('/chain/addresses/import', asyncH(async (req, res) => {
    const b = parse(z.object({ chain: z.enum(['BTC', 'ETH', 'TRON']), addresses: z.array(z.string().max(100)).min(1).max(1000) }).strict(), req.body);
    res.json(await importAddresses(b.chain, b.addresses));
  }));

  r.get('/reconcile', asyncH(async (_req, res) => {
    const d = await reconcile({
      custodyBalance: async (asset) => { // the ledger must never owe customers more than the chain actually holds
        const a: any = await Asset.findOne({ symbol: asset }).lean();
        const c = a && deps.chains?.[a.chain];
        return c?.custodyBalance ? c.custodyBalance(asset) : undefined;
      },
    });
    res.status(d.length ? 409 : 200).json({ ok: d.length === 0, discrepancies: d });
  }));
  return r;
}
