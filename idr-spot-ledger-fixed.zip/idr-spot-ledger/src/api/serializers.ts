/** Explicit allow-lists: internal fields (hashes, versions, request hashes, other users' ids) never leave the server. */
const id = (o: any) => String(o._id ?? o.id);
export const ser = {
  user: (u: any) => ({ id: id(u), email: u.email, phone: u.phone, status: u.status, kycLevel: u.kycLevel, role: u.role, twoFAEnabled: !!u.twoFA?.enabled, createdAt: u.createdAt }),
  account: (a: any) => ({ asset: a.asset, available: a.available, locked: a.locked }),
  order: (o: any) => ({
    id: id(o), market: o.marketSymbol, side: o.side, type: o.type, tif: o.tif, price: o.price, qty: o.qty, filledQty: o.filledQty,
    quoteFilled: o.quoteFilled, feePaid: o.feePaid, status: o.status, clientOrderId: o.clientOrderId, createdAt: o.createdAt, updatedAt: o.updatedAt,
  }),
  myTrade: (t: any, userId: string) => ({
    id: id(t), market: t.marketSymbol, price: t.price, qty: t.qty, quoteQty: t.quoteQty, side: String(t.takerUserId) === userId ? t.takerSide : (t.takerSide === 'buy' ? 'sell' : 'buy'),
    role: String(t.takerUserId) === userId ? 'taker' : 'maker', fee: String(t.takerUserId) === userId ? t.takerFee : t.makerFee, executedAt: t.executedAt,
  }),
  publicTrade: (t: any) => ({ price: t.price, qty: t.qty, takerSide: t.takerSide, time: t.executedAt }),
  ledger: (e: any) => ({
    id: id(e), asset: e.asset, bucket: e.bucket, direction: e.direction, amount: e.amount, balanceAfterAvailable: e.balanceAfterAvailable,
    balanceAfterLocked: e.balanceAfterLocked, type: e.type, refType: e.refType, refId: e.refId, createdAt: e.createdAt,
  }),
  withdrawal: (w: any) => ({ id: id(w), asset: w.asset, address: w.address, memo: w.memo, amount: w.amount, fee: w.fee, status: w.status, txHash: w.txHash, createdAt: w.createdAt }),
  deposit: (d: any) => ({ id: id(d), asset: d.asset, chain: d.chain, txHash: d.txHash, amount: d.amount, confirmations: d.confirmations, status: d.status, createdAt: d.createdAt }),
  market: (m: any) => ({ symbol: m.symbol, base: m.base, quote: m.quote, tickSize: m.tickSize, lotSize: m.lotSize, minQty: m.minQty, minNotional: m.minNotional, makerFeeBps: m.makerFeeBps, takerFeeBps: m.takerFeeBps, status: m.status }),
};

/** Aggregate [id, price, qty, seq] rows into price levels; never exposes order or user ids. */
export function levels(rows: Array<[string, string, string, number]>, depth = 50): Array<[string, string]> {
  const out: Array<[string, bigint]> = [];
  for (const [, price, qty] of rows) {
    const last = out[out.length - 1];
    if (last && last[0] === price) last[1] += BigInt(qty);
    else out.push([price, BigInt(qty)]);
  }
  return out.slice(0, depth).map(([p, q]) => [p, q.toString()]);
}
