import { ValidationError } from './errors.ts';

/** Non-negative integer, no leading zeros. Same pattern is enforced by the MongoDB $jsonSchema validator. */
export const AMOUNT_PATTERN = '^(0|[1-9][0-9]*)$';
export const AMOUNT_RE = new RegExp(AMOUNT_PATTERN);
export const MAX_AMOUNT = 10n ** 40n;

export function parseAmount(value: unknown, field = 'amount'): bigint {
  if (typeof value !== 'string' || !AMOUNT_RE.test(value)) {
    throw new ValidationError(`${field} must be a non-negative integer string`);
  }
  const v = BigInt(value);
  if (v > MAX_AMOUNT) throw new ValidationError(`${field} is too large`);
  return v;
}

export function parsePositive(value: unknown, field = 'amount'): bigint {
  const v = parseAmount(value, field);
  if (v <= 0n) throw new ValidationError(`${field} must be greater than zero`);
  return v;
}

export function toAmountString(v: bigint): string {
  if (v < 0n) throw new ValidationError('negative amount cannot be stored');
  return v.toString();
}

export function pow10(n: number): bigint {
  if (!Number.isInteger(n) || n < 0 || n > 36) throw new ValidationError('invalid decimals');
  return 10n ** BigInt(n);
}

/**
 * price  = quote smallest units per 1 WHOLE base unit (e.g. rupiah per 1 BTC)
 * qty    = base smallest units (e.g. satoshi)
 * result = quote smallest units, rounded DOWN. Both sides of a trade use this same
 *          number, so no rounding dust is ever created or lost.
 */
export function quoteAmount(price: bigint, qty: bigint, baseDecimals: number): bigint {
  return (price * qty) / pow10(baseDecimals);
}

function checkBps(bps: number) {
  if (!Number.isInteger(bps) || bps < 0 || bps > 10000) throw new ValidationError('bps must be an integer 0..10000');
}
export function feeFloor(amount: bigint, bps: number): bigint {
  checkBps(bps);
  return (amount * BigInt(bps)) / 10000n;
}
export function feeCeil(amount: bigint, bps: number): bigint {
  checkBps(bps);
  return (amount * BigInt(bps) + 9999n) / 10000n;
}
export const minBig = (a: bigint, b: bigint): bigint => (a < b ? a : b);
export const maxBig = (a: bigint, b: bigint): bigint => (a > b ? a : b);
