export const MIN_KYC_LEVEL_TO_TRADE = 1;
export const MIN_KYC_LEVEL_TO_WITHDRAW = 1;
export const DEFAULT_CONFIRMATIONS = 6;
export const CHAIN_CONFIRMATIONS: Record<string, number> = { BTC: 3, ETH: 12, TRON: 20, BANK: 0 };
export const MAX_FEE_BPS = 1000; // 10% hard ceiling on any configured fee

/** Mutable runtime switch: testnet mode accepts testnet address formats (BTC tb1.../m/n/2). Set once at boot. */
export const network = { testnet: false };
/** Monitor a credited deposit until it is this deep (a reorg deeper than this is outside the design). */
export const CHAIN_FINALITY: Record<string, number> = { BTC: 12, ETH: 24, TRON: 40 };
