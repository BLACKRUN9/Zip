import { addressFromPrivate, decodeEip1559, hexBuf, signEip1559, txHash } from '../chain/evmCrypto.ts';
import { hexToBig, pad32, toHex } from '../chain/evmRpc.ts';
import type { Signer } from '../chain/evmRpc.ts';
import { checkTransfer, SignerError } from './policy.ts';
import type { SignerLimits, TransferRequest } from './policy.ts';
import type { SignedRecord, SignerStore } from './store.ts';

export interface EvmSignerConfig {
  privateKey: Buffer; // 32 bytes. Testnet: env var. Production: HSM/KMS (the interface below is all that is needed from it)
  chainId: bigint; // 11155111 = Sepolia
  rpc: (method: string, params: unknown[]) => Promise<any>;
  nativeAsset: string;
  tokens: Record<string, string>; // asset -> ERC-20 contract
  limits: SignerLimits;
  store: SignerStore;
  now?: () => number;
}

const TRANSFER_SELECTOR = '0xa9059cbb'; // transfer(address,uint256)
const BALANCE_OF = '0x70a08231';
const NATIVE_GAS = 21_000n;

/**
 * Builds, signs and broadcasts payouts from ONE hot wallet. Safety properties:
 *  - idempotent per reference: a retry re-sends the SAME signed bytes (same nonce), so it can never pay twice;
 *  - the record (nonce, raw tx, hash) is stored BEFORE broadcasting, so a crash between the two is recoverable;
 *  - nonces are allocated under a mutex from max(chain pending count, stored max + 1);
 *  - policy limits (per-transfer, per-24h) are enforced here, independently of the exchange API.
 * Not handled (documented): fee bumping for stuck transactions, multiple signer instances.
 */
export class EvmSigner implements Signer {
  cfg: EvmSignerConfig;
  hotAddress: string;
  tail: Promise<unknown> = Promise.resolve();

  constructor(cfg: EvmSignerConfig) { this.cfg = cfg; this.hotAddress = addressFromPrivate(cfg.privateKey); }
  now(): number { return (this.cfg.now ?? Date.now)(); }

  sendTransfer(p: { asset: string; to: string; amount: bigint; reference: string }): Promise<string> {
    const run = this.tail.catch(() => undefined).then(() => this._transfer(p));
    this.tail = run;
    return run;
  }

  async _transfer(req: TransferRequest): Promise<string> {
    const { store } = this.cfg;
    const existing = store.get(req.reference);
    if (existing) {
      if (existing.asset !== req.asset || existing.to !== req.to.toLowerCase() || existing.amount !== req.amount.toString()) {
        throw new SignerError('REFERENCE_CONFLICT', 'this reference was already used for a different transfer');
      }
      await this._broadcast(existing); // crash recovery / retry: same bytes, same nonce
      return existing.txHash;
    }
    checkTransfer(req, this.cfg.limits, store.spentSince(req.asset, this.now() - 24 * 3600_000), this.hotAddress, this.cfg.tokens, this.cfg.nativeAsset);

    const isNative = req.asset === this.cfg.nativeAsset;
    const contract = this.cfg.tokens[req.asset];
    const to = req.to.toLowerCase();
    const data = isNative ? '0x' : TRANSFER_SELECTOR + pad32(to).slice(2) + req.amount.toString(16).padStart(64, '0');
    const { rpc } = this.cfg;

    const [block, tipRaw, chainCount] = await Promise.all([
      rpc('eth_getBlockByNumber', ['latest', false]),
      rpc('eth_maxPriorityFeePerGas', []).catch(() => toHex(1_500_000_000n)),
      rpc('eth_getTransactionCount', [this.hotAddress, 'pending']),
    ]);
    const tip = hexToBig(tipRaw);
    const maxFee = 2n * hexToBig(block.baseFeePerGas ?? '0x0') + tip;
    let gasLimit = NATIVE_GAS;
    if (!isNative) {
      try { gasLimit = (hexToBig(await rpc('eth_estimateGas', [{ from: this.hotAddress, to: contract, data }])) * 13n) / 10n; }
      catch { throw new SignerError('ESTIMATE_FAILED', 'the token transfer would revert (balance or contract problem)'); }
    }
    const feeBudget = gasLimit * maxFee;
    const ethBal = hexToBig(await rpc('eth_getBalance', [this.hotAddress, 'latest']));
    if (isNative ? ethBal < req.amount + feeBudget : ethBal < feeBudget) throw new SignerError('INSUFFICIENT_HOT_FUNDS', 'hot wallet cannot cover amount + gas: top it up');
    if (!isNative) {
      const tokenBal = hexToBig(await rpc('eth_call', [{ to: contract, data: BALANCE_OF + pad32(this.hotAddress).slice(2) }, 'latest']));
      if (tokenBal < req.amount) throw new SignerError('INSUFFICIENT_HOT_FUNDS', `hot wallet holds too little ${req.asset}`);
    }

    const nonce = Math.max(Number(hexToBig(chainCount)), store.maxNonce(this.cfg.chainId.toString()) + 1);
    const tx = signEip1559({ chainId: this.cfg.chainId, nonce: BigInt(nonce), maxPriorityFeePerGas: tip, maxFeePerGas: maxFee, gasLimit, to: isNative ? to : contract, value: isNative ? req.amount : 0n, data }, this.cfg.privateKey);
    const rec: SignedRecord = { reference: req.reference, asset: req.asset, to, amount: req.amount.toString(), nonce, txHash: tx.hash, raw: tx.raw, chainId: this.cfg.chainId.toString(), createdAt: this.now() };
    store.put(rec); // durable BEFORE it can reach the network
    await this._broadcast(rec);
    return rec.txHash;
  }

  /** Sending the same signed bytes again is always safe: nodes answer "already known" / "nonce too low" instead of paying twice. */
  async _broadcast(rec: SignedRecord): Promise<void> {
    try {
      await this.cfg.rpc('eth_sendRawTransaction', [rec.raw]);
    } catch (e) {
      const m = String((e as Error).message ?? e).toLowerCase();
      if (m.includes('already known') || m.includes('known transaction') || m.includes('already imported')) return;
      if (m.includes('nonce too low')) {
        if (await this.cfg.rpc('eth_getTransactionByHash', [rec.txHash])) return; // it was mined earlier
        throw new SignerError('NONCE_CONFLICT', 'nonce already used by another transaction: needs a human');
      }
      throw e;
    }
  }
}
export { decodeEip1559, hexBuf, txHash };
