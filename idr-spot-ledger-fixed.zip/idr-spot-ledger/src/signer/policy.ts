/**
 * The signer is the last line of defence: even if the exchange API is fully compromised, the signer refuses
 * anything outside these rules. Pure functions, no I/O.
 */
export class SignerError extends Error {
  code: string;
  constructor(code: string, message: string) { super(message); this.name = 'SignerError'; this.code = code; }
}
export interface SignerLimits {
  perTx: Record<string, bigint>; // max per transfer, smallest units, per asset
  perDay: Record<string, bigint>; // max per rolling 24h, per asset
}
export interface TransferRequest { reference: string; asset: string; to: string; amount: bigint }

const ADDR = /^0x[0-9a-fA-F]{40}$/;
const REF = /^[\w\-.:]{4,80}$/;
export const ZERO_ADDRESS = '0x' + '0'.repeat(40);

export function checkTransfer(req: TransferRequest, limits: SignerLimits, spent24h: bigint, hotAddress: string, tokens: Record<string, string>, nativeAsset: string): void {
  if (!REF.test(req.reference)) throw new SignerError('BAD_REQUEST', 'invalid reference');
  if (req.asset !== nativeAsset && !tokens[req.asset]) throw new SignerError('UNKNOWN_ASSET', `asset ${req.asset} is not configured`);
  if (!ADDR.test(req.to)) throw new SignerError('BAD_ADDRESS', 'invalid destination address');
  const to = req.to.toLowerCase();
  if (to === ZERO_ADDRESS) throw new SignerError('BAD_ADDRESS', 'refusing to send to the zero address');
  if (to === hotAddress.toLowerCase()) throw new SignerError('BAD_ADDRESS', 'refusing to send to the hot wallet itself');
  if (Object.values(tokens).some((c) => c.toLowerCase() === to)) throw new SignerError('BAD_ADDRESS', 'refusing to send tokens to a token contract');
  if (req.amount <= 0n) throw new SignerError('BAD_REQUEST', 'amount must be positive');
  const perTx = limits.perTx[req.asset], perDay = limits.perDay[req.asset];
  if (perTx === undefined || perDay === undefined) throw new SignerError('NO_LIMIT', `no limits configured for ${req.asset}: refusing`); // fail closed
  if (req.amount > perTx) throw new SignerError('OVER_TX_LIMIT', `amount exceeds the per-transfer limit of ${perTx}`);
  if (spent24h + req.amount > perDay) throw new SignerError('OVER_DAILY_LIMIT', `would exceed the 24h limit of ${perDay}`);
}
