import { closeSync, existsSync, fsyncSync, openSync, readFileSync, renameSync, writeSync } from 'node:fs';

/** One record per payout reference. Written BEFORE the transaction is broadcast: that is what makes retries and crashes safe. */
export interface SignedRecord {
  reference: string; asset: string; to: string; amount: string; nonce: number; txHash: string; raw: string; chainId: string; createdAt: number;
}
export interface SignerStore {
  get(reference: string): SignedRecord | undefined;
  put(r: SignedRecord): void; // must be durable when it returns
  maxNonce(chainId: string): number; // -1 if none
  spentSince(asset: string, sinceMs: number): bigint;
}

export class MemoryStore implements SignerStore {
  rows: Map<string, SignedRecord> = new Map();
  get(reference: string) { return this.rows.get(reference); }
  put(r: SignedRecord) { if (this.rows.has(r.reference)) throw new Error('reference already stored'); this.rows.set(r.reference, r); }
  maxNonce(chainId: string) { let m = -1; for (const r of this.rows.values()) if (r.chainId === chainId && r.nonce > m) m = r.nonce; return m; }
  spentSince(asset: string, sinceMs: number) { let s = 0n; for (const r of this.rows.values()) if (r.asset === asset && r.createdAt >= sinceMs) s += BigInt(r.amount); return s; }
}

/** Durable JSON file: write to a temp file, fsync, atomic rename. Replace with a database for anything beyond a single signer instance. */
export class FileStore extends MemoryStore {
  path: string;
  constructor(path: string) {
    super();
    this.path = path;
    if (existsSync(path)) for (const r of JSON.parse(readFileSync(path, 'utf8')) as SignedRecord[]) this.rows.set(r.reference, r);
  }
  put(r: SignedRecord) {
    super.put(r);
    const tmp = this.path + '.tmp';
    const fd = openSync(tmp, 'w', 0o600);
    try { writeSync(fd, JSON.stringify([...this.rows.values()])); fsyncSync(fd); } finally { closeSync(fd); }
    renameSync(tmp, this.path);
  }
}
