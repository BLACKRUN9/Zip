import { createServer } from 'node:http';
import type { Server } from 'node:http';
import { AppError } from '../errors.ts';
import { H_SIG, H_TS, signedHeaders, verifyWebhook } from '../payments/webhook.ts';
import type { Signer } from '../chain/evmRpc.ts';
import { SignerError } from './policy.ts';

const MAX_BODY = 4096;
const TOLERANCE_MS = 60_000;
const STATUS: Record<string, number> = { BAD_REQUEST: 400, BAD_ADDRESS: 400, UNKNOWN_ASSET: 400, NO_LIMIT: 403, OVER_TX_LIMIT: 403, OVER_DAILY_LIMIT: 403, REFERENCE_CONFLICT: 409, NONCE_CONFLICT: 409, INSUFFICIENT_HOT_FUNDS: 503, ESTIMATE_FAILED: 422 };

export interface HandlerDeps { signer: Signer; secret: string; now?: () => number }
/** Transport-independent request handler (unit-testable without sockets). Every request must carry a fresh HMAC. */
export function createHandler(d: HandlerDeps) {
  return async (method: string, url: string, headers: Record<string, string | undefined>, rawBody: string): Promise<{ status: number; body: unknown }> => {
    const now = (d.now ?? Date.now)();
    if (method !== 'POST' || url !== '/v1/transfer') return { status: 404, body: { error: 'NOT_FOUND' } };
    if (rawBody.length > MAX_BODY || !verifyWebhook(d.secret, { [H_TS]: headers[H_TS], [H_SIG]: headers[H_SIG] }, rawBody, now, TOLERANCE_MS)) return { status: 401, body: { error: 'UNAUTHORIZED' } };
    let m: any;
    try { m = JSON.parse(rawBody); } catch { return { status: 400, body: { error: 'BAD_REQUEST', message: 'invalid JSON' } }; }
    if (typeof m?.reference !== 'string' || typeof m.asset !== 'string' || typeof m.to !== 'string' || typeof m.amount !== 'string' || !/^[1-9]\d{0,38}$/.test(m.amount)) {
      return { status: 400, body: { error: 'BAD_REQUEST', message: 'reference, asset, to, amount (integer string) required' } };
    }
    try {
      const txHash = await d.signer.sendTransfer({ reference: m.reference, asset: m.asset, to: m.to, amount: BigInt(m.amount) });
      return { status: 200, body: { txHash } };
    } catch (e) {
      if (e instanceof SignerError) return { status: STATUS[e.code] ?? 400, body: { error: e.code, message: e.message } };
      console.error(JSON.stringify({ level: 'error', msg: 'signer failure', err: String(e) }));
      return { status: 502, body: { error: 'UPSTREAM', message: 'could not broadcast; safe to retry with the same reference' } };
    }
  };
}

export function startSignerServer(handler: ReturnType<typeof createHandler>, port: number, host = '127.0.0.1'): Promise<Server> {
  const server = createServer((req, res) => {
    const chunks: Buffer[] = [];
    let size = 0;
    req.on('data', (c: Buffer) => { size += c.length; if (size > MAX_BODY * 2) { req.destroy(); } else chunks.push(c); });
    req.on('end', async () => {
      const headers = { [H_TS]: req.headers[H_TS] as string | undefined, [H_SIG]: req.headers[H_SIG] as string | undefined };
      const out = await handler(req.method ?? '', req.url ?? '', headers, Buffer.concat(chunks).toString('utf8'));
      res.writeHead(out.status, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
      res.end(JSON.stringify(out.body));
    });
  });
  return new Promise((resolve) => server.listen(port, host, () => resolve(server))); // bind to loopback / a private interface only
}

/** The exchange API's view of the signer: a Signer that talks HTTP with a signed request. */
export class SignerClient implements Signer {
  url: string;
  secret: string;
  fetch: (url: string, init: any) => Promise<any>;
  constructor(o: { url: string; secret: string; fetch: (url: string, init: any) => Promise<any> }) { this.url = o.url; this.secret = o.secret; this.fetch = o.fetch; }
  async sendTransfer(p: { asset: string; to: string; amount: bigint; reference: string }): Promise<string> {
    const raw = JSON.stringify({ reference: p.reference, asset: p.asset, to: p.to, amount: p.amount.toString() });
    const res = await this.fetch(`${this.url}/v1/transfer`, { method: 'POST', headers: signedHeaders(this.secret, raw, Date.now()), body: raw });
    const j = await res.json().catch(() => ({}));
    if (!res.ok) throw new AppError(j.error ?? 'SIGNER_ERROR', j.message ?? `signer http ${res.status}`);
    return j.txHash as string;
  }
}
