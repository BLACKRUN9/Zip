/**
 * Stand-alone signer process (run it on its own host/container, reachable only from the exchange API):
 *   SIGNER_PRIVATE_KEY=<64 hex> SIGNER_SECRET=<shared secret> EVM_RPC_URL=... CHAIN_ID=11155111 \
 *   EVM_USDT_ADDRESS=0x... SIGNER_STORE_PATH=./signer-state.json node --experimental-strip-types src/signer/main.ts
 * A key in an environment variable is acceptable for a TESTNET hot wallet only. On mainnet use an HSM/KMS-backed signer.
 */
import { EvmSigner } from './evmSigner.ts';
import { createHandler, startSignerServer } from './http.ts';
import { FileStore } from './store.ts';

const need = (n: string): string => { const v = process.env[n]; if (!v) throw new Error(`missing env ${n}`); return v; };
const big = (n: string, d: string): bigint => BigInt(process.env[n] ?? d);

async function main() {
  const chainId = BigInt(need('CHAIN_ID'));
  if (process.env.NODE_ENV === 'production' && chainId === 1n) throw new Error('refusing to run an env-var key on Ethereum mainnet: use an HSM/KMS signer');
  const rpcUrl = need('EVM_RPC_URL');
  let id = 0;
  const rpc = async (method: string, params: unknown[]) => {
    const r = await fetch(rpcUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ jsonrpc: '2.0', id: ++id, method, params }) });
    const j: any = await r.json();
    if (j.error) throw new Error(j.error.message);
    return j.result;
  };
  const tokens = process.env.EVM_USDT_ADDRESS ? { USDT: process.env.EVM_USDT_ADDRESS } : {};
  const signer = new EvmSigner({
    privateKey: Buffer.from(need('SIGNER_PRIVATE_KEY').replace(/^0x/, ''), 'hex'), chainId, rpc, nativeAsset: 'ETH', tokens, store: new FileStore(process.env.SIGNER_STORE_PATH ?? './signer-state.json'),
    limits: { // conservative testnet defaults, override per asset
      perTx: { ETH: big('LIMIT_ETH_TX', '500000000000000000'), USDT: big('LIMIT_USDT_TX', '1000000000') },
      perDay: { ETH: big('LIMIT_ETH_DAY', '2000000000000000000'), USDT: big('LIMIT_USDT_DAY', '5000000000') },
    },
  });
  const server = await startSignerServer(createHandler({ signer, secret: need('SIGNER_SECRET') }), Number(process.env.SIGNER_PORT ?? 4000), process.env.SIGNER_HOST ?? '127.0.0.1');
  console.log(JSON.stringify({ msg: 'signer listening', hotAddress: signer.hotAddress, chainId: chainId.toString(), port: (server.address() as any).port }));
}
main().catch((e) => { console.error(e); process.exit(1); });
