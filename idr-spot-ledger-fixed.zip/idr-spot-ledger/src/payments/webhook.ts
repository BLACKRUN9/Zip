import { createHmac, timingSafeEqual } from 'node:crypto';

export const WEBHOOK_TOLERANCE_MS = 5 * 60_000;
export const H_TS = 'x-webhook-timestamp';
export const H_SIG = 'x-webhook-signature';

/** signature = hex(HMAC_SHA256(secret, "<timestamp>.<raw body>")). The RAW body string, byte for byte. */
export const signWebhook = (secret: string, timestamp: number | string, rawBody: string): string =>
  createHmac('sha256', secret).update(`${timestamp}.${rawBody}`).digest('hex');

export function signedHeaders(secret: string, rawBody: string, now: number): Record<string, string> {
  return { [H_TS]: String(now), [H_SIG]: signWebhook(secret, now, rawBody), 'content-type': 'application/json' };
}

export function verifyWebhook(secret: string, headers: Record<string, string | undefined>, rawBody: string, now: number, toleranceMs = WEBHOOK_TOLERANCE_MS): boolean {
  const ts = headers[H_TS], sig = headers[H_SIG];
  if (!ts || !sig || !/^\d{10,16}$/.test(ts) || !/^[0-9a-f]{64}$/i.test(sig)) return false;
  if (Math.abs(now - Number(ts)) > toleranceMs) return false; // stale or far-future: replay window
  const want = Buffer.from(signWebhook(secret, ts, rawBody), 'hex');
  const got = Buffer.from(sig, 'hex');
  return want.length === got.length && timingSafeEqual(want, got);
}
