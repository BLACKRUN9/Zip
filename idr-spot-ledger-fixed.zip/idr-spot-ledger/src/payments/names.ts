/**
 * Bank sender name vs the name on the user's KYC. Conservative on purpose: "false" only costs a manual review,
 * a wrong "true" would credit money from a third party (an AML problem). Pure function.
 */
const TITLES = new Set(['BAPAK', 'BPK', 'IBU', 'SDR', 'SDRI', 'TUAN', 'NYONYA', 'NY', 'MR', 'MRS', 'MS', 'H', 'HJ', 'DR', 'DRS', 'DRA', 'IR', 'PROF', 'SE', 'SH', 'ST', 'SKOM', 'MM', 'MSI', 'SPD', 'SKM', 'AMD', 'SSOS', 'MH', 'MT', 'MBA']);
const BUSINESS = new Set(['PT', 'CV', 'UD', 'YAYASAN', 'KOPERASI', 'TOKO', 'FIRMA', 'PD']);

export function nameTokens(raw: string): string[] {
  return raw
    .normalize('NFKD').replace(/[\u0300-\u036f]/g, '') // strip diacritics
    .toUpperCase()
    .replace(/[^A-Z\s]/g, ' ') // punctuation, digits
    .split(/\s+/)
    .filter(Boolean);
}

export function nameMatches(sender: string, kycName: string): boolean {
  const a = nameTokens(sender);
  const b = nameTokens(kycName);
  if (a.some((t) => BUSINESS.has(t)) || b.some((t) => BUSINESS.has(t))) return false; // company accounts are never auto-matched
  const sa = a.filter((t) => !TITLES.has(t));
  const sb = b.filter((t) => !TITLES.has(t));
  if (sa.length === 0 || sb.length === 0) return false;
  const [small, big] = sa.length <= sb.length ? [sa, sb] : [sb, sa];
  if (small.length < 2) return sa.length === sb.length && sa[0] === sb[0]; // single-word names must be identical
  // every word of the shorter name must appear in the longer one; banks truncate, so a >=3-letter prefix of a word counts
  return small.every((t) => big.some((u) => u === t || (t.length >= 3 && u.startsWith(t)) || (u.length >= 3 && t.startsWith(u))));
}
