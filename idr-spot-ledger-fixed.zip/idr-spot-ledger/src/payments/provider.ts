import { createHash, randomInt } from 'node:crypto';
import { AppError } from '../errors.ts';
import { H_SIG, H_TS, signedHeaders, verifyWebhook } from './webhook.ts';

export const BANKS = ['BCA', 'MANDIRI', 'BNI', 'BRI'] as const;
export type Bank = (typeof BANKS)[number];
export const isBank = (s: string): s is Bank => (BANKS as readonly string[]).includes(s);

export type PaymentEvent =
  | { type: 'deposit.paid'; providerRef: string; vaNumber: string; amount: string; senderName: string; paidAt: string }
  | { type: 'payout.completed' | 'payout.failed'; providerRef: string; reference: string; reason?: string };

export interface PaymentProvider {
  name: string;
  verifyWebhook(headers: Record<string, string | undefined>, rawBody: string, now?: number): boolean;
  parseWebhook(rawBody: string): PaymentEvent;
  createVirtualAccount(i: { userId: string; displayName: string; bank: Bank }): Promise<{ vaNumber: string; bank: Bank }>;
  /** MUST be idempotent per `reference` (a retry returns the same payout, never pays twice). */
  createPayout(i: { reference: string; amount: string; bank: Bank; accountNumber: string; accountName: string }): Promise<{ gatewayRef: string }>;
}

const REF = /^[\w\-.]{4,64}$/;
const bad = (m: string) => new AppError('VALIDATION', `bad webhook: ${m}`);

/** Strict, allow-listed parsing: an authenticated sender still must not be able to smuggle unexpected shapes. */
export function parsePaymentEvent(rawBody: string): PaymentEvent {
  let m: any;
  try { m = JSON.parse(rawBody); } catch { throw bad('invalid JSON'); }
  if (!m || typeof m !== 'object') throw bad('not an object');
  const ref = (v: unknown, n: string) => { if (typeof v !== 'string' || !REF.test(v)) throw bad(n); return v; };
  if (m.type === 'deposit.paid') {
    if (typeof m.vaNumber !== 'string' || !/^\d{8,20}$/.test(m.vaNumber)) throw bad('vaNumber');
    if (typeof m.amount !== 'string' || !/^[1-9]\d{0,14}$/.test(m.amount)) throw bad('amount');
    if (typeof m.senderName !== 'string' || m.senderName.length < 1 || m.senderName.length > 100) throw bad('senderName');
    if (typeof m.paidAt !== 'string' || Number.isNaN(Date.parse(m.paidAt))) throw bad('paidAt');
    return { type: 'deposit.paid', providerRef: ref(m.providerRef, 'providerRef'), vaNumber: m.vaNumber, amount: m.amount, senderName: m.senderName, paidAt: m.paidAt };
  }
  if (m.type === 'payout.completed' || m.type === 'payout.failed') {
    return { type: m.type, providerRef: ref(m.providerRef, 'providerRef'), reference: ref(m.reference, 'reference'), reason: typeof m.reason === 'string' ? m.reason.slice(0, 200) : undefined };
  }
  throw bad('unknown type');
}

const VA_PREFIX: Record<Bank, string> = { BCA: '39', MANDIRI: '88', BNI: '98', BRI: '26' };

/**
 * A pretend bank + payment gateway for development and demos. It behaves like a real one where it matters:
 * asynchronous signed webhooks, duplicate deliveries, name mismatches, failed payouts. NEVER enable in production.
 */
export class SimProvider implements PaymentProvider {
  name = 'sim';
  secret: string;
  now: () => number;
  /** Where signed webhooks are delivered (the app wires this to its real webhook handler). */
  deliver: (rawBody: string, headers: Record<string, string>) => Promise<unknown>;
  payouts: Map<string, { reference: string; gatewayRef: string; amount: string; bank: Bank; accountNumber: string; accountName: string; status: 'processing' | 'completed' | 'failed' }> = new Map();
  seq = 0;

  constructor(o: { secret: string; now?: () => number; deliver?: SimProvider['deliver'] }) {
    if (process.env.NODE_ENV === 'production') throw new AppError('CONFIG', 'the simulated payment provider must not run in production');
    this.secret = o.secret;
    this.now = o.now ?? Date.now;
    this.deliver = o.deliver ?? (async () => { throw new Error('SimProvider.deliver is not wired'); });
  }

  verifyWebhook(headers: Record<string, string | undefined>, rawBody: string, now = this.now()): boolean {
    return verifyWebhook(this.secret, { [H_TS]: headers[H_TS], [H_SIG]: headers[H_SIG] }, rawBody, now);
  }
  parseWebhook = parsePaymentEvent;

  async createVirtualAccount(i: { userId: string; displayName: string; bank: Bank }) {
    // 2-digit bank prefix + 10 random digits. The caller stores it under a UNIQUE index and retries on collision.
    return { bank: i.bank, vaNumber: VA_PREFIX[i.bank] + String(randomInt(0, 10 ** 10)).padStart(10, '0') };
  }

  async createPayout(i: { reference: string; amount: string; bank: Bank; accountNumber: string; accountName: string }) {
    const hit = this.payouts.get(i.reference);
    if (hit) return { gatewayRef: hit.gatewayRef }; // idempotent
    const gatewayRef = `SIMPO-${++this.seq}-${createHash('sha256').update(i.reference).digest('hex').slice(0, 8)}`;
    this.payouts.set(i.reference, { ...i, gatewayRef, status: 'processing' });
    return { gatewayRef };
  }

  async _send(event: PaymentEvent): Promise<void> {
    const raw = JSON.stringify(event);
    await this.deliver(raw, signedHeaders(this.secret, raw, this.now()));
  }

  /** "A customer transfers money from their bank app to a virtual account." */
  async simulateTransfer(o: { vaNumber: string; amount: string; senderName: string; paymentId?: string; duplicate?: boolean }): Promise<string> {
    const providerRef = o.paymentId ?? `SIMPAY-${this.now()}-${++this.seq}`;
    const ev: PaymentEvent = { type: 'deposit.paid', providerRef, vaNumber: o.vaNumber, amount: o.amount, senderName: o.senderName, paidAt: new Date(this.now()).toISOString() };
    await this._send(ev);
    if (o.duplicate) await this._send(ev); // gateways retry: the receiver must be idempotent
    return providerRef;
  }

  /** "The bank settled (or rejected) a disbursement." */
  async simulatePayoutResult(reference: string, outcome: 'completed' | 'failed', reason?: string): Promise<void> {
    const p = this.payouts.get(reference);
    if (!p) throw new AppError('NOT_FOUND', 'unknown payout reference');
    p.status = outcome;
    await this._send({ type: outcome === 'completed' ? 'payout.completed' : 'payout.failed', providerRef: p.gatewayRef, reference, reason });
  }
}
