import { Asset, Market } from './db/models.ts';
import { ensureSystemAccounts } from './services/ledger.ts';

/**
 * Idempotent bootstrap: assets (IDR/BTC/ETH/USDT), 3 IDR markets, system accounts.
 * All amounts are integers in each asset's smallest unit.
 *
 * Market sanity rule (checked again at order time): price * lotSize / 10^baseDecimals >= 1,
 * so every lot-multiple fill is worth at least one quote unit.
 */
export async function seedBasics(o: { usdtChain?: string } = {}) {
  const assets = [
    { symbol: 'IDR', name: 'Indonesian Rupiah', decimals: 0, type: 'fiat', chain: 'BANK', minDeposit: '10000', minWithdraw: '50000', withdrawFee: '6500' },
    { symbol: 'BTC', name: 'Bitcoin', decimals: 8, type: 'crypto', chain: 'BTC', minDeposit: '10000', minWithdraw: '20000', withdrawFee: '10000' },
    { symbol: 'ETH', name: 'Ether', decimals: 18, type: 'crypto', chain: 'ETH', minDeposit: '1000000000000000', minWithdraw: '5000000000000000', withdrawFee: '1000000000000000' },
    { symbol: 'USDT', name: 'Tether', decimals: 6, type: 'crypto', chain: o.usdtChain ?? 'TRON', minDeposit: '1000000', minWithdraw: '10000000', withdrawFee: '1000000' },
  ];
  for (const a of assets) await Asset.updateOne({ symbol: a.symbol }, { $setOnInsert: { ...a, enabled: true } }, { upsert: true });

  const markets = [
    { symbol: 'BTC_IDR', base: 'BTC', quote: 'IDR', tickSize: '1000', lotSize: '1000', minQty: '1000', minNotional: '10000' },
    { symbol: 'ETH_IDR', base: 'ETH', quote: 'IDR', tickSize: '1000', lotSize: '1000000000000000', minQty: '1000000000000000', minNotional: '10000' },
    { symbol: 'USDT_IDR', base: 'USDT', quote: 'IDR', tickSize: '1', lotSize: '10000', minQty: '10000', minNotional: '10000' },
  ];
  for (const m of markets) {
    await Market.updateOne({ symbol: m.symbol }, { $setOnInsert: { ...m, makerFeeBps: 10, takerFeeBps: 20, status: 'active' } }, { upsert: true });
  }
  await ensureSystemAccounts();
}
