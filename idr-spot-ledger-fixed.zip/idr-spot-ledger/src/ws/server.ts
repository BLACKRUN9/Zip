import type { IncomingMessage, Server } from 'node:http';
import type { Duplex } from 'node:stream';
import { WebSocketServer } from 'ws';
import type { WebSocket } from 'ws';
import type { MarketFeed } from '../marketdata/feed.ts';
import { ApiKey, Order, User } from '../db/models.ts';
import { ser } from '../api/serializers.ts';
import { authenticateAccess } from '../services/auth.ts';
import { authenticateApiRequest } from '../services/apikeys.ts';
import { cancelOrder, placeOrder } from '../services/orders.ts';
import type { EngineGateway } from '../services/orders.ts';
import { Connection } from './connection.ts';
import { MAX_MSG_BYTES } from './protocol.ts';

export interface WsDeps {
  feed: MarketFeed;
  /** Enables order entry for API-key (bot) connections. */
  gateway?: EngineGateway;
  /** Browser Origins allowed to connect. Clients that send no Origin (bots/servers) are not affected. [] = no browser may connect. */
  allowedOrigins: string[];
  trustProxy?: boolean;
  maxPerIp?: number;
  maxTotal?: number;
  heartbeatMs?: number;
}

const reject = (socket: Duplex, code: number, text: string) => {
  socket.write(`HTTP/1.1 ${code} ${text}\r\nConnection: close\r\nContent-Length: 0\r\n\r\n`);
  socket.destroy();
};
const clientIp = (req: IncomingMessage, trustProxy?: boolean): string => {
  const xff = req.headers['x-forwarded-for'];
  if (trustProxy && typeof xff === 'string') return xff.split(',')[0].trim();
  return req.socket.remoteAddress ?? 'unknown';
};

/** Attach /ws to an http server. Protocol: see src/ws/protocol.ts. Tokens travel in the first message, never in the URL. */
export function attachWebSocket(server: Server, deps: WsDeps) {
  const wss = new WebSocketServer({ noServer: true, maxPayload: MAX_MSG_BYTES });
  const perIp = new Map<string, number>();
  const maxPerIp = deps.maxPerIp ?? 20;
  const maxTotal = deps.maxTotal ?? 5000;

  server.on('upgrade', (req, socket, head) => {
    let path = '';
    try { path = new URL(req.url ?? '', 'http://x').pathname; } catch { /* ignore */ }
    if (path !== '/ws') { socket.destroy(); return; }
    const origin = req.headers.origin;
    if (origin && !deps.allowedOrigins.includes(origin)) { reject(socket, 403, 'Forbidden'); return; }
    const ip = clientIp(req, deps.trustProxy);
    if ((perIp.get(ip) ?? 0) >= maxPerIp || wss.clients.size >= maxTotal) { reject(socket, 429, 'Too Many Requests'); return; }
    perIp.set(ip, (perIp.get(ip) ?? 0) + 1);
    wss.handleUpgrade(req, socket, head, (ws) => onConnection(ws, ip));
  });

  function onConnection(ws: WebSocket, ip: string) {
    let alive = true;
    const conn = new Connection({
      hub: deps.feed.hub,
      authenticate: async (token) => {
        const { session } = await authenticateAccess(token);
        return { userId: String(session.userId), expiresAt: new Date(session.accessExpiresAt).getTime() };
      },
      authenticateKey: async (p) => {
        // same signed-request scheme as REST, over the fixed request line "GET /ws" with an empty body
        const a = await authenticateApiRequest({ keyId: p.apiKey, timestamp: p.timestamp, signature: p.signature, method: 'GET', path: '/ws', body: '', ip });
        return {
          userId: String(a.user._id),
          permissions: a.permissions,
          revalidate: async () => {
            const [key, user]: any[] = await Promise.all([ApiKey.exists({ keyId: a.keyId, revokedAt: null }), User.findById(a.user._id).select('status').lean()]);
            return !!key && !!user && user.status !== 'closed';
          },
        };
      },
      placeOrder: deps.gateway ? (uid, m) => placeOrder({ userId: uid, market: m.market, side: m.side, type: m.type, tif: m.tif, price: m.price, qty: m.qty, clientOrderId: m.clientOrderId, idempotencyKey: m.idempotencyKey }, deps.gateway).then(async (o) => ser.order(await Order.findById(o.id).lean())) : undefined, // same allow-listed shape as REST
      cancelOrder: deps.gateway ? (uid, orderId) => cancelOrder(uid, orderId, deps.gateway!) : undefined,
      snapshot: (ch, uid) => deps.feed.snapshot(ch, uid),
      send: (obj) => {
        if (ws.readyState !== ws.OPEN) return;
        if (ws.bufferedAmount > 1_000_000) { ws.close(1013, 'slow consumer'); return; } // never buffer unboundedly for a stalled client
        ws.send(JSON.stringify(obj));
      },
      close: (code, reason) => ws.close(code, reason),
      now: () => Date.now(),
    });
    ws.on('pong', () => { alive = true; });
    ws.on('message', (data, isBinary) => {
      if (isBinary) { ws.close(1003, 'text only'); return; }
      conn.handleRaw(data.toString('utf8')).catch(() => ws.close(1011, 'internal error'));
    });
    const hb = setInterval(() => {
      if (!alive) { ws.terminate(); return; }
      alive = false;
      ws.ping();
      conn.heartbeat().catch(() => {}); // session expiry + bot API-key revocation checks
    }, deps.heartbeatMs ?? 15_000);
    const done = () => {
      clearInterval(hb);
      conn.dispose();
      const n = (perIp.get(ip) ?? 1) - 1;
      if (n <= 0) perIp.delete(ip); else perIp.set(ip, n);
    };
    ws.on('close', done);
    ws.on('error', () => ws.terminate());
  }

  return { wss, close: () => new Promise<void>((resolve) => { for (const c of wss.clients) c.terminate(); wss.close(() => resolve()); }) };
}
