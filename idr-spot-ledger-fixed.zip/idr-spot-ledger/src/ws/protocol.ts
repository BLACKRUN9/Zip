import { isInterval } from '../marketdata/candles.ts';
import type { Interval } from '../marketdata/candles.ts';

export const MAX_MSG_BYTES = 4096;
export const MAX_SUBSCRIPTIONS = 20;
export const MAX_PROTOCOL_ERRORS = 5;

export class WsProtocolError extends Error {
  code: string;
  constructor(code: string, message: string) { super(message); this.name = 'WsProtocolError'; this.code = code; }
}

export type Channel =
  | { kind: 'ticker' | 'trades' | 'book'; market: string }
  | { kind: 'candles'; market: string; interval: Interval }
  | { kind: 'orders' | 'balances' };

export interface PlaceOrderMsg {
  op: 'order.place';
  id: string; // client correlation id, echoed in the ack/error
  market: string;
  side: 'buy' | 'sell';
  type: 'limit' | 'market';
  tif?: 'GTC' | 'IOC';
  price?: string;
  qty: string;
  clientOrderId?: string;
  idempotencyKey: string; // required, same exactly-once semantics as the REST Idempotency-Key
}
export type ClientMsg =
  | { op: 'auth'; token: string } // browser session (access token)
  | { op: 'auth'; apiKey: string; timestamp: string; signature: string } // bot (HMAC over "<ts>\nGET\n/ws\n<sha256('')>")
  | { op: 'subscribe' | 'unsubscribe'; channel: string }
  | PlaceOrderMsg
  | { op: 'order.cancel'; id: string; orderId: string }
  | { op: 'ping' };

const MARKET_RE = /^[A-Z0-9]{2,10}_[A-Z0-9]{2,10}$/;
const AMOUNT_RE = /^(0|[1-9]\d{0,38})$/;
const ID_RE = /^[\w\-.:]{1,64}$/;
const KEY_RE = /^[A-Za-z0-9_\-:.]{8,128}$/;

export function parseChannel(s: unknown): Channel {
  if (typeof s !== 'string' || s.length > 40) throw new WsProtocolError('INVALID_CHANNEL', 'invalid channel');
  const p = s.split(':');
  if ((s === 'orders' || s === 'balances') && p.length === 1) return { kind: s };
  if ((p[0] === 'ticker' || p[0] === 'trades' || p[0] === 'book') && p.length === 2 && MARKET_RE.test(p[1])) return { kind: p[0], market: p[1] };
  if (p[0] === 'candles' && p.length === 3 && MARKET_RE.test(p[1]) && isInterval(p[2])) return { kind: 'candles', market: p[1], interval: p[2] };
  throw new WsProtocolError('INVALID_CHANNEL', 'unknown channel');
}
export const isPrivate = (c: Channel): boolean => c.kind === 'orders' || c.kind === 'balances';

/** Hub key. Private channels are namespaced by the AUTHENTICATED user id, never by anything the client sends. */
export function hubKey(c: Channel, userId?: string): string {
  switch (c.kind) {
    case 'orders': case 'balances': return `${c.kind}:${userId}`;
    case 'candles': return `candles:${c.market}:${c.interval}`;
    default: return `${c.kind}:${c.market}`;
  }
}

const bad = (m: string) => new WsProtocolError('BAD_MESSAGE', m);
const str = (v: unknown, re: RegExp, name: string): string => {
  if (typeof v !== 'string' || !re.test(v)) throw bad(`invalid ${name}`);
  return v;
};

export function parseClientMessage(raw: unknown): ClientMsg {
  const text = typeof raw === 'string' ? raw : Buffer.isBuffer(raw) ? raw.toString('utf8') : '';
  if (!text || Buffer.byteLength(text) > MAX_MSG_BYTES) throw bad('empty or oversized message');
  let m: any;
  try { m = JSON.parse(text); } catch { throw bad('invalid JSON'); }
  if (!m || typeof m !== 'object' || Array.isArray(m)) throw bad('message must be an object');
  switch (m.op) {
    case 'ping': return { op: 'ping' };
    case 'auth':
      if (m.apiKey !== undefined) {
        return {
          op: 'auth',
          apiKey: str(m.apiKey, /^ak_[A-Za-z0-9_\-]{8,60}$/, 'apiKey'),
          timestamp: str(m.timestamp, /^\d{10,16}$/, 'timestamp'),
          signature: str(m.signature, /^[0-9a-fA-F]{64}$/, 'signature'),
        };
      }
      if (typeof m.token !== 'string' || m.token.length < 10 || m.token.length > 200) throw bad('invalid token');
      return { op: 'auth', token: m.token };
    case 'subscribe':
    case 'unsubscribe':
      if (typeof m.channel !== 'string') throw bad('channel required');
      return { op: m.op, channel: m.channel };
    case 'order.place': {
      const side = m.side, type = m.type, tif = m.tif;
      if (side !== 'buy' && side !== 'sell') throw bad('invalid side');
      if (type !== 'limit' && type !== 'market') throw bad('invalid type');
      if (tif !== undefined && tif !== 'GTC' && tif !== 'IOC') throw bad('invalid tif');
      return {
        op: 'order.place',
        id: str(m.id, ID_RE, 'id'),
        market: str(m.market, MARKET_RE, 'market'),
        side, type, tif,
        price: m.price === undefined ? undefined : str(m.price, AMOUNT_RE, 'price'),
        qty: str(m.qty, AMOUNT_RE, 'qty'),
        clientOrderId: m.clientOrderId === undefined ? undefined : str(m.clientOrderId, ID_RE, 'clientOrderId'),
        idempotencyKey: str(m.idempotencyKey, KEY_RE, 'idempotencyKey'),
      };
    }
    case 'order.cancel':
      return { op: 'order.cancel', id: str(m.id, ID_RE, 'id'), orderId: str(m.orderId, /^[0-9a-f]{24}$/, 'orderId') };
    default:
      throw new WsProtocolError('UNKNOWN_OP', 'unknown op');
  }
}
