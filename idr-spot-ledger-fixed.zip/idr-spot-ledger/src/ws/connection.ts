import { toErrorBody } from '../api/http.ts';
import { TokenBucket } from '../security/ratelimit.ts';
import type { Hub } from '../marketdata/hub.ts';
import { MAX_PROTOCOL_ERRORS, MAX_SUBSCRIPTIONS, WsProtocolError, hubKey, isPrivate, parseChannel, parseClientMessage } from './protocol.ts';
import type { Channel, PlaceOrderMsg } from './protocol.ts';

export interface KeyAuth { userId: string; permissions: string[]; revalidate: () => Promise<boolean> }
export interface ConnDeps {
  hub: Hub;
  authenticate(token: string): Promise<{ userId: string; expiresAt: number }>;
  /** Bot auth. Absent => API-key auth is not offered on this server. */
  authenticateKey?(p: { apiKey: string; timestamp: string; signature: string }): Promise<KeyAuth>;
  placeOrder?(userId: string, m: PlaceOrderMsg): Promise<unknown>;
  cancelOrder?(userId: string, orderId: string): Promise<unknown>;
  snapshot(channel: Channel, userId?: string): Promise<{ data: any; seq?: number }>;
  send(obj: unknown): void;
  close(code: number, reason: string): void;
  now(): number;
  limiter?: TokenBucket;
  tradeLimiter?: TokenBucket;
}
interface Sub { unsub: () => void; ready: boolean; queue: Array<{ data: any; seq?: number }> }
const MAX_QUEUE = 1000;

/**
 * Transport-independent protocol state machine for ONE websocket client (unit-testable without sockets).
 * Subscribe = register on the hub first, fetch a snapshot, send it, then flush only updates NEWER than the
 * snapshot (by seq). A client never sees an update before its snapshot, and never a duplicate.
 * Two auth kinds: 'session' (browser; private streams) and 'apikey' (bot; private streams + order entry).
 */
export class Connection {
  deps: ConnDeps;
  userId?: string;
  kind?: 'session' | 'apikey';
  perms: string[] = [];
  expiresAt = 0;
  revalidate?: () => Promise<boolean>;
  subs: Map<string, Sub> = new Map();
  errors = 0;
  authFailures = 0;
  closed = false;
  rate: TokenBucket;
  tradeRate: TokenBucket;

  constructor(deps: ConnDeps) {
    this.deps = deps;
    this.rate = deps.limiter ?? new TokenBucket(20, 10);
    this.tradeRate = deps.tradeLimiter ?? new TokenBucket(50, 25);
  }

  _error(code: string, message: string, extra: object = {}): void {
    this.deps.send({ type: 'error', code, message, ...extra });
  }
  _strike(): void {
    if (++this.errors >= MAX_PROTOCOL_ERRORS) {
      this.deps.close(1008, 'too many errors');
      this.dispose();
    }
  }
  _dropPrivate(): void {
    for (const [ch, s] of [...this.subs]) {
      let c: Channel | null = null;
      try { c = parseChannel(ch); } catch { /* ignore */ }
      if (c && isPrivate(c)) { s.unsub(); this.subs.delete(ch); }
    }
  }
  _canRead(): boolean {
    return !!this.userId && (this.kind === 'session' || this.perms.includes('read') || this.perms.includes('trade'));
  }

  /** Sync expiry check. Browser sessions stop streaming private data when the access token expires; bots do not expire. */
  tick(): void {
    if (this.userId && this.kind === 'session' && this.deps.now() >= this.expiresAt) {
      this._dropPrivate();
      this.userId = undefined;
      this.kind = undefined;
      this._error('TOKEN_EXPIRED', 'access token expired: send auth again');
    }
  }

  /** Heartbeat: expiry + (for bots) re-check that the API key was not revoked and the user is still allowed. */
  async heartbeat(): Promise<void> {
    if (this.closed) return;
    this.tick();
    if (this.kind === 'apikey' && this.revalidate) {
      let ok = false;
      try { ok = await this.revalidate(); } catch { ok = true; /* transient DB failure: do not kick bots on an outage */ }
      if (!ok && !this.closed) {
        this._error('KEY_REVOKED', 'API key is no longer valid');
        this.deps.close(1008, 'api key revoked');
        this.dispose();
      }
    }
  }

  async handleRaw(raw: unknown): Promise<void> {
    if (this.closed) return;
    this.tick();
    if (!this.rate.consume('c', this.deps.now()).ok) {
      this._error('RATE_LIMITED', 'too many messages');
      this._strike();
      return;
    }
    let msg;
    try { msg = parseClientMessage(raw); } catch (e) {
      const err = e instanceof WsProtocolError ? e : new WsProtocolError('BAD_MESSAGE', 'bad message');
      this._error(err.code, err.message);
      this._strike();
      return;
    }
    switch (msg.op) {
      case 'ping':
        this.deps.send({ type: 'pong', t: this.deps.now() });
        return;
      case 'auth':
        return this._auth(msg);
      case 'subscribe':
        return this._subscribe(msg.channel);
      case 'unsubscribe': {
        const s = this.subs.get(msg.channel);
        if (s) { s.unsub(); this.subs.delete(msg.channel); }
        this.deps.send({ type: 'unsubscribed', channel: msg.channel });
        return;
      }
      case 'order.place':
        return this._trade(msg.id, async (uid) => this.deps.placeOrder!(uid, msg));
      case 'order.cancel':
        return this._trade(msg.id, async (uid) => this.deps.cancelOrder!(uid, msg.orderId));
    }
  }

  async _auth(msg: { op: 'auth'; token?: string; apiKey?: string; timestamp?: string; signature?: string }): Promise<void> {
    if (this.userId) { this._error('ALREADY_AUTHED', 'already authenticated'); return; }
    try {
      if (msg.apiKey !== undefined) {
        if (!this.deps.authenticateKey) throw new Error('api keys not supported');
        const a = await this.deps.authenticateKey({ apiKey: msg.apiKey, timestamp: msg.timestamp!, signature: msg.signature! });
        if (this.closed) return;
        this.userId = a.userId; this.kind = 'apikey'; this.perms = a.permissions; this.revalidate = a.revalidate; this.expiresAt = Infinity;
        this.deps.send({ type: 'authed', kind: 'apikey', permissions: a.permissions });
      } else {
        const a = await this.deps.authenticate(msg.token!);
        if (this.closed) return;
        this.userId = a.userId; this.kind = 'session'; this.perms = []; this.expiresAt = a.expiresAt;
        this.deps.send({ type: 'authed', kind: 'session', expiresAt: a.expiresAt });
      }
    } catch {
      this._error('AUTH_FAILED', 'invalid or expired credentials');
      if (++this.authFailures >= 3) { this.deps.close(1008, 'authentication failed'); this.dispose(); }
    }
  }

  /** Order entry over the socket: API-key connections with the "trade" permission only. Always answers with ack or error for the same id. */
  async _trade(id: string, run: (userId: string) => Promise<unknown>): Promise<void> {
    const fail = (code: string, message: string) => this.deps.send({ type: 'order.error', id, code, message });
    if (!this.userId || this.kind !== 'apikey') return fail('FORBIDDEN', 'order entry requires API-key authentication');
    if (!this.perms.includes('trade')) return fail('FORBIDDEN', 'API key lacks the "trade" permission');
    if (!this.deps.placeOrder || !this.deps.cancelOrder) return fail('NOT_SUPPORTED', 'order entry is not enabled');
    if (!this.tradeRate.consume('t', this.deps.now()).ok) return fail('RATE_LIMITED', 'too many order requests');
    try {
      const order = await run(this.userId);
      this.deps.send({ type: 'order.ack', id, order });
    } catch (e) {
      const { body } = toErrorBody(e, id); // same allow-list as REST: no internals leak
      fail(body.error, body.message);
    }
  }

  async _subscribe(channelStr: string): Promise<void> {
    let channel: Channel;
    try { channel = parseChannel(channelStr); } catch (e: any) { this._error(e.code ?? 'INVALID_CHANNEL', e.message); this._strike(); return; }
    if (isPrivate(channel)) {
      if (!this.userId) { this._error('AUTH_REQUIRED', 'authenticate first'); return; }
      if (!this._canRead()) { this._error('FORBIDDEN', 'API key lacks the "read" permission'); return; }
    }
    if (this.subs.has(channelStr)) { this.deps.send({ type: 'subscribed', channel: channelStr }); return; } // idempotent
    if (this.subs.size >= MAX_SUBSCRIPTIONS) { this._error('TOO_MANY_SUBSCRIPTIONS', `at most ${MAX_SUBSCRIPTIONS} subscriptions`); return; }

    const sub: Sub = { unsub: () => {}, ready: false, queue: [] };
    sub.unsub = this.deps.hub.subscribe(hubKey(channel, this.userId), (m) => {
      if (this.closed) return;
      if (!sub.ready) { if (sub.queue.length < MAX_QUEUE) sub.queue.push(m); return; }
      this.deps.send({ type: 'update', channel: channelStr, seq: m.seq, data: m.data });
    });
    this.subs.set(channelStr, sub);
    try {
      const snap = await this.deps.snapshot(channel, this.userId);
      if (this.closed || this.subs.get(channelStr) !== sub) return;
      this.deps.send({ type: 'subscribed', channel: channelStr });
      this.deps.send({ type: 'snapshot', channel: channelStr, seq: snap.seq, data: snap.data });
      for (const m of sub.queue) {
        if (m.seq !== undefined && snap.seq !== undefined && m.seq <= snap.seq) continue; // already inside the snapshot
        this.deps.send({ type: 'update', channel: channelStr, seq: m.seq, data: m.data });
      }
      sub.queue = [];
      sub.ready = true;
    } catch {
      sub.unsub();
      if (this.subs.get(channelStr) === sub) this.subs.delete(channelStr);
      this._error('SNAPSHOT_FAILED', 'could not load snapshot');
    }
  }

  dispose(): void {
    this.closed = true;
    for (const s of this.subs.values()) s.unsub();
    this.subs.clear();
  }
}
