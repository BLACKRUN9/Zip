export interface ChainTransfer {
  asset: string;
  to: string;
  amount: bigint;
  txHash: string;
  vout: number; // output index (BTC) / log index (ERC-20) / 0 for native transfers
  blockHeight: number;
  blockHash: string;
}
export interface TxStatus {
  blockHeight: number | null; // null = known but not mined yet
  blockHash: string | null;
  confirmations: number;
  failed?: boolean; // mined but reverted/failed on chain
}
export interface ChainAdapter {
  chain: string;
  /** Largest block range one scanDeposits call may cover (RPC providers cap this). */
  maxScan?: number;
  getTip(): Promise<{ height: number; hash: string }>;
  scanDeposits(addresses: string[], from: number, to: number): Promise<ChainTransfer[]>;
  /** null = the chain does not know this transaction (never seen, or dropped by a reorg). */
  getTx(txHash: string): Promise<TxStatus | null>;
  /** MUST be idempotent per `reference`: a retry returns the same txHash, never pays twice. */
  broadcast(w: { reference: string; asset: string; to: string; amount: bigint; memo?: string }): Promise<{ txHash: string }>;
  /** Total funds the exchange controls on chain (hot wallet + deposit addresses). Used for the solvency check. */
  custodyBalance?(asset: string): Promise<bigint>;
}
