import { createHash } from 'node:crypto';
import { AppError } from '../errors.ts';
import type { ChainAdapter, ChainTransfer, TxStatus } from './types.ts';

interface SimTx { hash: string; asset: string; from: string; to: string; amount: bigint; kind: 'faucet' | 'withdrawal'; blockHeight: number | null; blockHash: string | null }
const BECH32 = 'qpzry9x8gf2tvdw0s3jn54khce6mua7l';
const B58 = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
const sha = (s: string) => createHash('sha256').update(s).digest();

/**
 * A fake blockchain ("testnet") for development: faucet, mining, confirmations, reorgs, withdrawals.
 * Deterministic and fully in memory. Addresses look valid for their chain but are NOT real addresses.
 */
export class SimChain implements ChainAdapter {
  chain: string;
  maxScan = 10_000;
  height = 0;
  blocks: Array<{ height: number; hash: string; txs: string[] }> = [{ height: 0, hash: 'genesis', txs: [] }];
  txs: Map<string, SimTx> = new Map();
  mempool: string[] = [];
  owned: Set<string> = new Set(); // addresses the exchange controls
  sent: Map<string, string> = new Map(); // withdrawal reference -> txHash (idempotency)
  hotAddress: string;
  genesis: Map<string, bigint> = new Map();
  n = 0;
  salt = 0; // changes block hashes after a reorg, like a real fork

  constructor(chain: string, o: { genesis?: Record<string, bigint> } = {}) {
    this.chain = chain;
    this.hotAddress = this.newAddress();
    for (const [a, v] of Object.entries(o.genesis ?? {})) this.genesis.set(a, v);
  }

  newAddress(): string {
    const seed = `${this.chain}:addr:${++this.n}`;
    const h = Buffer.concat([sha(seed), sha(seed + ':2')]); // 64 bytes: enough for any address format below
    let out: string;
    if (this.chain === 'ETH') out = '0x' + h.toString('hex').slice(0, 40);
    else if (this.chain === 'TRON') out = 'T' + Array.from(h.subarray(0, 33), (b) => B58[b % 58]).join('');
    else out = 'tb1q' + Array.from(h.subarray(0, 38), (b) => BECH32[b % 32]).join(''); // BTC testnet look-alike
    this.owned.add(out.toLowerCase());
    return out;
  }

  _hash(kind: string): string { return createHash('sha256').update(`${this.chain}:${kind}:${++this.n}:${this.salt}`).digest('hex'); }

  /** Anyone sends test coins to `to` (they appear in the mempool; mine() confirms them). */
  faucet(to: string, asset: string, amount: bigint): string {
    if (amount <= 0n) throw new AppError('VALIDATION', 'amount must be positive');
    const hash = this._hash('tx');
    this.txs.set(hash, { hash, asset, from: 'faucet', to: to.toLowerCase(), amount, kind: 'faucet', blockHeight: null, blockHash: null });
    this.mempool.push(hash);
    return hash;
  }

  mine(blocks = 1): void {
    for (let i = 0; i < blocks; i++) {
      const height = ++this.height;
      const hash = this._hash('block');
      const included = this.mempool.splice(0); // all pending txs go into the first new block
      for (const h of included) { const t = this.txs.get(h)!; t.blockHeight = height; t.blockHash = hash; }
      this.blocks.push({ height, hash, txs: included });
    }
  }

  /** Chain reorganisation: the last `depth` blocks vanish; their txs go back to the mempool, or disappear entirely. */
  reorg(depth: number, o: { dropTxs?: boolean } = {}): void {
    if (depth < 1 || depth > this.height) throw new AppError('VALIDATION', 'invalid reorg depth');
    this.salt++;
    for (let i = 0; i < depth; i++) {
      const b = this.blocks.pop()!;
      for (const h of b.txs) {
        const t = this.txs.get(h)!;
        t.blockHeight = null; t.blockHash = null;
        if (o.dropTxs) this.txs.delete(h); else this.mempool.push(h);
      }
      this.height--;
    }
  }

  async getTip() { return { height: this.height, hash: this.blocks[this.height].hash }; }

  async scanDeposits(addresses: string[], from: number, to: number): Promise<ChainTransfer[]> {
    const want = new Set(addresses.map((a) => a.toLowerCase()));
    const out: ChainTransfer[] = [];
    for (const b of this.blocks) {
      if (b.height < from || b.height > to) continue;
      for (const h of b.txs) {
        const t = this.txs.get(h)!;
        if (want.has(t.to)) out.push({ asset: t.asset, to: t.to, amount: t.amount, txHash: t.hash, vout: 0, blockHeight: b.height, blockHash: b.hash });
      }
    }
    return out;
  }

  async getTx(hash: string): Promise<TxStatus | null> {
    const t = this.txs.get(hash);
    if (!t) return null;
    if (t.blockHeight === null) return { blockHeight: null, blockHash: null, confirmations: 0 };
    return { blockHeight: t.blockHeight, blockHash: t.blockHash, confirmations: this.height - t.blockHeight + 1 };
  }

  async broadcast(w: { reference: string; asset: string; to: string; amount: bigint }): Promise<{ txHash: string }> {
    const done = this.sent.get(w.reference);
    if (done) return { txHash: done };
    if ((await this.custodyBalance(w.asset)) < w.amount) throw new AppError('CONFLICT', 'insufficient custody balance for this payout');
    const hash = this._hash('tx');
    this.txs.set(hash, { hash, asset: w.asset, from: this.hotAddress, to: w.to.toLowerCase(), amount: w.amount, kind: 'withdrawal', blockHeight: null, blockHash: null });
    this.mempool.push(hash);
    this.sent.set(w.reference, hash);
    return { txHash: hash };
  }

  /** Confirmed funds sitting on exchange-controlled addresses, minus everything already paid out. */
  async custodyBalance(asset: string): Promise<bigint> {
    let v = this.genesis.get(asset) ?? 0n;
    for (const t of this.txs.values()) {
      if (t.asset !== asset) continue;
      if (t.kind === 'faucet' && t.blockHeight !== null && this.owned.has(t.to)) v += t.amount;
      if (t.kind === 'withdrawal') v -= t.amount; // counted from broadcast on: never promise the same coins twice
    }
    return v;
  }
}
