import { AppError } from '../errors.ts';
import type { ChainAdapter, ChainTransfer, TxStatus } from './types.ts';

export const TRANSFER_TOPIC = '0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef'; // keccak256("Transfer(address,address,uint256)")
const BALANCE_OF = '0x70a08231';

export const hexToBig = (h: string): bigint => (h === '0x' || h === '' ? 0n : BigInt(h));
export const toHex = (n: number | bigint): string => '0x' + BigInt(n).toString(16);
export const pad32 = (addr: string): string => '0x' + addr.toLowerCase().replace(/^0x/, '').padStart(64, '0');
export const topicToAddress = (t: string): string => '0x' + t.slice(-40).toLowerCase();
export const chunk = <T>(a: T[], n: number): T[][] => { const o: T[][] = []; for (let i = 0; i < a.length; i += n) o.push(a.slice(i, i + n)); return o; };

/** Hot-wallet signing lives in a SEPARATE hardened service. Implement idempotency by `reference` there. */
export interface Signer { sendTransfer(p: { asset: string; to: string; amount: bigint; reference: string }): Promise<string> }

export interface EvmConfig {
  chain: string; // 'ETH'
  rpcUrl: string;
  fetch: (url: string, init: any) => Promise<any>;
  nativeAsset: string; // 'ETH'
  tokens: Record<string, string>; // asset symbol -> ERC-20 contract address (e.g. { USDT: '0x...' } on Sepolia)
  signer?: Signer;
  custodyAddresses?: () => Promise<string[]>; // hot wallet + all deposit addresses
  maxScan?: number;
}

/**
 * Read-only chain access over JSON-RPC (Ethereum Sepolia or any EVM testnet) + a Signer for payouts.
 * Deposits: native ETH by scanning blocks, ERC-20 by filtering Transfer logs whose recipient is one of our addresses.
 * This adapter holds NO private keys.
 */
export class EvmRpcChain implements ChainAdapter {
  chain: string;
  maxScan: number;
  cfg: EvmConfig;
  id = 0;
  constructor(cfg: EvmConfig) { this.cfg = cfg; this.chain = cfg.chain; this.maxScan = cfg.maxScan ?? 200; }

  async rpc(method: string, params: unknown[]): Promise<any> {
    const res = await this.cfg.fetch(this.cfg.rpcUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ jsonrpc: '2.0', id: ++this.id, method, params }) });
    if (!res.ok) throw new AppError('CHAIN_RPC', `rpc http ${res.status}`);
    const j = await res.json();
    if (j.error) throw new AppError('CHAIN_RPC', `rpc ${method}: ${j.error.message ?? 'error'}`);
    return j.result;
  }

  async getTip() {
    const height = Number(hexToBig(await this.rpc('eth_blockNumber', [])));
    const b = await this.rpc('eth_getBlockByNumber', [toHex(height), false]);
    return { height, hash: b.hash as string };
  }

  async scanDeposits(addresses: string[], from: number, to: number): Promise<ChainTransfer[]> {
    if (!addresses.length || to < from) return [];
    const mine = new Set(addresses.map((a) => a.toLowerCase()));
    const out: ChainTransfer[] = [];
    for (let h = from; h <= to; h++) { // native transfers: look at every transaction in the block
      const b = await this.rpc('eth_getBlockByNumber', [toHex(h), true]);
      if (!b) continue;
      for (const tx of b.transactions as any[]) {
        if (tx.to && mine.has(tx.to.toLowerCase()) && hexToBig(tx.value) > 0n) {
          out.push({ asset: this.cfg.nativeAsset, to: tx.to.toLowerCase(), amount: hexToBig(tx.value), txHash: tx.hash, vout: 0, blockHeight: h, blockHash: b.hash });
        }
      }
    }
    for (const [asset, contract] of Object.entries(this.cfg.tokens)) { // tokens: ask the node for matching logs only
      for (const group of chunk([...mine], 50)) {
        const logs = await this.rpc('eth_getLogs', [{ fromBlock: toHex(from), toBlock: toHex(to), address: contract, topics: [TRANSFER_TOPIC, null, group.map(pad32)] }]);
        for (const l of logs as any[]) {
          if (l.removed || l.topics?.length !== 3) continue; // reorged-out logs / ERC-721 style events
          out.push({ asset, to: topicToAddress(l.topics[2]), amount: hexToBig(l.data), txHash: l.transactionHash, vout: Number(hexToBig(l.logIndex)), blockHeight: Number(hexToBig(l.blockNumber)), blockHash: l.blockHash });
        }
      }
    }
    return out;
  }

  async getTx(hash: string): Promise<TxStatus | null> {
    const r = await this.rpc('eth_getTransactionReceipt', [hash]);
    if (!r) {
      const pending = await this.rpc('eth_getTransactionByHash', [hash]);
      return pending ? { blockHeight: null, blockHash: null, confirmations: 0 } : null;
    }
    const bn = Number(hexToBig(r.blockNumber));
    const tip = Number(hexToBig(await this.rpc('eth_blockNumber', [])));
    return { blockHeight: bn, blockHash: r.blockHash, confirmations: Math.max(0, tip - bn + 1), failed: r.status === '0x0' };
  }

  async broadcast(w: { reference: string; asset: string; to: string; amount: bigint }): Promise<{ txHash: string }> {
    if (!this.cfg.signer) throw new AppError('NOT_CONFIGURED', 'no signer configured: payouts on this chain are disabled');
    return { txHash: await this.cfg.signer.sendTransfer({ asset: w.asset, to: w.to, amount: w.amount, reference: w.reference }) };
  }

  async custodyBalance(asset: string): Promise<bigint> {
    const addrs = (await this.cfg.custodyAddresses?.()) ?? [];
    let sum = 0n;
    for (const a of addrs) {
      if (asset === this.cfg.nativeAsset) sum += hexToBig(await this.rpc('eth_getBalance', [a, 'latest']));
      else if (this.cfg.tokens[asset]) sum += hexToBig(await this.rpc('eth_call', [{ to: this.cfg.tokens[asset], data: BALANCE_OF + pad32(a).slice(2) }, 'latest']));
    }
    return sum;
  }
}
