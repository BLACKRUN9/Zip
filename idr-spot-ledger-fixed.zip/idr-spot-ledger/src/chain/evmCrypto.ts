/**
 * Ethereum primitives implemented with BigInt, verified in tests against published vectors and against Node's own
 * secp256k1 / ECDSA. Used ONLY by the isolated signer service. For production prefer audited libraries
 * (@noble/curves, @noble/hashes) behind an HSM/KMS: this file exists so the testnet flow works with zero dependencies.
 */
import { createHmac } from 'node:crypto';

// ---------------------------------------------------------------- keccak-256 (Ethereum's hash: NOT NIST SHA3)
const M64 = (1n << 64n) - 1n;
const RC = [0x0000000000000001n, 0x0000000000008082n, 0x800000000000808an, 0x8000000080008000n, 0x000000000000808bn, 0x0000000080000001n, 0x8000000080008081n, 0x8000000000008009n,
  0x000000000000008an, 0x0000000000000088n, 0x0000000080008009n, 0x000000008000000an, 0x000000008000808bn, 0x800000000000008bn, 0x8000000000008089n, 0x8000000000008003n,
  0x8000000000008002n, 0x8000000000000080n, 0x000000000000800an, 0x800000008000000an, 0x8000000080008081n, 0x8000000000008080n, 0x0000000080000001n, 0x8000000080008008n];
const ROT = [[0, 36, 3, 41, 18], [1, 44, 10, 45, 2], [62, 6, 43, 15, 61], [28, 55, 25, 21, 56], [27, 20, 39, 8, 14]]; // ROT[x][y]
const rotl = (v: bigint, n: number): bigint => (n === 0 ? v : ((v << BigInt(n)) | (v >> BigInt(64 - n))) & M64);

function keccakF(s: bigint[]): void {
  for (let round = 0; round < 24; round++) {
    const C = [0, 1, 2, 3, 4].map((x) => s[x] ^ s[x + 5] ^ s[x + 10] ^ s[x + 15] ^ s[x + 20]);
    for (let x = 0; x < 5; x++) { const D = C[(x + 4) % 5] ^ rotl(C[(x + 1) % 5], 1); for (let y = 0; y < 5; y++) s[x + 5 * y] ^= D; }
    const B: bigint[] = new Array(25).fill(0n);
    for (let x = 0; x < 5; x++) for (let y = 0; y < 5; y++) B[y + 5 * ((2 * x + 3 * y) % 5)] = rotl(s[x + 5 * y], ROT[x][y]);
    for (let x = 0; x < 5; x++) for (let y = 0; y < 5; y++) s[x + 5 * y] = B[x + 5 * y] ^ (~B[((x + 1) % 5) + 5 * y] & M64 & B[((x + 2) % 5) + 5 * y]);
    s[0] ^= RC[round];
  }
}

export function keccak256(data: Uint8Array): Buffer {
  const rate = 136;
  const padded = Buffer.alloc(Math.ceil((data.length + 1) / rate) * rate);
  padded.set(data);
  padded[data.length] ^= 0x01; // keccak padding (SHA3 would use 0x06)
  padded[padded.length - 1] ^= 0x80;
  const s: bigint[] = new Array(25).fill(0n);
  for (let off = 0; off < padded.length; off += rate) {
    for (let i = 0; i < rate / 8; i++) s[i] ^= padded.readBigUInt64LE(off + i * 8);
    keccakF(s);
  }
  const out = Buffer.alloc(32);
  for (let i = 0; i < 4; i++) out.writeBigUInt64LE(s[i], i * 8);
  return out;
}

// ---------------------------------------------------------------- secp256k1
const P = 0xfffffffffffffffffffffffffffffffffffffffffffffffffffffffefffffc2fn;
export const N = 0xfffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141n;
const GX = 0x79be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798n;
const GY = 0x483ada7726a3c4655da4fbfc0e1108a8fd17b448a68554199c47d08ffb10d4b8n;
type Pt = { x: bigint; y: bigint } | null;
const mod = (a: bigint, m: bigint) => ((a % m) + m) % m;
function inv(a: bigint, m: bigint): bigint { // extended Euclid
  let [r0, r1, s0, s1] = [mod(a, m), m, 1n, 0n];
  while (r1 !== 0n) { const q = r0 / r1; [r0, r1] = [r1, r0 - q * r1]; [s0, s1] = [s1, s0 - q * s1]; }
  if (r0 !== 1n) throw new Error('not invertible');
  return mod(s0, m);
}
function powmod(b: bigint, e: bigint, m: bigint): bigint {
  let r = 1n; b = mod(b, m);
  while (e > 0n) { if (e & 1n) r = (r * b) % m; b = (b * b) % m; e >>= 1n; }
  return r;
}
function add(a: Pt, b: Pt): Pt {
  if (!a) return b;
  if (!b) return a;
  if (a.x === b.x) {
    if (mod(a.y + b.y, P) === 0n) return null;
    const l = mod(3n * a.x * a.x * inv(2n * a.y, P), P); // doubling (curve a = 0)
    const x = mod(l * l - 2n * a.x, P);
    return { x, y: mod(l * (a.x - x) - a.y, P) };
  }
  const l = mod((b.y - a.y) * inv(b.x - a.x, P), P);
  const x = mod(l * l - a.x - b.x, P);
  return { x, y: mod(l * (a.x - x) - a.y, P) };
}
function mul(k: bigint, pt: Pt): Pt {
  let r: Pt = null, q: Pt = pt;
  for (; k > 0n; k >>= 1n) { if (k & 1n) r = add(r, q); q = add(q, q); }
  return r;
}
const G: Pt = { x: GX, y: GY };
const be32 = (v: bigint): Buffer => { const b = Buffer.alloc(32); b.writeBigUInt64BE((v >> 192n) & M64, 0); b.writeBigUInt64BE((v >> 128n) & M64, 8); b.writeBigUInt64BE((v >> 64n) & M64, 16); b.writeBigUInt64BE(v & M64, 24); return b; };
const toInt = (b: Uint8Array): bigint => BigInt('0x' + (Buffer.from(b).toString('hex') || '0'));

export function publicKey(priv: Uint8Array): Buffer { // 64 bytes, uncompressed without the 0x04 prefix
  const d = toInt(priv);
  if (d <= 0n || d >= N) throw new Error('invalid private key');
  const q = mul(d, G)!;
  return Buffer.concat([be32(q.x), be32(q.y)]);
}
export const addressFromPublic = (pub64: Uint8Array): string => '0x' + keccak256(pub64).subarray(12).toString('hex');
export const addressFromPrivate = (priv: Uint8Array): string => addressFromPublic(publicKey(priv));

/** EIP-55 mixed-case checksum address. */
export function toChecksumAddress(addr: string): string {
  const a = addr.toLowerCase().replace(/^0x/, '');
  const h = keccak256(Buffer.from(a, 'ascii')).toString('hex');
  return '0x' + [...a].map((c, i) => (parseInt(h[i], 16) >= 8 ? c.toUpperCase() : c)).join('');
}

function rfc6979(d: bigint, digest: Uint8Array): bigint {
  const x = be32(d), h = be32(mod(toInt(digest), N));
  const hm = (k: Buffer, ...parts: Buffer[]) => createHmac('sha256', k).update(Buffer.concat(parts)).digest();
  let V: Buffer = Buffer.alloc(32, 0x01), K: Buffer = Buffer.alloc(32, 0x00);
  K = hm(K, V, Buffer.from([0]), x, h); V = hm(K, V);
  K = hm(K, V, Buffer.from([1]), x, h); V = hm(K, V);
  for (;;) {
    V = hm(K, V);
    const k = toInt(V);
    if (k >= 1n && k < N) return k;
    K = hm(K, V, Buffer.from([0])); V = hm(K, V);
  }
}

export interface Signature { r: bigint; s: bigint; recovery: 0 | 1 | 2 | 3 }
/** Deterministic (RFC 6979) ECDSA over a 32-byte digest; low-S normalised as Ethereum requires. */
export function sign(digest: Uint8Array, priv: Uint8Array): Signature {
  if (digest.length !== 32) throw new Error('digest must be 32 bytes');
  const d = toInt(priv), z = toInt(digest);
  const k = rfc6979(d, digest);
  const R = mul(k, G)!;
  const r = mod(R.x, N);
  let s = mod(inv(k, N) * (z + r * d), N);
  if (r === 0n || s === 0n) throw new Error('bad signature');
  let rec = (Number(R.y & 1n) | (R.x >= N ? 2 : 0)) as 0 | 1 | 2 | 3;
  if (s > N / 2n) { s = N - s; rec = (rec ^ 1) as 0 | 1 | 2 | 3; }
  return { r, s, recovery: rec };
}

export function recoverPublic(digest: Uint8Array, sig: Signature): Buffer {
  const x = sig.recovery & 2 ? sig.r + N : sig.r;
  const y2 = mod(x * x * x + 7n, P);
  let y = powmod(y2, (P + 1n) / 4n, P);
  if (mod(y * y, P) !== y2) throw new Error('not on curve');
  if (Number(y & 1n) !== (sig.recovery & 1)) y = P - y;
  const R: Pt = { x, y };
  const rinv = inv(sig.r, N), z = toInt(digest);
  const sR = mul(sig.s, R);
  const zG = mul(mod(-z, N), G);
  const Q = mul(rinv, add(sR, zG));
  if (!Q) throw new Error('recovery failed');
  return Buffer.concat([be32(Q.x), be32(Q.y)]);
}

// ---------------------------------------------------------------- RLP
export type Rlp = Buffer | Rlp[];
const lenBytes = (n: number): Buffer => { let h = n.toString(16); if (h.length % 2) h = '0' + h; return Buffer.from(h, 'hex'); };
export function rlp(item: Rlp): Buffer {
  if (Array.isArray(item)) {
    const body = Buffer.concat(item.map(rlp));
    return Buffer.concat([body.length < 56 ? Buffer.from([0xc0 + body.length]) : Buffer.concat([Buffer.from([0xf7 + lenBytes(body.length).length]), lenBytes(body.length)]), body]);
  }
  if (item.length === 1 && item[0] < 0x80) return item;
  if (item.length < 56) return Buffer.concat([Buffer.from([0x80 + item.length]), item]);
  return Buffer.concat([Buffer.from([0xb7 + lenBytes(item.length).length]), lenBytes(item.length), item]);
}
export function rlpDecode(buf: Buffer): Rlp {
  const [v, used] = dec(buf, 0);
  if (used !== buf.length) throw new Error('trailing bytes');
  return v;
}
function dec(b: Buffer, o: number): [Rlp, number] {
  const t = b[o];
  if (t < 0x80) return [b.subarray(o, o + 1), o + 1];
  if (t < 0xb8) { const n = t - 0x80; return [b.subarray(o + 1, o + 1 + n), o + 1 + n]; }
  if (t < 0xc0) { const ll = t - 0xb7, n = Number(toInt(b.subarray(o + 1, o + 1 + ll))); return [b.subarray(o + 1 + ll, o + 1 + ll + n), o + 1 + ll + n]; }
  let n: number, start: number;
  if (t < 0xf8) { n = t - 0xc0; start = o + 1; } else { const ll = t - 0xf7; n = Number(toInt(b.subarray(o + 1, o + 1 + ll))); start = o + 1 + ll; }
  const out: Rlp[] = [];
  for (let p = start; p < start + n;) { const [v, np] = dec(b, p); out.push(v); p = np; }
  return [out, start + n];
}
/** minimal big-endian integer encoding (0 -> empty), as RLP requires */
export const rlpInt = (v: bigint): Buffer => (v === 0n ? Buffer.alloc(0) : Buffer.from(v.toString(16).padStart(Math.ceil(v.toString(16).length / 2) * 2, '0'), 'hex'));
export const hexBuf = (h: string): Buffer => Buffer.from(h.replace(/^0x/, '').length % 2 ? '0' + h.replace(/^0x/, '') : h.replace(/^0x/, ''), 'hex');

// ---------------------------------------------------------------- EIP-1559 (type 2) transactions
export interface Eip1559Tx {
  chainId: bigint; nonce: bigint; maxPriorityFeePerGas: bigint; maxFeePerGas: bigint; gasLimit: bigint;
  to: string; value: bigint; data: string; // hex
}
export function signEip1559(tx: Eip1559Tx, priv: Uint8Array): { raw: string; hash: string; from: string } {
  const fields = [rlpInt(tx.chainId), rlpInt(tx.nonce), rlpInt(tx.maxPriorityFeePerGas), rlpInt(tx.maxFeePerGas), rlpInt(tx.gasLimit), hexBuf(tx.to), rlpInt(tx.value), hexBuf(tx.data), [] as Rlp[]] as Rlp[];
  const digest = keccak256(Buffer.concat([Buffer.from([0x02]), rlp(fields)]));
  const sig = sign(digest, priv);
  const raw = Buffer.concat([Buffer.from([0x02]), rlp([...fields, rlpInt(BigInt(sig.recovery & 1)), rlpInt(sig.r), rlpInt(sig.s)])]);
  return { raw: '0x' + raw.toString('hex'), hash: '0x' + keccak256(raw).toString('hex'), from: addressFromPrivate(priv) };
}
/** Inverse of signEip1559: what a node does to find out who sent a raw transaction. */
export function decodeEip1559(rawHex: string): Eip1559Tx & { from: string } {
  const raw = hexBuf(rawHex);
  if (raw[0] !== 0x02) throw new Error('not a type-2 transaction');
  const f = rlpDecode(raw.subarray(1)) as Buffer[];
  if (f.length !== 12) throw new Error('bad field count');
  const unsigned = rlp(f.slice(0, 9) as Rlp[]);
  const digest = keccak256(Buffer.concat([Buffer.from([0x02]), unsigned]));
  const pub = recoverPublic(digest, { r: toInt(f[10]), s: toInt(f[11]), recovery: Number(toInt(f[9])) as 0 | 1 });
  return { chainId: toInt(f[0]), nonce: toInt(f[1]), maxPriorityFeePerGas: toInt(f[2]), maxFeePerGas: toInt(f[3]), gasLimit: toInt(f[4]), to: '0x' + f[5].toString('hex'), value: toInt(f[6]), data: '0x' + f[7].toString('hex'), from: addressFromPublic(pub) };
}
export const txHash = (rawHex: string): string => '0x' + keccak256(hexBuf(rawHex)).toString('hex');
