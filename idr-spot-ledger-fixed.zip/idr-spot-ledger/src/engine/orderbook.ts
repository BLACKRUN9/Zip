/**
 * Pure, deterministic in-memory order book (no I/O, no DB). Price-time priority.
 * Determinism matters: replaying the logged commands must rebuild the identical book.
 *
 * NOTE: sorted arrays are O(n) per insert. Fine for MVP; swap for price-level
 * maps/heaps in the performance phase without changing this interface.
 */
export type Side = 'buy' | 'sell';

export interface OrderInput {
  id: string;
  userId: string;
  side: Side;
  type: 'limit' | 'market';
  tif: 'GTC' | 'IOC';
  /** limit: limit price. market buy: protection cap. market sell: 0n. */
  price: bigint;
  qty: bigint;
}

export interface RestingOrder {
  id: string;
  userId: string;
  side: Side;
  price: bigint;
  qty: bigint; // remaining
  seq: number;
}

export type BookOutput =
  | { type: 'trade'; makerOrderId: string; takerOrderId: string; makerUserId: string; takerUserId: string; price: bigint; qty: bigint }
  | { type: 'canceled'; orderId: string; reason: 'user' | 'ioc_remaining' | 'self_trade' };

export interface LogEvent {
  seq: number;
  type: string;
  payload: any;
}

export class OrderBook {
  bids: RestingOrder[] = []; // best (highest) first
  asks: RestingOrder[] = []; // best (lowest) first
  known: Set<string> = new Set();

  has(id: string): boolean {
    return this.known.has(id);
  }

  isResting(id: string): boolean {
    return this.bids.some((o) => o.id === id) || this.asks.some((o) => o.id === id);
  }

  accept(o: OrderInput, seq: number): BookOutput[] {
    if (this.known.has(o.id)) return []; // idempotent re-submit
    this.known.add(o.id);
    const out: BookOutput[] = [];
    if (o.qty <= 0n) {
      out.push({ type: 'canceled', orderId: o.id, reason: 'ioc_remaining' });
      return out;
    }
    const opposite = o.side === 'buy' ? this.asks : this.bids;
    let remaining = o.qty;
    let stp = false;
    while (remaining > 0n && opposite.length > 0) {
      const best = opposite[0];
      const crosses = o.side === 'buy' ? best.price <= o.price : best.price >= o.price;
      if (!crosses) break;
      if (best.userId === o.userId) {
        stp = true; // self-trade prevention: cancel the incoming (newest) order's remainder
        break;
      }
      const fill = remaining < best.qty ? remaining : best.qty;
      out.push({
        type: 'trade',
        makerOrderId: best.id,
        takerOrderId: o.id,
        makerUserId: best.userId,
        takerUserId: o.userId,
        price: best.price, // always the maker's price
        qty: fill,
      });
      best.qty -= fill;
      remaining -= fill;
      if (best.qty === 0n) opposite.shift();
    }
    if (remaining > 0n) {
      if (o.type === 'limit' && o.tif === 'GTC' && !stp) {
        this._rest({ id: o.id, userId: o.userId, side: o.side, price: o.price, qty: remaining, seq });
      } else {
        out.push({ type: 'canceled', orderId: o.id, reason: stp ? 'self_trade' : 'ioc_remaining' });
      }
    }
    return out;
  }

  cancel(orderId: string): BookOutput[] {
    for (const side of [this.bids, this.asks]) {
      const i = side.findIndex((o) => o.id === orderId);
      if (i >= 0) {
        side.splice(i, 1);
        return [{ type: 'canceled', orderId, reason: 'user' }];
      }
    }
    return [];
  }

  _rest(o: RestingOrder): void {
    const arr = o.side === 'buy' ? this.bids : this.asks;
    let i = 0;
    // insert after all orders with equal-or-better price (time priority within a level)
    while (i < arr.length && (o.side === 'buy' ? arr[i].price >= o.price : arr[i].price <= o.price)) i++;
    arr.splice(i, 0, o);
  }

  snapshot() {
    const f = (o: RestingOrder) => [o.id, o.price.toString(), o.qty.toString(), o.seq];
    return { bids: this.bids.map(f), asks: this.asks.map(f) };
  }
}

export function outputToEvent(out: BookOutput): { type: string; payload: any } {
  if (out.type === 'trade') {
    return {
      type: 'trade',
      payload: {
        makerOrderId: out.makerOrderId,
        takerOrderId: out.takerOrderId,
        makerUserId: out.makerUserId,
        takerUserId: out.takerUserId,
        price: out.price.toString(),
        qty: out.qty.toString(),
      },
    };
  }
  return { type: 'order_canceled', payload: { orderId: out.orderId, reason: out.reason } };
}

function canon(ev: { type: string; payload: any }): string {
  const p = ev.payload;
  return ev.type === 'trade'
    ? `trade|${p.makerOrderId}|${p.takerOrderId}|${p.price}|${p.qty}`
    : `${ev.type}|${p.orderId}|${p.reason}`;
}

const isDerived = (t: string) => t === 'trade' || t === 'order_canceled';

/**
 * Rebuild a book by RE-EXECUTING the logged commands (order_accepted, cancel_requested)
 * and verifying that the re-derived trades/cancels equal what was logged. A mismatch
 * means the log is corrupt or the matching code changed incompatibly.
 */
export function replayLog(events: LogEvent[]): { book: OrderBook; lastSeq: number; mismatches: string[] } {
  const book = new OrderBook();
  const mismatches: string[] = [];
  let i = 0;
  let lastSeq = 0;
  while (i < events.length) {
    const ev = events[i];
    lastSeq = ev.seq;
    i++;
    let outs: BookOutput[];
    if (ev.type === 'order_accepted') {
      const p = ev.payload;
      outs = book.accept(
        { id: p.id, userId: p.userId, side: p.side, type: p.type, tif: p.tif, price: BigInt(p.price), qty: BigInt(p.qty) },
        ev.seq,
      );
    } else if (ev.type === 'cancel_requested') {
      outs = book.cancel(ev.payload.orderId);
    } else {
      mismatches.push(`seq ${ev.seq}: unexpected event type ${ev.type}`);
      continue;
    }
    const expected = outs.map((o) => canon(outputToEvent(o)));
    const actual: string[] = [];
    while (i < events.length && isDerived(events[i].type)) {
      actual.push(canon(events[i]));
      lastSeq = events[i].seq;
      i++;
    }
    if (expected.length !== actual.length || expected.some((e, k) => e !== actual[k])) {
      mismatches.push(`seq ${ev.seq}: derived events differ from re-execution`);
    }
  }
  return { book, lastSeq, mismatches };
}
