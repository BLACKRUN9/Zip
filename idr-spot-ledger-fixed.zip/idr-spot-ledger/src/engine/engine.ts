import { Types } from 'mongoose';
import { EngineEvent } from '../db/models.ts';
import { withTxn } from '../db/txn.ts';
import { InvariantViolation } from '../errors.ts';
import { OrderBook, outputToEvent, replayLog } from './orderbook.ts';
import type { BookOutput } from './orderbook.ts';
import type { EngineOrder } from '../services/orders.ts';
import type { EngineEventLike } from '../services/settlement.ts';

/**
 * Event-sourced matching engine. Per market: commands are applied to an in-memory OrderBook, and the command +
 * its derived events are persisted ATOMICALLY to engine_events with contiguous seq numbers. If persisting fails,
 * the in-memory book is discarded and rebuilt from the log on next use, so memory can never run ahead of the log.
 * Single process / single writer per market (run exactly one engine instance per market).
 */
export class MatchingEngine {
  books: Map<string, OrderBook> = new Map();
  nextSeq: Map<string, number> = new Map();
  chains: Map<string, Promise<unknown>> = new Map();

  _serial<T>(marketId: string, fn: () => Promise<T>): Promise<T> {
    const prev = this.chains.get(marketId) ?? Promise.resolve();
    const next = prev.catch(() => undefined).then(fn);
    this.chains.set(marketId, next.catch(() => undefined));
    return next;
  }

  /** Rebuild a market's book by re-executing its log (and verifying the log is self-consistent). */
  async recover(marketId: string): Promise<OrderBook> {
    const rows: any[] = await EngineEvent.find({ marketId }).sort({ seq: 1 }).lean();
    const events = rows.map((r) => ({ seq: r.seq, type: r.type, payload: r.payload }));
    for (let i = 0; i < events.length; i++) {
      if (events[i].seq !== i + 1) throw new InvariantViolation(`engine log gap for ${marketId} at index ${i} (seq ${events[i].seq})`);
    }
    const { book, lastSeq, mismatches } = replayLog(events);
    if (mismatches.length) throw new InvariantViolation(`engine log for ${marketId} failed replay: ${mismatches.slice(0, 3).join('; ')}`);
    this.books.set(marketId, book);
    this.nextSeq.set(marketId, lastSeq + 1);
    return book;
  }

  async _book(marketId: string): Promise<OrderBook> {
    return this.books.get(marketId) ?? this.recover(marketId);
  }

  async _persist(marketId: string, command: { type: string; payload: any }, outs: BookOutput[]): Promise<EngineEventLike[]> {
    let seq = this.nextSeq.get(marketId)!;
    const rows = [command, ...outs.map(outputToEvent)].map((e) => ({ marketId: new Types.ObjectId(marketId), seq: seq++, type: e.type, payload: e.payload }));
    try {
      await withTxn(async (session) => { await EngineEvent.insertMany(rows, { session }); });
    } catch (e) {
      this.books.delete(marketId); // memory is ahead of the log: throw it away, recover() rebuilds it
      this.nextSeq.delete(marketId);
      throw e;
    }
    this.nextSeq.set(marketId, seq);
    return rows.map((r) => ({ marketId, seq: r.seq, type: r.type, payload: r.payload }));
  }

  /** Accept an order. Idempotent per order id (a re-submit logs and returns nothing). */
  submit(o: EngineOrder): Promise<EngineEventLike[]> {
    return this._serial(o.marketId, async () => {
      const book = await this._book(o.marketId);
      if (book.has(o.id)) return [];
      const seq = this.nextSeq.get(o.marketId)!;
      const outs = book.accept(
        { id: o.id, userId: o.userId, side: o.side, type: o.type, tif: o.tif, price: BigInt(o.price), qty: BigInt(o.qty) },
        seq,
      );
      return this._persist(o.marketId, { type: 'order_accepted', payload: { ...o } }, outs);
    });
  }

  /** Cancel a resting order. Unknown / already-gone orders are a silent no-op (nothing logged). */
  cancel(marketId: string, orderId: string): Promise<EngineEventLike[]> {
    return this._serial(marketId, async () => {
      const book = await this._book(marketId);
      if (!book.isResting(orderId)) return [];
      const outs = book.cancel(orderId);
      return this._persist(marketId, { type: 'cancel_requested', payload: { orderId } }, outs);
    });
  }

  snapshot(marketId: string) {
    return this.books.get(marketId)?.snapshot();
  }

  /** Snapshot that loads (recovers) the book first if this process has not touched the market yet. */
  book(marketId: string) {
    return this._serial(marketId, async () => (await this._book(marketId)).snapshot());
  }
}
