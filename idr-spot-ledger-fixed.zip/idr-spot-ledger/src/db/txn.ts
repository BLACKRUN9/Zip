import mongoose from 'mongoose';
import type { ClientSession, Model } from 'mongoose';
import { Conflict } from '../errors.ts';

/** In-process keyed mutex. Reduces write-conflict retry storms on hot accounts; the DB is still the real guard. */
const tails = new Map<string, Promise<void>>();
async function acquire(key: string): Promise<() => void> {
  const prev = tails.get(key) ?? Promise.resolve();
  let release!: () => void;
  const mine = new Promise<void>((r) => { release = r; });
  const tail = prev.then(() => mine);
  tails.set(key, tail);
  await prev;
  return () => {
    release();
    if (tails.get(key) === tail) tails.delete(key);
  };
}

export const isDuplicateKey = (e: any): boolean => e?.code === 11000 || e?.cause?.code === 11000;

/**
 * Run fn in a MongoDB transaction (snapshot isolation, majority writes).
 * - session.withTransaction() already retries TransientTransactionError / UnknownTransactionCommitResult.
 * - Unique-key races (same idempotency key submitted concurrently) are retried: on retry the loser sees the
 *   winner's committed row and returns it.
 * - fn MAY RUN MORE THAN ONCE: it must not have side effects outside the session.
 */
export async function withTxn<T>(fn: (session: ClientSession) => Promise<T>, opts: { lockKeys?: string[] } = {}): Promise<T> {
  const keys = [...new Set(opts.lockKeys ?? [])].sort();
  const releases: Array<() => void> = [];
  for (const k of keys) releases.push(await acquire(k));
  try {
    for (let attempt = 0; ; attempt++) {
      const session = await mongoose.startSession();
      try {
        let result!: T;
        await session.withTransaction(
          async () => { result = await fn(session); },
          { readConcern: { level: 'snapshot' }, writeConcern: { w: 'majority' }, readPreference: 'primary' },
        );
        return result;
      } catch (e) {
        if (isDuplicateKey(e) && attempt < 3) continue;
        throw e;
      } finally {
        await session.endSession();
      }
    }
  } finally {
    for (const r of releases.reverse()) r();
  }
}

/** Use the caller's session if given (compose into a larger transaction), else open a new transaction. */
export function runIn<T>(session: ClientSession | undefined, fn: (s: ClientSession) => Promise<T>, opts: { lockKeys?: string[] } = {}): Promise<T> {
  return session ? fn(session) : withTxn(fn, opts);
}

/** Optimistic-locked update: matches only if the document is still at the version we read. */
export async function updateVersioned(model: Model<any>, doc: { _id: any; version: number }, set: Record<string, unknown>, session: ClientSession) {
  const r = await model.updateOne({ _id: doc._id, version: doc.version }, { $set: set, $inc: { version: 1 } }, { session });
  if (r.matchedCount !== 1) throw new Conflict(`concurrent modification on ${model.modelName} ${doc._id}`);
}
