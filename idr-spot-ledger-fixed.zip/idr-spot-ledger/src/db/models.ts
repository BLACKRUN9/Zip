import mongoose, { Schema } from 'mongoose';
import { AMOUNT_RE } from '../money.ts';
import { AppError } from '../errors.ts';

const OID = Schema.Types.ObjectId;

/** Stored as integer STRINGS (smallest unit). Never Number/float. Also enforced by DB $jsonSchema (see init.ts). */
const amt = (extra: Record<string, unknown> = {}) => ({ type: String, required: true, default: '0', match: AMOUNT_RE, ...extra });
const mk = (def: Record<string, any>, opts: Record<string, any> = {}) =>
  new Schema(def, { timestamps: true, versionKey: false, ...opts });

/** Append-only guard at the application layer. The real guard is a DB role without update/remove on these collections. */
function appendOnly(schema: Schema) {
  const blocked = () => { throw new AppError('APPEND_ONLY', 'this collection is append-only'); };
  for (const op of ['updateOne', 'updateMany', 'findOneAndUpdate', 'findOneAndReplace', 'replaceOne', 'deleteOne', 'deleteMany', 'findOneAndDelete'] as const) {
    schema.pre(op as any, blocked);
  }
  schema.pre('save', function () { if (!this.isNew) blocked(); });
}

const model = (name: string, coll: string, schema: Schema) =>
  (mongoose.models[name] as mongoose.Model<any>) ?? mongoose.model<any>(name, schema, coll);

// ---------------------------------------------------------------- users / kyc
const userSchema = mk({
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  phone: { type: String },
  passwordHash: { type: String, required: true },
  status: { type: String, enum: ['active', 'frozen', 'closed'], default: 'active' },
  kycLevel: { type: Number, default: 0, min: 0 },
  emailVerified: { type: Boolean, default: false },
  failedLogins: { type: Number, default: 0 },
  lockedUntil: { type: Date, default: null },
  withdrawLockedUntil: { type: Date, default: null }, // set for 24h after password change/reset/2FA disable
  passwordChangedAt: { type: Date },
  twoFA: {
    enabled: { type: Boolean, default: false },
    secretEnc: { type: String }, // AES-GCM, AAD = totp:<userId>
    lastCounter: { type: Number, default: 0 }, // last accepted TOTP step (replay protection)
    recoveryHashes: [String], // sha256 of single-use recovery codes
  },
  role: { type: String, enum: ['user', 'admin', 'support'], default: 'user' },
  lastLoginAt: { type: Date },
  version: { type: Number, default: 0 },
});
export const User = model('User', 'users', userSchema);

const kycSchema = mk({
  userId: { type: OID, ref: 'User', required: true, unique: true },
  fullName: String,
  nik: String, // AES-GCM ciphertext, AAD = kyc:<userId>
  nikHash: { type: String, index: true }, // HMAC blind index: finds duplicates without decrypting
  dob: Date,
  address: String,
  docImages: [String], // object-storage keys, never raw files
  selfieKey: String,
  status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' },
  reviewedBy: { type: OID, ref: 'User' },
  reason: String,
  version: { type: Number, default: 0 },
});
kycSchema.index({ nikHash: 1 }, { unique: true, partialFilterExpression: { status: 'approved' } }); // one identity, one approved account
export const KycProfile = model('KycProfile', 'kyc_profiles', kycSchema);

// ---------------------------------------------------------------- assets / markets
const assetSchema = mk({
  symbol: { type: String, required: true, unique: true, uppercase: true },
  name: { type: String, required: true },
  decimals: { type: Number, required: true, min: 0, max: 36, validate: Number.isInteger },
  type: { type: String, enum: ['fiat', 'crypto'], required: true },
  chain: { type: String },
  minDeposit: amt(),
  minWithdraw: amt(),
  withdrawFee: amt(),
  enabled: { type: Boolean, default: true },
});
export const Asset = model('Asset', 'assets', assetSchema);

const bps = { type: Number, required: true, min: 0, max: 1000, validate: Number.isInteger };
const marketSchema = mk({
  symbol: { type: String, required: true, unique: true, uppercase: true },
  base: { type: String, required: true },
  quote: { type: String, required: true },
  tickSize: amt({ default: undefined }), // price step, in quote smallest units per 1 whole base
  lotSize: amt({ default: undefined }), // qty step, in base smallest units
  minQty: amt({ default: undefined }),
  minNotional: amt({ default: undefined }), // in quote smallest units
  makerFeeBps: bps,
  takerFeeBps: bps,
  status: { type: String, enum: ['active', 'halted', 'cancel_only'], default: 'active' },
});
export const Market = model('Market', 'markets', marketSchema);

// ---------------------------------------------------------------- accounts / ledger
/**
 * owner: "u:<userId>" or "s:<systemName>".
 * normalSide: 'credit' for liabilities (user balances, fee_revenue), 'debit' for assets (hot_wallet, suspense).
 *   A leg whose direction == normalSide INCREASES the bucket; the opposite direction DECREASES it.
 */
const accountSchema = mk({
  owner: { type: String, required: true },
  userId: { type: OID, ref: 'User', default: null },
  systemName: { type: String, enum: ['fee_revenue', 'hot_wallet', 'suspense', null], default: null },
  asset: { type: String, required: true },
  normalSide: { type: String, enum: ['credit', 'debit'], required: true },
  available: amt(),
  locked: amt(),
  version: { type: Number, default: 0 },
});
accountSchema.index({ owner: 1, asset: 1 }, { unique: true });
accountSchema.index({ userId: 1, asset: 1 }, { unique: true, partialFilterExpression: { userId: { $type: 'objectId' } } });
export const Account = model('Account', 'accounts', accountSchema);

const ledgerTxSchema = mk(
  {
    txId: { type: String, required: true, unique: true },
    idempotencyKey: { type: String, required: true, unique: true },
    type: { type: String, required: true },
    refType: String,
    refId: String,
  },
  { timestamps: { createdAt: true, updatedAt: false } },
);
appendOnly(ledgerTxSchema);
export const LedgerTransaction = model('LedgerTransaction', 'ledger_transactions', ledgerTxSchema);

const ledgerEntrySchema = mk(
  {
    txId: { type: String, required: true },
    legIndex: { type: Number, required: true },
    accountId: { type: OID, ref: 'Account', required: true },
    userId: { type: OID, ref: 'User', default: null },
    asset: { type: String, required: true },
    bucket: { type: String, enum: ['available', 'locked'], required: true },
    direction: { type: String, enum: ['debit', 'credit'], required: true },
    amount: amt({ default: undefined }),
    balanceAfterAvailable: amt({ default: undefined }),
    balanceAfterLocked: amt({ default: undefined }),
    type: {
      type: String,
      enum: ['deposit', 'withdraw', 'order_lock', 'order_unlock', 'trade', 'fee', 'adjustment'],
      required: true,
    },
    refType: String,
    refId: String,
    idempotencyKey: { type: String, required: true },
  },
  { timestamps: { createdAt: true, updatedAt: false } },
);
ledgerEntrySchema.index({ txId: 1, legIndex: 1 }, { unique: true });
ledgerEntrySchema.index({ accountId: 1, _id: 1 });
ledgerEntrySchema.index({ userId: 1, createdAt: -1 });
ledgerEntrySchema.index({ refType: 1, refId: 1 });
ledgerEntrySchema.index({ idempotencyKey: 1 });
appendOnly(ledgerEntrySchema);
export const LedgerEntry = model('LedgerEntry', 'ledger_entries', ledgerEntrySchema);

// ---------------------------------------------------------------- orders / trades
const orderSchema = mk({
  userId: { type: OID, ref: 'User', required: true },
  marketId: { type: OID, ref: 'Market', required: true },
  marketSymbol: { type: String, required: true },
  side: { type: String, enum: ['buy', 'sell'], required: true },
  type: { type: String, enum: ['limit', 'market'], required: true },
  tif: { type: String, enum: ['GTC', 'IOC'], required: true },
  price: amt({ default: undefined }), // market buy: protection cap; market sell: '0'
  qty: amt({ default: undefined }),
  filledQty: amt(),
  quoteFilled: amt(),
  feePaid: amt(), // quote units
  lockAsset: { type: String, required: true },
  lockedAmount: amt(), // funds still reserved for this order
  makerFeeBps: bps, // snapshot at placement so the reserve always covers the fee
  takerFeeBps: bps,
  status: { type: String, enum: ['new', 'partial', 'filled', 'canceled', 'rejected'], default: 'new' },
  clientOrderId: { type: String },
  idempotencyKey: { type: String, required: true },
  requestHash: { type: String, required: true },
  seq: { type: Number, default: null }, // engine sequence of the accepted event
  engineStatus: { type: String, enum: ['pending_submit', 'submitted'], default: 'pending_submit' },
  cancelRequested: { type: Boolean, default: false },
  version: { type: Number, default: 0 },
});
orderSchema.index({ marketId: 1, status: 1, side: 1, price: 1, seq: 1 });
orderSchema.index({ userId: 1, createdAt: -1 });
orderSchema.index({ userId: 1, idempotencyKey: 1 }, { unique: true });
orderSchema.index({ userId: 1, clientOrderId: 1 }, { unique: true, partialFilterExpression: { clientOrderId: { $type: 'string' } } });
orderSchema.index({ engineStatus: 1, status: 1, createdAt: 1 });
export const Order = model('Order', 'orders', orderSchema);

const tradeSchema = mk(
  {
    marketId: { type: OID, ref: 'Market', required: true },
    marketSymbol: { type: String, required: true },
    price: amt({ default: undefined }),
    qty: amt({ default: undefined }),
    quoteQty: amt({ default: undefined }),
    takerOrderId: { type: OID, ref: 'Order', required: true },
    makerOrderId: { type: OID, ref: 'Order', required: true },
    takerUserId: { type: OID, ref: 'User', required: true },
    makerUserId: { type: OID, ref: 'User', required: true },
    takerSide: { type: String, enum: ['buy', 'sell'], required: true },
    takerFee: amt(),
    makerFee: amt(),
    seq: { type: Number, required: true },
    executedAt: { type: Date, default: Date.now },
  },
  { timestamps: { createdAt: true, updatedAt: false } },
);
tradeSchema.index({ marketId: 1, seq: 1 }, { unique: true });
tradeSchema.index({ takerUserId: 1, createdAt: -1 });
tradeSchema.index({ makerUserId: 1, createdAt: -1 });
appendOnly(tradeSchema);
export const Trade = model('Trade', 'trades', tradeSchema);

// ---------------------------------------------------------------- money in / out
const depositSchema = mk({
  userId: { type: OID, ref: 'User', required: true },
  asset: { type: String, required: true },
  chain: { type: String, required: true },
  address: { type: String, required: true },
  txHash: { type: String, required: true },
  vout: { type: Number, required: true, default: 0 },
  amount: amt({ default: undefined }),
  confirmations: { type: Number, default: 0 },
  status: { type: String, enum: ['pending', 'credited', 'rejected', 'reversed'], default: 'pending' },
  reason: String,
  shortfall: amt(),
  blockHash: String, // block the transaction was last seen in (reorg detection)
  creditedAt: Date,
  version: { type: Number, default: 0 },
});
depositSchema.index({ chain: 1, txHash: 1, vout: 1 }, { unique: true }); // prevents double-credit
depositSchema.index({ userId: 1, createdAt: -1 });
export const Deposit = model('Deposit', 'deposits', depositSchema);

const withdrawalSchema = mk({
  userId: { type: OID, ref: 'User', required: true },
  asset: { type: String, required: true },
  address: { type: String, required: true },
  memo: String,
  amount: amt({ default: undefined }), // amount sent to the destination
  fee: amt(), // withdrawal fee charged on top
  lockedAmount: amt(), // amount + fee while in flight
  status: { type: String, enum: ['pending', 'approved', 'broadcast', 'completed', 'rejected'], default: 'pending' },
  approvedBy: { type: OID, ref: 'User' },
  approvedAt: Date,
  txHash: String,
  riskFlags: [String],
  rejectReason: String,
  idempotencyKey: { type: String, required: true },
  requestHash: { type: String, required: true },
  version: { type: Number, default: 0 },
});
withdrawalSchema.index({ userId: 1, idempotencyKey: 1 }, { unique: true });
withdrawalSchema.index({ status: 1, createdAt: 1 });
export const Withdrawal = model('Withdrawal', 'withdrawals', withdrawalSchema);

const BANK_ENUM = ['BCA', 'MANDIRI', 'BNI', 'BRI'];
const fiatSchema = mk({
  userId: { type: OID, ref: 'User', required: true },
  type: { type: String, enum: ['deposit', 'withdraw'], required: true },
  method: { type: String, enum: ['VA', 'bank'], required: true },
  providerRef: { type: String, required: true, unique: true }, // deposits: the gateway's payment id. withdrawals: WD-<id> (our reference, sent to the gateway)
  gatewayRef: String, // the gateway's own payout id
  amount: amt({ default: undefined }),
  fee: amt(),
  lockedAmount: amt(), // withdrawals: amount + fee while in flight
  bankAccount: { bank: String, number: String, last4: String, name: String }, // withdraw: number is AES-GCM ciphertext
  senderName: String,
  status: { type: String, enum: ['pending', 'credited', 'manual_review', 'rejected', 'completed', 'approved', 'processing', 'failed'], default: 'pending' },
  nameMatch: { type: Boolean, default: false },
  reason: String,
  approvedBy: { type: OID, ref: 'User' },
  idempotencyKey: String,
  requestHash: String,
  version: { type: Number, default: 0 },
});
fiatSchema.index({ userId: 1, createdAt: -1 });
fiatSchema.index({ userId: 1, idempotencyKey: 1 }, { unique: true, partialFilterExpression: { idempotencyKey: { $type: 'string' } } });
fiatSchema.index({ type: 1, status: 1, createdAt: 1 });
export const FiatTransaction = model('FiatTransaction', 'fiat_transactions', fiatSchema);

// ---------------------------------------------------------------- api / audit / engine / idempotency
const apiKeySchema = mk({
  userId: { type: OID, ref: 'User', required: true, index: true },
  keyId: { type: String, required: true, unique: true },
  label: { type: String, default: '' },
  secretEnc: { type: String, required: true }, // AES-GCM, AAD = apikey:<keyId> (HMAC verification needs the raw secret)
  permissions: [{ type: String, enum: ['read', 'trade'] }], // 'withdraw' deliberately not allowed
  ipWhitelist: [String],
  lastUsedAt: Date,
  revokedAt: { type: Date, default: null },
});
export const ApiKey = model('ApiKey', 'api_keys', apiKeySchema);

const auditSchema = mk(
  {
    actorId: { type: OID, ref: 'User', default: null },
    action: { type: String, required: true },
    target: String,
    before: Schema.Types.Mixed,
    after: Schema.Types.Mixed,
    ip: String,
    userAgent: String,
  },
  { timestamps: { createdAt: true, updatedAt: false } },
);
auditSchema.index({ actorId: 1, createdAt: -1 });
auditSchema.index({ target: 1, createdAt: -1 });
appendOnly(auditSchema);
export const AuditLog = model('AuditLog', 'audit_logs', auditSchema);

const engineEventSchema = mk(
  {
    marketId: { type: OID, ref: 'Market', required: true },
    seq: { type: Number, required: true },
    type: { type: String, enum: ['order_accepted', 'cancel_requested', 'trade', 'order_canceled'], required: true },
    payload: { type: Schema.Types.Mixed, required: true },
  },
  { timestamps: { createdAt: true, updatedAt: false } },
);
engineEventSchema.index({ marketId: 1, seq: 1 }, { unique: true });
appendOnly(engineEventSchema);
export const EngineEvent = model('EngineEvent', 'engine_events', engineEventSchema);

const idemSchema = mk({
  scope: { type: String, required: true },
  key: { type: String, required: true },
  requestHash: { type: String, required: true },
  response: Schema.Types.Mixed,
  expireAt: { type: Date, default: () => new Date(Date.now() + 24 * 3600 * 1000), index: { expires: 0 } },
});
idemSchema.index({ scope: 1, key: 1 }, { unique: true });
export const IdempotencyKey = model('IdempotencyKey', 'idempotency_keys', idemSchema);

const sessionSchema = mk({
  userId: { type: OID, ref: 'User', required: true, index: true },
  familyId: { type: String, required: true, index: true }, // all rotations of one login share a family
  accessHash: { type: String, required: true, unique: true },
  refreshHash: { type: String, required: true, unique: true },
  accessExpiresAt: { type: Date, required: true },
  refreshExpiresAt: { type: Date, required: true, index: { expires: 0 } },
  ip: String,
  userAgent: String,
  lastUsedAt: Date,
  rotatedAt: { type: Date, default: null },
  revokedAt: { type: Date, default: null },
});
export const Session = model('Session', 'sessions', sessionSchema);

const resetSchema = mk({
  userId: { type: OID, ref: 'User', required: true, index: true },
  tokenHash: { type: String, required: true, unique: true },
  expiresAt: { type: Date, required: true, index: { expires: 0 } },
  usedAt: { type: Date, default: null },
});
export const PasswordReset = model('PasswordReset', 'password_resets', resetSchema);

const candleSchema = mk({
  marketSymbol: { type: String, required: true },
  interval: { type: String, enum: ['1m', '5m', '15m', '1h', '4h', '1d'], required: true },
  openTime: { type: Number, required: true }, // ms since epoch, UTC-aligned bucket start
  open: amt({ default: undefined }),
  high: amt({ default: undefined }),
  low: amt({ default: undefined }),
  close: amt({ default: undefined }),
  volume: amt(), // base units
  quoteVolume: amt(), // quote units
  trades: { type: Number, default: 0 },
  lastSeq: { type: Number, default: 0 }, // highest trade seq folded in (idempotency)
  version: { type: Number, default: 0 },
});
candleSchema.index({ marketSymbol: 1, interval: 1, openTime: 1 }, { unique: true });
export const Candle = model('Candle', 'candles', candleSchema);

const vaSchema = mk({
  userId: { type: OID, ref: 'User', required: true, index: true },
  bank: { type: String, enum: BANK_ENUM, required: true },
  provider: { type: String, required: true },
  vaNumber: { type: String, required: true, unique: true },
});
vaSchema.index({ userId: 1, bank: 1, provider: 1 }, { unique: true });
export const VirtualAccount = model('VirtualAccount', 'virtual_accounts', vaSchema);

const bankAcctSchema = mk({
  userId: { type: OID, ref: 'User', required: true, index: true },
  bank: { type: String, enum: BANK_ENUM, required: true },
  numberEnc: { type: String, required: true }, // AES-GCM, AAD = bank:<userId>
  last4: String,
  holderName: { type: String, required: true }, // must match the KYC name
  active: { type: Boolean, default: true },
  disabledAt: Date,
});
bankAcctSchema.index({ userId: 1 }, { unique: true, partialFilterExpression: { active: true } }); // one active payout account per user
export const BankAccount = model('BankAccount', 'bank_accounts', bankAcctSchema);

const depositAddrSchema = mk({
  chain: { type: String, required: true },
  address: { type: String, required: true },
  userId: { type: OID, ref: 'User', default: null },
  assignedAt: Date,
});
depositAddrSchema.index({ chain: 1, address: 1 }, { unique: true });
depositAddrSchema.index({ chain: 1, userId: 1 });
depositAddrSchema.index({ chain: 1, userId: 1 }, { unique: true, partialFilterExpression: { userId: { $type: 'objectId' } } }); // one address per user per chain
export const DepositAddress = model('DepositAddress', 'deposit_addresses', depositAddrSchema);

const chainStateSchema = mk({
  chain: { type: String, required: true, unique: true },
  lastScanned: { type: Number, default: 0 },
  lastHash: String,
});
export const ChainState = model('ChainState', 'chain_state', chainStateSchema);

export const ALL_MODELS = [
  User, KycProfile, Asset, Market, Account, LedgerTransaction, LedgerEntry, Order, Trade,
  Deposit, Withdrawal, FiatTransaction, ApiKey, AuditLog, EngineEvent, IdempotencyKey, Session, PasswordReset, Candle, VirtualAccount, BankAccount, DepositAddress, ChainState,
];
