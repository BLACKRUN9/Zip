import mongoose from 'mongoose';
import { ALL_MODELS } from './models.ts';
import { AMOUNT_PATTERN } from '../money.ts';

/** Collections whose string-amount fields are also validated by MongoDB itself (defence in depth). */
const VALIDATED: Record<string, string[]> = {
  accounts: ['available', 'locked'],
  ledger_entries: ['amount', 'balanceAfterAvailable', 'balanceAfterLocked'],
  orders: ['price', 'qty', 'filledQty', 'quoteFilled', 'feePaid', 'lockedAmount'],
  trades: ['price', 'qty', 'quoteQty', 'takerFee', 'makerFee'],
  deposits: ['amount', 'shortfall'],
  withdrawals: ['amount', 'fee', 'lockedAmount'],
  fiat_transactions: ['amount', 'fee', 'lockedAmount'],
  candles: ['open', 'high', 'low', 'close', 'volume', 'quoteVolume'],
};

/** Call once at boot (and in tests): creates collections (transactions need them to exist), validators, indexes. */
export async function initDb(): Promise<void> {
  const db = mongoose.connection.db!;
  for (const m of ALL_MODELS) {
    try {
      await db.createCollection(m.collection.name);
    } catch (e: any) {
      if (e?.code !== 48) throw e; // 48 = NamespaceExists
    }
  }
  for (const [coll, fields] of Object.entries(VALIDATED)) {
    const properties = Object.fromEntries(fields.map((f) => [f, { bsonType: 'string', pattern: AMOUNT_PATTERN }]));
    await db.command({
      collMod: coll,
      validator: { $jsonSchema: { bsonType: 'object', properties } },
      validationLevel: 'strict',
      validationAction: 'error',
    });
  }
  for (const m of ALL_MODELS) await m.syncIndexes();
}
