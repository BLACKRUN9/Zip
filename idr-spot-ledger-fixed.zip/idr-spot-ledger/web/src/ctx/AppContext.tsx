import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { ApiClient } from '../lib/api.ts';
import { WsClient } from '../lib/ws.ts';
import type { WsStatus } from '../lib/ws.ts';
import { API_BASE, WS_URL } from '../env.ts';
import type { Asset, MarketInfo, User } from '../types.ts';

interface Ctx {
  api: ApiClient;
  ws: WsClient;
  user: User | null;
  ready: boolean;
  wsStatus: WsStatus;
  assets: Record<string, Asset>;
  markets: MarketInfo[];
  login(email: string, password: string, code?: string): Promise<void>;
  logout(): Promise<void>;
  refreshUser(): Promise<void>;
}
const AppCtx = createContext<Ctx | null>(null);
export const useApp = (): Ctx => {
  const c = useContext(AppCtx);
  if (!c) throw new Error('useApp outside AppProvider');
  return c;
};

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [ready, setReady] = useState(false);
  const [wsStatus, setWsStatus] = useState<WsStatus>('idle');
  const [assets, setAssets] = useState<Record<string, Asset>>({});
  const [markets, setMarkets] = useState<MarketInfo[]>([]);
  const lost = useRef<() => void>(() => {});

  // one API client and one socket for the whole app
  const { api, ws } = useMemo(() => {
    const api = new ApiClient({ baseUrl: API_BASE, fetch: (u, i) => fetch(u, i), storage: sessionStorage, onSessionLost: () => lost.current() });
    const ws = new WsClient({
      url: WS_URL,
      getToken: () => api.token(),
      WebSocketImpl: WebSocket,
      setTimeout: (fn, ms) => window.setTimeout(fn, ms),
      clearTimeout: (h) => window.clearTimeout(h),
    });
    return { api, ws };
  }, []);

  useEffect(() => {
    lost.current = () => { setUser(null); ws.authChanged(); };
    const off = ws.onStatus(setWsStatus);
    let alive = true;
    (async () => {
      try {
        const [a, m] = await Promise.all([api.get('/v1/assets', { auth: false }), api.get('/v1/markets', { auth: false })]);
        if (!alive) return;
        setAssets(Object.fromEntries(a.items.map((x: Asset) => [x.symbol, x])));
        setMarkets(m.items);
      } catch { /* the UI shows an error banner where metadata is required */ }
      if (api.hasSession) {
        try { const me = await api.get('/v1/me'); if (alive) setUser(me); } catch { /* not logged in */ }
      }
      if (alive) setReady(true);
    })();
    return () => { alive = false; off(); };
  }, [api, ws]);

  const refreshUser = useCallback(async () => { setUser(await api.get('/v1/me')); }, [api]);
  const login = useCallback(async (email: string, password: string, code?: string) => {
    await api.login(email, password, code);
    setUser(await api.get('/v1/me'));
    ws.authChanged(); // reconnect so the socket speaks as the new identity
  }, [api, ws]);
  const logout = useCallback(async () => { await api.logout(); setUser(null); ws.authChanged(); }, [api, ws]);

  const value = useMemo(() => ({ api, ws, user, ready, wsStatus, assets, markets, login, logout, refreshUser }), [api, ws, user, ready, wsStatus, assets, markets, login, logout, refreshUser]);
  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>;
}
