import { Navigate, Route, Routes } from 'react-router-dom';
import { Layout, RequireAuth } from './components/Layout.tsx';
import { Admin } from './pages/Admin.tsx';
import { Forgot, Login, Register, Reset } from './pages/AuthPages.tsx';
import { Kyc } from './pages/Kyc.tsx';
import { Security } from './pages/Security.tsx';
import { Trade } from './pages/Trade.tsx';
import { Wallet } from './pages/Wallet.tsx';

export function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Navigate to="/trade" replace />} />
        <Route path="/trade/:market?" element={<Trade />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/forgot" element={<Forgot />} />
        <Route path="/reset" element={<Reset />} />
        <Route element={<RequireAuth />}>
          <Route path="/wallet" element={<Wallet />} />
          <Route path="/kyc" element={<Kyc />} />
          <Route path="/security" element={<Security />} />
        </Route>
        <Route element={<RequireAuth admin />}>
          <Route path="/admin" element={<Admin />} />
        </Route>
        <Route path="*" element={<Navigate to="/trade" replace />} />
      </Route>
    </Routes>
  );
}
