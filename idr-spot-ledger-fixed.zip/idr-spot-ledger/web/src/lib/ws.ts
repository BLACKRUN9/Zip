import { backoffDelay } from './backoff.ts';

export interface WsEvent { type: 'snapshot' | 'update'; channel: string; seq?: number; data: any }
type Handler = (e: WsEvent) => void;
export type WsStatus = 'idle' | 'connecting' | 'open' | 'reconnecting' | 'closed';

export interface WsDeps {
  url: string;
  /** Fresh access token for private channels, or null when logged out. */
  getToken: () => Promise<string | null>;
  WebSocketImpl: any;
  setTimeout: (fn: () => void, ms: number) => any;
  clearTimeout: (h: any) => void;
  random?: () => number;
  pingMs?: number; // app-level ping interval
  staleMs?: number; // no message at all for this long => reconnect
}
const isPrivate = (ch: string) => ch === 'orders' || ch === 'balances';

/**
 * Resilient client for the exchange socket:
 *  - ref-counted subscriptions, re-sent automatically after every reconnect (the server snapshot resyncs the UI);
 *  - exponential backoff with jitter; reset only after the connection proved healthy (a message arrived);
 *  - private channels wait for `authed`; TOKEN_EXPIRED triggers a transparent re-auth with a fresh token;
 *  - stale-connection detection (half-open TCP) via ping/any-message watchdog.
 */
export class WsClient {
  deps: WsDeps;
  ws: any = null;
  status: WsStatus = 'idle';
  attempt = 0;
  subs: Map<string, Set<Handler>> = new Map();
  sent: Set<string> = new Set(); // channels subscribed on the CURRENT socket
  authed = false;
  authPending = false;
  authGaveUp = false; // logged out (no token): stop asking until login state changes or we reconnect
  wantClosed = false;
  statusListeners: Set<(s: WsStatus) => void> = new Set();
  reconnectTimer: any = null;
  pingTimer: any = null;
  lastMsgAt = 0;
  now: () => number = Date.now;

  constructor(deps: WsDeps) { this.deps = deps; }

  _setStatus(s: WsStatus) { this.status = s; for (const l of this.statusListeners) l(s); }
  onStatus(l: (s: WsStatus) => void): () => void { this.statusListeners.add(l); return () => this.statusListeners.delete(l); }

  connect(): void {
    this.wantClosed = false;
    if (this.ws || this.reconnectTimer) return;
    this._open();
  }

  _open(): void {
    this._setStatus(this.attempt === 0 ? 'connecting' : 'reconnecting');
    const ws = new this.deps.WebSocketImpl(this.deps.url);
    this.ws = ws;
    ws.onopen = () => {
      this.sent.clear();
      this.authed = false;
      this.authGaveUp = false;
      this.lastMsgAt = this.now();
      this._startWatchdog();
      this._flush();
    };
    ws.onmessage = (ev: any) => this._onMessage(ev.data);
    ws.onclose = () => this._onClose(ws);
    ws.onerror = () => { /* onclose follows */ };
  }

  _send(obj: unknown): boolean {
    if (!this.ws || this.ws.readyState !== 1) return false;
    this.ws.send(JSON.stringify(obj));
    return true;
  }

  /** Send whatever is pending: auth first if a private channel is wanted, then subscribe the rest. */
  _flush(): void {
    if (!this.ws || this.ws.readyState !== 1) return;
    const wantsPrivate = [...this.subs.keys()].some(isPrivate);
    if (wantsPrivate && !this.authed && !this.authPending && !this.authGaveUp) {
      this.authPending = true;
      this.deps.getToken().then((t) => {
        this.authPending = false;
        if (t && this._send({ op: 'auth', token: t })) return;
        this.authGaveUp = !t; // logged out: never loop on a missing token; public channels still work
        this._flush();
      }, () => {
        this.authPending = false;
        // transient failure while fetching a token (e.g. refresh over a flaky network): retry later, never in a tight loop
        this.deps.setTimeout(() => { if (!this.wantClosed) this._flush(); }, 5000);
      });
    }
    for (const ch of this.subs.keys()) {
      if (this.sent.has(ch)) continue;
      if (isPrivate(ch) && !this.authed) continue;
      if (this._send({ op: 'subscribe', channel: ch })) this.sent.add(ch);
    }
  }

  _onMessage(raw: string): void {
    this.lastMsgAt = this.now();
    if (this.attempt > 0) this.attempt = 0; // healthy again
    let m: any;
    try { m = JSON.parse(raw); } catch { return; }
    switch (m.type) {
      case 'authed': this.authed = true; this._flush(); return;
      case 'snapshot': case 'update': {
        const hs = this.subs.get(m.channel);
        if (hs) for (const h of [...hs]) h({ type: m.type, channel: m.channel, seq: m.seq, data: m.data });
        return;
      }
      case 'error':
        if (m.code === 'TOKEN_EXPIRED' || m.code === 'AUTH_REQUIRED') {
          // the server dropped our private streams: forget them locally, re-auth with a fresh token, resubscribe
          this.authed = false;
          for (const ch of [...this.sent]) if (isPrivate(ch)) this.sent.delete(ch);
          this._flush();
        }
        return;
      default: return;
    }
  }

  _startWatchdog(): void {
    this._stopWatchdog();
    const ping = this.deps.pingMs ?? 20_000, stale = this.deps.staleMs ?? 50_000;
    const tick = () => {
      if (this.now() - this.lastMsgAt > stale) { try { this.ws?.close(); } catch { /* ignore */ } return; }
      this._send({ op: 'ping' });
      this.pingTimer = this.deps.setTimeout(tick, ping);
    };
    this.pingTimer = this.deps.setTimeout(tick, ping);
  }
  _stopWatchdog(): void {
    if (this.pingTimer) { this.deps.clearTimeout(this.pingTimer); this.pingTimer = null; }
  }

  _onClose(ws: any): void {
    if (this.ws !== ws) return;
    this.ws = null;
    this.authed = false;
    this.authPending = false;
    this.sent.clear();
    this._stopWatchdog();
    if (this.wantClosed) { this._setStatus('closed'); return; }
    this._setStatus('reconnecting');
    const delay = backoffDelay(this.attempt++, this.deps.random);
    this.reconnectTimer = this.deps.setTimeout(() => { this.reconnectTimer = null; if (!this.wantClosed) this._open(); }, delay);
  }

  subscribe(channel: string, handler: Handler): () => void {
    let set = this.subs.get(channel);
    if (!set) { set = new Set(); this.subs.set(channel, set); }
    set.add(handler);
    this.connect();
    this._flush();
    return () => {
      const cur = this.subs.get(channel);
      if (!cur) return;
      cur.delete(handler);
      if (cur.size === 0) {
        this.subs.delete(channel);
        if (this.sent.delete(channel)) this._send({ op: 'unsubscribe', channel });
      }
    };
  }

  /** Force a fresh snapshot for a channel (used when a sequence gap is detected). */
  resync(channel: string): void {
    if (this.sent.delete(channel)) this._send({ op: 'unsubscribe', channel });
    this._flush();
  }

  /** Call after login/logout so private channels (un)subscribe without waiting for a reconnect. */
  authChanged(): void {
    this.authGaveUp = false;
    if (this.ws && this.ws.readyState === 1) {
      for (const ch of [...this.sent]) if (isPrivate(ch)) { this._send({ op: 'unsubscribe', channel: ch }); this.sent.delete(ch); }
      this.ws.close(); // simplest correct way to drop the old identity: reconnect (backoff attempt 0 => quick)
    }
  }

  close(): void {
    this.wantClosed = true;
    if (this.reconnectTimer) { this.deps.clearTimeout(this.reconnectTimer); this.reconnectTimer = null; }
    this._stopWatchdog();
    try { this.ws?.close(); } catch { /* ignore */ }
    if (!this.ws) this._setStatus('closed');
  }
}
