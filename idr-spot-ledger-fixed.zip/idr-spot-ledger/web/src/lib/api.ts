/**
 * API client. Access token lives in MEMORY only; the refresh token is kept in sessionStorage (per tab, gone when
 * the tab closes). Trade-off: sessionStorage is readable by injected scripts, so the SPA must ship a strict CSP
 * (see web/README.md). A more hardened option is an httpOnly refresh cookie (needs a small backend change + CSRF token).
 */
export class ApiError extends Error {
  status: number;
  code: string;
  requestId?: string;
  constructor(status: number, code: string, message: string, requestId?: string) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
    this.requestId = requestId;
  }
}

export interface Tokens { accessToken: string; refreshToken: string; accessExpiresAt: string; refreshExpiresAt: string }
export interface StorageLike { getItem(k: string): string | null; setItem(k: string, v: string): void; removeItem(k: string): void }
export interface ApiDeps {
  baseUrl: string;
  fetch: (url: string, init: any) => Promise<any>;
  storage: StorageLike;
  onSessionLost: () => void;
  now?: () => number;
  uuid?: () => string;
  timeoutMs?: number;
}
export interface ReqOpts { auth?: boolean; idempotencyKey?: string; signal?: AbortSignal }

const RT_KEY = 'rt';

export class ApiClient {
  deps: ApiDeps;
  access: string | null = null;
  accessExp = 0;
  refreshing: Promise<boolean> | null = null;

  constructor(deps: ApiDeps) { this.deps = deps; }
  now(): number { return (this.deps.now ?? Date.now)(); }
  get hasSession(): boolean { return !!this.access || !!this.deps.storage.getItem(RT_KEY); }

  _store(t: Tokens): void {
    this.access = t.accessToken;
    this.accessExp = new Date(t.accessExpiresAt).getTime();
    this.deps.storage.setItem(RT_KEY, t.refreshToken);
  }
  _clear(): void {
    this.access = null;
    this.accessExp = 0;
    this.deps.storage.removeItem(RT_KEY);
  }

  async login(email: string, password: string, code?: string): Promise<void> {
    const t = await this.request<Tokens>('POST', '/v1/auth/login', { email, password, ...(code ? { code } : {}) }, { auth: false });
    this._store(t);
  }

  async logout(): Promise<void> {
    try { if (this.access) await this.request('POST', '/v1/auth/logout', undefined, { auth: true }); } catch { /* still clear locally */ }
    this._clear();
  }

  /** Returns a usable access token, refreshing first when missing/expiring. Single-flight: concurrent callers share one refresh. */
  async token(): Promise<string | null> {
    if (this.access && this.accessExp - this.now() > 20_000) return this.access;
    if (!this.deps.storage.getItem(RT_KEY)) return null;
    await this.refresh();
    return this.access;
  }

  refresh(): Promise<boolean> {
    if (!this.refreshing) {
      this.refreshing = (async () => {
        const rt = this.deps.storage.getItem(RT_KEY);
        if (!rt) return false;
        try {
          const t = await this.request<Tokens>('POST', '/v1/auth/refresh', { refreshToken: rt }, { auth: false });
          this._store(t);
          return true;
        } catch (e) {
          // a refresh token is single-use: any failure means the session is gone (expired, revoked, reuse detected)
          if (e instanceof ApiError && e.status < 500) { this._clear(); this.deps.onSessionLost(); }
          return false;
        } finally {
          this.refreshing = null;
        }
      })();
    }
    return this.refreshing;
  }

  async request<T = any>(method: string, path: string, body?: unknown, o: ReqOpts = {}, retried = false): Promise<T> {
    const headers: Record<string, string> = { Accept: 'application/json' };
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    if (o.idempotencyKey) headers['Idempotency-Key'] = o.idempotencyKey;
    if (o.auth !== false && path !== '/v1/auth/login' && path !== '/v1/auth/refresh') {
      const tk = await this.token();
      if (!tk) throw new ApiError(401, 'UNAUTHENTICATED', 'sesi berakhir, silakan masuk lagi');
      headers.Authorization = `Bearer ${tk}`;
    }
    const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    const timer = ctrl ? setTimeout(() => ctrl.abort(), this.deps.timeoutMs ?? 15_000) : null;
    let res: any;
    try {
      res = await this.deps.fetch(this.deps.baseUrl + path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body), signal: o.signal ?? ctrl?.signal });
    } catch {
      throw new ApiError(0, 'NETWORK', 'tidak dapat terhubung ke server');
    } finally {
      if (timer) clearTimeout(timer);
    }
    if (res.status === 204) return undefined as T;
    let data: any = null;
    try { data = await res.json(); } catch { /* non-JSON body */ }
    if (res.ok) return data as T;
    const err = new ApiError(res.status, data?.error ?? 'HTTP_' + res.status, data?.message ?? 'terjadi kesalahan', data?.requestId);
    if (err.code === 'INVALID_TOKEN' && o.auth !== false && !retried) {
      this.access = null; // stale access token: refresh once, then replay the request with the SAME idempotency key
      if (await this.refresh()) return this.request<T>(method, path, body, o, true);
    }
    throw err;
  }

  get = <T = any>(path: string, o?: ReqOpts) => this.request<T>('GET', path, undefined, o);
  post = <T = any>(path: string, body?: unknown, o?: ReqOpts) => this.request<T>('POST', path, body, o);
  del = <T = any>(path: string, o?: ReqOpts) => this.request<T>('DELETE', path, undefined, o);
  newKey(): string { return (this.deps.uuid ?? (() => crypto.randomUUID()))(); }
}

/** Indonesian messages for the stable API error codes. Unknown codes fall back to the server message. */
export const ERROR_TEXT: Record<string, string> = {
  INVALID_CREDENTIALS: 'Email, kata sandi, atau kode salah.',
  ACCOUNT_LOCKED: 'Terlalu banyak percobaan. Coba lagi dalam 15 menit.',
  TWOFA_REQUIRED: 'Masukkan kode 2FA.',
  TWOFA_INVALID: 'Kode 2FA salah atau sudah dipakai. Tunggu kode berikutnya.',
  TWOFA_SETUP_REQUIRED: 'Aktifkan 2FA terlebih dahulu di menu Keamanan.',
  INSUFFICIENT_FUNDS: 'Saldo tidak cukup.',
  FORBIDDEN: 'Tindakan ini tidak diizinkan untuk akun Anda saat ini.',
  MARKET_NOT_ACTIVE: 'Pasar sedang tidak aktif.',
  RATE_LIMITED: 'Terlalu banyak permintaan. Coba lagi sebentar.',
  IDEMPOTENCY_MISMATCH: 'Permintaan ini sudah pernah dikirim dengan isi berbeda. Muat ulang halaman.',
  CONFLICT: 'Data bertabrakan dengan data yang sudah ada.',
  NETWORK: 'Tidak dapat terhubung ke server. Periksa koneksi Anda.',
  UNAUTHENTICATED: 'Sesi berakhir. Silakan masuk lagi.',
};
export const errorText = (e: unknown): string =>
  e instanceof ApiError ? ERROR_TEXT[e.code] ?? e.message : 'Terjadi kesalahan tak terduga.';
