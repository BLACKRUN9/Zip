/** Exponential backoff with "equal jitter" (50-100% of the step) so thousands of clients do not reconnect in lockstep. */
export function backoffDelay(attempt: number, random: () => number = Math.random, baseMs = 500, capMs = 15_000): number {
  const step = Math.min(capMs, baseMs * 2 ** Math.min(attempt, 30));
  return Math.round(step * (0.5 + random() / 2));
}
