/**
 * Display + input helpers. Money is NEVER a JS float here: amounts are integer strings in the asset's smallest
 * unit (same as the API) and all maths is BigInt. Formatting truncates (never rounds up) so the UI cannot show
 * more than the user owns. The server stays the authority; this is for UX and early validation.
 */
export class InputError extends Error {
  code: 'INVALID_NUMBER' | 'TOO_MANY_DECIMALS' | 'AMBIGUOUS' | 'EMPTY';
  constructor(code: InputError['code'], message: string) { super(message); this.name = 'InputError'; this.code = code; }
}
const pow10 = (n: number): bigint => 10n ** BigInt(n);
const group = (digits: string): string => digits.replace(/\B(?=(\d{3})+(?!\d))/g, '.'); // Indonesian: 1.000.000

/** "50000000", 8 -> "0,5"   ·   "1500000000", 0 -> "1.500.000.000" */
export function formatUnits(v: string, decimals: number, o: { maxFrac?: number; minFrac?: number } = {}): string {
  const big = BigInt(v);
  const neg = big < 0n;
  const abs = neg ? -big : big;
  const base = pow10(decimals);
  const intPart = (abs / base).toString();
  let frac = decimals ? (abs % base).toString().padStart(decimals, '0') : '';
  frac = frac.slice(0, Math.min(o.maxFrac ?? decimals, decimals)).replace(/0+$/, '');
  frac = frac.padEnd(Math.min(o.minFrac ?? 0, decimals), '0');
  return `${neg ? '-' : ''}${group(intPart)}${frac ? ',' + frac : ''}`;
}
/** Value for an <input>: plain digits, "," as decimal separator, no grouping (so parseUnits round-trips it exactly). */
export function plainUnits(v: string, decimals: number): string {
  const big = BigInt(v);
  const base = pow10(decimals);
  const frac = decimals ? (big % base).toString().padStart(decimals, '0').replace(/0+$/, '') : '';
  return `${big / base}${frac ? ',' + frac : ''}`;
}
export const formatIdr = (v: string): string => `Rp ${formatUnits(v, 0)}`;
export const formatPct = (bps: number | null): string => (bps === null ? '-' : `${bps > 0 ? '+' : ''}${(Math.trunc(bps) / 100).toFixed(2).replace('.', ',')}%`);

/**
 * Text typed by a person -> integer string in smallest units.
 *  decimals = 0 (IDR): digits only; Indonesian thousand dots ("1.500.000") are accepted when well-formed.
 *  decimals > 0: one decimal separator, "." or ","; ambiguous grouped input such as "1.000.000" is rejected.
 */
export function parseUnits(input: string, decimals: number): string {
  const s = input.trim();
  if (!s) throw new InputError('EMPTY', 'wajib diisi');
  const grouped = /^\d{1,3}(\.\d{3})+$/.test(s);
  if (decimals === 0) {
    if (/^\d+$/.test(s)) return BigInt(s).toString();
    if (grouped) return BigInt(s.replace(/\./g, '')).toString();
    throw new InputError('INVALID_NUMBER', 'hanya angka bulat');
  }
  if (grouped && s.split('.').length > 2) throw new InputError('AMBIGUOUS', 'format angka ambigu, gunakan koma untuk desimal');
  const m = /^(\d+)(?:[.,](\d+))?$/.exec(s);
  if (!m) throw new InputError('INVALID_NUMBER', 'angka tidak valid');
  const frac = m[2] ?? '';
  if (frac.length > decimals) throw new InputError('TOO_MANY_DECIMALS', `maksimal ${decimals} angka di belakang koma`);
  return BigInt(m[1] + frac.padEnd(decimals, '0')).toString();
}

export const quoteAmount = (price: string, qty: string, baseDecimals: number): bigint => (BigInt(price) * BigInt(qty)) / pow10(baseDecimals);
export const feeCeil = (amount: bigint, bps: number): bigint => (amount * BigInt(bps) + 9999n) / 10000n;
export const feeFloor = (amount: bigint, bps: number): bigint => (amount * BigInt(bps)) / 10000n;
export const isMultiple = (v: string | bigint, step: string | bigint): boolean => BigInt(step) > 0n && BigInt(v) % BigInt(step) === 0n;

/** What the server will lock for a buy order (identical formula to the backend: notional + ceil(max(maker,taker) fee)). */
export function buyReserve(price: string, qty: string, baseDecimals: number, makerBps: number, takerBps: number): bigint {
  const n = quoteAmount(price, qty, baseDecimals);
  return n + feeCeil(n, Math.max(makerBps, takerBps));
}

/** Largest qty (multiple of lot) whose buy reserve fits in `quoteBalance`. */
export function maxBuyQty(quoteBalance: string, price: string, baseDecimals: number, lot: string, makerBps: number, takerBps: number): bigint {
  const bal = BigInt(quoteBalance), p = BigInt(price), step = BigInt(lot);
  if (bal <= 0n || p <= 0n || step <= 0n) return 0n;
  const bps = BigInt(Math.max(makerBps, takerBps));
  let q = (bal * 10000n * pow10(baseDecimals)) / (p * (10000n + bps));
  q -= q % step;
  while (q > 0n && buyReserve(price, q.toString(), baseDecimals, makerBps, takerBps) > bal) q -= step;
  return q;
}
