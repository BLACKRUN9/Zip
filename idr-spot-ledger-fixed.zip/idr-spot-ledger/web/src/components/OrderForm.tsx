import { useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '../ctx/AppContext.tsx';
import { InputError, buyReserve, feeFloor, formatUnits, isMultiple, maxBuyQty, parseUnits, plainUnits, quoteAmount } from '../lib/money.ts';
import { errorText } from '../lib/api.ts';
import { Alert, Tabs } from './ui.tsx';
import type { Asset, Balance, MarketInfo } from '../types.ts';

interface Props { market: MarketInfo; base: Asset; quote: Asset; balances: Record<string, Balance>; picked: { price: string; n: number } | null }

export function OrderForm({ market: m, base, quote, balances, picked }: Props) {
  const { api, user } = useApp();
  const [side, setSide] = useState<'buy' | 'sell'>('buy');
  const [type, setType] = useState<'limit' | 'market'>('limit');
  const [priceText, setPriceText] = useState('');
  const [qtyText, setQtyText] = useState('');
  const [confirming, setConfirming] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [ok, setOk] = useState('');
  const key = useRef(api.newKey());

  // A new idempotency key for every distinct order; the SAME key while the user retries an unchanged order after an error.
  useEffect(() => { key.current = api.newKey(); setConfirming(false); }, [api, side, type, priceText, qtyText, m.symbol]);
  useEffect(() => { if (picked) setPriceText(plainUnits(picked.price, quote.decimals)); }, [picked, quote.decimals]);

  const needsPrice = type === 'limit' || side === 'buy'; // market BUY needs a protection price cap
  const avail = (sym: string) => BigInt(balances[sym]?.available ?? '0');

  const calc = useMemo(() => {
    const problems: string[] = [];
    let price: string | undefined, qty: string | undefined;
    const tryParse = (text: string, dec: number, label: string): string | undefined => {
      if (!text.trim()) return undefined;
      try { return parseUnits(text, dec); } catch (e) { problems.push(`${label}: ${e instanceof InputError ? e.message : 'tidak valid'}`); return undefined; }
    };
    if (needsPrice) price = tryParse(priceText, quote.decimals, type === 'market' ? 'Batas harga' : 'Harga');
    qty = tryParse(qtyText, base.decimals, 'Jumlah');
    if (price && !isMultiple(price, m.tickSize)) problems.push(`Harga harus kelipatan ${formatUnits(m.tickSize, quote.decimals)}`);
    if (qty && !isMultiple(qty, m.lotSize)) problems.push(`Jumlah harus kelipatan ${formatUnits(m.lotSize, base.decimals)}`);
    if (qty && BigInt(qty) < BigInt(m.minQty)) problems.push(`Jumlah minimum ${formatUnits(m.minQty, base.decimals)} ${base.symbol}`);
    const total = price && qty ? quoteAmount(price, qty, base.decimals) : null;
    if (total !== null && total < BigInt(m.minNotional)) problems.push(`Nilai order minimum ${formatUnits(m.minNotional, quote.decimals)} ${quote.symbol}`);
    let need: bigint | null = null;
    if (side === 'buy' && price && qty) {
      need = buyReserve(price, qty, base.decimals, m.makerFeeBps, m.takerFeeBps);
      if (need > avail(quote.symbol)) problems.push(`Saldo ${quote.symbol} tidak cukup (butuh ${formatUnits(need.toString(), quote.decimals)})`);
    }
    if (side === 'sell' && qty && BigInt(qty) > avail(base.symbol)) problems.push(`Saldo ${base.symbol} tidak cukup`);
    const complete = !!qty && (!needsPrice || !!price) && problems.length === 0;
    return { problems, price, qty, total, need, fee: total !== null ? feeFloor(total, m.takerFeeBps) : null, complete };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [side, type, priceText, qtyText, balances, m, base, quote, needsPrice]);

  function pct(p: number) {
    const lot = BigInt(m.lotSize);
    let q = 0n;
    if (side === 'sell') q = (avail(base.symbol) * BigInt(p)) / 100n;
    else if (calc.price) q = (maxBuyQty(avail(quote.symbol).toString(), calc.price, base.decimals, m.lotSize, m.makerFeeBps, m.takerFeeBps) * BigInt(p)) / 100n;
    q -= q % lot;
    setQtyText(q > 0n ? plainUnits(q.toString(), base.decimals) : '');
  }

  async function submit() {
    setBusy(true); setErr(''); setOk('');
    try {
      const body: Record<string, string> = { market: m.symbol, side, type, qty: calc.qty! };
      if (needsPrice) body.price = calc.price!;
      if (type === 'limit') body.tif = 'GTC';
      await api.post('/v1/orders', body, { idempotencyKey: key.current });
      setOk('Order terkirim.'); setQtyText(''); setConfirming(false);
    } catch (e) { setErr(errorText(e)); setConfirming(false); }
    finally { setBusy(false); }
  }

  if (!user) return <div className="card"><h2>Trading</h2><p><Link to="/login">Masuk</Link> atau <Link to="/register">daftar</Link> untuk mulai trading.</p></div>;
  if (user.kycLevel < 1) return <div className="card"><h2>Trading</h2><Alert kind="warn">Selesaikan verifikasi identitas dulu di menu <Link to="/kyc">Verifikasi</Link> sebelum trading.</Alert></div>;
  const halted = m.status !== 'active';

  return (
    <div className="card col">
      <Tabs value={side} onChange={setSide} items={[['buy', 'Beli'], ['sell', 'Jual']]} />
      <Tabs value={type} onChange={setType} items={[['limit', 'Limit'], ['market', 'Market']]} />
      {halted && <Alert kind="warn">Pasar sedang {m.status === 'halted' ? 'dihentikan' : 'hanya menerima pembatalan'}.</Alert>}
      {needsPrice && (
        <div className="field"><label htmlFor="of-price">{type === 'market' ? `Batas harga maksimum (${quote.symbol})` : `Harga (${quote.symbol})`}</label>
          <input id="of-price" className="input" inputMode="decimal" value={priceText} onChange={(e) => setPriceText(e.target.value)} /></div>
      )}
      <div className="field"><label htmlFor="of-qty">Jumlah ({base.symbol})</label>
        <input id="of-qty" className="input" inputMode="decimal" value={qtyText} onChange={(e) => setQtyText(e.target.value)} />
        <div className="row">{[25, 50, 75, 100].map((p) => <button key={p} type="button" className="btn small" onClick={() => pct(p)} disabled={side === 'buy' && !calc.price}>{p}%</button>)}</div></div>
      <div className="muted">Tersedia: {formatUnits(balances[side === 'buy' ? quote.symbol : base.symbol]?.available ?? '0', side === 'buy' ? quote.decimals : base.decimals, { maxFrac: 8 })} {side === 'buy' ? quote.symbol : base.symbol}</div>
      {calc.total !== null && <div>Total ≈ <b>{formatUnits(calc.total.toString(), quote.decimals)}</b> {quote.symbol} <span className="muted">· biaya taker ≈ {formatUnits((calc.fee ?? 0n).toString(), quote.decimals)} ({m.takerFeeBps / 100}%)</span></div>}
      {type === 'market' && side === 'buy' && <p className="muted">Order market dieksekusi pada harga terbaik yang ada hingga batas harga Anda; sisanya dibatalkan.</p>}
      <div aria-live="polite">{calc.problems.map((p) => <div key={p} className="sell-t">{p}</div>)}</div>
      <Alert>{err}</Alert>
      <Alert kind="ok">{ok}</Alert>
      {!confirming ? (
        <button className={`btn ${side}`} disabled={!calc.complete || busy || halted} onClick={() => setConfirming(true)}>{side === 'buy' ? 'Beli' : 'Jual'} {base.symbol}</button>
      ) : (
        <div className="alert warn col">
          <b>Konfirmasi: {side === 'buy' ? 'BELI' : 'JUAL'} {formatUnits(calc.qty!, base.decimals)} {base.symbol}{needsPrice ? ` @ ${formatUnits(calc.price!, quote.decimals)}` : ' (harga pasar)'}</b>
          <div className="row"><button className={`btn ${side}`} disabled={busy} onClick={() => void submit()}>{busy ? 'Mengirim…' : 'Ya, kirim order'}</button><button className="btn" onClick={() => setConfirming(false)}>Batal</button></div>
        </div>
      )}
    </div>
  );
}
