import { useEffect, useRef, useState } from 'react';
import { createChart } from 'lightweight-charts';
import type { UTCTimestamp } from 'lightweight-charts';
import { useApp } from '../ctx/AppContext.tsx';

const INTERVALS = ['1m', '5m', '15m', '1h', '4h', '1d'] as const;
type Iv = (typeof INTERVALS)[number];
interface Wire { t: number; o: string; h: string; l: string; c: string; v: string; n: number }

// The chart library works in JS numbers. That is fine for DRAWING (IDR prices are < 2^53); money maths elsewhere is BigInt.
const bar = (c: Wire) => ({ time: (c.t / 1000) as UTCTimestamp, open: Number(c.o), high: Number(c.h), low: Number(c.l), close: Number(c.c) });
const volBar = (c: Wire, baseDecimals: number) => ({ time: (c.t / 1000) as UTCTimestamp, value: Number(c.v) / 10 ** baseDecimals, color: Number(c.c) >= Number(c.o) ? '#16c78455' : '#ea394355' });

export function Chart({ market, baseDecimals }: { market: string; baseDecimals: number }) {
  const { api, ws } = useApp();
  const box = useRef<HTMLDivElement>(null);
  const [iv, setIv] = useState<Iv>('15m');
  const [error, setError] = useState('');

  useEffect(() => {
    if (!box.current) return;
    const chart = createChart(box.current, {
      height: 340,
      layout: { background: { color: 'transparent' }, textColor: '#8b95a7' },
      grid: { vertLines: { color: '#1d2433' }, horzLines: { color: '#1d2433' } },
      timeScale: { timeVisible: true, secondsVisible: false, borderColor: '#252d3d' },
      rightPriceScale: { borderColor: '#252d3d' },
    });
    const candles = chart.addCandlestickSeries({ upColor: '#16c784', downColor: '#ea3943', borderVisible: false, wickUpColor: '#16c784', wickDownColor: '#ea3943' });
    const volume = chart.addHistogramSeries({ priceFormat: { type: 'volume' }, priceScaleId: '' });
    volume.priceScale().applyOptions({ scaleMargins: { top: 0.82, bottom: 0 } });

    let alive = true;
    setError('');
    api.get(`/v1/markets/${market}/candles?interval=${iv}&limit=300`, { auth: false }).then(
      (r) => {
        if (!alive) return;
        candles.setData(r.candles.map(bar));
        volume.setData(r.candles.map((c: Wire) => volBar(c, baseDecimals)));
        chart.timeScale().fitContent();
      },
      () => alive && setError('Gagal memuat grafik.'),
    );
    // live: the server sends the latest candle; same open time => replace, newer => append
    const off = ws.subscribe(`candles:${market}:${iv}`, (e) => {
      if (e.type !== 'update') return;
      candles.update(bar(e.data));
      volume.update(volBar(e.data, baseDecimals));
    });
    const ro = new ResizeObserver(() => box.current && chart.applyOptions({ width: box.current.clientWidth }));
    ro.observe(box.current);
    return () => { alive = false; off(); ro.disconnect(); chart.remove(); };
  }, [api, ws, market, iv, baseDecimals]);

  return (
    <div className="card">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h2>{market.replace('_', '/')}</h2>
        <div className="row" role="group" aria-label="Interval">
          {INTERVALS.map((x) => <button key={x} className={`btn small ${x === iv ? 'primary' : ''}`} onClick={() => setIv(x)}>{x}</button>)}
        </div>
      </div>
      {error && <p className="muted">{error}</p>}
      <div ref={box} />
    </div>
  );
}
