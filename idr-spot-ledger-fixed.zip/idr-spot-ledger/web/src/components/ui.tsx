import { useId } from 'react';
import type { InputHTMLAttributes, ReactNode } from 'react';

export function Field({ label, hint, ...p }: { label: string; hint?: string } & InputHTMLAttributes<HTMLInputElement>) {
  const id = useId();
  return (
    <div className="field">
      <label htmlFor={id}>{label}</label>
      <input id={id} className="input" {...p} />
      {hint && <span className="muted">{hint}</span>}
    </div>
  );
}
export const Alert = ({ kind = 'err', children }: { kind?: 'err' | 'ok' | 'warn'; children: ReactNode }) =>
  children ? <div className={`alert ${kind}`} role={kind === 'err' ? 'alert' : 'status'}>{children}</div> : null;

export function Tabs<T extends string>({ value, onChange, items }: { value: T; onChange: (v: T) => void; items: Array<[T, string]> }) {
  return (
    <div className="tabs" role="tablist">
      {items.map(([k, label]) => (
        <button key={k} role="tab" aria-selected={value === k} className={`tab ${value === k ? 'active' : ''}`} onClick={() => onChange(k)}>{label}</button>
      ))}
    </div>
  );
}
export const Loading = ({ error }: { error?: string }) => (error ? <Alert>{error}</Alert> : <p className="muted">Memuat…</p>);
export const fmtTime = (iso: string | number) => new Date(iso).toLocaleString('id-ID', { dateStyle: 'short', timeStyle: 'medium' });
