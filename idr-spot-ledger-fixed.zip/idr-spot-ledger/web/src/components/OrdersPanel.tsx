import { useState } from 'react';
import { useApp } from '../ctx/AppContext.tsx';
import { useAsync, useOpenOrders } from '../hooks.ts';
import { errorText } from '../lib/api.ts';
import { formatUnits } from '../lib/money.ts';
import { Alert, Loading, Tabs, fmtTime } from './ui.tsx';
import type { Asset, Order } from '../types.ts';

interface Props { market: string; base: Asset; quote: Asset }
const STATUS: Record<string, string> = { new: 'Baru', partial: 'Sebagian', filled: 'Terisi', canceled: 'Dibatalkan', rejected: 'Ditolak' };

function OrderRows({ rows, base, quote, onCancel }: { rows: Order[]; base: Asset; quote: Asset; onCancel?: (id: string) => void }) {
  return (
    <table className="table">
      <thead><tr><th>Waktu</th><th>Sisi</th><th>Tipe</th><th className="num">Harga</th><th className="num">Jumlah</th><th className="num">Terisi</th><th>Status</th>{onCancel && <th />}</tr></thead>
      <tbody>
        {rows.map((o) => (
          <tr key={o.id}>
            <td className="muted">{fmtTime(o.createdAt)}</td>
            <td className={o.side === 'buy' ? 'buy-t' : 'sell-t'}>{o.side === 'buy' ? 'Beli' : 'Jual'}</td>
            <td>{o.type}</td>
            <td className="num">{o.type === 'market' && o.side === 'sell' ? 'Market' : formatUnits(o.price, quote.decimals)}</td>
            <td className="num">{formatUnits(o.qty, base.decimals, { maxFrac: 8 })}</td>
            <td className="num">{formatUnits(o.filledQty, base.decimals, { maxFrac: 8 })}</td>
            <td><span className="badge">{STATUS[o.status] ?? o.status}</span></td>
            {onCancel && <td><button className="btn small danger" onClick={() => onCancel(o.id)}>Batalkan</button></td>}
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function History({ market, base, quote }: Props) {
  const { api } = useApp();
  const q = useAsync(() => api.get(`/v1/orders?market=${market}&limit=50`), [api, market]);
  if (!q.data) return <Loading error={q.error} />;
  const rows = (q.data.items as Order[]).filter((o) => o.status !== 'new' && o.status !== 'partial');
  return rows.length ? <OrderRows rows={rows} base={base} quote={quote} /> : <p className="muted">Belum ada riwayat order.</p>;
}

function MyTrades({ market, base, quote }: Props) {
  const { api } = useApp();
  const q = useAsync(() => api.get('/v1/trades/mine?limit=50'), [api]);
  if (!q.data) return <Loading error={q.error} />;
  const rows = (q.data.items as any[]).filter((t) => t.market === market);
  return rows.length ? (
    <table className="table"><thead><tr><th>Waktu</th><th>Sisi</th><th className="num">Harga</th><th className="num">Jumlah</th><th className="num">Biaya</th><th>Peran</th></tr></thead>
      <tbody>{rows.map((t) => (
        <tr key={t.id}><td className="muted">{fmtTime(t.executedAt)}</td><td className={t.side === 'buy' ? 'buy-t' : 'sell-t'}>{t.side === 'buy' ? 'Beli' : 'Jual'}</td>
          <td className="num">{formatUnits(t.price, quote.decimals)}</td><td className="num">{formatUnits(t.qty, base.decimals, { maxFrac: 8 })}</td>
          <td className="num">{formatUnits(t.fee, quote.decimals)}</td><td>{t.role}</td></tr>))}</tbody></table>
  ) : <p className="muted">Belum ada transaksi.</p>;
}

export function OrdersPanel(p: Props) {
  const { api, user } = useApp();
  const [tab, setTab] = useState<'open' | 'history' | 'trades'>('open');
  const [err, setErr] = useState('');
  const open = useOpenOrders(!!user).filter((o) => o.market === p.market);
  if (!user) return null;
  async function cancel(id: string) {
    setErr('');
    try { await api.del(`/v1/orders/${id}`); } catch (e) { setErr(errorText(e)); }
  }
  return (
    <div className="card">
      <Tabs value={tab} onChange={setTab} items={[['open', `Order terbuka (${open.length})`], ['history', 'Riwayat order'], ['trades', 'Transaksi saya']]} />
      <Alert>{err}</Alert>
      {tab === 'open' && (open.length ? <OrderRows rows={open} base={p.base} quote={p.quote} onCancel={(id) => void cancel(id)} /> : <p className="muted">Tidak ada order terbuka.</p>)}
      {tab === 'history' && <History {...p} />}
      {tab === 'trades' && <MyTrades {...p} />}
    </div>
  );
}
