import { useBook, useTrades } from '../hooks.ts';
import { formatUnits } from '../lib/money.ts';
import type { Asset } from '../types.ts';

interface Props { market: string; base: Asset; quote: Asset; onPick: (price: string) => void }

export function OrderBook({ market, base, quote, onPick }: Props) {
  const book = useBook(market, 14);
  const cum = (rows: Array<[string, string]>) => { let c = 0n; return rows.map(([p, q]) => ({ p, q, c: (c += BigInt(q)) })); };
  const asks = cum(book.asks); // best (lowest) first
  const bids = cum(book.bids); // best (highest) first
  const max = [asks.at(-1)?.c ?? 0n, bids.at(-1)?.c ?? 0n].reduce((a, b) => (a > b ? a : b), 1n);
  const spread = asks[0] && bids[0] ? BigInt(asks[0].p) - BigInt(bids[0].p) : null;
  const row = (r: { p: string; q: bigint | string; c: bigint }, color: string, cls: string) => (
    <div className="book-row" key={r.p + cls} onClick={() => onPick(r.p)} role="button" tabIndex={0} onKeyDown={(e) => e.key === 'Enter' && onPick(r.p)}>
      <span className="bar" style={{ width: `${Number((r.c * 100n) / max)}%`, background: color }} />
      <span className={cls}>{formatUnits(r.p, quote.decimals)}</span>
      <span>{formatUnits(String(r.q), base.decimals, { maxFrac: 6 })}</span>
    </div>
  );
  return (
    <div className="card">
      <h2>Order book</h2>
      <div className="row" style={{ justifyContent: 'space-between' }}><h3>Harga ({quote.symbol})</h3><h3>Jumlah ({base.symbol})</h3></div>
      {[...asks].reverse().map((r) => row(r, 'var(--sell)', 'sell-t'))}
      <div className="muted" style={{ textAlign: 'center', padding: '.3rem' }}>{spread === null ? '—' : `Selisih ${formatUnits(spread.toString(), quote.decimals)}`}</div>
      {bids.map((r) => row(r, 'var(--buy)', 'buy-t'))}
      {!asks.length && !bids.length && <p className="muted">Belum ada order.</p>}
    </div>
  );
}

export function RecentTrades({ market, base, quote }: { market: string; base: Asset; quote: Asset }) {
  const rows = useTrades(market);
  return (
    <div className="card">
      <h2>Transaksi terakhir</h2>
      <table className="table"><thead><tr><th>Waktu</th><th className="num">Harga</th><th className="num">Jumlah</th></tr></thead>
        <tbody>
          {rows.slice(0, 20).map((t) => (
            <tr key={t.seq}>
              <td className="muted">{new Date(t.time).toLocaleTimeString('id-ID')}</td>
              <td className={`num ${t.takerSide === 'buy' ? 'buy-t' : 'sell-t'}`}>{formatUnits(t.price, quote.decimals)}</td>
              <td className="num">{formatUnits(t.qty, base.decimals, { maxFrac: 6 })}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {!rows.length && <p className="muted">Belum ada transaksi.</p>}
    </div>
  );
}
