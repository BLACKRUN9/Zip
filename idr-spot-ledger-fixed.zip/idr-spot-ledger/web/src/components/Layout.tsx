import { NavLink, Navigate, Outlet, useLocation } from 'react-router-dom';
import { useApp } from '../ctx/AppContext.tsx';

export function Layout() {
  const { user, wsStatus, logout } = useApp();
  const cls = ({ isActive }: { isActive: boolean }) => (isActive ? 'active' : '');
  return (
    <>
      <nav className="nav" aria-label="Navigasi utama">
        <span className="brand">Bursa IDR</span>
        <NavLink to="/trade" className={cls}>Trading</NavLink>
        {user && <NavLink to="/wallet" className={cls}>Dompet</NavLink>}
        {user && <NavLink to="/kyc" className={cls}>Verifikasi</NavLink>}
        {user && <NavLink to="/security" className={cls}>Keamanan</NavLink>}
        {user?.role === 'admin' && <NavLink to="/admin" className={cls}>Admin</NavLink>}
        <span className="sp" />
        <span title={`Koneksi real-time: ${wsStatus}`}><span className={`dot ${wsStatus}`} />{wsStatus === 'open' ? 'Live' : wsStatus === 'idle' ? '' : 'Menyambung…'}</span>
        {user ? (<><span className="muted">{user.email}</span><button className="btn small" onClick={() => void logout()}>Keluar</button></>) : (<><NavLink to="/login">Masuk</NavLink><NavLink to="/register">Daftar</NavLink></>)}
      </nav>
      <main className="page"><Outlet /></main>
    </>
  );
}

/** UI convenience only. The API enforces every permission again on the server. */
export function RequireAuth({ admin = false }: { admin?: boolean }) {
  const { user, ready } = useApp();
  const loc = useLocation();
  if (!ready) return <p className="muted page">Memuat…</p>;
  if (!user) return <Navigate to="/login" state={{ from: loc.pathname }} replace />;
  if (admin && user.role !== 'admin') return <Navigate to="/trade" replace />;
  return <Outlet />;
}
