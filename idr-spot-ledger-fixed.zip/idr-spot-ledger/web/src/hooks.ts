import { useCallback, useEffect, useRef, useState } from 'react';
import { BookSync } from '@shared/bookDelta.ts';
import type { BookView } from '@shared/bookDelta.ts';
import { useApp } from './ctx/AppContext.tsx';
import type { WsEvent } from './lib/ws.ts';
import { errorText } from './lib/api.ts';
import type { Balance, Order, PublicTrade, Ticker } from './types.ts';

/** Subscribe to a socket channel for the lifetime of the component. Pass null to disable. */
export function useChannel(channel: string | null, onEvent: (e: WsEvent) => void): void {
  const { ws } = useApp();
  const ref = useRef(onEvent);
  ref.current = onEvent;
  useEffect(() => {
    if (!channel) return;
    return ws.subscribe(channel, (e) => ref.current(e));
  }, [ws, channel]);
}

/** Order book: snapshot + sequenced deltas. A sequence gap triggers a resync (fresh snapshot). */
export function useBook(market: string, depth = 20): BookView {
  const { ws } = useApp();
  const sync = useRef(new BookSync(50));
  const [view, setView] = useState<BookView>({ bids: [], asks: [] });
  const channel = `book:${market}`;
  useEffect(() => { sync.current = new BookSync(50); setView({ bids: [], asks: [] }); }, [market]);
  useChannel(channel, (e) => {
    if (e.type === 'snapshot') sync.current.snapshot(e.data, e.seq ?? 0);
    else if (sync.current.update(e.data, e.seq ?? -1) === 'gap') { ws.resync(channel); return; }
    const v = sync.current.view;
    setView({ bids: v.bids.slice(0, depth), asks: v.asks.slice(0, depth) });
  });
  return view;
}

export function useTicker(market: string | ''): Ticker | null {
  const [t, setT] = useState<Ticker | null>(null);
  useEffect(() => setT(null), [market]);
  useChannel(market ? `ticker:${market}` : null, (e) => setT(e.data));
  return t;
}

export function useTrades(market: string): PublicTrade[] {
  const [rows, setRows] = useState<PublicTrade[]>([]);
  useEffect(() => setRows([]), [market]);
  useChannel(`trades:${market}`, (e) => {
    if (e.type === 'snapshot') setRows(e.data);
    else setRows((prev) => (prev.some((r) => r.seq === e.data.seq) ? prev : [e.data, ...prev].slice(0, 50)));
  });
  return rows;
}

/** Private: live balances. Empty (and inactive) while logged out. */
export function useBalances(enabled: boolean): Record<string, Balance> {
  const [map, setMap] = useState<Record<string, Balance>>({});
  useEffect(() => { if (!enabled) setMap({}); }, [enabled]);
  useChannel(enabled ? 'balances' : null, (e) => setMap(Object.fromEntries((e.data as Balance[]).map((b) => [b.asset, b]))));
  return map;
}

/** Private: open orders, kept live (snapshot = open orders; each update replaces one order by id). */
export function useOpenOrders(enabled: boolean): Order[] {
  const [map, setMap] = useState<Record<string, Order>>({});
  useEffect(() => { if (!enabled) setMap({}); }, [enabled]);
  useChannel(enabled ? 'orders' : null, (e) => {
    if (e.type === 'snapshot') { setMap(Object.fromEntries((e.data as Order[]).map((o) => [o.id, o]))); return; }
    const o = e.data as Order;
    setMap((m) => {
      const next = { ...m };
      if (o.status === 'new' || o.status === 'partial') next[o.id] = o; else delete next[o.id];
      return next;
    });
  });
  return Object.values(map).sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
}

/** One-shot async call with loading / error state and a manual reload. */
export function useAsync<T>(fn: () => Promise<T>, deps: unknown[]) {
  const [state, setState] = useState<{ data?: T; error?: string; loading: boolean }>({ loading: true });
  const run = useCallback(() => {
    let alive = true;
    setState((s) => ({ ...s, loading: true, error: undefined }));
    fn().then((data) => alive && setState({ data, loading: false }), (e) => alive && setState({ error: errorText(e), loading: false }));
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  useEffect(() => run(), [run]);
  return { ...state, reload: run };
}
