import { useState } from 'react';
import type { FormEvent } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useApp } from '../ctx/AppContext.tsx';
import { ApiError, errorText } from '../lib/api.ts';
import { Alert, Field } from '../components/ui.tsx';

export function Login() {
  const { login } = useApp();
  const nav = useNavigate();
  const from = (useLocation().state as { from?: string } | null)?.from ?? '/trade';
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [code, setCode] = useState('');
  const [needCode, setNeedCode] = useState(false);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true); setErr('');
    try { await login(email, password, code || undefined); nav(from, { replace: true }); }
    catch (x) {
      if (x instanceof ApiError && x.code === 'TWOFA_REQUIRED') { setNeedCode(true); setErr('Masukkan kode 6 digit dari aplikasi autentikator (atau kode pemulihan).'); }
      else setErr(errorText(x));
    } finally { setBusy(false); }
  }
  return (
    <form className="card narrow col" onSubmit={submit}>
      <h1>Masuk</h1>
      <Alert>{err}</Alert>
      <Field label="Email" type="email" autoComplete="username" required value={email} onChange={(e) => setEmail(e.target.value)} />
      <Field label="Kata sandi" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} />
      {needCode && <Field label="Kode 2FA" inputMode="numeric" autoComplete="one-time-code" autoFocus value={code} onChange={(e) => setCode(e.target.value.trim())} />}
      <button className="btn primary" disabled={busy}>{busy ? 'Memproses…' : 'Masuk'}</button>
      <div className="row"><Link to="/register">Buat akun</Link><Link to="/forgot">Lupa kata sandi?</Link></div>
    </form>
  );
}

export function Register() {
  const { api, login } = useApp();
  const nav = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [again, setAgain] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  async function submit(e: FormEvent) {
    e.preventDefault();
    if (password !== again) { setErr('Konfirmasi kata sandi tidak sama.'); return; }
    setBusy(true); setErr('');
    try {
      await api.post('/v1/auth/register', { email, password }, { auth: false });
      await login(email, password);
      nav('/kyc', { replace: true });
    } catch (x) { setErr(x instanceof ApiError && x.code === 'VALIDATION' ? x.message : errorText(x)); }
    finally { setBusy(false); }
  }
  return (
    <form className="card narrow col" onSubmit={submit}>
      <h1>Daftar</h1>
      <Alert>{err}</Alert>
      <Field label="Email" type="email" autoComplete="username" required value={email} onChange={(e) => setEmail(e.target.value)} />
      <Field label="Kata sandi" type="password" autoComplete="new-password" required minLength={10} hint="Minimal 10 karakter. Kalimat sandi panjang lebih aman daripada simbol acak." value={password} onChange={(e) => setPassword(e.target.value)} />
      <Field label="Ulangi kata sandi" type="password" autoComplete="new-password" required value={again} onChange={(e) => setAgain(e.target.value)} />
      <button className="btn primary" disabled={busy}>{busy ? 'Memproses…' : 'Daftar'}</button>
      <p className="muted">Setelah mendaftar, selesaikan verifikasi identitas (KYC) dan aktifkan 2FA sebelum bisa trading dan menarik dana.</p>
    </form>
  );
}

export function Forgot() {
  const { api } = useApp();
  const [email, setEmail] = useState('');
  const [done, setDone] = useState(false);
  const [err, setErr] = useState('');
  async function submit(e: FormEvent) {
    e.preventDefault(); setErr('');
    try { await api.post('/v1/auth/password/forgot', { email }, { auth: false }); setDone(true); } catch (x) { setErr(errorText(x)); }
  }
  return (
    <form className="card narrow col" onSubmit={submit}>
      <h1>Lupa kata sandi</h1>
      <Alert>{err}</Alert>
      {done ? <Alert kind="ok">Jika email terdaftar, tautan reset sudah dikirim. Tautan berlaku 30 menit.</Alert> : (<>
        <Field label="Email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
        <button className="btn primary">Kirim tautan reset</button></>)}
      <Link to="/login">Kembali</Link>
    </form>
  );
}

/** Reset link format: https://app/reset#token=XXXX. The token is in the URL FRAGMENT so it is never sent to servers or logged. */
export function Reset() {
  const { api } = useApp();
  const nav = useNavigate();
  const token = new URLSearchParams(location.hash.slice(1)).get('token') ?? '';
  const [password, setPassword] = useState('');
  const [err, setErr] = useState('');
  const [ok, setOk] = useState(false);
  async function submit(e: FormEvent) {
    e.preventDefault(); setErr('');
    try { await api.post('/v1/auth/password/reset', { token, password }, { auth: false }); setOk(true); history.replaceState(null, '', '/reset'); setTimeout(() => nav('/login'), 2500); }
    catch (x) { setErr(x instanceof ApiError && x.code === 'VALIDATION' ? x.message : x instanceof ApiError && x.code === 'INVALID_TOKEN' ? 'Tautan tidak valid atau sudah kedaluwarsa.' : errorText(x)); }
  }
  return (
    <form className="card narrow col" onSubmit={submit}>
      <h1>Atur kata sandi baru</h1>
      <Alert>{err}</Alert>
      {ok ? <Alert kind="ok">Kata sandi diubah. Semua sesi lama dikeluarkan. Penarikan dana dikunci 24 jam demi keamanan.</Alert> : (<>
        {!token && <Alert>Tautan reset tidak lengkap.</Alert>}
        <Field label="Kata sandi baru" type="password" autoComplete="new-password" required minLength={10} value={password} onChange={(e) => setPassword(e.target.value)} />
        <button className="btn primary" disabled={!token}>Simpan</button></>)}
    </form>
  );
}
