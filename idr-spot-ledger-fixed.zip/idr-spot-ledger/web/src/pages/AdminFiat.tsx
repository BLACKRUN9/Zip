import { useState } from 'react';
import { useApp } from '../ctx/AppContext.tsx';
import { useAsync } from '../hooks.ts';
import { errorText } from '../lib/api.ts';
import { formatUnits } from '../lib/money.ts';
import { Alert, Field, Loading, fmtTime } from '../components/ui.tsx';
import { useSim } from './IdrWallet.tsx';

export function AdminFiat() {
  const { api } = useApp();
  const sim = useSim();
  const [status, setStatus] = useState('pending');
  const list = useAsync(() => api.get(`/v1/admin/fiat/withdrawals?status=${status}`), [api, status]);
  const review = useAsync(() => api.get('/v1/admin/fiat/deposits/review'), [api]);
  const [reasons, setReasons] = useState<Record<string, string>>({});
  const [err, setErr] = useState(''); const [msg, setMsg] = useState('');
  const [chain, setChain] = useState('ETH'); const [depth, setDepth] = useState('1');

  async function run(fn: () => Promise<unknown>, done?: string) {
    setErr(''); setMsg('');
    try { await fn(); if (done) setMsg(done); list.reload(); review.reload(); } catch (e) { setErr(errorText(e)); }
  }
  return (
    <>
      <div className="card col"><h2>Penarikan IDR</h2><Alert>{err}</Alert><Alert kind="ok">{msg}</Alert>
        <select aria-label="Status" style={{ width: 'auto' }} value={status} onChange={(e) => setStatus(e.target.value)}>{['pending', 'approved', 'processing', 'completed', 'failed', 'rejected'].map((s) => <option key={s}>{s}</option>)}</select>
        {list.data ? (list.data.items.length ? (
          <table className="table"><thead><tr><th>Waktu</th><th>User</th><th className="num">Jumlah</th><th>Rekening tujuan</th><th /></tr></thead>
            <tbody>{list.data.items.map((w: any) => (
              <tr key={w.id}><td className="muted">{fmtTime(w.createdAt)}</td><td className="mono">{w.userId.slice(-8)}</td><td className="num">Rp {formatUnits(w.amount, 0)}</td><td>{w.bank} •••{w.last4} a.n. {w.holder}</td>
                <td>
                  {w.status === 'pending' && (<div className="row"><button className="btn small buy" onClick={() => void run(() => api.post(`/v1/admin/fiat/withdrawals/${w.id}/approve`), 'Disetujui dan dikirim ke gateway.')}>Setujui</button>
                    <input className="input" style={{ width: 140 }} placeholder="alasan tolak" value={reasons[w.id] ?? ''} onChange={(e) => setReasons({ ...reasons, [w.id]: e.target.value })} />
                    <button className="btn small danger" disabled={!reasons[w.id]?.trim()} onClick={() => void run(() => api.post(`/v1/admin/fiat/withdrawals/${w.id}/reject`, { reason: reasons[w.id] }), 'Ditolak, dana dikembalikan.')}>Tolak</button></div>)}
                  {sim?.bank && w.status === 'processing' && (<div className="row"><span className="badge">simulator</span>
                    <button className="btn small buy" onClick={() => void run(() => api.post(`/v1/sim/payout/${w.reference}`, { outcome: 'completed' }), 'Bank menyelesaikan payout.')}>Bank sukses</button>
                    <button className="btn small danger" onClick={() => void run(() => api.post(`/v1/sim/payout/${w.reference}`, { outcome: 'failed', reason: 'simulasi: rekening ditolak' }), 'Bank menolak payout; dana dikembalikan.')}>Bank gagal</button></div>)}
                </td></tr>))}</tbody></table>
        ) : <p className="muted">Tidak ada data.</p>) : <Loading error={list.error} />}
      </div>

      <div className="card col"><h2>Deposit IDR perlu tinjauan</h2>
        <p className="muted">Nama pengirim tidak cocok dengan nama KYC. Bandingkan, lalu lepaskan hanya jika yakin pemilik rekening sama.</p>
        {review.data ? (review.data.items.length ? (
          <table className="table"><thead><tr><th>Waktu</th><th>User</th><th>Pengirim</th><th className="num">Jumlah</th><th /></tr></thead>
            <tbody>{review.data.items.map((d: any) => <tr key={d.reference}><td className="muted">{fmtTime(d.createdAt)}</td><td className="mono">{d.userId.slice(-8)}</td><td>{d.senderName}</td><td className="num">Rp {formatUnits(d.amount, 0)}</td>
              <td><button className="btn small" onClick={() => void run(() => api.post(`/v1/admin/fiat/deposits/${d.reference}/credit`), 'Deposit dikreditkan.')}>Kreditkan</button></td></tr>)}</tbody></table>
        ) : <p className="muted">Tidak ada.</p>) : <Loading error={review.error} />}
      </div>

      {sim?.chains?.length ? (
        <div className="card col"><h2>Alat testnet simulasi</h2>
          <div className="row">
            <select aria-label="Chain" style={{ width: 'auto' }} value={chain} onChange={(e) => setChain(e.target.value)}>{sim.chains.map((c) => <option key={c}>{c}</option>)}</select>
            <button className="btn" onClick={() => void run(() => api.post('/v1/sim/chain/mine', { chain, blocks: 1 }), 'Satu blok ditambang.')}>Tambang 1 blok</button>
            <Field label="Kedalaman reorg" value={depth} onChange={(e) => setDepth(e.target.value.replace(/\D/g, ''))} style={{ width: 80 }} />
            <button className="btn danger" onClick={() => void run(() => api.post('/v1/sim/chain/reorg', { chain, depth: Number(depth) || 1 }), 'Reorg: blok terakhir dibatalkan, transaksi kembali ke mempool.')}>Reorg</button>
          </div>
          <p className="muted">Reorg menghapus blok terakhir. Deposit yang belum cukup konfirmasi akan mundur; yang sudah dikreditkan dan hilang dari chain akan dibatalkan otomatis.</p>
        </div>
      ) : null}
    </>
  );
}
