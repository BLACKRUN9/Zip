import { useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '../ctx/AppContext.tsx';
import { useAsync, useBalances } from '../hooks.ts';
import { ApiError, errorText } from '../lib/api.ts';
import { InputError, formatUnits, parseUnits } from '../lib/money.ts';
import { Alert, Field, Loading, fmtTime } from '../components/ui.tsx';
import { IdrDeposit, IdrWithdraw, useSim } from './IdrWallet.tsx';

const WSTATUS: Record<string, string> = { pending: 'Menunggu persetujuan', approved: 'Disetujui', broadcast: 'Dikirim ke jaringan', completed: 'Selesai', rejected: 'Ditolak' };

function Deposit() {
  const { api, assets } = useApp();
  const crypto = Object.values(assets).filter((a) => a.type === 'crypto');
  const [sym, setSym] = useState(crypto[0]?.symbol ?? '');
  const [addr, setAddr] = useState<{ address: string; memo?: string } | null>(null);
  const [err, setErr] = useState('');
  useEffect(() => { setAddr(null); setErr(''); }, [sym]);
  const a = assets[sym];
  async function show() {
    setErr('');
    try { setAddr(await api.get(`/v1/deposits/address/${sym}`)); }
    catch (e) { setErr(e instanceof ApiError && e.code === 'NOT_FOUND' ? 'Alamat deposit belum tersedia.' : errorText(e)); }
  }
  const hist = useAsync(() => api.get('/v1/deposits?limit=20'), [api]);
  const sim = useSim();
  const [faucetText, setFaucetText] = useState('');
  const [faucetMsg, setFaucetMsg] = useState('');
  async function faucet() {
    setErr(''); setFaucetMsg('');
    try {
      await api.post('/v1/sim/faucet', { asset: sym, amount: parseUnits(faucetText, a!.decimals) });
      setFaucetMsg('Token testnet dikirim ke alamat deposit Anda. Setelah blok ditambang dan terkonfirmasi, saldo masuk otomatis.');
      hist.reload();
    } catch (e) { setErr(e instanceof InputError ? e.message : errorText(e)); }
  }
  return (
    <div className="card col">
      <h2>Deposit kripto</h2>
      <div className="row">
        <select aria-label="Aset" style={{ width: 'auto' }} value={sym} onChange={(e) => setSym(e.target.value)}>{crypto.map((c) => <option key={c.symbol} value={c.symbol}>{c.symbol} · {c.name}</option>)}</select>
        <button className="btn" onClick={() => void show()}>Tampilkan alamat deposit</button>
      </div>
      <Alert>{err}</Alert>
      {addr && a && (
        <div className="secret"><div className="mono">{addr.address}</div>{addr.memo && <div>Memo: <span className="mono">{addr.memo}</span></div>}
          <p className="muted">Kirim hanya <b>{a.symbol}</b> lewat jaringan <b>{a.chain}</b>. Aset atau jaringan lain tidak dapat dipulihkan. Minimum {formatUnits(a.minDeposit, a.decimals)} {a.symbol}.</p></div>
      )}
      {sim?.chains?.includes(a?.chain ?? '') && addr && (
        <div className="alert warn col">
          <b>Faucet testnet simulasi (mode pengembangan)</b>
          <Field label={`Jumlah ${sym} untuk dicetak`} inputMode="decimal" value={faucetText} onChange={(e) => setFaucetText(e.target.value)} />
          <button className="btn primary" disabled={!faucetText} onClick={() => void faucet()}>Minta token testnet</button>
          <Alert kind="ok">{faucetMsg}</Alert>
        </div>
      )}
      <h3>Riwayat deposit</h3>
      {hist.data ? (hist.data.items.length ? (
        <table className="table"><thead><tr><th>Waktu</th><th>Aset</th><th className="num">Jumlah</th><th>Konfirmasi</th><th>Status</th></tr></thead>
          <tbody>{hist.data.items.map((d: any) => <tr key={d.id}><td className="muted">{fmtTime(d.createdAt)}</td><td>{d.asset}</td><td className="num">{formatUnits(d.amount, assets[d.asset]?.decimals ?? 0, { maxFrac: 8 })}</td><td>{d.confirmations}</td><td><span className="badge">{d.status}</span></td></tr>)}</tbody></table>
      ) : <p className="muted">Belum ada deposit.</p>) : <Loading error={hist.error} />}
    </div>
  );
}

function Withdraw({ onDone }: { onDone: () => void }) {
  const { api, assets, user } = useApp();
  const crypto = Object.values(assets).filter((a) => a.type === 'crypto');
  const balances = useBalances(true);
  const [sym, setSym] = useState(crypto[0]?.symbol ?? '');
  const [address, setAddress] = useState('');
  const [memo, setMemo] = useState('');
  const [amountText, setAmountText] = useState('');
  const [totp, setTotp] = useState('');
  const [confirming, setConfirming] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [ok, setOk] = useState('');
  const key = useRef(api.newKey());
  useEffect(() => { key.current = api.newKey(); setConfirming(false); }, [api, sym, address, memo, amountText]); // same key only while the request is unchanged
  const a = assets[sym];
  const calc = useMemo(() => {
    if (!a) return null;
    try {
      const amount = parseUnits(amountText, a.decimals);
      const total = BigInt(amount) + BigInt(a.withdrawFee);
      const problems: string[] = [];
      if (BigInt(amount) < BigInt(a.minWithdraw)) problems.push(`Minimum penarikan ${formatUnits(a.minWithdraw, a.decimals)} ${a.symbol}`);
      if (total > BigInt(balances[a.symbol]?.available ?? '0')) problems.push('Saldo tidak cukup (jumlah + biaya)');
      return { amount, total, problems };
    } catch (e) { return { amount: '', total: 0n, problems: amountText ? [e instanceof InputError ? e.message : 'tidak valid'] : [] }; }
  }, [a, amountText, balances]);
  if (!user?.twoFAEnabled) return <div className="card"><h2>Tarik dana</h2><Alert kind="warn">Aktifkan 2FA di menu <Link to="/security">Keamanan</Link> untuk menarik dana.</Alert></div>;
  if (user.kycLevel < 1) return <div className="card"><h2>Tarik dana</h2><Alert kind="warn">Selesaikan <Link to="/kyc">verifikasi identitas</Link> untuk menarik dana.</Alert></div>;
  const ready = !!a && !!calc?.amount && calc.problems.length === 0 && address.trim().length >= 10 && /^\d{6}$/.test(totp);

  async function submit() {
    setBusy(true); setErr(''); setOk('');
    try {
      await api.post('/v1/withdrawals', { asset: sym, address: address.trim(), ...(memo ? { memo } : {}), amount: calc!.amount, totp }, { idempotencyKey: key.current });
      setOk('Permintaan penarikan dikirim dan menunggu persetujuan.'); setAmountText(''); setTotp(''); setConfirming(false); onDone();
    } catch (e) { setErr(errorText(e)); setConfirming(false); }
    finally { setBusy(false); }
  }
  return (
    <div className="card col">
      <h2>Tarik dana</h2>
      <select aria-label="Aset" value={sym} onChange={(e) => setSym(e.target.value)}>{crypto.map((c) => <option key={c.symbol} value={c.symbol}>{c.symbol}</option>)}</select>
      <Field label={`Alamat tujuan (${a?.chain ?? ''})`} value={address} onChange={(e) => setAddress(e.target.value)} autoComplete="off" spellCheck={false} />
      <Field label="Memo / tag (jika ada)" value={memo} onChange={(e) => setMemo(e.target.value)} />
      <Field label={`Jumlah (${sym})`} inputMode="decimal" value={amountText} onChange={(e) => setAmountText(e.target.value)} />
      {a && <div className="muted">Tersedia {formatUnits(balances[sym]?.available ?? '0', a.decimals, { maxFrac: 8 })} · biaya {formatUnits(a.withdrawFee, a.decimals)} {sym} · total dipotong {calc?.amount ? formatUnits(calc.total.toString(), a.decimals) : '—'} {sym}</div>}
      {calc?.problems.map((p) => <div key={p} className="sell-t">{p}</div>)}
      <Field label="Kode 2FA (6 digit)" inputMode="numeric" autoComplete="one-time-code" maxLength={6} value={totp} onChange={(e) => setTotp(e.target.value.replace(/\D/g, ''))} />
      <Alert>{err}</Alert><Alert kind="ok">{ok}</Alert>
      {!confirming ? <button className="btn primary" disabled={!ready || busy} onClick={() => setConfirming(true)}>Tarik</button> : (
        <div className="alert warn col">
          <b>Periksa dengan teliti. Transaksi blockchain tidak bisa dibatalkan.</b>
          <div>Kirim <b>{formatUnits(calc!.amount, a!.decimals)} {sym}</b> ke:</div><div className="mono">{address.trim()}</div>
          <div className="row"><button className="btn primary" disabled={busy} onClick={() => void submit()}>{busy ? 'Mengirim…' : 'Ya, tarik dana'}</button><button className="btn" onClick={() => setConfirming(false)}>Periksa lagi</button></div>
        </div>
      )}
      <p className="muted">Penarikan ditinjau tim kami. Setelah mengganti kata sandi atau 2FA, penarikan dikunci 24 jam.</p>
    </div>
  );
}

export function Wallet() {
  const { api, assets } = useApp();
  const balances = useBalances(true);
  const list = useAsync(() => api.get('/v1/withdrawals?limit=30'), [api]);
  const rows = Object.values(assets).sort((a, b) => a.symbol.localeCompare(b.symbol));
  return (
    <>
      <div className="card"><h2>Saldo</h2>
        <table className="table"><thead><tr><th>Aset</th><th className="num">Tersedia</th><th className="num">Terkunci</th></tr></thead>
          <tbody>{rows.map((a) => <tr key={a.symbol}><td><b>{a.symbol}</b> <span className="muted">{a.name}</span></td>
            <td className="num">{formatUnits(balances[a.symbol]?.available ?? '0', a.decimals, { maxFrac: 8 })}</td>
            <td className="num muted">{formatUnits(balances[a.symbol]?.locked ?? '0', a.decimals, { maxFrac: 8 })}</td></tr>)}</tbody></table></div>
      <div className="row" style={{ alignItems: 'flex-start' }}>
        <div style={{ flex: '1 1 420px' }}><IdrDeposit /><Deposit /></div>
        <div style={{ flex: '1 1 420px' }}>
          <IdrWithdraw />
          <Withdraw onDone={list.reload} />
          <div className="card"><h2>Riwayat penarikan</h2>
            {list.data ? (list.data.items.length ? (
              <table className="table"><thead><tr><th>Waktu</th><th>Aset</th><th className="num">Jumlah</th><th>Status</th></tr></thead>
                <tbody>{list.data.items.map((w: any) => <tr key={w.id}><td className="muted">{fmtTime(w.createdAt)}</td><td>{w.asset}</td><td className="num">{formatUnits(w.amount, assets[w.asset]?.decimals ?? 0, { maxFrac: 8 })}</td><td><span className="badge">{WSTATUS[w.status] ?? w.status}</span></td></tr>)}</tbody></table>
            ) : <p className="muted">Belum ada penarikan.</p>) : <Loading error={list.error} />}
          </div>
        </div>
      </div>
    </>
  );
}
