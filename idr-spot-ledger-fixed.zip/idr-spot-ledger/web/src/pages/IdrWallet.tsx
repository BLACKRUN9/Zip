import { useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '../ctx/AppContext.tsx';
import { useAsync, useBalances } from '../hooks.ts';
import { errorText } from '../lib/api.ts';
import { InputError, formatUnits, parseUnits } from '../lib/money.ts';
import { Alert, Field, Loading, fmtTime } from '../components/ui.tsx';

const BANKS = ['BCA', 'MANDIRI', 'BNI', 'BRI'];
const STATUS: Record<string, string> = { pending: 'Menunggu persetujuan', approved: 'Disetujui', processing: 'Diproses bank', completed: 'Selesai', failed: 'Gagal (dana dikembalikan)', rejected: 'Ditolak', credited: 'Masuk', manual_review: 'Ditinjau petugas' };

/** Is the development simulator switched on? (the endpoint does not exist in production) */
export function useSim(): { enabled: boolean; bank: boolean; chains: string[] } | null {
  const { api } = useApp();
  const q = useAsync(() => api.get('/v1/sim/status', { auth: false }).catch(() => null), [api]);
  return (q.data as any) ?? null;
}

export function IdrDeposit() {
  const { api, user } = useApp();
  const sim = useSim();
  const [bank, setBank] = useState('BCA');
  const [va, setVa] = useState<{ vaNumber: string; name: string; bank: string } | null>(null);
  const [err, setErr] = useState('');
  const [ok, setOk] = useState('');
  const [amountText, setAmountText] = useState('250.000');
  const [sender, setSender] = useState('');
  const [dup, setDup] = useState(false);
  const hist = useAsync(() => api.get('/v1/fiat/transactions'), [api]);
  useEffect(() => { setVa(null); setErr(''); }, [bank]);
  useEffect(() => { if (va && !sender) setSender(va.name); }, [va, sender]);

  if (user && user.kycLevel < 1) return <div className="card"><h2>Deposit IDR</h2><Alert kind="warn">Selesaikan <Link to="/kyc">verifikasi identitas</Link> untuk mendapat nomor virtual account.</Alert></div>;
  async function show() { setErr(''); try { setVa(await api.get(`/v1/fiat/deposit-va?bank=${bank}`)); } catch (e) { setErr(errorText(e)); } }
  async function simulate() {
    setErr(''); setOk('');
    try {
      const amount = parseUnits(amountText, 0);
      await api.post('/v1/sim/bank/transfer', { bank, amount, senderName: sender || va?.name || 'TEST', duplicate: dup });
      setOk('Transfer simulasi terkirim. Saldo bertambah bila nama pengirim cocok dengan nama KYC; jika beda, masuk antrean tinjauan.');
      hist.reload();
    } catch (e) { setErr(e instanceof InputError ? e.message : errorText(e)); }
  }
  return (
    <div className="card col">
      <h2>Deposit IDR</h2>
      <div className="row">
        <select aria-label="Bank" style={{ width: 'auto' }} value={bank} onChange={(e) => setBank(e.target.value)}>{BANKS.map((b) => <option key={b}>{b}</option>)}</select>
        <button className="btn" onClick={() => void show()}>Tampilkan nomor virtual account</button>
      </div>
      <Alert>{err}</Alert>
      {va && (
        <div className="secret">
          <div>Bank <b>{va.bank}</b> · atas nama <b>{va.name}</b></div>
          <div className="mono" style={{ fontSize: '1.2rem' }}>{va.vaNumber}</div>
          <p className="muted">Transfer hanya dari rekening atas nama Anda sendiri. Transfer dari nama lain ditahan untuk ditinjau. Minimum Rp 10.000.</p>
        </div>
      )}
      {sim?.bank && va && (
        <div className="alert warn col">
          <b>Simulator bank (mode pengembangan)</b>
          <Field label="Jumlah (Rp)" inputMode="numeric" value={amountText} onChange={(e) => setAmountText(e.target.value)} />
          <Field label="Nama pengirim" value={sender} onChange={(e) => setSender(e.target.value)} hint="Coba nama berbeda untuk melihat antrean tinjauan." />
          <label className="row"><input type="checkbox" checked={dup} onChange={(e) => setDup(e.target.checked)} /> Kirim webhook dua kali (uji idempotensi)</label>
          <button className="btn primary" onClick={() => void simulate()}>Simulasikan transfer ke VA</button>
          <Alert kind="ok">{ok}</Alert>
        </div>
      )}
      <h3>Riwayat IDR</h3>
      {hist.data ? <FiatHistory rows={hist.data.items} /> : <Loading error={hist.error} />}
    </div>
  );
}

function FiatHistory({ rows }: { rows: any[] }) {
  return rows.length ? (
    <table className="table"><thead><tr><th>Waktu</th><th>Jenis</th><th className="num">Jumlah</th><th>Status</th></tr></thead>
      <tbody>{rows.map((f) => <tr key={f.id}><td className="muted">{fmtTime(f.createdAt)}</td><td>{f.type === 'deposit' ? 'Deposit' : `Tarik → ${f.bank ?? ''} •••${f.last4 ?? ''}`}</td>
        <td className="num">{formatUnits(f.amount, 0)}</td><td><span className="badge">{STATUS[f.status] ?? f.status}</span>{f.reason ? <span className="muted"> {f.reason}</span> : null}</td></tr>)}</tbody></table>
  ) : <p className="muted">Belum ada transaksi IDR.</p>;
}

export function IdrWithdraw() {
  const { api, user, assets } = useApp();
  const idr = assets.IDR;
  const balances = useBalances(true);
  const acct = useAsync(() => api.get('/v1/fiat/bank-account'), [api]);
  const hist = useAsync(() => api.get('/v1/fiat/transactions'), [api]);
  const [edit, setEdit] = useState(false);
  const [bank, setBank] = useState('BCA'); const [number, setNumber] = useState(''); const [holder, setHolder] = useState(''); const [totpA, setTotpA] = useState('');
  const [amountText, setAmountText] = useState(''); const [totp, setTotp] = useState('');
  const [confirming, setConfirming] = useState(false); const [busy, setBusy] = useState(false);
  const [err, setErr] = useState(''); const [ok, setOk] = useState('');
  const key = useRef(api.newKey());
  useEffect(() => { key.current = api.newKey(); setConfirming(false); }, [api, amountText]); // same key only while the request is unchanged

  const calc = useMemo(() => {
    if (!idr) return null;
    try {
      const amount = parseUnits(amountText, 0);
      const total = BigInt(amount) + BigInt(idr.withdrawFee);
      const problems: string[] = [];
      if (BigInt(amount) < BigInt(idr.minWithdraw)) problems.push(`Minimum penarikan Rp ${formatUnits(idr.minWithdraw, 0)}`);
      if (total > BigInt(balances.IDR?.available ?? '0')) problems.push('Saldo tidak cukup (jumlah + biaya)');
      return { amount, total, problems };
    } catch (e) { return { amount: '', total: 0n, problems: amountText ? [e instanceof InputError ? e.message : 'tidak valid'] : [] }; }
  }, [idr, amountText, balances]);

  if (!user?.twoFAEnabled) return <div className="card"><h2>Tarik IDR</h2><Alert kind="warn">Aktifkan 2FA di menu <Link to="/security">Keamanan</Link> untuk menarik dana.</Alert></div>;
  if (user.kycLevel < 1) return <div className="card"><h2>Tarik IDR</h2><Alert kind="warn">Selesaikan <Link to="/kyc">verifikasi identitas</Link> dulu.</Alert></div>;
  const account = acct.data?.account;

  async function saveAccount() {
    setErr(''); setOk('');
    try { await api.post('/v1/fiat/bank-account', { bank, accountNumber: number, holderName: holder, totp: totpA }); setEdit(false); setNumber(''); setTotpA(''); acct.reload(); setOk('Rekening disimpan. Jika Anda mengganti rekening, penarikan dikunci 24 jam.'); }
    catch (e) { setErr(errorText(e)); }
  }
  async function submit() {
    setBusy(true); setErr(''); setOk('');
    try { await api.post('/v1/fiat/withdrawals', { amount: calc!.amount, totp }, { idempotencyKey: key.current }); setOk('Permintaan penarikan dikirim dan menunggu persetujuan.'); setAmountText(''); setTotp(''); setConfirming(false); hist.reload(); }
    catch (e) { setErr(errorText(e)); setConfirming(false); }
    finally { setBusy(false); }
  }
  const ready = !!calc?.amount && calc.problems.length === 0 && /^\d{6}$/.test(totp) && !!account;
  return (
    <div className="card col">
      <h2>Tarik IDR</h2>
      <Alert>{err}</Alert><Alert kind="ok">{ok}</Alert>
      {acct.data && !edit && account && (
        <div className="row" style={{ justifyContent: 'space-between' }}><span>Rekening tujuan: <b>{account.bank}</b> •••{account.last4} a.n. <b>{account.holderName}</b></span><button className="btn small" onClick={() => setEdit(true)}>Ganti</button></div>
      )}
      {acct.data && (edit || !account) && (
        <div className="col">
          <b>{account ? 'Ganti rekening' : 'Tambah rekening tujuan'}</b>
          <p className="muted">Hanya rekening atas nama Anda sendiri (sesuai KYC) yang diterima.</p>
          <select aria-label="Bank" value={bank} onChange={(e) => setBank(e.target.value)}>{BANKS.map((b) => <option key={b}>{b}</option>)}</select>
          <Field label="Nomor rekening" inputMode="numeric" value={number} onChange={(e) => setNumber(e.target.value.replace(/\D/g, ''))} />
          <Field label="Nama pemilik rekening" value={holder} onChange={(e) => setHolder(e.target.value)} />
          <Field label="Kode 2FA" inputMode="numeric" maxLength={6} autoComplete="one-time-code" value={totpA} onChange={(e) => setTotpA(e.target.value.replace(/\D/g, ''))} />
          <div className="row"><button className="btn primary" disabled={number.length < 5 || !holder || totpA.length !== 6} onClick={() => void saveAccount()}>Simpan rekening</button>{account && <button className="btn" onClick={() => setEdit(false)}>Batal</button>}</div>
        </div>
      )}
      {account && !edit && (<>
        <Field label="Jumlah (Rp)" inputMode="numeric" value={amountText} onChange={(e) => setAmountText(e.target.value)} />
        {idr && <div className="muted">Tersedia Rp {formatUnits(balances.IDR?.available ?? '0', 0)} · biaya Rp {formatUnits(idr.withdrawFee, 0)} · total dipotong {calc?.amount ? 'Rp ' + formatUnits(calc.total.toString(), 0) : '—'}</div>}
        {calc?.problems.map((p) => <div key={p} className="sell-t">{p}</div>)}
        <Field label="Kode 2FA (6 digit)" inputMode="numeric" maxLength={6} autoComplete="one-time-code" value={totp} onChange={(e) => setTotp(e.target.value.replace(/\D/g, ''))} />
        {!confirming ? <button className="btn primary" disabled={!ready || busy} onClick={() => setConfirming(true)}>Tarik</button> : (
          <div className="alert warn col"><b>Kirim Rp {formatUnits(calc!.amount, 0)} ke {account.bank} •••{account.last4} a.n. {account.holderName}?</b>
            <div className="row"><button className="btn primary" disabled={busy} onClick={() => void submit()}>{busy ? 'Mengirim…' : 'Ya, tarik'}</button><button className="btn" onClick={() => setConfirming(false)}>Periksa lagi</button></div></div>
        )}
      </>)}
      <h3>Riwayat IDR</h3>
      {hist.data ? <FiatHistory rows={hist.data.items} /> : <Loading error={hist.error} />}
    </div>
  );
}
