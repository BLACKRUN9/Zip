import { useState } from 'react';
import { useApp } from '../ctx/AppContext.tsx';
import { useAsync } from '../hooks.ts';
import { errorText } from '../lib/api.ts';
import { formatUnits } from '../lib/money.ts';
import { Alert, Field, Loading, Tabs, fmtTime } from '../components/ui.tsx';
import { AdminFiat } from './AdminFiat.tsx';

function KycQueue() {
  const { api } = useApp();
  const list = useAsync(() => api.get('/v1/admin/kyc/pending'), [api]);
  const [sel, setSel] = useState<string | null>(null);
  const [view, setView] = useState<any>(null);
  const [reason, setReason] = useState('');
  const [err, setErr] = useState('');
  async function open(id: string) {
    setErr(''); setSel(id); setView(null); setReason('');
    try { setView(await api.get(`/v1/admin/kyc/${id}`)); } catch (e) { setErr(errorText(e)); }
  }
  async function decide(decision: 'approved' | 'rejected') {
    setErr('');
    try { await api.post(`/v1/admin/kyc/${sel}/review`, { decision, ...(reason ? { reason } : {}) }); setSel(null); setView(null); list.reload(); } catch (e) { setErr(errorText(e)); }
  }
  return (
    <div className="row" style={{ alignItems: 'flex-start' }}>
      <div className="card" style={{ flex: '1 1 260px' }}><h2>Antrian KYC</h2>
        {list.data ? (list.data.items.length ? list.data.items.map((k: any) => (
          <div key={k.userId}><button className="btn small" style={{ width: '100%', textAlign: 'left', marginBottom: 4 }} onClick={() => void open(k.userId)}>{k.fullName} <span className="muted">· {fmtTime(k.submittedAt)}</span></button></div>
        )) : <p className="muted">Antrian kosong.</p>) : <Loading error={list.error} />}
      </div>
      <div className="card col" style={{ flex: '2 1 480px' }}>
        <Alert>{err}</Alert>
        {!sel && <p className="muted">Pilih pengajuan untuk ditinjau.</p>}
        {sel && !view && !err && <Loading />}
        {view && (<>
          <Alert kind="warn">Data pribadi sensitif. Setiap pembukaan halaman ini tercatat atas nama Anda. Jangan menyalin atau menyimpan di luar sistem.</Alert>
          <div><b>{view.fullName}</b> · NIK <span className="mono">{view.nik}</span> · Lahir {String(view.dob).slice(0, 10)}</div>
          <div>{view.address}</div>
          <div className="row">{view.files.map((f: any) => <a key={f.key} href={f.url} target="_blank" rel="noreferrer noopener"><img src={f.url} alt="dokumen KYC" style={{ maxWidth: 260, maxHeight: 200, borderRadius: 6 }} referrerPolicy="no-referrer" /></a>)}{!view.files.length && <span className="muted">Pratinjau berkas belum dikonfigurasi (storage).</span>}</div>
          <Field label="Alasan (wajib jika menolak)" value={reason} onChange={(e) => setReason(e.target.value)} maxLength={300} />
          <div className="row"><button className="btn buy" onClick={() => void decide('approved')}>Setujui</button><button className="btn sell" disabled={!reason.trim()} onClick={() => void decide('rejected')}>Tolak</button></div>
        </>)}
      </div>
    </div>
  );
}

function Withdrawals() {
  const { api, assets } = useApp();
  const [status, setStatus] = useState('pending');
  const list = useAsync(() => api.get(`/v1/admin/withdrawals?status=${status}`), [api, status]);
  const [reasons, setReasons] = useState<Record<string, string>>({});
  const [err, setErr] = useState('');
  async function act(id: string, kind: 'approve' | 'reject') {
    setErr('');
    try { await api.post(`/v1/admin/withdrawals/${id}/${kind}`, kind === 'reject' ? { reason: reasons[id] ?? '' } : undefined); list.reload(); } catch (e) { setErr(errorText(e)); }
  }
  return (
    <div className="card col"><h2>Penarikan</h2>
      <select aria-label="Status" style={{ width: 'auto' }} value={status} onChange={(e) => setStatus(e.target.value)}>{['pending', 'approved', 'broadcast', 'completed', 'rejected'].map((s) => <option key={s}>{s}</option>)}</select>
      <Alert>{err}</Alert>
      {list.data ? (list.data.items.length ? (
        <table className="table"><thead><tr><th>Waktu</th><th>User</th><th>Aset</th><th className="num">Jumlah</th><th>Alamat</th><th>Risiko</th><th /></tr></thead>
          <tbody>{list.data.items.map((w: any) => (
            <tr key={w.id}><td className="muted">{fmtTime(w.createdAt)}</td><td className="mono">{w.userId.slice(-8)}</td><td>{w.asset}</td>
              <td className="num">{formatUnits(w.amount, assets[w.asset]?.decimals ?? 0, { maxFrac: 8 })}</td><td className="mono">{w.address}</td><td>{w.riskFlags?.join(', ') || '—'}</td>
              <td>{w.status === 'pending' && (<div className="row"><button className="btn small buy" onClick={() => void act(w.id, 'approve')}>Setujui</button>
                <input className="input" style={{ width: 140 }} placeholder="alasan tolak" value={reasons[w.id] ?? ''} onChange={(e) => setReasons({ ...reasons, [w.id]: e.target.value })} />
                <button className="btn small danger" disabled={!reasons[w.id]?.trim()} onClick={() => void act(w.id, 'reject')}>Tolak</button></div>)}</td></tr>))}</tbody></table>
      ) : <p className="muted">Tidak ada data.</p>) : <Loading error={list.error} />}
      <p className="muted">Periksa alamat tujuan dan pola akun sebelum menyetujui. Anda tidak dapat menyetujui penarikan milik sendiri.</p>
    </div>
  );
}

function Users() {
  const { api } = useApp();
  const [id, setId] = useState(''); const [reason, setReason] = useState(''); const [msg, setMsg] = useState(''); const [err, setErr] = useState('');
  async function set(status: 'active' | 'frozen') {
    setErr(''); setMsg('');
    try { await api.post(`/v1/admin/users/${id.trim()}/status`, { status, reason }); setMsg(`Status pengguna: ${status}`); } catch (e) { setErr(errorText(e)); }
  }
  return (
    <div className="card col" style={{ maxWidth: 520 }}><h2>Pengguna</h2><Alert>{err}</Alert><Alert kind="ok">{msg}</Alert>
      <Field label="User ID" value={id} onChange={(e) => setId(e.target.value)} className="input mono" />
      <Field label="Alasan (tercatat di audit log)" value={reason} onChange={(e) => setReason(e.target.value)} />
      <div className="row"><button className="btn danger" disabled={!id || !reason.trim()} onClick={() => void set('frozen')}>Bekukan (keluarkan semua sesi)</button><button className="btn" disabled={!id || !reason.trim()} onClick={() => void set('active')}>Aktifkan</button></div>
    </div>
  );
}

function Markets() {
  const { api, markets } = useApp();
  const [reason, setReason] = useState(''); const [msg, setMsg] = useState(''); const [err, setErr] = useState('');
  async function set(sym: string, status: string) {
    setErr(''); setMsg('');
    try { await api.post(`/v1/admin/markets/${sym}/status`, { status, reason }); setMsg(`${sym} → ${status}. Muat ulang untuk melihat status terbaru.`); } catch (e) { setErr(errorText(e)); }
  }
  return (
    <div className="card col"><h2>Pasar</h2><Alert>{err}</Alert><Alert kind="ok">{msg}</Alert>
      <Field label="Alasan (wajib, tercatat di audit log)" value={reason} onChange={(e) => setReason(e.target.value)} />
      <table className="table"><thead><tr><th>Pasar</th><th>Status</th><th /></tr></thead>
        <tbody>{markets.map((m) => <tr key={m.symbol}><td>{m.symbol}</td><td><span className="badge">{m.status}</span></td>
          <td><div className="row">{['active', 'cancel_only', 'halted'].filter((s) => s !== m.status).map((s) => <button key={s} className="btn small" disabled={!reason.trim()} onClick={() => void set(m.symbol, s)}>{s}</button>)}</div></td></tr>)}</tbody></table>
    </div>
  );
}

function Reconcile() {
  const { api } = useApp();
  const [res, setRes] = useState<any>(null); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  async function run() {
    setBusy(true); setErr('');
    try { setRes(await api.get('/v1/admin/reconcile')); }
    catch (e: any) { if (e?.status === 409) setRes({ ok: false, discrepancies: [{ kind: 'lihat log server', detail: 'rekonsiliasi menemukan selisih' }] }); else setErr(errorText(e)); }
    finally { setBusy(false); }
  }
  return (
    <div className="card col"><h2>Rekonsiliasi pembukuan</h2><Alert>{err}</Alert>
      <button className="btn primary" style={{ width: 'fit-content' }} disabled={busy} onClick={() => void run()}>{busy ? 'Memeriksa…' : 'Jalankan pemeriksaan'}</button>
      {res && (res.ok ? <Alert kind="ok">Semua saldo konsisten dengan ledger.</Alert> : <Alert>Ditemukan selisih. Hentikan penarikan dan selidiki segera.<ul>{res.discrepancies.map((d: any, i: number) => <li key={i}><b>{d.kind}</b>: {d.detail}</li>)}</ul></Alert>)}
    </div>
  );
}

export function Admin() {
  const [tab, setTab] = useState<'kyc' | 'wd' | 'idr' | 'users' | 'markets' | 'rec'>('kyc');
  return (
    <>
      <h1>Panel admin</h1>
      <Tabs value={tab} onChange={setTab} items={[['kyc', 'KYC'], ['wd', 'Penarikan kripto'], ['idr', 'IDR & testnet'], ['users', 'Pengguna'], ['markets', 'Pasar'], ['rec', 'Rekonsiliasi']]} />
      {tab === 'kyc' && <KycQueue />}{tab === 'wd' && <Withdrawals />}{tab === 'idr' && <AdminFiat />}{tab === 'users' && <Users />}{tab === 'markets' && <Markets />}{tab === 'rec' && <Reconcile />}
    </>
  );
}
