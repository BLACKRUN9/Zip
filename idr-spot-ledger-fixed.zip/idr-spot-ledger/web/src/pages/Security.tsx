import { useEffect, useState } from 'react';
import type { FormEvent } from 'react';
import QRCode from 'qrcode';
import { useApp } from '../ctx/AppContext.tsx';
import { useAsync } from '../hooks.ts';
import { errorText } from '../lib/api.ts';
import { Alert, Field, Loading, fmtTime } from '../components/ui.tsx';

function TwoFA() {
  const { api, user, refreshUser } = useApp();
  const [setup, setSetup] = useState<{ secret: string; otpauthUri: string } | null>(null);
  const [qr, setQr] = useState('');
  const [code, setCode] = useState('');
  const [codes, setCodes] = useState<string[] | null>(null);
  const [password, setPassword] = useState('');
  const [err, setErr] = useState('');
  useEffect(() => { if (setup) QRCode.toDataURL(setup.otpauthUri, { margin: 1, width: 200 }).then(setQr, () => setQr('')); }, [setup]);

  async function start() { setErr(''); try { setSetup(await api.post('/v1/auth/2fa/setup')); } catch (e) { setErr(errorText(e)); } }
  async function confirm(e: FormEvent) {
    e.preventDefault(); setErr('');
    try { const r = await api.post('/v1/auth/2fa/confirm', { code }); setCodes(r.recoveryCodes); setSetup(null); setCode(''); await refreshUser(); }
    catch (x) { setErr(errorText(x)); }
  }
  async function disable(e: FormEvent) {
    e.preventDefault(); setErr('');
    try { await api.post('/v1/auth/2fa/disable', { password, code }); setPassword(''); setCode(''); await refreshUser(); }
    catch (x) { setErr(errorText(x)); }
  }
  return (
    <div className="card col">
      <h2>Autentikasi dua langkah (2FA)</h2>
      <Alert>{err}</Alert>
      {codes && (
        <div className="secret col">
          <b>Simpan kode pemulihan ini sekarang. Kode hanya ditampilkan sekali.</b>
          <div className="mono">{codes.map((c) => <div key={c}>{c}</div>)}</div>
          <div className="row"><button className="btn small" onClick={() => void navigator.clipboard.writeText(codes.join('\n'))}>Salin</button><button className="btn small primary" onClick={() => setCodes(null)}>Sudah saya simpan</button></div>
        </div>
      )}
      {user?.twoFAEnabled ? (
        <form className="col" onSubmit={disable}>
          <Alert kind="ok">2FA aktif.</Alert>
          <h3>Nonaktifkan (penarikan dikunci 24 jam setelahnya)</h3>
          <Field label="Kata sandi" type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} />
          <Field label="Kode 2FA atau kode pemulihan" value={code} onChange={(e) => setCode(e.target.value.trim())} />
          <button className="btn danger" disabled={!password || !code}>Nonaktifkan 2FA</button>
        </form>
      ) : setup ? (
        <form className="col" onSubmit={confirm}>
          <p>Pindai dengan aplikasi autentikator (Google Authenticator, Authy, dll.), atau masukkan kunci secara manual.</p>
          {qr && <img src={qr} alt="Kode QR untuk 2FA" width={200} height={200} />}
          <div className="mono secret">{setup.secret}</div>
          <Field label="Kode 6 digit dari aplikasi" inputMode="numeric" maxLength={6} autoComplete="one-time-code" value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))} />
          <button className="btn primary" disabled={code.length !== 6}>Aktifkan</button>
        </form>
      ) : <button className="btn primary" onClick={() => void start()}>Siapkan 2FA</button>}
    </div>
  );
}

function Password() {
  const { api } = useApp();
  const [cur, setCur] = useState(''); const [next, setNext] = useState('');
  const [err, setErr] = useState(''); const [ok, setOk] = useState('');
  async function submit(e: FormEvent) {
    e.preventDefault(); setErr(''); setOk('');
    try { await api.post('/v1/auth/password/change', { currentPassword: cur, newPassword: next }); setCur(''); setNext(''); setOk('Kata sandi diubah. Sesi di perangkat lain dikeluarkan dan penarikan dikunci 24 jam.'); }
    catch (x) { setErr(errorText(x)); }
  }
  return (
    <form className="card col" onSubmit={submit}>
      <h2>Ubah kata sandi</h2><Alert>{err}</Alert><Alert kind="ok">{ok}</Alert>
      <Field label="Kata sandi saat ini" type="password" autoComplete="current-password" value={cur} onChange={(e) => setCur(e.target.value)} />
      <Field label="Kata sandi baru" type="password" autoComplete="new-password" minLength={10} value={next} onChange={(e) => setNext(e.target.value)} />
      <button className="btn" disabled={!cur || next.length < 10}>Ubah</button>
    </form>
  );
}

function Sessions() {
  const { api } = useApp();
  const q = useAsync(() => api.get('/v1/auth/sessions'), [api]);
  const [err, setErr] = useState('');
  async function revoke(id: string) { setErr(''); try { await api.del(`/v1/auth/sessions/${id}`); q.reload(); } catch (e) { setErr(errorText(e)); } }
  return (
    <div className="card"><h2>Sesi aktif</h2><Alert>{err}</Alert>
      {q.data ? (
        <table className="table"><thead><tr><th>Perangkat</th><th>IP</th><th>Masuk</th><th /></tr></thead>
          <tbody>{q.data.items.map((s: any) => (
            <tr key={s.id}><td>{String(s.userAgent ?? '').slice(0, 60) || '—'}</td><td>{s.ip}</td><td className="muted">{fmtTime(s.createdAt)}</td>
              <td>{s.id === q.data.currentSessionId ? <span className="badge">Ini</span> : <button className="btn small danger" onClick={() => void revoke(s.id)}>Keluarkan</button>}</td></tr>))}</tbody></table>
      ) : <Loading error={q.error} />}
    </div>
  );
}

function ApiKeys() {
  const { api, user } = useApp();
  const q = useAsync(() => api.get('/v1/api-keys'), [api]);
  const [label, setLabel] = useState(''); const [trade, setTrade] = useState(false); const [ips, setIps] = useState('');
  const [created, setCreated] = useState<{ keyId: string; secret: string } | null>(null);
  const [err, setErr] = useState('');
  async function create(e: FormEvent) {
    e.preventDefault(); setErr('');
    try {
      const ipWhitelist = ips.split(/[\s,]+/).filter(Boolean);
      const r = await api.post('/v1/api-keys', { label, permissions: trade ? ['read', 'trade'] : ['read'], ...(ipWhitelist.length ? { ipWhitelist } : {}) });
      setCreated(r); setLabel(''); setIps(''); q.reload();
    } catch (x) { setErr(errorText(x)); }
  }
  async function revoke(id: string) { try { await api.del(`/v1/api-keys/${id}`); q.reload(); } catch (e) { setErr(errorText(e)); } }
  if (!user?.twoFAEnabled) return <div className="card"><h2>API key (bot trading)</h2><Alert kind="warn">Aktifkan 2FA untuk membuat API key.</Alert></div>;
  return (
    <div className="card col">
      <h2>API key (bot trading)</h2>
      <p className="muted">API key tidak pernah bisa menarik dana, mengubah sandi, atau mengelola 2FA. Key dengan izin trading wajib dibatasi ke alamat IP tertentu.</p>
      <Alert>{err}</Alert>
      {created && <div className="secret col"><b>Simpan secret ini sekarang. Tidak akan ditampilkan lagi.</b><div>Key ID: <span className="mono">{created.keyId}</span></div><div>Secret: <span className="mono">{created.secret}</span></div><button className="btn small primary" onClick={() => setCreated(null)}>Sudah saya simpan</button></div>}
      <form className="col" onSubmit={create}>
        <Field label="Label" maxLength={50} value={label} onChange={(e) => setLabel(e.target.value)} />
        <label className="row"><input type="checkbox" checked={trade} onChange={(e) => setTrade(e.target.checked)} /> Izinkan trading (selain membaca)</label>
        <div className="field"><label htmlFor="ak-ips">Whitelist IP (pisahkan dengan spasi/koma){trade ? ' — wajib' : ''}</label><textarea id="ak-ips" rows={2} value={ips} onChange={(e) => setIps(e.target.value)} /></div>
        <button className="btn primary" disabled={trade && !ips.trim()}>Buat API key</button>
      </form>
      {q.data ? (
        <table className="table"><thead><tr><th>Label</th><th>Key ID</th><th>Izin</th><th>IP</th><th /></tr></thead>
          <tbody>{q.data.items.map((k: any) => <tr key={k.keyId}><td>{k.label || '—'}</td><td className="mono">{k.keyId}</td><td>{k.permissions.join(', ')}</td><td>{k.ipWhitelist.join(', ') || '—'}</td><td><button className="btn small danger" onClick={() => void revoke(k.keyId)}>Cabut</button></td></tr>)}</tbody></table>
      ) : <Loading error={q.error} />}
    </div>
  );
}

export function Security() {
  return (<><h1>Keamanan akun</h1><TwoFA /><Password /><Sessions /><ApiKeys /></>);
}
