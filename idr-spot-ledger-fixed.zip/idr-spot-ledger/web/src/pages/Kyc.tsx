import { useState } from 'react';
import type { FormEvent } from 'react';
import { useApp } from '../ctx/AppContext.tsx';
import { useAsync } from '../hooks.ts';
import { errorText } from '../lib/api.ts';
import { Alert, Field, Loading } from '../components/ui.tsx';

const MAX = 5 * 1024 * 1024;

export function Kyc() {
  const { api, refreshUser } = useApp();
  const st = useAsync(() => api.get('/v1/kyc'), [api]);
  const [fullName, setFullName] = useState('');
  const [nik, setNik] = useState('');
  const [dob, setDob] = useState('');
  const [address, setAddress] = useState('');
  const [doc, setDoc] = useState<File | null>(null);
  const [selfie, setSelfie] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  async function upload(file: File, kind: 'doc' | 'selfie'): Promise<string> {
    if (!['image/jpeg', 'image/png'].includes(file.type)) throw new Error('Hanya JPG atau PNG.');
    if (file.size > MAX) throw new Error('Ukuran file maksimal 5 MB.');
    const r = await api.post('/v1/kyc/upload-url', { kind, contentType: file.type });
    const res = await fetch(r.url, { method: 'PUT', headers: { 'Content-Type': file.type, ...(r.headers ?? {}) }, body: file });
    if (!res.ok) throw new Error('Unggah file gagal. Coba lagi.');
    return r.key;
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!doc || !selfie) { setErr('Foto KTP dan swafoto wajib diunggah.'); return; }
    setBusy(true); setErr('');
    try {
      const [docKey, selfieKey] = await Promise.all([upload(doc, 'doc'), upload(selfie, 'selfie')]);
      await api.post('/v1/kyc', { fullName, nik, dob, address, docKeys: [docKey], selfieKey });
      st.reload(); void refreshUser();
    } catch (x) { setErr(x instanceof Error && !('code' in x) ? x.message : errorText(x)); }
    finally { setBusy(false); }
  }

  if (!st.data) return <Loading error={st.error} />;
  const s = st.data;
  if (s.status === 'approved') return <div className="card"><h1>Verifikasi identitas</h1><Alert kind="ok">Identitas Anda sudah terverifikasi ({s.fullName}, NIK {s.nik}).</Alert></div>;
  if (s.status === 'pending') return <div className="card"><h1>Verifikasi identitas</h1><Alert kind="warn">Dokumen Anda sedang ditinjau. Biasanya selesai dalam 1×24 jam.</Alert></div>;
  return (
    <form className="card narrow col" style={{ maxWidth: 560 }} onSubmit={submit}>
      <h1>Verifikasi identitas (KYC)</h1>
      {s.status === 'rejected' && <Alert>Pengajuan ditolak: {s.reason}. Silakan kirim ulang dengan data yang benar.</Alert>}
      <Alert>{err}</Alert>
      <Field label="Nama lengkap sesuai KTP" required value={fullName} onChange={(e) => setFullName(e.target.value)} />
      <Field label="NIK (16 digit)" required inputMode="numeric" maxLength={16} pattern="\d{16}" value={nik} onChange={(e) => setNik(e.target.value.replace(/\D/g, ''))} />
      <Field label="Tanggal lahir" type="date" required value={dob} onChange={(e) => setDob(e.target.value)} />
      <Field label="Alamat sesuai KTP" required value={address} onChange={(e) => setAddress(e.target.value)} />
      <div className="field"><label htmlFor="k-doc">Foto KTP (JPG/PNG, maks 5 MB)</label><input id="k-doc" type="file" accept="image/jpeg,image/png" onChange={(e) => setDoc(e.target.files?.[0] ?? null)} /></div>
      <div className="field"><label htmlFor="k-selfie">Swafoto memegang KTP (JPG/PNG, maks 5 MB)</label><input id="k-selfie" type="file" accept="image/jpeg,image/png" onChange={(e) => setSelfie(e.target.files?.[0] ?? null)} /></div>
      <button className="btn primary" disabled={busy}>{busy ? 'Mengunggah…' : 'Kirim untuk ditinjau'}</button>
      <p className="muted">Data Anda dienkripsi dan hanya diakses petugas verifikasi; setiap akses tercatat.</p>
    </form>
  );
}
