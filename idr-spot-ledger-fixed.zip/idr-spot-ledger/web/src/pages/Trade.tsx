import { useState } from 'react';
import { Navigate, useNavigate, useParams } from 'react-router-dom';
import { useApp } from '../ctx/AppContext.tsx';
import { useBalances, useTicker } from '../hooks.ts';
import { formatPct, formatUnits } from '../lib/money.ts';
import { Chart } from '../components/Chart.tsx';
import { OrderBook, RecentTrades } from '../components/Book.tsx';
import { OrderForm } from '../components/OrderForm.tsx';
import { OrdersPanel } from '../components/OrdersPanel.tsx';
import { Loading } from '../components/ui.tsx';

export function Trade() {
  const { market: param } = useParams();
  const nav = useNavigate();
  const { markets, assets, user } = useApp();
  const [picked, setPicked] = useState<{ price: string; n: number } | null>(null);
  const symbol = (param ?? markets[0]?.symbol ?? '').toUpperCase();
  const m = markets.find((x) => x.symbol === symbol);
  const base = m && assets[m.base];
  const quote = m && assets[m.quote];
  const ticker = useTicker(m ? symbol : '');
  const balances = useBalances(!!user);
  if (!markets.length) return <Loading />;
  if (!m || !base || !quote) return <Navigate to={`/trade/${markets[0].symbol}`} replace />;
  const up = (ticker?.changeBps ?? 0) >= 0;
  return (
    <>
      <div className="card row" style={{ justifyContent: 'space-between' }}>
        <select aria-label="Pilih pasar" style={{ width: 'auto' }} value={symbol} onChange={(e) => nav(`/trade/${e.target.value}`)}>
          {markets.map((x) => <option key={x.symbol} value={x.symbol}>{x.base}/{x.quote}</option>)}
        </select>
        <div><span className="muted">Terakhir </span><b className={up ? 'buy-t' : 'sell-t'}>{ticker?.last ? formatUnits(ticker.last, quote.decimals) : '—'}</b></div>
        <div><span className="muted">24j </span><b className={up ? 'buy-t' : 'sell-t'}>{formatPct(ticker?.changeBps ?? null)}</b></div>
        <div><span className="muted">Tinggi </span>{ticker?.high ? formatUnits(ticker.high, quote.decimals) : '—'}</div>
        <div><span className="muted">Rendah </span>{ticker?.low ? formatUnits(ticker.low, quote.decimals) : '—'}</div>
        <div><span className="muted">Volume </span>{formatUnits(ticker?.volume ?? '0', base.decimals, { maxFrac: 4 })} {base.symbol}</div>
      </div>
      <div className="grid-trade">
        <div>
          <Chart market={symbol} baseDecimals={base.decimals} />
          <OrdersPanel market={symbol} base={base} quote={quote} />
        </div>
        <div>
          <OrderBook market={symbol} base={base} quote={quote} onPick={(price) => setPicked({ price, n: Date.now() })} />
          <RecentTrades market={symbol} base={base} quote={quote} />
        </div>
        <div>
          <OrderForm market={m} base={base} quote={quote} balances={balances} picked={picked} />
          {user && (
            <div className="card"><h3>Saldo</h3>
              {[quote, base].map((a) => (
                <div className="row" key={a.symbol} style={{ justifyContent: 'space-between' }}>
                  <span>{a.symbol}</span>
                  <span className="num">{formatUnits(balances[a.symbol]?.available ?? '0', a.decimals, { maxFrac: 8 })}
                    {BigInt(balances[a.symbol]?.locked ?? '0') > 0n && <span className="muted"> (+{formatUnits(balances[a.symbol].locked, a.decimals, { maxFrac: 8 })} terkunci)</span>}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  );
}
