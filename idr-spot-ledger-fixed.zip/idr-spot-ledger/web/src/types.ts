export interface User { id: string; email: string; phone?: string; status: string; kycLevel: number; role: string; twoFAEnabled: boolean }
export interface Asset { symbol: string; name: string; decimals: number; type: 'fiat' | 'crypto'; chain?: string; minDeposit: string; minWithdraw: string; withdrawFee: string }
export interface MarketInfo { symbol: string; base: string; quote: string; tickSize: string; lotSize: string; minQty: string; minNotional: string; makerFeeBps: number; takerFeeBps: number; status: string }
export interface Order { id: string; market: string; side: 'buy' | 'sell'; type: 'limit' | 'market'; tif: string; price: string; qty: string; filledQty: string; quoteFilled: string; feePaid: string; status: string; createdAt: string }
export interface Balance { asset: string; available: string; locked: string }
export interface Ticker { last: string | null; open: string | null; high: string | null; low: string | null; volume: string; quoteVolume: string; trades: number; changeBps: number | null }
export interface PublicTrade { price: string; qty: string; takerSide: 'buy' | 'sell'; time: string; seq: number }
