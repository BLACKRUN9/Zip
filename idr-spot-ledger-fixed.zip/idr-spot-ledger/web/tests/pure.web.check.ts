// Dependency-free: node --experimental-strip-types tests/pure.web.check.ts
import assert from 'node:assert/strict';
import { InputError, plainUnits, buyReserve, feeCeil, formatIdr, formatPct, formatUnits, isMultiple, maxBuyQty, parseUnits, quoteAmount } from '../src/lib/money.ts';
import { backoffDelay } from '../src/lib/backoff.ts';
import { ApiClient, ApiError, errorText } from '../src/lib/api.ts';
import { WsClient } from '../src/lib/ws.ts';

let passed = 0;
const t = async (name: string, fn: () => void | Promise<void>) => { await fn(); passed++; console.log('ok -', name); };

// ------------------------------------------------------------------ money
await t('formatUnits: Indonesian grouping, truncation (never rounds up), min/max fraction', () => {
  assert.equal(formatUnits('1500000000', 0), '1.500.000.000');
  assert.equal(formatUnits('50000000', 8), '0,5');
  assert.equal(formatUnits('123456789', 8), '1,23456789');
  assert.equal(formatUnits('123456789', 8, { maxFrac: 4 }), '1,2345'); // truncated, not 1,2346
  assert.equal(formatUnits('199999999', 8, { maxFrac: 2 }), '1,99'); // 1.99999999 must not display as 2,00
  assert.equal(formatUnits('100000000', 8, { minFrac: 2 }), '1,00');
  assert.equal(formatUnits('0', 8), '0');
  assert.equal(formatUnits('-1500', 0), '-1.500');
  assert.equal(formatUnits('1000000000000000000', 18), '1');
  assert.equal(formatIdr('2500000'), 'Rp 2.500.000');
  assert.equal(formatPct(526), '+5,26%');
  assert.equal(formatPct(-2500), '-25,00%');
  assert.equal(formatPct(null), '-');
});
await t('parseUnits: strict input, IDR thousand dots, ambiguity rejected, no floats', () => {
  assert.equal(parseUnits('1500000000', 0), '1500000000');
  assert.equal(parseUnits('1.500.000.000', 0), '1500000000');
  assert.equal(parseUnits('0,5', 8), '50000000');
  assert.equal(parseUnits('0.5', 8), '50000000');
  assert.equal(parseUnits('0.00000001', 8), '1');
  assert.equal(parseUnits('007', 0), '7');
  assert.equal(parseUnits('1', 18), '1000000000000000000');
  const bad = (s: string, d: number, code: string) => assert.throws(() => parseUnits(s, d), (e: any) => e instanceof InputError && e.code === code, `${s}/${d}`);
  bad('', 8, 'EMPTY'); bad('   ', 0, 'EMPTY');
  bad('1.5', 0, 'INVALID_NUMBER'); bad('1,5', 0, 'INVALID_NUMBER'); bad('1.50.000', 0, 'INVALID_NUMBER');
  bad('0.000000001', 8, 'TOO_MANY_DECIMALS');
  bad('1.000.000', 8, 'AMBIGUOUS');
  for (const s of ['abc', '-1', '1e5', '1..2', ',5', '5,', '1 000']) bad(s, 8, 'INVALID_NUMBER');
});
await t('plainUnits round-trips through parseUnits for any value', () => {
  assert.equal(plainUnits('50000000', 8), '0,5');
  assert.equal(plainUnits('1500000000', 0), '1500000000');
  assert.equal(plainUnits('123456789012345678', 18), '0,123456789012345678');
  for (const [v, d] of [['1', 8], ['100000000', 8], ['999999999999', 6], ['5', 0], ['1000000000000000000', 18]] as const) assert.equal(parseUnits(plainUnits(v, d), d), v);
});
await t('quote/fee/reserve match the server formulas; maxBuyQty is the exact largest affordable lot multiple', () => {
  assert.equal(quoteAmount('1000000000', '50000000', 8), 500_000_000n);
  assert.equal(feeCeil(500_000_000n, 20), 1_000_000n);
  assert.equal(buyReserve('1000000000', '50000000', 8, 10, 20), 501_000_000n);
  assert.equal(isMultiple('10000000', '1000'), true);
  assert.equal(isMultiple('10000500', '1000'), false);
  let s = 7;
  const rnd = (n: number) => { s = (s * 1103515245 + 12345) & 0x7fffffff; return s % n; };
  for (let i = 0; i < 300; i++) {
    const price = String((1 + rnd(2000)) * 1_000_000), lot = String(1000 * (1 + rnd(5)));
    const bal = String(rnd(10 ** 9) * 10 + rnd(1000));
    const q = maxBuyQty(bal, price, 8, lot, 10, 20);
    assert.equal(q % BigInt(lot), 0n);
    if (q > 0n) assert.ok(buyReserve(price, q.toString(), 8, 10, 20) <= BigInt(bal), 'fits');
    assert.ok(buyReserve(price, (q + BigInt(lot)).toString(), 8, 10, 20) > BigInt(bal), 'maximal');
  }
  assert.equal(maxBuyQty('0', '1000', 8, '1000', 10, 20), 0n);
});
await t('backoff: grows, is jittered within 50-100%, caps', () => {
  assert.equal(backoffDelay(0, () => 1), 500);
  assert.equal(backoffDelay(0, () => 0), 250);
  assert.equal(backoffDelay(3, () => 1), 4000);
  assert.equal(backoffDelay(20, () => 1), 15000);
  assert.equal(backoffDelay(20, () => 0), 7500);
  assert.equal(backoffDelay(10_000, () => 1), 15000);
});

// ------------------------------------------------------------------ api client
function makeApi() {
  const store = new Map<string, string>();
  const calls: any[] = [];
  let lost = 0;
  let uuidN = 0;
  let handler: (url: string, init: any) => any = () => ({ status: 200, ok: true, json: async () => ({}) });
  const api = new ApiClient({
    baseUrl: 'https://api.test',
    fetch: async (url, init) => { calls.push({ url: url.replace('https://api.test', ''), init }); return handler(url.replace('https://api.test', ''), init); },
    storage: { getItem: (k) => store.get(k) ?? null, setItem: (k, v) => void store.set(k, v), removeItem: (k) => void store.delete(k) },
    onSessionLost: () => { lost++; },
    uuid: () => `uuid-${++uuidN}`,
    now: () => 1_000_000,
  });
  const res = (status: number, body?: any) => ({ status, ok: status >= 200 && status < 300, json: async () => { if (body === undefined) throw new Error('no body'); return body; } });
  const tok = (n: number) => ({ accessToken: `acc-${n}`, refreshToken: `ref-${n}`, accessExpiresAt: new Date(1_000_000 + 900_000).toISOString(), refreshExpiresAt: new Date(1_000_000 + 9e9).toISOString() });
  return { api, store, calls, res, tok, lost: () => lost, on: (h: typeof handler) => { handler = h; } };
}
await t('api: login keeps access token in memory, refresh token in sessionStorage; bearer attached', async () => {
  const r = makeApi();
  r.on((url) => (url === '/v1/auth/login' ? r.res(200, r.tok(1)) : r.res(200, { ok: 1 })));
  await r.api.login('a@b.id', 'pw');
  assert.equal(r.store.get('rt'), 'ref-1');
  assert.equal(JSON.stringify([...r.store]).includes('acc-1'), false); // access token never persisted
  await r.api.get('/v1/me');
  assert.equal(r.calls.at(-1).init.headers.Authorization, 'Bearer acc-1');
  assert.equal(r.calls[0].init.headers.Authorization, undefined); // login itself is unauthenticated
});
await t('api: an expired access token triggers ONE refresh even with concurrent requests (single-flight)', async () => {
  const r = makeApi();
  let refreshes = 0;
  r.on((url, init) => {
    if (url === '/v1/auth/refresh') { refreshes++; return r.res(200, r.tok(2)); }
    return r.res(200, { who: init.headers.Authorization });
  });
  r.store.set('rt', 'ref-1'); // page reload: only the refresh token survives
  const outs = await Promise.all([r.api.get('/v1/me'), r.api.get('/v1/balances'), r.api.get('/v1/orders')]);
  assert.equal(refreshes, 1);
  assert.deepEqual(outs.map((o) => o.who), ['Bearer acc-2', 'Bearer acc-2', 'Bearer acc-2']);
  assert.equal(r.store.get('rt'), 'ref-2'); // rotated
});
await t('api: INVALID_TOKEN -> refresh -> retry once with the SAME idempotency key', async () => {
  const r = makeApi();
  let first = true;
  r.on((url, init) => {
    if (url === '/v1/auth/login') return r.res(200, r.tok(1));
    if (url === '/v1/auth/refresh') return r.res(200, r.tok(2));
    if (first) { first = false; return r.res(401, { error: 'INVALID_TOKEN', message: 'x', requestId: 'r1' }); }
    return r.res(201, { id: 'order-1', auth: init.headers.Authorization });
  });
  await r.api.login('a@b.id', 'pw');
  const out = await r.api.post('/v1/orders', { qty: '1' }, { idempotencyKey: 'key-1' });
  assert.deepEqual(out, { id: 'order-1', auth: 'Bearer acc-2' });
  const orderCalls = r.calls.filter((c) => c.url === '/v1/orders');
  assert.equal(orderCalls.length, 2);
  assert.deepEqual(orderCalls.map((c) => c.init.headers['Idempotency-Key']), ['key-1', 'key-1']);
});
await t('api: failed refresh clears the session and notifies once; server errors keep it', async () => {
  const r = makeApi();
  r.on((url) => (url === '/v1/auth/refresh' ? r.res(401, { error: 'INVALID_TOKEN', message: 'expired' }) : r.res(200, {})));
  r.store.set('rt', 'ref-old');
  await assert.rejects(() => r.api.get('/v1/me'), (e: any) => e instanceof ApiError && e.code === 'UNAUTHENTICATED');
  assert.equal(r.store.has('rt'), false);
  assert.equal(r.lost(), 1);

  const r2 = makeApi();
  r2.on((url) => (url === '/v1/auth/refresh' ? r2.res(503, { error: 'INTERNAL', message: 'down' }) : r2.res(200, {})));
  r2.store.set('rt', 'ref-keep');
  await assert.rejects(() => r2.api.get('/v1/me'));
  assert.equal(r2.store.get('rt'), 'ref-keep'); // a server outage must not log the user out
  assert.equal(r2.lost(), 0);
});
await t('api: error mapping (JSON, non-JSON, network, 204) and Indonesian texts', async () => {
  const r = makeApi();
  r.on((url) => {
    if (url === '/a') return r.res(422, { error: 'INSUFFICIENT_FUNDS', message: 'insufficient available IDR', requestId: 'rq' });
    if (url === '/b') return r.res(502);
    if (url === '/c') return r.res(204);
    throw new Error('socket hang up');
  });
  r.store.set('rt', 'x');
  r.api.access = 'acc'; r.api.accessExp = 9e12;
  await assert.rejects(() => r.api.get('/a'), (e: any) => e.status === 422 && e.code === 'INSUFFICIENT_FUNDS' && e.requestId === 'rq' && errorText(e) === 'Saldo tidak cukup.');
  await assert.rejects(() => r.api.get('/b'), (e: any) => e.status === 502 && e.code === 'HTTP_502');
  assert.equal(await r.api.del('/c'), undefined);
  await assert.rejects(() => r.api.get('/d'), (e: any) => e.code === 'NETWORK' && e.status === 0);
  assert.equal(errorText(new Error('boom')), 'Terjadi kesalahan tak terduga.');
  assert.equal(r.api.newKey(), 'uuid-1');
});

// ------------------------------------------------------------------ websocket client
class FakeWS {
  static instances: FakeWS[] = [];
  readyState = 0; sent: any[] = []; onopen: any; onmessage: any; onclose: any; onerror: any;
  url: string;
  constructor(url: string) { this.url = url; FakeWS.instances.push(this); }
  send(s: string) { this.sent.push(JSON.parse(s)); }
  close() { this.readyState = 3; this.onclose?.(); }
  open() { this.readyState = 1; this.onopen?.(); }
  recv(o: any) { this.onmessage?.({ data: JSON.stringify(o) }); }
}
function wsRig(token: string | null = 'tok-1') {
  FakeWS.instances = [];
  const timers: Array<{ at: number; fn: () => void; h: number; dead: boolean }> = [];
  let clock = 0, h = 0, tokenValue = token;
  const client = new WsClient({
    url: 'wss://x/ws', getToken: async () => tokenValue, WebSocketImpl: FakeWS as any,
    setTimeout: (fn, ms) => { const e = { at: clock + ms, fn, h: ++h, dead: false }; timers.push(e); return e.h; },
    clearTimeout: (id) => { const e = timers.find((x) => x.h === id); if (e) e.dead = true; },
    random: () => 1, pingMs: 1000, staleMs: 2500,
  });
  client.now = () => clock;
  const advance = (ms: number) => { clock += ms; for (const e of timers.filter((x) => !x.dead && x.at <= clock)) { e.dead = true; e.fn(); } };
  const cur = () => FakeWS.instances.at(-1)!;
  const flush = () => new Promise((r) => setImmediate(r));
  return { client, advance, cur, flush, setToken: (v: string | null) => { tokenValue = v; } };
}
await t('ws: subscribe waits for open; public needs no auth; ref-counted; unsubscribe only when last handler leaves', async () => {
  const r = wsRig();
  const got: any[] = [];
  const off1 = r.client.subscribe('ticker:BTC_IDR', (e) => got.push(['a', e.type]));
  const off2 = r.client.subscribe('ticker:BTC_IDR', (e) => got.push(['b', e.type]));
  assert.deepEqual(r.cur().sent, []); // not open yet
  r.cur().open();
  assert.deepEqual(r.cur().sent, [{ op: 'subscribe', channel: 'ticker:BTC_IDR' }]); // ONE subscribe for two handlers
  r.cur().recv({ type: 'snapshot', channel: 'ticker:BTC_IDR', data: 1 });
  r.cur().recv({ type: 'update', channel: 'other', data: 1 });
  assert.deepEqual(got, [['a', 'snapshot'], ['b', 'snapshot']]);
  off1();
  assert.equal(r.cur().sent.length, 1);
  off2();
  assert.deepEqual(r.cur().sent.at(-1), { op: 'unsubscribe', channel: 'ticker:BTC_IDR' });
});
await t('ws: private channels authenticate first and only subscribe after "authed"', async () => {
  const r = wsRig();
  r.client.subscribe('book:BTC_IDR', () => {});
  r.client.subscribe('orders', () => {});
  r.cur().open();
  await r.flush();
  assert.deepEqual(r.cur().sent.map((m) => m.op + ':' + (m.channel ?? '')), ['subscribe:book:BTC_IDR', 'auth:']);
  assert.equal(r.cur().sent[1].token, 'tok-1');
  r.cur().recv({ type: 'authed' });
  assert.deepEqual(r.cur().sent.at(-1), { op: 'subscribe', channel: 'orders' });
});
await t('ws: reconnect with backoff, subscriptions and auth restored; backoff resets after a healthy message', async () => {
  const r = wsRig();
  r.client.subscribe('orders', () => {});
  r.client.subscribe('trades:BTC_IDR', () => {});
  r.cur().open(); await r.flush(); r.cur().recv({ type: 'authed' });
  const first = r.cur();
  first.close(); // network drop
  assert.equal(r.client.status, 'reconnecting');
  assert.equal(FakeWS.instances.length, 1);
  r.advance(499);
  assert.equal(FakeWS.instances.length, 1);
  r.advance(2); // attempt 0 delay = 500 ms (random=1)
  assert.equal(FakeWS.instances.length, 2);
  r.cur().close(); // fails again before any message: delay doubles
  r.advance(999);
  assert.equal(FakeWS.instances.length, 2);
  r.advance(2);
  assert.equal(FakeWS.instances.length, 3);
  r.cur().open(); await r.flush();
  assert.deepEqual(r.cur().sent.map((m) => m.op), ['subscribe', 'auth']);
  r.cur().recv({ type: 'authed' });
  assert.deepEqual(r.cur().sent.map((m) => m.channel ?? m.op), ['trades:BTC_IDR', 'auth', 'orders']);
  assert.equal(r.client.attempt, 0); // healthy => reset
});
await t('ws: TOKEN_EXPIRED triggers a transparent re-auth with a fresh token and resubscribes private channels', async () => {
  const r = wsRig();
  r.client.subscribe('balances', () => {});
  r.cur().open(); await r.flush(); r.cur().recv({ type: 'authed' });
  r.setToken('tok-2');
  r.cur().recv({ type: 'error', code: 'TOKEN_EXPIRED' });
  await r.flush();
  assert.deepEqual(r.cur().sent.at(-1), { op: 'auth', token: 'tok-2' });
  r.cur().recv({ type: 'authed' });
  assert.deepEqual(r.cur().sent.at(-1), { op: 'subscribe', channel: 'balances' });
});
await t('ws: logged-out users still get public channels; resync re-requests the snapshot; close() stops reconnecting', async () => {
  const r = wsRig(null);
  r.client.subscribe('orders', () => {});
  r.client.subscribe('book:BTC_IDR', () => {});
  r.cur().open(); await r.flush();
  assert.deepEqual(r.cur().sent.map((m) => m.op + ':' + (m.channel ?? '')), ['subscribe:book:BTC_IDR']); // no token => no auth, no private
  let tokenCalls = 0;
  const orig = (r.client.deps as any).getToken;
  (r.client.deps as any).getToken = async () => { tokenCalls++; return orig(); };
  r.client.subscribe('balances', () => {}); // another private channel while logged out
  await r.flush(); await r.flush();
  assert.ok(tokenCalls <= 1, `must not loop asking for a token (asked ${tokenCalls}x)`); // regression: used to spin forever
  r.client.resync('book:BTC_IDR');
  assert.deepEqual(r.cur().sent.slice(-2).map((m) => m.op), ['unsubscribe', 'subscribe']);
  r.client.close();
  r.advance(60_000);
  assert.equal(FakeWS.instances.length, 1);
  assert.equal(r.client.status, 'closed');
});
await t('ws: watchdog pings, and a silent (half-open) connection is dropped and re-established', async () => {
  const r = wsRig();
  r.client.subscribe('ticker:BTC_IDR', () => {});
  r.cur().open();
  r.advance(1000);
  assert.deepEqual(r.cur().sent.at(-1), { op: 'ping' });
  r.cur().recv({ type: 'pong' }); // server alive
  r.advance(1000);
  r.advance(1000);
  assert.equal(r.cur().readyState, 1);
  r.advance(3000); // nothing heard for > staleMs
  assert.equal(r.cur().readyState, 3);
  r.advance(1000);
  assert.equal(FakeWS.instances.length, 2); // reconnected
});

console.log(`\nall ${passed} web-lib checks passed`);
