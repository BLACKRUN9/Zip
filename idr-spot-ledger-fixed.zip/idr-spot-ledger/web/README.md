# Web app (React + Vite)

```bash
cd web && npm install
npm run dev        # http://localhost:5173, proxies /v1 and /ws to the API on :3000
npm run test:pure  # dependency-free checks of the money / API-client / WebSocket-client libraries
npm run build      # type-check + production bundle in web/dist
```
Not yet executed by the author: `npm install`, `tsc`, `vite build`, and opening the UI in a browser. Run them first and expect small fixes.
`lightweight-charts` is pinned to major 4 (v5 changed the series API).

## Deploy
Serve `dist/` as static files from the SAME origin as the API (`/v1`, `/ws` proxied) so no CORS is needed, behind TLS. Send these headers:
```
Content-Security-Policy: default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https://STORAGE_HOST; connect-src 'self' wss://YOUR_HOST https://STORAGE_HOST; font-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'; object-src 'none'
Strict-Transport-Security: max-age=63072000; includeSubDomains
X-Content-Type-Options: nosniff
Referrer-Policy: no-referrer
Permissions-Policy: camera=(), microphone=(), geolocation=()
Cross-Origin-Opener-Policy: same-origin
```
`'unsafe-inline'` is for STYLES only (React style attributes, chart canvas); there is no inline script. The object-storage bucket must allow
`PUT` from your origin (KYC upload) and serve KYC reads only through short-lived signed URLs.

## Security notes
- Access token: memory only. Refresh token: `sessionStorage` (per tab). Any XSS can read it, which is why the CSP above matters; a stricter option is an
  httpOnly refresh cookie (needs a small backend change plus CSRF protection). Never add third-party scripts (analytics, chat widgets) to this origin.
- Password-reset links carry the token in the URL fragment (`/reset#token=...`) so it never reaches servers, proxies or logs. Configure the mailer accordingly.
- Hiding admin pages is cosmetic. Every admin action is authorised again on the server (role + 2FA + optional IP allowlist) and audited.
- Client-side order checks are for UX; the server re-validates everything.

## Simulation mode (local development)
Start the API with `PAYMENT_PROVIDER=sim CHAIN_MODE=sim`. The Wallet page then shows (clearly labelled) panels to simulate a bank transfer to your virtual account,
mint testnet coins from the faucet, and (as admin, under Admin -> "IDR & testnet") settle payouts, mine blocks and trigger reorgs. In production these endpoints do
not exist and the panels never render.
