import type { CSSProperties } from "react";
import type { DepthRow } from "../../server/demo/view";

const bar = (pct: number): CSSProperties => ({ ["--p" as string]: `${pct}%` });

export function OrderBook({ asks, bids, spread, asOf, baseSymbol, quoteSymbol }: { asks: DepthRow[]; bids: DepthRow[]; spread: string | null; asOf: string; baseSymbol: string; quoteSymbol: string }) {
  if (asks.length === 0 && bids.length === 0) return <p className="muted" style={{ padding: 16, textAlign: "center" }}>No simulated liquidity.</p>;
  return (
    <div className="table-wrap">
      <table className="tbl" style={{ fontSize: 12 }}>
        <caption className="sr-only">Simulated order book for {baseSymbol}/{quoteSymbol}</caption>
        <thead><tr><th scope="col">Price ({quoteSymbol})</th><th scope="col" className="r">Size ({baseSymbol})</th></tr></thead>
        <tbody>
          {asks.map((r) => (<tr key={`a${r.price}`} className="depth-row depth-ask" style={bar(r.pct)}><td className="num down">{r.price}</td><td className="num r">{r.qty}</td></tr>))}
          <tr><td colSpan={2} className="muted" style={{ textAlign: "center", padding: "6px 12px" }}>Spread {spread ?? "—"}</td></tr>
          {bids.map((r) => (<tr key={`b${r.price}`} className="depth-row depth-bid" style={bar(r.pct)}><td className="num up">{r.price}</td><td className="num r">{r.qty}</td></tr>))}
        </tbody>
      </table>
      <p className="muted" style={{ fontSize: 11, padding: "6px 12px" }}>SIMULATED liquidity · as of {asOf} UTC · not a real exchange quote</p>
    </div>
  );
}
