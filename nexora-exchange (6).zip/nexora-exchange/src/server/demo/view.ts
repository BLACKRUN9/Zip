import "server-only";
import { formatBps, formatGrouped, formatUtc } from "../../lib/money/format";
import { notional } from "../../lib/money/trade-math";
import { depthPercent, sparkPath } from "../../lib/ui/chart-geometry";
import { candlesWithFallback, toPayload } from "../market-data/service";
import type { MarketConfig, Order } from "../trading/exchange";
import { MARKETS, MARKET_META, findMarket } from "./config";
import { getMarketData } from "./market-data";
import { getRuntime, type Runtime } from "./runtime";

export interface MarketRow { symbol: string; base: string; quote: string; name: string; last: string; lastRaw: bigint | null; lastSource: "TRADE" | "REFERENCE"; change: string; changeBps: bigint; spark: string }
export interface OrderRow { id: string; at: string; market: string; side: "BUY" | "SELL"; type: string; price: string; qty: string; filled: string; status: string; reason: string | null; open: boolean }
export interface TradeRow { id: string; time: string; price: string; qty: string; side: "BUY" | "SELL"; synthetic: boolean }
export interface UserTradeRow extends TradeRow { market: string; role: string }
export interface DepthRow { price: string; qty: string; pct: number }
export interface BalanceRow { asset: string; available: string; reserved: string; pending: string; total: string; price: string; value: string; valueRaw: bigint; sharePct: number }
export interface TransferRow { id: string; at: string; kind: string; asset: string; amount: string; status: string; reason: string | null; user?: string }

const CANDLES_PER_DAY = 96;
const qtyFmt = (v: bigint, d: number) => formatGrouped(v, d, { minFraction: 2 });
const priceFmt = (v: bigint, d: number) => formatGrouped(v, d);
const ZERO = { available: 0n, reserved: 0n, pending: 0n };
const candles = async (symbol: string, limit: number, minutes = 15) => { const { primary, fallback } = getMarketData(); return { req: { market: symbol, intervalMinutes: minutes, limit }, res: await candlesWithFallback(primary, fallback, { market: symbol, intervalMinutes: minutes, limit }) }; };

/** Last fill, else the reference price (clearly labelled). Never a fabricated trade. */
function priceOf(rt: Runtime, m: MarketConfig): { price: bigint | null; source: "TRADE" | "REFERENCE" } {
  const t = rt.exchange.recentTrades(m.symbol, 1)[0];
  if (t) return { price: t.price, source: "TRADE" };
  return { price: rt.references.get(m.symbol) ?? null, source: "REFERENCE" };
}

async function marketRow(rt: Runtime, m: MarketConfig): Promise<MarketRow> {
  const { price, source } = priceOf(rt, m);
  const cs = (await candles(m.symbol, CANDLES_PER_DAY)).res.candles;
  const bps = cs.length >= 2 && (cs[0] as { open: bigint }).open > 0n ? ((((cs[cs.length - 1] as { close: bigint }).close - (cs[0] as { open: bigint }).open) * 10_000n) / (cs[0] as { open: bigint }).open) : 0n;
  return {
    symbol: m.symbol, base: m.base.symbol, quote: m.quote.symbol, name: MARKET_META[m.symbol]?.name ?? m.symbol,
    last: price === null ? "—" : priceFmt(price, m.quote.decimals), lastRaw: price, lastSource: source,
    change: cs.length >= 2 ? formatBps(bps) : "—", changeBps: bps, spark: sparkPath(cs.map((c) => c.close), 100, 28),
  };
}

function orderRow(o: Order, m: MarketConfig): OrderRow {
  return {
    id: o.id, at: formatUtc(o.createdAt), market: o.market, side: o.side, type: o.type,
    price: o.price === null ? "Market" : priceFmt(o.price, m.quote.decimals), qty: qtyFmt(o.qty, m.base.decimals), filled: qtyFmt(o.filledQty, m.base.decimals),
    status: o.status, reason: o.reason, open: o.status === "OPEN" || o.status === "PARTIALLY_FILLED",
  };
}
const marketOrThrow = (symbol: string) => { const m = findMarket(symbol); if (!m) throw new Error(`unknown market ${symbol}`); return m; };

export async function getMarkets(): Promise<MarketRow[]> {
  const rt = await getRuntime();
  return Promise.all(MARKETS.map((m) => marketRow(rt, m)));
}

/** `userId` null = public market data only (no balances, no personal orders). */
export async function getTerminal(symbol: string, userId: string | null) {
  const m = findMarket(symbol);
  if (!m) return null;
  const rt = await getRuntime(); const ex = rt.exchange;
  const row = await marketRow(rt, m);
  const { req, res } = await candles(m.symbol, 120);
  const chart = toPayload(req, res, rt.vol.syntheticCount(m.symbol) > 0);
  const d = ex.depth(m.symbol, 12);
  const maxQty = [...d.bids, ...d.asks].reduce((a, r) => (r.qty > a ? r.qty : a), 0n);
  const toDepth = (rows: typeof d.bids): DepthRow[] => rows.map((r) => ({ price: priceFmt(r.price, m.quote.decimals), qty: qtyFmt(r.qty, m.base.decimals), pct: depthPercent(r.qty, maxQty) }));
  const bestBid = d.bids[0]?.price ?? null, bestAsk = d.asks[0]?.price ?? null;
  const bal = userId ? ex.getBalances(userId) : {};
  const b = bal[m.base.symbol] ?? ZERO, q = bal[m.quote.symbol] ?? ZERO;
  const all = userId ? ex.listOrders(userId).filter((o) => o.market === m.symbol).sort((x, y) => y.createdAt - x.createdAt) : [];
  return {
    market: { symbol: m.symbol, base: m.base.symbol, quote: m.quote.symbol, name: row.name, baseDecimals: m.base.decimals, quoteDecimals: m.quote.decimals, takerFeeBps: m.takerFeeBps, makerFeeBps: m.makerFeeBps },
    last: row.last, lastSource: row.lastSource, change: row.change, positive: row.changeBps >= 0n,
    chart, canTrade: userId !== null,
    depth: { asks: toDepth([...d.asks].reverse()), bids: toDepth(d.bids), spread: bestBid !== null && bestAsk !== null ? priceFmt(bestAsk - bestBid, m.quote.decimals) : null, asOf: formatUtc(d.asOf, true) },
    trades: ex.recentTrades(m.symbol, 25).map((t): TradeRow => ({ id: t.id, time: formatUtc(t.at, true), price: priceFmt(t.price, m.quote.decimals), qty: qtyFmt(t.qty, m.base.decimals), side: t.takerSide, synthetic: rt.vol.isSynthetic(m.symbol, t.id) })),
    balances: { base: qtyFmt(b.available, m.base.decimals), baseReserved: qtyFmt(b.reserved, m.base.decimals), quote: priceFmt(q.available, m.quote.decimals), quoteReserved: priceFmt(q.reserved, m.quote.decimals) },
    form: {
      market: m.symbol, baseSymbol: m.base.symbol, quoteSymbol: m.quote.symbol, baseDecimals: m.base.decimals, quoteDecimals: m.quote.decimals,
      takerFeeBps: m.takerFeeBps, makerFeeBps: m.makerFeeBps, minQty: m.minQty.toString(), minNotional: m.minNotional.toString(),
      refBuy: bestAsk === null ? null : bestAsk.toString(), refSell: bestBid === null ? null : bestBid.toString(),
      availableBase: b.available.toString(), availableQuote: q.available.toString(),
    },
    openOrders: all.filter((o) => o.status === "OPEN" || o.status === "PARTIALLY_FILLED").map((o) => orderRow(o, m)),
    history: all.filter((o) => o.status !== "OPEN" && o.status !== "PARTIALLY_FILLED").map((o) => orderRow(o, m)),
  };
}
export type TerminalView = NonNullable<Awaited<ReturnType<typeof getTerminal>>>;

export async function getBalances(userId: string): Promise<{ rows: BalanceRow[]; total: string }> {
  const rt = await getRuntime();
  const bal = rt.exchange.getBalances(userId);
  const raw = Object.entries(bal).map(([asset, v]) => {
    const m = MARKETS.find((x) => x.base.symbol === asset);
    const total = v.available + v.reserved + v.pending;
    const decimals = m ? m.base.decimals : asset === "USDT" ? 6 : 2;
    const price = m ? priceOf(rt, m).price ?? 0n : asset === "USDT" ? 1_000_000n : 100n; // stablecoin/USD at par (simulated)
    const priceDec = m ? m.quote.decimals : decimals;
    const valueRaw = m ? notional(total, price, m.base.decimals) : total;
    return { asset, v, total, decimals, price, priceDec, valueRaw, valueDec: m ? m.quote.decimals : decimals };
  });
  // value everything in a common 2-decimal unit (display only)
  const to2 = (v: bigint, dec: number) => (dec >= 2 ? v / 10n ** BigInt(dec - 2) : v * 10n ** BigInt(2 - dec));
  const grand = raw.reduce((a, r) => a + to2(r.valueRaw, r.valueDec), 0n);
  const rows = raw.sort((a, b) => (to2(b.valueRaw, b.valueDec) > to2(a.valueRaw, a.valueDec) ? 1 : -1)).map((r): BalanceRow => ({
    asset: r.asset, available: qtyFmt(r.v.available, r.decimals), reserved: qtyFmt(r.v.reserved, r.decimals), pending: qtyFmt(r.v.pending, r.decimals), total: qtyFmt(r.total, r.decimals),
    price: priceFmt(r.price, r.priceDec), value: priceFmt(to2(r.valueRaw, r.valueDec), 2), valueRaw: to2(r.valueRaw, r.valueDec), sharePct: depthPercent(to2(r.valueRaw, r.valueDec), grand),
  }));
  return { rows, total: priceFmt(grand, 2) };
}

export async function getDashboard(userId: string) {
  const rt = await getRuntime();
  const [markets, balances] = [await getMarkets(), await getBalances(userId)];
  const orders = rt.exchange.listOrders(userId).sort((a, b) => b.createdAt - a.createdAt);
  return {
    total: balances.total, assets: balances.rows.length, markets,
    openOrders: orders.filter((o) => o.status === "OPEN" || o.status === "PARTIALLY_FILLED").length,
    recent: orders.slice(0, 5).map((o) => orderRow(o, marketOrThrow(o.market))),
  };
}

export async function getOrdersView(userId: string) {
  const rt = await getRuntime();
  const orders = rt.exchange.listOrders(userId).sort((a, b) => b.createdAt - a.createdAt);
  const rows = orders.map((o) => orderRow(o, marketOrThrow(o.market)));
  const trades = rt.exchange.userTrades(userId, 50).map((t): UserTradeRow => {
    const m = marketOrThrow(t.market);
    return { id: t.id, market: t.market, time: formatUtc(t.at, true), price: priceFmt(t.price, m.quote.decimals), qty: qtyFmt(t.qty, m.base.decimals), side: t.userSide, role: t.role, synthetic: rt.vol.isSynthetic(t.market, t.id) };
  });
  return { open: rows.filter((r) => r.open), history: rows.filter((r) => !r.open), trades };
}

const transferRow = (t: ReturnType<Runtime["exchange"]["listTransfers"]>[number]): TransferRow => {
  const dec = MARKETS.flatMap((m) => [m.base, m.quote]).find((a) => a.symbol === t.asset)?.decimals ?? 2;
  return { id: t.id, at: formatUtc(t.createdAt), kind: t.kind, asset: t.asset, amount: qtyFmt(t.amount, dec), status: t.status, reason: t.reason, user: t.userId };
};
export async function getWalletView(userId: string) {
  const rt = await getRuntime();
  const { rows } = await getBalances(userId);
  const transfers = rt.exchange.listTransfers(userId).sort((a, b) => b.createdAt - a.createdAt).map(transferRow);
  return { balances: rows, transfers, assets: [...new Set(MARKETS.flatMap((m) => [m.quote.symbol, m.base.symbol]))] };
}

export async function getAdminView() {
  const rt = await getRuntime();
  const issues = rt.exchange.reconcileExchange();
  return {
    stats: rt.exchange.stats(), issues: issues.map((i) => i.kind),
    feeRevenue: MARKETS.map((m) => ({ asset: m.quote.symbol, v: rt.exchange.ledger.balance(`system:fees:${m.quote.symbol}`, m.quote.symbol), d: m.quote.decimals })).filter((x, i, a) => a.findIndex((y) => y.asset === x.asset) === i).map((x) => `${priceFmt(x.v, x.d)} ${x.asset}`).join(" · "),
    seededAt: formatUtc(rt.seededAt, true),
    markets: MARKETS.map((m) => ({ symbol: m.symbol, takerFeeBps: m.takerFeeBps, makerFeeBps: m.makerFeeBps })),
    pending: rt.exchange.allTransfers("PENDING").sort((a, b) => a.createdAt - b.createdAt).map(transferRow),
    audit: rt.audit.slice(-30).reverse().map((e) => ({ at: formatUtc(e.at, true), actor: e.actorId, action: e.action, target: e.target })),
  };
}
