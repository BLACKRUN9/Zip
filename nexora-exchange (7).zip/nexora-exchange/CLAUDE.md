# NEXORA Exchange — project conventions

DEMO-ONLY crypto exchange MVP. No real funds, keys, chains, payment providers or live trading APIs. Ever.

## Safety rules (non-negotiable)
- `DEMO_MODE` must equal the string `true`; `src/server/config/demo-guard.ts` aborts otherwise. No live mode, no override flag.
- Every balance-affecting server operation calls `requireDemo()` first.
- Never store private keys, seed phrases, signing credentials. Never broadcast transactions.
- Never claim licensed / compliant / audited / production-ready. Label all balances, orders, fills as SIMULATED in the UI.
- No real customer data in seeds or fixtures.

## Engineering rules
- TypeScript strict. Validate all untrusted input with Zod at the boundary.
- Money = BigInt atomic units (or Postgres NUMERIC). No JS `number` arithmetic on money. Use `src/lib/money`.
- Ledger: balanced double-entry, immutable once posted, corrections via `compensate()`. Unique `operationId` per operation (idempotency).
- DB access and financial logic server-side only. Role checks (USER/ADMIN) server-side, role read from DB never from the client.
- Never leak stack traces or secrets to clients or audit logs.
- Use a maintained auth library; do not hand-roll sessions/passwords.
- Never claim a command passed unless it was actually run.

## Layout
- `src/lib/money` decimal parsing/formatting, notional and fee math
- `src/server/matching` pure price-time-priority order book
- `src/server/ledger` journal, reconciliation, trade journal builder
- `src/server/config` demo guard
- `src/server/trading` `DemoExchange`: reference engine (orders, reserve/release, idempotency, simulated wallet, reconciliation)
- `src/server/market-data` seeded fictional candles + mock liquidity ladder
- `src/server/market-data` providers (simulated + Kraken public, read-only) behind `MarketDataProvider`; `MARKET_DATA_SOURCE` picks one
- `src/server/security` rate limiter + security headers; `src/server/audit` redaction; `src/server/risk` anomaly rules
- `src/server/demo` seeded in-memory runtime, commands (validated mutations) and view models; `src/app/actions.ts` Zod-validated server actions
- `src/app`, `src/components`: Next.js App Router UI (Milestone 1); `e2e/` Playwright specs
- `prisma/*.draft.*` UNVALIDATED schema + SQL integrity drafts
- `tests/` node:test suites for the pure core

## Commands
- Core + UI-logic tests: `npm test` (= `tsx --test tests/*.test.ts`)
- Server-layer tests: `npm run test:server` (needs `npm i server-only`; run with `--conditions=react-server`)
- E2E (needs browsers): `npx playwright install chromium && npm run e2e`
- Type check: `tsc -p tsconfig.json`
- (After bootstrap) `npm run lint`, `npm run test` (Vitest), `npm run e2e` (Playwright), `npx prisma validate`

## Test requirements
Cover: balanced entries, duplicate idempotency keys, insufficient funds, concurrency, partial fills/cancels, fees, precision, unauthorized access, no negative balances, reconciliation.

- Bots (`src/server/mm`) may only call DemoExchange, only for MM-role accounts, and every volume-bot trade is tagged SYNTHETIC. Never add a connector to a real venue.
- Roles come from `src/server/accounts/directory.ts`; every action checks the SERVER-SIDE actor (`getActor`). NEXORA_DEV_ACTOR is development-only (AUTH_MODE=dev); AUTH_MODE=better-auth ignores it. Role is derived from the directory by email, never from the session/browser.
- Market data is READ-ONLY. Never add trading/funding endpoints to a provider; hosts are fixed in code; failures must be visibly labelled, never silent.
