# Market data (chart)

**Charts are built only from fills on the simulated NEXORA exchange.** `GET /api/market/<symbol>/candles?interval=<1|5|15|60>&limit=<n>` aggregates the exchange's trades into OHLCV candles (open/close = first/last fill in the bucket, volume = base quantity traded). Buckets with no trades are flat candles at the previous close until "now", and the last candle is still forming, so it moves with every trade.
There is no seeded order book and no fabricated trade: with no orders the book and chart are empty. The header price is the last trade, or the editable *reference price* (labelled) before the first trade.

Two chart views share the same data: **NEXORA** (own SVG chart) and **TradingView** (TradingView's open-source Lightweight Charts library). Indicators: Volume and MA 20. The page polls every 5 s and has a Refresh button. Embedded TradingView *widgets* cannot display NEXORA's own data (they only show TradingView's feeds); a custom feed needs TradingView's licensed Charting Library.

`src/server/market-data/kraken.ts` (read-only Kraken public candles) and the simulated-seed provider remain as tested adapters behind `MarketDataProvider`, but are **not wired** into the app.
