# Financial model (SIMULATED)

- Amounts are BigInt atomic units. `qty` = base atomic; `price` = quote atomic per ONE whole base unit.
- `notional = floor(qty * price / 10^baseDecimals)` — identical for both counterparties so every fill balances.
- `fee = ceil(notional * feeBps / 10_000)`, charged in the quote asset, credited to the exchange fee account.
- Parsing rejects excess precision (no silent rounding), negatives, exponents and malformed input.
- Matching: strict price-time priority (price, then arrival `seq`). Fills execute at the maker price.
  A limit buy never fills above its limit; a limit sell never fills below it. Market orders never rest.
  Self-trade prevention skips the taker's own resting orders.
- Ledger: user balances are liability accounts (debit decreases, credit increases). Entries need >= 2 lines,
  one-sided positive amounts, and debits == credits per currency. Posted entries are frozen; fixes are compensating entries.
- Reconciliation reports UNBALANCED, DUPLICATE_OPERATION, INVALID_LINE, TOO_FEW_LINES, MISSING_REVERSAL_TARGET.
- Prices come from fictional seeded data and are NOT real exchange quotes.

## Reservations and fees (implemented in `src/server/trading/exchange.ts`)
- Buy limit reserves `notional(qty, limit) + feeOf(notional, max(maker,taker)) + 1`; sell reserves `qty`; market buy reserves the exact previewed cost `+ 1`.
- Fees accumulate per order and per role (maker/taker): fill fee = cumulativeFee(after) - cumulativeFee(before), so the total is exactly
  `ceil(totalNotional * bps / 10_000)` and cannot drift upward with many tiny fills. With two roles the total is at most `ceil(N * maxBps) + 1`,
  which the `+1` slack covers; therefore a reserved balance can never go negative while settling.
- Unused reserve is released when an order becomes FILLED/CANCELLED. A market order's unfilled remainder is cancelled (`MARKET_REMAINDER_UNFILLED`).
- Pending balance = funds locked for PENDING simulated withdrawals. Pending deposits are requests only; nothing is credited until an ADMIN decision.
- Known limitation: a maker order whittled down to a crumb can fill with `notional = 0` (floor); a DB version should enforce a minimum fill notional.

Not yet implemented here: DB persistence, row locking / SERIALIZABLE transactions, DB idempotency table (see prisma/ drafts).
