# NEXORA Exchange (DEMO ONLY)

Simulated crypto exchange MVP. Not licensed, audited, compliant or production-ready. No real funds, keys, chains or payment providers.

## Status (honest)
| Area | State |
|---|---|
| Money math, matching engine, double-entry ledger, demo guard | Done, tested (`tsx --test tests/*.test.ts`, 49 tests) |
| `DemoExchange`: reserve/release, partial fills, cancel, idempotency, simulated wallet, reconciliation, concurrency lock | Done, tested (in-memory reference implementation) |
| Seeded candles + liquidity ladder, rate limiter, security headers, audit redaction, risk rules | Done, tested |
| Prisma schema + SQL integrity constraints | **Draft, never validated or run** (`prisma/*.draft.*`) |
| Frontend (Milestone 1): landing, auth shells, dashboard, markets, terminal, portfolio, orders, wallet, settings, admin shell | Written; unit/server/render checks pass in the sandbox; **not yet built with `next build` or opened in a browser** |
| Playwright e2e (overflow, nav, forms, keyboard, disabled states) | Written, **never run** |
| Auth, API routes, Prisma migrations, RBAC, audit, rate-limit wiring | **Not built** (Milestones 2–4) |

## Bootstrap the full app (needs network + PostgreSQL)
```sh
npx create-next-app@latest nexora-app --typescript --tailwind --eslint --app --src-dir
cp -r src/lib src/server ../nexora-app/src/ && cp -r tests docs prisma CLAUDE.md .env.example .gitignore ../nexora-app/
cd ../nexora-app && npm i prisma @prisma/client zod && npm i -D vitest @playwright/test tsx
npx prisma --version   # inspect the major version, then `npx prisma init` and paste the draft models
```
Run core checks: `tsx --test tests/*.test.ts` and `tsc -p tsconfig.json`.

## Install the frontend into your Next.js app
```sh
# from the folder that contains both nexora-exchange/ and nexora-app/
cp -r nexora-exchange/src/lib nexora-exchange/src/server nexora-exchange/src/components nexora-app/src/
cp -r nexora-exchange/src/app/. nexora-app/src/app/          # overwrites layout.tsx, page.tsx, globals.css
cp -r nexora-exchange/tests nexora-exchange/tests-server nexora-exchange/e2e nexora-exchange/scripts nexora-exchange/config nexora-exchange/playwright.config.ts nexora-app/
cd nexora-app
npm i lightweight-charts     # TradingView chart (Apache-2.0: keep its attribution/NOTICE)
npm i server-only            # only if the build says it cannot resolve "server-only"
node scripts/add-scripts.mjs
npm test && npm run typecheck && npm run build && npm run dev
```
Open http://localhost:3000. Needs `DEMO_MODE=true` in `.env`. Landing page: `/`; terminal: `/trade/BTC-USD`.

GitHub Codespaces only: also copy `next.config.ts` (it trusts the Codespaces proxy domain so Server Actions are not rejected). If your project already has custom settings in `next.config.ts`, merge them instead of overwriting.

Notes: no authentication yet, so every visitor shares one SIMULATED account, and state lives in server memory (resets on restart).
If your project uses Tailwind v3, change the first line of `src/app/globals.css` as its comment says.

## Accounts, bots, chart
- Accounts `user1`, `user2`, `mm`, `mm2`, `admin` (simulated funds). Default `AUTH_MODE=dev`: pick the acting one with `NEXORA_DEV_ACTOR=admin` and restart. Real login (Better Auth + PostgreSQL, seeded accounts, no self-registration): `AUTH_MODE=better-auth`, see `docs/AUTH.md`.
- Market-maker console at `/mm` (roles MM, ADMIN). Start the bots from the CSV on boot with `MM_AUTOSTART=true`. See `docs/MARKET_MAKER.md` (including the field interpretations to confirm).
- Chart: NEXORA and TradingView views with Volume and MA indicators, built only from simulated trades. See `docs/MARKET_DATA.md`.
