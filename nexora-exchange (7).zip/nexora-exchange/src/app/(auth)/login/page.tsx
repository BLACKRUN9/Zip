import type { Metadata } from "next";
import Link from "next/link";
import { loginAction } from "../../auth-actions";
import { LoginForm } from "../../../components/layout/login-form";
import { Notice, SimBadge } from "../../../components/ui/primitives";
import { readAuthMode } from "../../../server/auth/mode";

export const metadata: Metadata = { title: "Log in" };
export const dynamic = "force-dynamic";

export default function LoginPage() {
  const real = readAuthMode(process.env) === "better-auth";
  return (
    <main id="main" className="wrap" style={{ maxWidth: 440, padding: "32px 16px" }}>
      <Link href="/" className="logo" style={{ marginBottom: 20 }}><span className="logo-mark" /> NEXORA</Link>
      <div className="card" style={{ marginTop: 16 }}>
        <header className="card-h"><h1 style={{ fontSize: 16 }}>Log in</h1><SimBadge /></header>
        <div className="card-b stack">
          {real ? (
            <>
              <LoginForm action={loginAction} />
              <Notice>Demo accounts are created by the administrator (no self-registration). All balances are simulated.</Notice>
            </>
          ) : (
            <>
              <Notice tone="warn">Sign-in is off: the server runs with AUTH_MODE=dev (the operator picks the acting account with NEXORA_DEV_ACTOR). See docs/AUTH.md to enable real login.</Notice>
              <form className="stack" aria-label="Log in (disabled)">
                <div className="field"><label className="label" htmlFor="li-email">Email</label><input id="li-email" className="input" type="email" disabled /></div>
                <div className="field"><label className="label" htmlFor="li-pw">Password</label><input id="li-pw" className="input" type="password" disabled /></div>
                <button type="button" className="btn" disabled aria-disabled="true">Log in (AUTH_MODE=better-auth required)</button>
              </form>
              <Link className="btn btn-primary" href="/dashboard">Continue as the development actor</Link>
            </>
          )}
          <p className="muted" style={{ textAlign: "center" }}>Self-registration is disabled. <Link href="/register" style={{ color: "var(--accent)" }}>Why?</Link></p>
        </div>
      </div>
    </main>
  );
}
