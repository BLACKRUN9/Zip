import type { Metadata } from "next";
import Link from "next/link";
import { Notice, SimBadge } from "../../../components/ui/primitives";

export const metadata: Metadata = { title: "Registration" };
export default function RegisterPage() {
  return (
    <main id="main" className="wrap" style={{ maxWidth: 440, padding: "32px 16px" }}>
      <Link href="/" className="logo" style={{ marginBottom: 20 }}><span className="logo-mark" /> NEXORA</Link>
      <div className="card" style={{ marginTop: 16 }}>
        <header className="card-h"><h1 style={{ fontSize: 16 }}>Registration</h1><SimBadge /></header>
        <div className="card-b stack">
          <Notice tone="warn">Self-registration is disabled in this demo. Accounts (user1, user2, mm, mm2, admin) are created by the administrator through the development seed, so nobody can create themselves a privileged account.</Notice>
          <Link className="btn btn-primary" href="/login">Go to log in</Link>
        </div>
      </div>
    </main>
  );
}
