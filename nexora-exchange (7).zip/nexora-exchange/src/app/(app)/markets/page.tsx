import type { Metadata } from "next";
import Link from "next/link";
import { Card, PageHeader, SimBadge } from "../../../components/ui/primitives";
import { getMarkets } from "../../../server/demo/view";

export const metadata: Metadata = { title: "Markets" };
export default async function MarketsPage() {
  const markets = await getMarkets();
  return (
    <div className="stack-lg">
      <PageHeader title="Markets" subtitle="Last trade on NEXORA; reference price (ref) until the first trade" actions={<SimBadge>SIMULATED</SimBadge>} />
      <Card title="Spot markets">
        <div className="table-wrap"><table className="tbl">
          <caption className="sr-only">Simulated spot markets</caption>
          <thead><tr><th scope="col">Market</th><th scope="col" className="r">Last (USD)</th><th scope="col" className="r">24h</th><th scope="col">Trend</th><th scope="col"><span className="sr-only">Trade</span></th></tr></thead>
          <tbody>{markets.map((m) => (
            <tr key={m.symbol}>
              <td><strong>{m.symbol}</strong><div className="muted" style={{ fontSize: 11 }}>{m.name}</div></td>
              <td className="num r">{m.last}{m.lastSource === "REFERENCE" ? <span className="muted" style={{ fontSize: 11 }}> ref</span> : null}</td>
              <td className={`num r ${m.changeBps >= 0n ? "up" : "down"}`}>{m.change}</td>
              <td>{m.spark ? <svg width={100} height={28} viewBox="0 0 100 28" role="img" aria-label={`${m.symbol} simulated 24h trend`}><path d={m.spark} fill="none" stroke={m.changeBps >= 0n ? "var(--up)" : "var(--down)"} strokeWidth={1.5} /></svg> : <span className="muted">—</span>}</td>
              <td><Link className="btn btn-sm" href={`/trade/${m.symbol}`}>Trade</Link></td>
            </tr>))}</tbody>
        </table></div>
      </Card>
    </div>
  );
}
