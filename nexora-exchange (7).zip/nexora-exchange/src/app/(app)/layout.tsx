import type { ReactNode } from "react";
import { logoutAction } from "../auth-actions";
import { AppShell } from "../../components/layout/app-shell";
import { getActor } from "../../server/auth/actor";
import { readAuthMode } from "../../server/auth/mode";

// State is a live in-memory simulation, so never prerender these pages.
export const dynamic = "force-dynamic";
export default async function AppLayout({ children }: { children: ReactNode }) {
  const actor = await getActor();
  return <AppShell actor={actor} logout={actor && readAuthMode(process.env) === "better-auth" ? logoutAction : undefined}>{children}</AppShell>;
}
