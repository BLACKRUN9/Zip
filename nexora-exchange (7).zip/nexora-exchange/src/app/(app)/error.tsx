"use client";
import { ErrorState } from "../../components/ui/primitives";

// Never render error.message: it may contain internals. The digest is an opaque reference id.
export default function AppError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <ErrorState title="Something went wrong" hint={error.digest ? `Reference: ${error.digest}` : "Please try again."}
      action={<button type="button" className="btn btn-sm" onClick={() => reset()}>Try again</button>} />
  );
}
