import type { Metadata } from "next";
import { SignInRequired } from "../../../components/layout/sign-in-required";
import { Card, DisabledButton, Notice, PageHeader } from "../../../components/ui/primitives";
import { accountById, can, type Permission } from "../../../server/accounts/directory";
import { getActor } from "../../../server/auth/actor";

export const metadata: Metadata = { title: "Settings" };
const PERMS: Permission[] = ["trade", "wallet", "mm:view", "mm:control", "mm:config", "admin:view", "transfers:decide"];

export default async function SettingsPage() {
  const guard = process.env.DEMO_MODE === "true";
  const actor = await getActor();
  if (!actor) return <SignInRequired what="Settings" />;
  return (
    <div className="stack-lg">
      <PageHeader title="Settings" subtitle="Read-only until authentication exists" />
      <Card title="Account">
        <dl className="dl">
          <dt>User</dt><dd className="num">{actor.userId}</dd>
          <dt>Name</dt><dd>{accountById(actor.userId)?.label ?? "—"}</dd>
          <dt>Role</dt><dd>{actor.role} (assigned on the server)</dd>
          <dt>Verification</dt><dd>DEMO (simulated, not real KYC)</dd>
          <dt>Server demo guard</dt><dd className={guard ? "up" : "down"}>{guard ? "Active" : "NOT ACTIVE — operations disabled"}</dd>
        </dl>
      </Card>
      <Card title="Permissions">
        <dl className="dl">{PERMS.map((p) => (<div key={p} style={{ display: "contents" }}><dt className="num">{p}</dt><dd className={can(actor.role, p) ? "up" : "muted"}>{can(actor.role, p) ? "allowed" : "denied"}</dd></div>))}</dl>
      </Card>
      <Card title="Preferences & security">
        <div className="stack">
          <Notice>Disabled on purpose: the features behind these controls are not built yet.</Notice>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <DisabledButton reason="Profiles arrive with authentication (Milestone 2)">Edit profile</DisabledButton>
            <DisabledButton reason="Password auth arrives in Milestone 2">Change password</DisabledButton>
          </div>
        </div>
      </Card>
    </div>
  );
}
