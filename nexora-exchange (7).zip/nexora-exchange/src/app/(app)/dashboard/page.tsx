import type { Metadata } from "next";
import Link from "next/link";
import { OrdersTable } from "../../../components/trading/orders-table";
import { Card, Notice, PageHeader, SimBadge, Stat } from "../../../components/ui/primitives";
import { SignInRequired } from "../../../components/layout/sign-in-required";
import { getActor } from "../../../server/auth/actor";
import { getDashboard } from "../../../server/demo/view";

export const metadata: Metadata = { title: "Dashboard" };
export default async function DashboardPage() {
  const actor = await getActor();
  if (!actor) return <SignInRequired what="The dashboard" />;
  const d = await getDashboard(actor.userId);
  return (
    <div className="stack-lg">
      <PageHeader title="Dashboard" subtitle={`Account ${actor.userId} (${actor.role}) — simulated`} actions={<SimBadge>SIMULATED BALANCES</SimBadge>} />
      <div className="grid-cards">
        <Stat label="Simulated portfolio value (USD)" value={d.total} sub="Marked at simulated prices" />
        <Stat label="Open simulated orders" value={d.openOrders} />
        <Stat label="Assets held" value={d.assets} />
      </div>
      <Card title="Simulated markets" action={<Link className="btn btn-ghost btn-sm" href="/markets">All markets</Link>}>
        <div className="table-wrap"><table className="tbl">
          <caption className="sr-only">Top simulated markets</caption>
          <thead><tr><th scope="col">Market</th><th scope="col" className="r">Last</th><th scope="col" className="r">24h</th><th scope="col"><span className="sr-only">Trade</span></th></tr></thead>
          <tbody>{d.markets.map((m) => (<tr key={m.symbol}><td>{m.symbol}</td><td className="num r">{m.last}{m.lastSource === "REFERENCE" ? <span className="muted" style={{ fontSize: 11 }}> ref</span> : null}</td><td className={`num r ${m.changeBps >= 0n ? "up" : "down"}`}>{m.change}</td><td><Link className="btn btn-sm" href={`/trade/${m.symbol}`}>Trade</Link></td></tr>))}</tbody>
        </table></div>
      </Card>
      <Card title="Recent simulated orders" action={<Link className="btn btn-ghost btn-sm" href="/orders">View all</Link>}>
        <OrdersTable rows={d.recent} empty="No orders yet. Place one from the trading terminal." />
      </Card>
      <Notice>Everything on this page is simulated. Prices are fictional seed data and are not real exchange quotes.</Notice>
    </div>
  );
}
