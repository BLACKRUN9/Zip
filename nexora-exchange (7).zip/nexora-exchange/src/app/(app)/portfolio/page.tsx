import type { Metadata } from "next";
import { Card, EmptyState, PageHeader, SimBadge, Stat } from "../../../components/ui/primitives";
import { SignInRequired } from "../../../components/layout/sign-in-required";
import { getActor } from "../../../server/auth/actor";
import { getBalances } from "../../../server/demo/view";

export const metadata: Metadata = { title: "Portfolio" };
export default async function PortfolioPage() {
  const actor = await getActor();
  if (!actor) return <SignInRequired what="Your portfolio" />;
  const { rows, total } = await getBalances(actor.userId);
  return (
    <div className="stack-lg">
      <PageHeader title="Portfolio" subtitle="Server-confirmed simulated balances" actions={<SimBadge>SIMULATED BALANCES</SimBadge>} />
      <div className="grid-cards"><Stat label="Total simulated value (USD)" value={total} sub="Valued at simulated prices" /></div>
      <Card title="Assets">
        {rows.length === 0 ? <EmptyState title="No balances" hint="Create a simulated deposit request in the wallet." /> : (
          <div className="table-wrap"><table className="tbl">
            <caption className="sr-only">Simulated balances by asset</caption>
            <thead><tr><th scope="col">Asset</th><th scope="col" className="r">Available</th><th scope="col" className="r">Reserved</th><th scope="col" className="r">Pending</th><th scope="col" className="r">Price (USD)</th><th scope="col" className="r">Value (USD)</th><th scope="col">Share</th></tr></thead>
            <tbody>{rows.map((r) => (
              <tr key={r.asset}>
                <td><strong>{r.asset}</strong></td><td className="num r">{r.available}</td><td className="num r">{r.reserved}</td><td className="num r">{r.pending}</td>
                <td className="num r">{r.price}</td><td className="num r">{r.value}</td>
                <td style={{ minWidth: 110 }}><div style={{ display: "flex", alignItems: "center", gap: 8 }}><div style={{ flex: 1, height: 6, borderRadius: 3, background: "var(--surface-3)" }}><div style={{ width: `${r.sharePct}%`, height: 6, borderRadius: 3, background: "var(--accent)" }} /></div><span className="num muted" style={{ fontSize: 11 }}>{r.sharePct}%</span></div></td>
              </tr>))}</tbody>
          </table></div>)}
      </Card>
      <p className="muted" style={{ fontSize: 12 }}>Reserved = locked by open orders. Pending = locked by pending simulated withdrawals.</p>
    </div>
  );
}
