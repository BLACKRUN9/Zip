import type { Metadata } from "next";
import { requestTransferAction } from "../../actions";
import { TransferForm } from "../../../components/trading/transfer-form";
import { Card, Notice, PageHeader, SimBadge, StatusBadge } from "../../../components/ui/primitives";
import { SignInRequired } from "../../../components/layout/sign-in-required";
import { getActor } from "../../../server/auth/actor";
import { getWalletView } from "../../../server/demo/view";

export const metadata: Metadata = { title: "Wallet (demo)" };
export default async function WalletPage() {
  const actor = await getActor();
  if (!actor) return <SignInRequired what="The wallet" />;
  const w = await getWalletView(actor.userId);
  return (
    <div className="stack-lg">
      <PageHeader title="Wallet (demo)" subtitle="Simulated deposits and withdrawals only" actions={<SimBadge>NO REAL MONEY</SimBadge>} />
      <Notice tone="warn">No payment provider, bank, or blockchain is connected. Requests are bookkeeping entries in a simulation and stay pending until an admin decision (admin approval UI arrives in Milestone 4).</Notice>
      <div className="grid-cards" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 320px), 1fr))" }}>
        <Card title="Balances">
          <div className="table-wrap"><table className="tbl">
            <caption className="sr-only">Simulated balances</caption>
            <thead><tr><th scope="col">Asset</th><th scope="col" className="r">Available</th><th scope="col" className="r">Reserved</th><th scope="col" className="r">Pending</th></tr></thead>
            <tbody>{w.balances.map((r) => (<tr key={r.asset}><td><strong>{r.asset}</strong></td><td className="num r">{r.available}</td><td className="num r">{r.reserved}</td><td className="num r">{r.pending}</td></tr>))}</tbody>
          </table></div>
        </Card>
        <Card title="New simulated request"><TransferForm assets={w.assets} action={requestTransferAction} /></Card>
      </div>
      <Card title="Requests">
        {w.transfers.length === 0 ? <p className="muted" style={{ textAlign: "center" }}>No requests yet.</p> : (
          <div className="table-wrap"><table className="tbl">
            <caption className="sr-only">Simulated transfer requests</caption>
            <thead><tr><th scope="col">Time (UTC)</th><th scope="col">Type</th><th scope="col">Asset</th><th scope="col" className="r">Amount</th><th scope="col">Status</th></tr></thead>
            <tbody>{w.transfers.map((t) => (<tr key={t.id}><td className="num muted">{t.at}</td><td>{t.kind}</td><td>{t.asset}</td><td className="num r">{t.amount}</td><td><StatusBadge status={t.status} /></td></tr>))}</tbody>
          </table></div>)}
      </Card>
    </div>
  );
}
