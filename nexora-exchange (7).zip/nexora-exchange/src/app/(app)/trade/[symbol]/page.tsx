import type { Metadata } from "next";
import { cookies } from "next/headers";
import { notFound } from "next/navigation";
import { placeOrderAction, cancelOrderAction } from "../../../actions";
import { LiveChart } from "../../../../components/trading/live-chart";
import { MarketNav } from "../../../../components/trading/market-nav";
import { OrderBook } from "../../../../components/trading/order-book";
import { OrderForm } from "../../../../components/trading/order-form";
import { OrdersTable } from "../../../../components/trading/orders-table";
import { RecentTrades } from "../../../../components/trading/recent-trades";
import { TerminalShell } from "../../../../components/trading/terminal-shell";
import { Card, Notice, SimBadge } from "../../../../components/ui/primitives";
import { LAYOUT_COOKIE, parseLayoutTheme } from "../../../../lib/ui/layout-theme";
import { can } from "../../../../server/accounts/directory";
import { getActor } from "../../../../server/auth/actor";
import { MARKETS } from "../../../../server/demo/config";
import { getTerminal } from "../../../../server/demo/view";

export const metadata: Metadata = { title: "Trading terminal" };

export default async function TradePage({ params }: { params: Promise<{ symbol: string }> }) {
  const { symbol } = await params;
  const actor = await getActor();
  const t = await getTerminal(symbol.toUpperCase(), actor && can(actor.role, "trade") ? actor.userId : null);
  if (!t) notFound();
  const m = t.market;
  const theme = parseLayoutTheme((await cookies()).get(LAYOUT_COOKIE)?.value);
  return (
    <div className="stack-lg">
      <MarketNav symbols={MARKETS.map((x) => x.symbol)} current={m.symbol} />
      <header style={{ display: "flex", flexWrap: "wrap", alignItems: "baseline", gap: "6px 16px" }}>
        <h1 style={{ fontSize: 22, fontWeight: 700 }}>{m.base} / {m.quote}</h1>
        <span className="num" style={{ fontSize: 20 }}>{t.last}</span>
        <span className={`num ${t.positive ? "up" : "down"}`}>{t.change} 24h</span>
        <span className={`badge ${t.lastSource === "TRADE" ? "badge-ok" : "badge-sim"}`}>{t.lastSource === "TRADE" ? "LAST TRADE (SIMULATED)" : "REFERENCE PRICE · no trades yet"}</span>
      </header>
      <TerminalShell
        initial={theme}
        chart={<Card title="Chart"><LiveChart initial={t.chart} symbol={m.symbol} label={`${m.base} / ${m.quote}`} quoteDecimals={m.quoteDecimals} baseDecimals={m.baseDecimals} /></Card>}
        book={
          <Card title="Order book" action={<SimBadge>SIMULATED</SimBadge>}>
            <OrderBook asks={t.depth.asks} bids={t.depth.bids} spread={t.depth.spread} spreadPct={t.depth.spreadPct} mid={t.depth.mid} asOf={t.depth.asOf} baseSymbol={m.base} quoteSymbol={m.quote} />
          </Card>
        }
        form={
          <Card title="Place order" action={<SimBadge />}>
            {t.canTrade ? (
              <>
                <OrderForm {...t.form} action={placeOrderAction} />
                <p className="muted" style={{ fontSize: 12, marginTop: 10 }}>Reserved: {t.balances.quoteReserved} {m.quote} · {t.balances.baseReserved} {m.base}</p>
              </>
            ) : <Notice tone="warn">Sign in to trade. {actor ? "Your role cannot place orders." : "Use the Log in button, or set NEXORA_DEV_ACTOR in .env for development."}</Notice>}
          </Card>
        }
        trades={<Card title="Recent trades" action={<SimBadge />}><RecentTrades trades={t.trades} baseSymbol={m.base} quoteSymbol={m.quote} /></Card>}
        orders={
          <Card title="Your orders" action={<SimBadge />}>
            <h3 className="label" style={{ marginBottom: 6 }}>Open orders</h3>
            <OrdersTable rows={t.openOrders} empty={t.canTrade ? "No open orders on this market." : "Sign in to see your orders."} cancelAction={cancelOrderAction} showMarket={false} />
            <h3 className="label" style={{ margin: "16px 0 6px" }}>Order history</h3>
            <OrdersTable rows={t.history} empty={t.canTrade ? "No completed orders on this market yet." : "Sign in to see your orders."} showMarket={false} />
          </Card>
        }
      />
    </div>
  );
}
