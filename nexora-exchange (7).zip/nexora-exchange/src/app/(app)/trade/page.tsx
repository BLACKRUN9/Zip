import { redirect } from "next/navigation";
import { DEFAULT_MARKET } from "../../../server/demo/config";

export default function TradeIndex() {
  redirect(`/trade/${DEFAULT_MARKET}`);
}
