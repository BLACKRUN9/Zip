import type { Metadata } from "next";
import { decideTransferAction } from "../../actions";
import { Forbidden, SignInRequired } from "../../../components/layout/sign-in-required";
import { Card, DisabledButton, EmptyState, PageHeader, Stat } from "../../../components/ui/primitives";
import { can } from "../../../server/accounts/directory";
import { getActor } from "../../../server/auth/actor";
import { getAdminView } from "../../../server/demo/view";

export const metadata: Metadata = { title: "Admin" };
export default async function AdminPage() {
  const actor = await getActor();
  if (!actor) return <SignInRequired what="The admin dashboard" />;
  if (!can(actor.role, "admin:view")) return <Forbidden role={actor.role} what="the admin dashboard" />;
  const a = await getAdminView();
  const clean = a.issues.length === 0;
  return (
    <div className="stack-lg">
      <PageHeader title="Admin dashboard" subtitle="Aggregates and approvals (simulated)" />
      <div className="grid-cards">
        <Stat label="Orders (all)" value={a.stats.orders} sub={`${a.stats.openOrders} open`} />
        <Stat label="Simulated fills" value={a.stats.trades} />
        <Stat label="Journal entries" value={a.stats.ledgerEntries} />
        <Stat label="Pending transfer requests" value={a.stats.pendingTransfers} />
        <Stat label="Fee revenue (simulated)" value={a.feeRevenue || "0"} />
      </div>
      <Card title="Pending simulated transfer requests">
        {a.pending.length === 0 ? <EmptyState title="Nothing pending" /> : (
          <div className="table-wrap"><table className="tbl">
            <caption className="sr-only">Pending simulated transfers</caption>
            <thead><tr><th scope="col">Time (UTC)</th><th scope="col">User</th><th scope="col">Type</th><th scope="col">Asset</th><th scope="col" className="r">Amount</th><th scope="col"><span className="sr-only">Decision</span></th></tr></thead>
            <tbody>{a.pending.map((t) => (
              <tr key={t.id}><td className="num muted">{t.at}</td><td>{t.user}</td><td>{t.kind}</td><td>{t.asset}</td><td className="num r">{t.amount}</td>
                <td><div className="row-actions">
                  <form action={decideTransferAction}><input type="hidden" name="id" value={t.id} /><input type="hidden" name="decision" value="COMPLETE" /><button type="submit" className="btn btn-sm btn-primary">Approve</button></form>
                  <form action={decideTransferAction}><input type="hidden" name="id" value={t.id} /><input type="hidden" name="decision" value="REJECT" /><button type="submit" className="btn btn-sm btn-ghost">Reject</button></form>
                </div></td></tr>))}</tbody>
          </table></div>)}
      </Card>
      <Card title="Ledger reconciliation" action={<span className={`badge ${clean ? "badge-ok" : "badge-bad"}`}>{clean ? "CLEAN" : `${a.issues.length} ISSUES`}</span>}>
        <p className="muted">{clean ? "Every journal entry balances, no duplicates, projection and reserves match." : `Issue kinds: ${[...new Set(a.issues)].join(", ")}`}</p>
        <p className="muted" style={{ fontSize: 12, marginTop: 6 }}>Runtime started {a.seededAt} UTC (in-memory simulation; resets on restart).</p>
      </Card>
      <Card title="Demo fee configuration">
        <div className="table-wrap"><table className="tbl">
          <caption className="sr-only">Fees per market</caption>
          <thead><tr><th scope="col">Market</th><th scope="col" className="r">Taker (bps)</th><th scope="col" className="r">Maker (bps)</th><th scope="col"><span className="sr-only">Edit</span></th></tr></thead>
          <tbody>{a.markets.map((m) => (<tr key={m.symbol}><td>{m.symbol}</td><td className="num r">{m.takerFeeBps}</td><td className="num r">{m.makerFeeBps}</td><td><DisabledButton reason="Fee editing arrives in Milestone 4 with audit logging">Edit</DisabledButton></td></tr>))}</tbody>
        </table></div>
      </Card>
      <Card title="Audit events (this runtime)">
        {a.audit.length === 0 ? <EmptyState title="No audit events yet" hint="Bot and approval actions are recorded here." /> : (
          <div className="table-wrap"><table className="tbl">
            <caption className="sr-only">Audit events</caption>
            <thead><tr><th scope="col">Time (UTC)</th><th scope="col">Actor</th><th scope="col">Action</th><th scope="col">Target</th></tr></thead>
            <tbody>{a.audit.map((e, i) => (<tr key={i}><td className="num muted">{e.at}</td><td>{e.actor}</td><td>{e.action}</td><td>{e.target}</td></tr>))}</tbody>
          </table></div>)}
      </Card>
    </div>
  );
}
