import type { Metadata } from "next";
import { cancelOrderAction } from "../../actions";
import { OrdersTable } from "../../../components/trading/orders-table";
import { Card, PageHeader, SimBadge } from "../../../components/ui/primitives";
import { SignInRequired } from "../../../components/layout/sign-in-required";
import { getActor } from "../../../server/auth/actor";
import { getOrdersView } from "../../../server/demo/view";

export const metadata: Metadata = { title: "Orders & trades" };
export default async function OrdersPage() {
  const actor = await getActor();
  if (!actor) return <SignInRequired what="Your orders" />;
  const v = await getOrdersView(actor.userId);
  return (
    <div className="stack-lg">
      <PageHeader title="Orders & trade history" actions={<SimBadge>SIMULATED</SimBadge>} />
      <Card title="Open orders"><OrdersTable rows={v.open} empty="No open orders." cancelAction={cancelOrderAction} /></Card>
      <Card title="Order history"><OrdersTable rows={v.history} empty="No completed orders yet." /></Card>
      <Card title="Trade history (simulated fills)">
        {v.trades.length === 0 ? <p className="muted" style={{ padding: 16, textAlign: "center" }}>No fills yet.</p> : (
          <div className="table-wrap"><table className="tbl">
            <caption className="sr-only">Simulated fills</caption>
            <thead><tr><th scope="col">Time (UTC)</th><th scope="col">Market</th><th scope="col">Side</th><th scope="col">Role</th><th scope="col" className="r">Price</th><th scope="col" className="r">Size</th></tr></thead>
            <tbody>{v.trades.map((t) => (<tr key={t.id}><td className="num muted">{t.time}</td><td>{t.market}</td><td className={t.side === "BUY" ? "up" : "down"}>{t.side}</td><td>{t.role}{t.synthetic ? <span className="badge badge-sim" style={{ marginLeft: 6 }}>SIM-BOT</span> : null}</td><td className="num r">{t.price}</td><td className="num r">{t.qty}</td></tr>))}</tbody>
          </table></div>)}
      </Card>
    </div>
  );
}
