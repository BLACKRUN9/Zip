import type { Metadata } from "next";
import { botCloneAction, botImportAction, botRemoveAction, botSaveAction, botStartAction, botStopAction, referenceAction } from "../../actions";
import { Forbidden, SignInRequired } from "../../../components/layout/sign-in-required";
import { AutoRefresh } from "../../../components/mm/auto-refresh";
import { BotCard } from "../../../components/mm/bot-card";
import { ImportForm, ReferenceForm } from "../../../components/mm/bot-forms";
import { Card, EmptyState, Notice, PageHeader, SimBadge } from "../../../components/ui/primitives";
import { formatGrouped, formatUtc } from "../../../lib/money/format";
import { can } from "../../../server/accounts/directory";
import { getActor } from "../../../server/auth/actor";
import { MARKETS } from "../../../server/demo/config";
import { panelSnapshot } from "../../../server/demo/mm";

export const metadata: Metadata = { title: "Market maker console" };

export default async function MmPage() {
  const actor = await getActor();
  if (!actor) return <SignInRequired what="The market maker console" />;
  if (!can(actor.role, "mm:view")) return <Forbidden role={actor.role} what="the market maker console" />;
  const snap = await panelSnapshot(actor);
  const dec = (market: string) => MARKETS.find((m) => m.symbol === market)!;
  const canConfig = can(actor.role, "mm:config");
  return (
    <div className="stack-lg">
      <PageHeader title="Market maker console" subtitle={`Signed in as ${actor.userId} (${actor.role}) — bots trade on the SIMULATED exchange only`} actions={<div className="row-actions"><SimBadge /><AutoRefresh /></div>} />
      <Notice tone="warn">Demo only. Bots use simulated funds and can only call the NEXORA simulation. Trades caused by volume bots are tagged SYNTHETIC and shown as such on charts. Configuration lives in memory and resets on restart (use config/ files for autostart).</Notice>
      {snap.synthetic.length ? <p className="muted" style={{ fontSize: 12 }}>Synthetic trades so far: {snap.synthetic.map((s) => `${s.market} ${s.trades}`).join(" · ")}</p> : null}

      {canConfig ? (
        <div className="grid-cards" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 340px), 1fr))" }}>
          <Card title="Reference prices (used by price_source = reference)">
            <div className="stack">{snap.references.map((r) => (<ReferenceForm key={r.market} market={r.market} current={formatGrouped(r.price, r.decimals)} action={referenceAction} />))}</div>
          </Card>
          <Card title="Import bots (CSV)">
            <ImportForm markets={MARKETS.map((m) => m.symbol)} action={botImportAction} defaultMap={actor.role === "ADMIN" ? "ACCT1=mm,ACCT2=mm2" : `ACCT1=${actor.userId}`} />
          </Card>
        </div>
      ) : null}

      <h2 style={{ fontSize: 16 }}>Bots ({snap.bots.length})</h2>
      {snap.bots.length === 0 ? <Card title="No bots"><EmptyState title="Nothing configured yet" hint="Import a CSV above. Clone a bot to run several with different settings (for example 3 buy and 3 sell)." /></Card> : null}
      {snap.bots.map((b) => (
        <BotCard key={b.id} bot={b} quoteDecimals={dec(b.market).quote.decimals} baseDecimals={dec(b.market).base.decimals}
          actions={{ start: botStartAction, stop: botStopAction, remove: botRemoveAction, clone: botCloneAction, save: botSaveAction }} />
      ))}

      <Card title="Activity log (latest 80)">
        {snap.logs.length === 0 ? <p className="muted" style={{ textAlign: "center" }}>No activity yet.</p> : (
          <div className="table-wrap" style={{ maxHeight: 360, overflowY: "auto" }}><table className="tbl" style={{ fontSize: 12 }}>
            <caption className="sr-only">Bot activity</caption>
            <thead><tr><th scope="col">Time (UTC)</th><th scope="col">Bot</th><th scope="col">Event</th><th scope="col">Detail</th></tr></thead>
            <tbody>{snap.logs.map((l, i) => (<tr key={i}><td className="num muted">{formatUtc(l.at, true)}</td><td>{l.strategyId}</td><td>{l.kind}</td><td style={{ whiteSpace: "normal", overflowWrap: "anywhere" }}>{l.message}</td></tr>))}</tbody>
          </table></div>)}
      </Card>
    </div>
  );
}
