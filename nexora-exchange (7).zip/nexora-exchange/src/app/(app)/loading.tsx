import { Skeleton } from "../../components/ui/primitives";

export default function Loading() {
  return (
    <div className="stack-lg" role="status" aria-label="Loading">
      <Skeleton height={28} width="40%" />
      <div className="grid-cards"><Skeleton height={88} /><Skeleton height={88} /><Skeleton height={88} /></div>
      <Skeleton height={280} />
      <span className="sr-only">Loading…</span>
    </div>
  );
}
