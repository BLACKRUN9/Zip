import Link from "next/link";
import { generateCandles } from "../server/market-data/seeded";
import { CandleChart } from "../components/trading/candle-chart";
import { SimBadge } from "../components/ui/primitives";

const PREVIEW = generateCandles({ seed: 11, startPrice: 4_250_000n, count: 72, intervalMs: 900_000, startTs: Date.UTC(2026, 0, 1) });
const FEATURES = [
  { t: "Simulated spot trading", d: "Market and limit orders matched by price-time priority against clearly labelled simulated liquidity." },
  { t: "Double-entry ledger", d: "Every balance change is a balanced, immutable journal entry with reserved, available and pending balances." },
  { t: "Portfolio & history", d: "Server-confirmed balances, open orders, fills and order history for the shared demo account." },
  { t: "Demo wallet", d: "Deposit and withdrawal requests that never touch a payment provider or a blockchain." },
];

export default function Landing() {
  return (
    <div>
      <header className="wrap" style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "14px 16px", gap: 8 }}>
        <Link href="/" className="logo"><span className="logo-mark" /> NEXORA</Link>
        <nav aria-label="Site" style={{ display: "flex", gap: 6, flexWrap: "wrap", justifyContent: "flex-end" }}>
          <Link className="btn btn-ghost btn-sm" href="/markets">Markets</Link>
          <Link className="btn btn-ghost btn-sm" href="/login">Log in</Link>
          <Link className="btn btn-primary btn-sm" href="/register">Register</Link>
        </nav>
      </header>
      <main id="main" className="wrap">
        <section className="hero">
          <div className="stack-lg">
            <SimBadge>DEMO ONLY · NO REAL FUNDS</SimBadge>
            <h1>Institutional-grade trading interface. <em>Fully simulated.</em></h1>
            <p className="muted" style={{ fontSize: 16, maxWidth: 560 }}>NEXORA Exchange is a demonstration of an exchange front-end and ledger. Every balance, order, fill and price is fictional and clearly labelled as simulated.</p>
            <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
              <Link className="btn btn-primary" href="/trade/BTC-USD">Open demo terminal</Link>
              <Link className="btn" href="/markets">Browse simulated markets</Link>
            </div>
          </div>
          <div className="card" aria-label="Chart preview"><div className="card-h"><h2>BTC / USD</h2><SimBadge>FICTIONAL DATA</SimBadge></div><div className="card-b"><CandleChart candles={PREVIEW} quoteDecimals={2} label="BTC / USD preview" sourceLabel="simulated candles (fictional data)" /></div></div>
        </section>
        <section aria-labelledby="features" style={{ padding: "24px 0" }}>
          <h2 id="features" style={{ fontSize: 20, marginBottom: 12 }}>What is in the demo</h2>
          <div className="grid-cards">{FEATURES.map((f) => (<div key={f.t} className="card" style={{ padding: 16 }}><h3 style={{ fontSize: 15 }}>{f.t}</h3><p className="muted" style={{ marginTop: 6 }}>{f.d}</p></div>))}</div>
        </section>
        <section className="alert alert-warn" style={{ margin: "8px 0 32px" }}>
          <strong>Important:</strong> this is a software demonstration. It does not accept real deposits, hold customer funds, store keys, or broadcast blockchain transactions. It is not licensed, audited, or production-ready.
        </section>
      </main>
      <footer className="wrap muted" style={{ padding: "16px 16px 40px", fontSize: 12 }}>© NEXORA demo · All data is simulated.</footer>
    </div>
  );
}
