import type { Metadata } from "next";
import type { ReactNode } from "react";
import { DemoBanner } from "../components/layout/demo-banner";
import "./globals.css";

export const metadata: Metadata = {
  title: { default: "NEXORA Exchange — Demo", template: "%s · NEXORA Demo" },
  description: "NEXORA Exchange is a simulated, demo-only trading interface. No real funds, no real cryptocurrency.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <DemoBanner />
        {children}
      </body>
    </html>
  );
}
