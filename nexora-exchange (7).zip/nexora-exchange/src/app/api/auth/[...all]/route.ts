import { toNextJsHandler } from "better-auth/next-js";
import { readAuthMode } from "../../../../server/auth/mode";
import { getAuth } from "../../../../server/auth/auth";

export const dynamic = "force-dynamic";

// Built lazily so importing this file at build time never needs DATABASE_URL or the auth secret.
const handlers = () => toNextJsHandler(getAuth());
const disabled = () => Response.json({ error: { code: "AUTH_DISABLED", message: "Authentication endpoints are off (AUTH_MODE is not better-auth)." } }, { status: 404 });

export async function GET(request: Request): Promise<Response> { return readAuthMode(process.env) === "better-auth" ? handlers().GET(request) : disabled(); }
export async function POST(request: Request): Promise<Response> { return readAuthMode(process.env) === "better-auth" ? handlers().POST(request) : disabled(); }
