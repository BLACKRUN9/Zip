import { handleCandles } from "../../../../../server/demo/market-api";

export const dynamic = "force-dynamic";

export async function GET(request: Request, ctx: { params: Promise<{ symbol: string }> }): Promise<Response> {
  const { symbol } = await ctx.params;
  return handleCandles(request, symbol);
}
