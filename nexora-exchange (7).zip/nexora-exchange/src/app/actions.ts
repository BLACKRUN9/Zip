"use server";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import type { FormState } from "../lib/ui/form-state";
import { getActor, requirePermission, AuthzError } from "../server/auth/actor";
import { cancelOrder, submitOrder, submitTransfer } from "../server/demo/commands";
import { botOp, cloneBot, importCsv, saveBot, setReference, type OpResult } from "../server/demo/mm";
import { getRuntime } from "../server/demo/runtime";

const KEY = z.string().regex(/^[A-Za-z0-9_.:-]{8,128}$/);
const BOT_ID = z.string().regex(/^[a-z0-9_-]{1,32}$/);
const orderSchema = z.object({ idempotencyKey: KEY, market: z.string().max(32), side: z.string().max(8), type: z.string().max(8), qty: z.string().trim().max(40), price: z.string().trim().max(40).default("") });
const transferSchema = z.object({ idempotencyKey: KEY, kind: z.string().max(16), asset: z.string().max(16), amount: z.string().trim().max(40) });
const bad: FormState = { status: "error", message: "Invalid request.", fieldErrors: {} };
const denied = (e: unknown): FormState => ({ status: "error", message: e instanceof AuthzError ? e.message : "Something went wrong. Please try again.", fieldErrors: {} });
const refresh = () => revalidatePath("/", "layout");
const asState = (r: OpResult, okMsg: string): FormState => (r.ok ? { status: "ok", message: okMsg, fieldErrors: {} } : { status: "error", message: r.errors.join(" • "), fieldErrors: {} });

// Every action: boundary validation (Zod) -> permission check against the SERVER-SIDE actor -> domain validation -> invariants.
export async function placeOrderAction(_prev: FormState, formData: FormData): Promise<FormState> {
  try {
    const actor = requirePermission(await getActor(), "trade");
    const parsed = orderSchema.safeParse(Object.fromEntries(formData));
    if (!parsed.success) return bad;
    const result = await submitOrder(actor.userId, parsed.data);
    refresh();
    return result;
  } catch (e) { return denied(e); }
}

export async function cancelOrderAction(formData: FormData): Promise<void> {
  const actor = await getActor();
  try { requirePermission(actor, "trade"); } catch { return; }
  const id = z.string().regex(/^ord_\d{1,12}$/).safeParse(formData.get("orderId"));
  if (!id.success || !actor) return;
  await cancelOrder(actor.userId, id.data);
  refresh();
}

export async function requestTransferAction(_prev: FormState, formData: FormData): Promise<FormState> {
  try {
    const actor = requirePermission(await getActor(), "wallet");
    const parsed = transferSchema.safeParse(Object.fromEntries(formData));
    if (!parsed.success) return bad;
    const result = await submitTransfer(actor.userId, parsed.data);
    refresh();
    return result;
  } catch (e) { return denied(e); }
}

export async function decideTransferAction(formData: FormData): Promise<void> {
  const actor = await getActor();
  try { requirePermission(actor, "transfers:decide"); } catch { return; }
  const p = z.object({ id: z.string().regex(/^xfer_\d{1,12}$/), decision: z.enum(["COMPLETE", "REJECT"]) }).safeParse(Object.fromEntries(formData));
  if (!p.success || !actor) return;
  try { await (await getRuntime()).exchange.decideTransfer(actor, p.data.id, p.data.decision); } catch { /* the queue re-renders with the true state */ }
  refresh();
}

const botIdOf = (fd: FormData) => BOT_ID.safeParse(fd.get("id"));
async function simpleBotAction(fd: FormData, op: "start" | "stop" | "remove"): Promise<void> {
  const id = botIdOf(fd); if (!id.success) return;
  try { await botOp(await getActor(), id.data, op); } catch { /* AuthzError: nothing to do */ }
  refresh();
}
export async function botStartAction(fd: FormData): Promise<void> { await simpleBotAction(fd, "start"); }
export async function botStopAction(fd: FormData): Promise<void> { await simpleBotAction(fd, "stop"); }
export async function botRemoveAction(fd: FormData): Promise<void> { await simpleBotAction(fd, "remove"); }

export async function botCloneAction(_prev: FormState, fd: FormData): Promise<FormState> {
  const p = z.object({ id: BOT_ID, name: z.string().trim().min(1).max(32) }).safeParse(Object.fromEntries(fd));
  if (!p.success) return bad;
  try { const r = await cloneBot(await getActor(), p.data.id, p.data.name); refresh(); return asState(r, `Cloned as "${p.data.name}" (stopped)`); } catch (e) { return denied(e); }
}

export async function botSaveAction(_prev: FormState, fd: FormData): Promise<FormState> {
  const id = botIdOf(fd); if (!id.success) return bad;
  const fields: Record<string, string> = {};
  for (const [k, v] of fd.entries()) if (k.startsWith("f:") && typeof v === "string") fields[k.slice(2)] = v;
  if (Object.keys(fields).length === 0 || Object.keys(fields).length > 40) return bad;
  try { const r = await saveBot(await getActor(), id.data, fields); refresh(); return asState(r, "Configuration saved"); } catch (e) { return denied(e); }
}

export async function botImportAction(_prev: FormState, fd: FormData): Promise<FormState> {
  const p = z.object({ csv: z.string().max(50_000), market: z.string().max(32), map: z.string().max(300) }).safeParse(Object.fromEntries(fd));
  if (!p.success) return bad;
  try { const r = await importCsv(await getActor(), p.data.csv, p.data.market, p.data.map); refresh(); return asState(r, `Imported ${r.count} bot(s) (stopped — review, then start)`); } catch (e) { return denied(e); }
}

export async function referenceAction(_prev: FormState, fd: FormData): Promise<FormState> {
  const p = z.object({ market: z.string().max(32), price: z.string().trim().max(40) }).safeParse(Object.fromEntries(fd));
  if (!p.success) return bad;
  try { const r = await setReference(await getActor(), p.data.market, p.data.price); refresh(); return asState(r, "Reference price updated"); } catch (e) { return denied(e); }
}
