"use server";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { z } from "zod";
import type { FormState } from "../lib/ui/form-state";
import { getAuth } from "../server/auth/auth";
import { readAuthMode } from "../server/auth/mode";
import { RateLimiter } from "../server/security/rate-limit";

const schema = z.object({ email: z.string().trim().toLowerCase().email().max(254), password: z.string().min(1).max(128) });
const g = globalThis as unknown as { __nexoraLoginLimiter?: RateLimiter };
const err = (message: string): FormState => ({ status: "error", message, fieldErrors: {} });

/** Sign in with a seeded account. Generic errors only (no account enumeration); attempts are rate limited per IP and per email. */
export async function loginAction(_prev: FormState, formData: FormData): Promise<FormState> {
  if (readAuthMode(process.env) !== "better-auth") return err("Sign-in is off: the server runs in dev-actor mode (AUTH_MODE=dev).");
  const parsed = schema.safeParse(Object.fromEntries(formData));
  if (!parsed.success) return err("Enter a valid email and password.");
  const h = await headers();
  const ip = (h.get("x-forwarded-for") ?? "unknown").split(",")[0]!.trim().slice(0, 64);
  const limiter = (g.__nexoraLoginLimiter ??= new RateLimiter(8, 5 * 60_000));
  const a = limiter.check(`ip:${ip}`), b = limiter.check(`email:${parsed.data.email}`);
  if (!a.allowed || !b.allowed) return err("Too many attempts. Please wait a few minutes and try again.");
  try { await getAuth().api.signInEmail({ body: { email: parsed.data.email, password: parsed.data.password }, headers: h }); }
  catch { return err("Invalid email or password."); }
  redirect("/dashboard"); // outside try/catch: redirect() works by throwing
}

export async function logoutAction(): Promise<void> {
  if (readAuthMode(process.env) === "better-auth") { try { await getAuth().api.signOut({ headers: await headers() }); } catch { /* already signed out */ } }
  redirect("/");
}
