import { MoneyError, parseDecimal } from "../money/decimal";
import { feeOf, notional } from "../money/trade-math";

export interface EstimateInput {
  side: "BUY" | "SELL";
  type: "MARKET" | "LIMIT";
  qty: string;
  price: string;
  baseDecimals: number;
  quoteDecimals: number;
  takerFeeBps: number;
  makerFeeBps: number;
  /** best ask (for BUY) / best bid (for SELL), used to ESTIMATE market orders. null = empty book. */
  referencePrice: bigint | null;
  minQty: bigint;
  minNotional: bigint;
  availableBase: bigint;
  availableQuote: bigint;
}

export type Estimate =
  | { ok: false; empty: boolean; errors: { qty?: string; price?: string; form?: string } }
  | { ok: true; qty: bigint; price: bigint; priceBasis: "LIMIT" | "REFERENCE"; notional: bigint; fee: bigint; total: bigint; insufficient: boolean; needed: bigint; neededAsset: "BASE" | "QUOTE" };

function explain(e: unknown, decimals: number): string {
  if (e instanceof MoneyError) {
    if (e.code === "PRECISION_EXCEEDED") return `At most ${decimals} decimal places`;
    return "Enter a positive number";
  }
  return "Invalid value";
}

/**
 * Client-side PREVIEW only. The server re-validates and is the source of truth for balances and fills.
 * Fee uses max(maker, taker) because a limit order may cross the book and be charged the taker rate.
 */
export function estimateOrder(i: EstimateInput): Estimate {
  const errors: { qty?: string; price?: string; form?: string } = {};
  const qtyEmpty = i.qty.trim() === "";
  const priceEmpty = i.price.trim() === "";
  let qty = 0n; let price = 0n;

  if (!qtyEmpty) {
    try {
      qty = parseDecimal(i.qty, i.baseDecimals);
      if (qty <= 0n) errors.qty = "Quantity must be greater than zero";
      else if (qty < i.minQty) errors.qty = "Below the minimum order size";
    } catch (e) { errors.qty = explain(e, i.baseDecimals); }
  }
  let basis: "LIMIT" | "REFERENCE" = "LIMIT";
  if (i.type === "LIMIT") {
    if (!priceEmpty) {
      try {
        price = parseDecimal(i.price, i.quoteDecimals);
        if (price <= 0n) errors.price = "Price must be greater than zero";
      } catch (e) { errors.price = explain(e, i.quoteDecimals); }
    }
  } else {
    basis = "REFERENCE";
    if (i.referencePrice === null) errors.form = "No simulated liquidity on this side of the book";
    else price = i.referencePrice;
  }

  const needsPrice = i.type === "LIMIT" && priceEmpty;
  if (qtyEmpty || needsPrice) return { ok: false, empty: true, errors };
  if (errors.qty || errors.price || errors.form) return { ok: false, empty: false, errors };

  const n = notional(qty, price, i.baseDecimals);
  if (n < i.minNotional) return { ok: false, empty: false, errors: { form: "Order value is below the minimum" } };
  const fee = feeOf(n, Math.max(i.takerFeeBps, i.makerFeeBps));
  const total = i.side === "BUY" ? n + fee : n - fee;
  const needed = i.side === "BUY" ? n + fee : qty;
  const available = i.side === "BUY" ? i.availableQuote : i.availableBase;
  return { ok: true, qty, price, priceBasis: basis, notional: n, fee, total, insufficient: needed > available, needed, neededAsset: i.side === "BUY" ? "QUOTE" : "BASE" };
}
