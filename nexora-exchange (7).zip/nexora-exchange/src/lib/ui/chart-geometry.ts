/** Pure presentation geometry. Prices stay bigint until the final pixel conversion (display only, never ledger math). */
export interface Ohlc { ts: number; open: bigint; high: bigint; low: bigint; close: bigint; volume?: bigint }
export interface CandleShape { cx: number; w: number; wickTop: number; wickBottom: number; bodyTop: number; bodyHeight: number; up: boolean }
export interface ChartGeometry { priceY: (p: bigint) => number; width: number; height: number; plotWidth: number; candles: CandleShape[]; ticks: { y: number; price: bigint }[]; min: bigint; max: bigint }
export interface GeometryOptions { width: number; height: number; padRight: number; padTop: number; padBottom: number; tickCount: number }

const r2 = (n: number) => Math.round(n * 100) / 100;

export function candleGeometry(candles: readonly Ohlc[], o: GeometryOptions): ChartGeometry {
  const plotWidth = o.width - o.padRight;
  if (candles.length === 0) return { priceY: () => 0, width: o.width, height: o.height, plotWidth, candles: [], ticks: [], min: 0n, max: 0n };
  let min = candles[0]!.low, max = candles[0]!.high;
  for (const c of candles) { if (c.low < min) min = c.low; if (c.high > max) max = c.high; }
  if (max === min) { // single price level (e.g. after the first trade): widen so ticks and candles have room and stay distinct
    const pad = max / 200n > 0n ? max / 200n : 1n;
    min = min > pad ? min - pad : 0n; max += pad;
  }
  const range = max - min;
  const plotH = o.height - o.padTop - o.padBottom;
  const yOf = (p: bigint) => r2(o.padTop + (plotH * Number(max - p)) / Number(range));
  const slot = plotWidth / candles.length;
  const shapes = candles.map((c, i): CandleShape => {
    const hi = c.open > c.close ? c.open : c.close, lo = c.open > c.close ? c.close : c.open;
    const bodyTop = yOf(hi), bodyBottom = yOf(lo);
    return { cx: r2(slot * i + slot / 2), w: r2(Math.max(1, slot * 0.62)), wickTop: yOf(c.high), wickBottom: yOf(c.low), bodyTop, bodyHeight: r2(Math.max(1, bodyBottom - bodyTop)), up: c.close >= c.open };
  });
  const seen = new Set<string>(); // tiny integer ranges can map several ticks to one price: keep each price once
  const ticks = Array.from({ length: o.tickCount }, (_, t) => {
    const price = o.tickCount > 1 ? min + (range * BigInt(t)) / BigInt(o.tickCount - 1) : min;
    return { y: yOf(price), price };
  }).filter((t) => { const k = t.price.toString(); if (seen.has(k)) return false; seen.add(k); return true; });
  return { priceY: yOf, width: o.width, height: o.height, plotWidth, candles: shapes, ticks, min, max };
}

export function sparkPath(values: readonly bigint[], width: number, height: number): string {
  if (values.length < 2) return "";
  let min = values[0]!, max = values[0]!;
  for (const v of values) { if (v < min) min = v; if (v > max) max = v; }
  const range = max - min === 0n ? 1n : max - min;
  return values.map((v, i) => `${i === 0 ? "M" : "L"}${r2((width * i) / (values.length - 1))} ${r2(height - (height * Number(v - min)) / Number(range))}`).join(" ");
}

/** 0..100 integer, computed in BigInt. */
export function depthPercent(qty: bigint, max: bigint): number {
  return max <= 0n ? 0 : Number((qty * 100n) / max);
}

/** Simple moving average of closes (integer floor). null until `period` values exist. */
export function sma(values: readonly bigint[], period: number): (bigint | null)[] {
  if (!Number.isInteger(period) || period < 1) throw new Error("period must be a positive integer");
  const out: (bigint | null)[] = []; let sum = 0n;
  values.forEach((v, i) => { sum += v; if (i >= period) sum -= values[i - period] as bigint; out.push(i >= period - 1 ? sum / BigInt(period) : null); });
  return out;
}

export interface VolumeBar { cx: number; w: number; y: number; h: number; up: boolean }
/** Volume histogram occupying the strip [baseY - maxHeight, baseY]. */
export function volumeBars(candles: readonly Ohlc[], o: { plotWidth: number; baseY: number; maxHeight: number }): VolumeBar[] {
  const max = candles.reduce((m, c) => ((c.volume ?? 0n) > m ? (c.volume as bigint) : m), 0n);
  const slot = candles.length ? o.plotWidth / candles.length : 0;
  return candles.map((c, i) => {
    const v = c.volume ?? 0n;
    const h = max === 0n ? 0 : Math.round((o.maxHeight * Number(v)) / Number(max) * 100) / 100;
    return { cx: Math.round((slot * i + slot / 2) * 100) / 100, w: Math.round(Math.max(1, slot * 0.62) * 100) / 100, y: o.baseY - h, h, up: c.close >= c.open };
  });
}

/** Indices for x-axis time labels: up to 4, unique, ascending, always inside [0, n-1]. */
export function timeLabelIndices(n: number): number[] {
  if (n <= 0) return [];
  return [...new Set([0, Math.floor(n / 3), Math.floor((2 * n) / 3), n - 1])].sort((a, b) => a - b);
}
