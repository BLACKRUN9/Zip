export const LAYOUT_THEMES = [
  { id: "pro", label: "Pro", hint: "Dense: chart · book · order" },
  { id: "classic", label: "Classic", hint: "Book · chart · order" },
  { id: "focus", label: "Focus", hint: "Large chart on top" },
] as const;
export type LayoutTheme = (typeof LAYOUT_THEMES)[number]["id"];
export const LAYOUT_COOKIE = "nexora-trade-layout";

/** Unknown/missing values fall back to "pro" (the cookie is a harmless UI preference, never trusted for anything else). */
export function parseLayoutTheme(v: string | null | undefined): LayoutTheme {
  return LAYOUT_THEMES.find((t) => t.id === v)?.id ?? "pro";
}
export const layoutCookie = (t: LayoutTheme): string => `${LAYOUT_COOKIE}=${t}; Path=/; Max-Age=31536000; SameSite=Lax`;
