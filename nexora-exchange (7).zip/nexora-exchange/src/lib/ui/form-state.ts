export interface FormState { status: "idle" | "ok" | "error"; message: string; fieldErrors: Record<string, string> }
export const IDLE: FormState = { status: "idle", message: "", fieldErrors: {} };
export type FormAction = (prev: FormState, formData: FormData) => Promise<FormState>;

/** Client-generated idempotency key (not a secret). Falls back when crypto.randomUUID is unavailable (non-secure context). */
export function newIdempotencyKey(): string {
  const c = (globalThis as { crypto?: { randomUUID?: () => string } }).crypto;
  if (c?.randomUUID) return c.randomUUID();
  return `k-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`;
}
