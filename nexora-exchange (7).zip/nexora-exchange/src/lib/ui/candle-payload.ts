import type { Ohlc } from "./chart-geometry";

export interface WireCandle { t: number; o: string; h: string; l: string; c: string; v: string }
export interface CandlePayload {
  market: string;
  intervalMinutes: number;
  source: "NEXORA-TRADES" | "SIMULATED-SEED" | "KRAKEN-PUBLIC";
  kind: "SIMULATED" | "REFERENCE";
  asOf: number;
  degraded: string | null;
  /** true when bot-generated (synthetic) volume is part of this market's trades. */
  synthetic?: boolean;
  candles: WireCandle[];
}

const INT = /^\d+$/;
/** Runtime check of untrusted JSON before it reaches BigInt(). */
export function isCandlePayload(x: unknown): x is CandlePayload {
  if (typeof x !== "object" || x === null) return false;
  const p = x as Partial<CandlePayload>;
  if (typeof p.market !== "string" || typeof p.intervalMinutes !== "number" || typeof p.asOf !== "number" || !Array.isArray(p.candles)) return false;
  if (p.kind !== "SIMULATED" && p.kind !== "REFERENCE") return false;
  if (p.source !== "NEXORA-TRADES" && p.source !== "SIMULATED-SEED" && p.source !== "KRAKEN-PUBLIC") return false;
  if (p.degraded !== null && typeof p.degraded !== "string") return false;
  if (p.synthetic !== undefined && typeof p.synthetic !== "boolean") return false;
  return p.candles.every((c) => c && typeof c.t === "number" && [c.o, c.h, c.l, c.c, c.v].every((v) => typeof v === "string" && INT.test(v)));
}
export const toOhlc = (p: CandlePayload): Ohlc[] => p.candles.map((c) => ({ ts: c.t, open: BigInt(c.o), high: BigInt(c.h), low: BigInt(c.l), close: BigInt(c.c), volume: BigInt(c.v) }));
