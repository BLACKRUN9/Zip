import { formatAtomic } from "./decimal";

export function groupThousands(intPart: string): string {
  return intPart.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

/** Display formatting for atomic units: "1,234.50". Trailing zeros trimmed down to `minFraction`. */
export function formatGrouped(value: bigint, decimals: number, opts: { minFraction?: number } = {}): string {
  const raw = formatAtomic(value, decimals);
  const neg = raw.startsWith("-");
  const [i = "0", f = ""] = (neg ? raw.slice(1) : raw).split(".");
  const min = opts.minFraction ?? decimals;
  let frac = f;
  while (frac.length > min && frac.endsWith("0")) frac = frac.slice(0, -1);
  return `${neg ? "-" : ""}${groupThousands(i)}${frac ? "." + frac : ""}`;
}

/** Basis points -> "+1.25%" (always explicit sign, 2 decimals). */
export function formatBps(bps: bigint): string {
  const sign = bps > 0n ? "+" : bps < 0n ? "-" : "";
  return `${sign}${formatAtomic(bps < 0n ? -bps : bps, 2)}%`;
}

/** Deterministic UTC formatting (no locale => no server/client hydration mismatch). */
export function formatUtc(ms: number, withSeconds = false): string {
  const iso = new Date(ms).toISOString();
  return withSeconds ? iso.slice(11, 19) : `${iso.slice(5, 10)} ${iso.slice(11, 16)}`;
}
