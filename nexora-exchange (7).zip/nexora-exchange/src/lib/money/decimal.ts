/**
 * Exact decimal <-> atomic-unit conversion using BigInt only.
 * No floating point is used anywhere in this module.
 */
export class MoneyError extends Error {
  constructor(public readonly code: "INVALID_FORMAT" | "PRECISION_EXCEEDED" | "NEGATIVE" | "INVALID_ARG", message: string) {
    super(message);
    this.name = "MoneyError";
  }
}

const DECIMAL_RE = /^(\d+)(?:\.(\d+))?$/;

export function pow10(n: number): bigint {
  if (!Number.isInteger(n) || n < 0 || n > 36) throw new MoneyError("INVALID_ARG", "decimals must be an integer in [0, 36]");
  return 10n ** BigInt(n);
}

/** Parse a non-negative decimal string into atomic units. Rejects excess precision instead of rounding. */
export function parseDecimal(input: string, decimals: number): bigint {
  const m = DECIMAL_RE.exec(input.trim());
  if (!m) throw new MoneyError("INVALID_FORMAT", `Not a valid non-negative decimal: "${input}"`);
  const whole = m[1] as string;
  const frac = m[2] ?? "";
  if (frac.length > decimals) throw new MoneyError("PRECISION_EXCEEDED", `At most ${decimals} decimal places allowed`);
  return BigInt(whole) * pow10(decimals) + BigInt(frac.padEnd(decimals, "0") || "0");
}

/** Like parseDecimal but ROUNDS (half up) extra fractional digits. For external display data only, never for orders. */
export function parseDecimalRounded(input: string, decimals: number): bigint {
  const m = DECIMAL_RE.exec(input.trim());
  if (!m) throw new MoneyError("INVALID_FORMAT", `Not a valid non-negative decimal: "${input}"`);
  const frac = m[2] ?? "";
  if (frac.length <= decimals) return parseDecimal(input, decimals);
  const kept = BigInt(m[1] as string) * pow10(decimals) + BigInt(frac.slice(0, decimals).padEnd(decimals, "0") || "0");
  return frac.charCodeAt(decimals) >= 53 ? kept + 1n : kept; // 53 = "5"
}

export function formatAtomic(value: bigint, decimals: number): string {
  const neg = value < 0n;
  const abs = neg ? -value : value;
  const base = pow10(decimals);
  const whole = abs / base;
  const frac = (abs % base).toString().padStart(decimals, "0");
  return `${neg ? "-" : ""}${whole}${decimals > 0 ? "." + frac : ""}`;
}

export function mulDivFloor(a: bigint, b: bigint, d: bigint): bigint {
  if (d <= 0n) throw new MoneyError("INVALID_ARG", "divisor must be positive");
  return (a * b) / d; // BigInt division truncates toward zero == floor for non-negative operands
}

export function mulDivCeil(a: bigint, b: bigint, d: bigint): bigint {
  if (d <= 0n) throw new MoneyError("INVALID_ARG", "divisor must be positive");
  return (a * b + d - 1n) / d;
}
