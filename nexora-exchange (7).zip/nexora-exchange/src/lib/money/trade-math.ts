import { mulDivCeil, mulDivFloor, pow10, MoneyError } from "./decimal";

/**
 * Conventions (documented in docs/FINANCIAL_MODEL.md):
 *  - qty:   base asset atomic units
 *  - price: quote asset atomic units per ONE whole base unit
 *  - notional = floor(qty * price / 10^baseDecimals)  (same value for both sides, so the ledger always balances)
 *  - fee      = ceil(notional * feeBps / 10_000)       (rounded up, in quote atomic units)
 */
export function notional(qty: bigint, price: bigint, baseDecimals: number): bigint {
  if (qty < 0n || price < 0n) throw new MoneyError("NEGATIVE", "qty and price must be non-negative");
  return mulDivFloor(qty, price, pow10(baseDecimals));
}

export function feeOf(notionalQuote: bigint, feeBps: number): bigint {
  if (!Number.isInteger(feeBps) || feeBps < 0 || feeBps > 10_000) throw new MoneyError("INVALID_ARG", "feeBps must be an integer in [0, 10000]");
  return mulDivCeil(notionalQuote, BigInt(feeBps), 10_000n);
}
