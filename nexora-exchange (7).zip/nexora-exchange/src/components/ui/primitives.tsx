import type { ReactNode } from "react";

export function SimBadge({ children = "SIMULATED" }: { children?: ReactNode }) {
  return <span className="badge badge-sim">{children}</span>;
}

export function Card({ title, action, children, className = "" }: { title: string; action?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={`card ${className}`}>
      <header className="card-h"><h2>{title}</h2>{action}</header>
      <div className="card-b">{children}</div>
    </section>
  );
}

export function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: string; actions?: ReactNode }) {
  return (
    <header style={{ display: "flex", flexWrap: "wrap", alignItems: "center", justifyContent: "space-between", gap: 12 }}>
      <div style={{ minWidth: 0 }}>
        <h1 style={{ fontSize: 22, fontWeight: 700 }}>{title}</h1>
        {subtitle ? <p className="muted" style={{ marginTop: 2 }}>{subtitle}</p> : null}
      </div>
      {actions}
    </header>
  );
}

export function Stat({ label, value, sub, tone }: { label: string; value: ReactNode; sub?: ReactNode; tone?: "up" | "down" }) {
  return (
    <div className="card" style={{ padding: 14 }}>
      <p className="label">{label}</p>
      <p className={`num ${tone ?? ""}`} style={{ fontSize: 22, fontWeight: 600, marginTop: 4, overflowWrap: "anywhere" }}>{value}</p>
      {sub ? <p className="muted" style={{ fontSize: 12, marginTop: 2 }}>{sub}</p> : null}
    </div>
  );
}

export function EmptyState({ title, hint }: { title: string; hint?: string }) {
  return (
    <div style={{ textAlign: "center", padding: "24px 12px" }}>
      <p style={{ fontWeight: 600 }}>{title}</p>
      {hint ? <p className="muted" style={{ marginTop: 4 }}>{hint}</p> : null}
    </div>
  );
}

export function ErrorState({ title, hint, action }: { title: string; hint?: string; action?: ReactNode }) {
  return (
    <div role="alert" className="alert alert-err" style={{ display: "grid", gap: 8 }}>
      <strong>{title}</strong>
      {hint ? <span>{hint}</span> : null}
      {action}
    </div>
  );
}

export function Skeleton({ height = 16, width = "100%" }: { height?: number; width?: number | string }) {
  return <div className="skeleton" style={{ height, width }} aria-hidden="true" />;
}

export function Notice({ tone = "info", children }: { tone?: "info" | "warn"; children: ReactNode }) {
  return <p className={`alert ${tone === "warn" ? "alert-warn" : "alert-info"}`}>{children}</p>;
}

const STATUS_TONE: Record<string, string> = { FILLED: "badge-ok", COMPLETED: "badge-ok", OPEN: "badge-pend", PARTIALLY_FILLED: "badge-pend", PENDING: "badge-pend", CANCELLED: "", REJECTED: "badge-bad" };
export function StatusBadge({ status }: { status: string }) {
  return <span className={`badge ${STATUS_TONE[status] ?? ""}`}>{status.replace("_", " ")}</span>;
}

/** A control for a feature that does not exist yet: visibly disabled, never a fake success. */
export function DisabledButton({ children, reason }: { children: ReactNode; reason: string }) {
  return <button type="button" className="btn btn-ghost" disabled aria-disabled="true" title={reason}>{children}</button>;
}
