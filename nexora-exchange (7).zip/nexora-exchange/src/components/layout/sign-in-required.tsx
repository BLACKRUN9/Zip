import { Card, Notice } from "../ui/primitives";

export function SignInRequired({ what }: { what: string }) {
  return (
    <Card title="Sign-in required">
      <div className="stack">
        <p>{what} needs an account.</p>
        <Notice tone="warn">Please <a href="/login" style={{ color: "var(--accent)", textDecoration: "underline" }}>log in</a>. In development without the database, the server operator can instead choose the acting account with <code>NEXORA_DEV_ACTOR</code> (AUTH_MODE=dev). See docs/AUTH.md.</Notice>
      </div>
    </Card>
  );
}

export function Forbidden({ role, what }: { role: string; what: string }) {
  return (
    <Card title="Not allowed">
      <p role="alert" className="alert alert-err">Your role ({role}) cannot access {what}.</p>
    </Card>
  );
}
