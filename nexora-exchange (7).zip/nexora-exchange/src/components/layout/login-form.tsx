"use client";
import { useActionState } from "react";
import { IDLE, type FormAction, type FormState } from "../../lib/ui/form-state";

export function LoginForm({ action }: { action: FormAction }) {
  const [state, formAction, pending] = useActionState<FormState, FormData>(action, IDLE);
  return (
    <form action={formAction} className="stack" aria-label="Log in">
      <div className="field"><label className="label" htmlFor="li-email">Email</label><input id="li-email" name="email" className="input" type="email" autoComplete="username" required /></div>
      <div className="field"><label className="label" htmlFor="li-pw">Password</label><input id="li-pw" name="password" className="input" type="password" autoComplete="current-password" required /></div>
      <div aria-live="polite">{state.status === "error" ? <p role="alert" className="alert alert-err">{state.message}</p> : null}</div>
      <button type="submit" className="btn btn-primary" disabled={pending}>{pending ? "Signing in…" : "Log in"}</button>
    </form>
  );
}
