import type { IconName } from "../ui/icons";

export interface NavItem { href: string; label: string; icon: IconName; match: string }
export const PRIMARY_NAV: NavItem[] = [
  { href: "/dashboard", label: "Dashboard", icon: "dashboard", match: "/dashboard" },
  { href: "/markets", label: "Markets", icon: "markets", match: "/markets" },
  { href: "/trade", label: "Trade", icon: "trade", match: "/trade" },
  { href: "/portfolio", label: "Portfolio", icon: "portfolio", match: "/portfolio" },
];
export const SECONDARY_NAV: NavItem[] = [
  { href: "/orders", label: "Orders", icon: "orders", match: "/orders" },
  { href: "/mm", label: "Market maker", icon: "bot", match: "/mm" },
  { href: "/wallet", label: "Wallet (demo)", icon: "wallet", match: "/wallet" },
  { href: "/settings", label: "Settings", icon: "settings", match: "/settings" },
  { href: "/admin", label: "Admin (shell)", icon: "admin", match: "/admin" },
];
export const isActive = (pathname: string, item: NavItem) => pathname === item.match || pathname.startsWith(item.match + "/");
