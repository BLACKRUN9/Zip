"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import type { MouseEvent, ReactNode } from "react";
import { Icon } from "../ui/icons";
import { SimBadge } from "../ui/primitives";
import { PRIMARY_NAV, SECONDARY_NAV, isActive, type NavItem } from "./nav";

function NavLinks({ items, pathname }: { items: NavItem[]; pathname: string }) {
  return (
    <>
      {items.map((it) => (
        <Link key={it.href} href={it.href} className="nav-link" aria-current={isActive(pathname, it) ? "page" : undefined}>
          <Icon name={it.icon} /> {it.label}
        </Link>
      ))}
    </>
  );
}

export function AppShell({ children, actor, logout }: { children: ReactNode; actor: { userId: string; role: string } | null; logout?: (() => Promise<void>) | undefined }) {
  const pathname = usePathname() ?? "";
  const moreActive = SECONDARY_NAV.some((i) => isActive(pathname, i));
  return (
    <div className="shell">
      <a href="#main" className="skip-link">Skip to content</a>
      <aside className="sidebar" aria-label="Primary">
        <Link href="/" className="logo" style={{ padding: "6px 12px 14px" }}><span className="logo-mark" /> NEXORA</Link>
        <nav aria-label="Main navigation" className="stack" style={{ gap: 2 }}>
          <NavLinks items={PRIMARY_NAV} pathname={pathname} />
          <hr style={{ border: 0, borderTop: "1px solid var(--border-soft)", width: "100%", margin: "8px 0" }} />
          <NavLinks items={SECONDARY_NAV} pathname={pathname} />
        </nav>
        <div style={{ marginTop: "auto", padding: 12 }}><SimBadge>SIMULATED ACCOUNT</SimBadge><p className="muted" style={{ fontSize: 12, marginTop: 6 }}>{actor ? `${logout ? "Signed in as" : "Acting as"} ${actor.userId} (${actor.role})${logout ? "" : " — development actor"}` : "Not signed in."}</p>{logout ? <form action={logout} style={{ marginTop: 8 }}><button type="submit" className="btn btn-sm btn-ghost">Log out</button></form> : !actor ? <Link href="/login" className="btn btn-sm" style={{ marginTop: 8 }}>Log in</Link> : null}</div>
      </aside>
      <div className="shell-main">
        <header className="topbar">
          <Link href="/" className="logo"><span className="logo-mark" /> NEXORA</Link>
          <span style={{ display: "flex", gap: 8, alignItems: "center" }}><span className="muted" style={{ fontSize: 12 }}>{actor ? `${actor.userId} · ${actor.role}` : "not signed in"}</span>{logout ? <form action={logout}><button type="submit" className="btn btn-sm btn-ghost">Log out</button></form> : !actor ? <Link href="/login" className="btn btn-sm">Log in</Link> : null}</span>
        </header>
        <main id="main" className="page" tabIndex={-1}>{children}</main>
        <nav className="bottom-nav" aria-label="Mobile navigation">
          {PRIMARY_NAV.map((it) => (
            <Link key={it.href} href={it.href} className="bn-item" aria-current={isActive(pathname, it) ? "page" : undefined}>
              <Icon name={it.icon} /> {it.label}
            </Link>
          ))}
          <details className="more">
            <summary className="bn-item" aria-current={moreActive ? "page" : undefined} aria-label="More pages"><Icon name="more" /> More</summary>
            <div className="more-menu">
              {SECONDARY_NAV.map((it) => (
                <Link key={it.href} href={it.href} className="nav-link" aria-current={isActive(pathname, it) ? "page" : undefined}
                  onClick={(e: MouseEvent<HTMLAnchorElement>) => e.currentTarget.closest("details")?.removeAttribute("open")}>
                  <Icon name={it.icon} /> {it.label}
                </Link>
              ))}
            </div>
          </details>
        </nav>
      </div>
    </div>
  );
}
