export function DemoBanner() {
  return (
    <div className="demo-banner" role="status" aria-label="Demo mode indicator">
      <strong>DEMO MODE</strong>
      <span>Simulated balances, orders and prices. No real funds or cryptocurrency.</span>
    </div>
  );
}
