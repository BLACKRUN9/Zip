"use client";
import { useActionState } from "react";
import { IDLE, type FormAction, type FormState } from "../../lib/ui/form-state";

function Result({ state }: { state: FormState }) {
  return <div aria-live="polite">{state.status !== "idle" ? <p className={`alert ${state.status === "ok" ? "alert-ok" : "alert-err"}`} style={{ overflowWrap: "anywhere" }}>{state.message}</p> : null}</div>;
}

export function ImportForm({ markets, action, defaultMap }: { markets: string[]; action: FormAction; defaultMap: string }) {
  const [state, formAction, pending] = useActionState<FormState, FormData>(action, IDLE);
  return (
    <form action={formAction} className="stack" aria-label="Import bots from CSV">
      <div className="field"><label className="label" htmlFor="im-market">Market</label>
        <select id="im-market" name="market" className="select" defaultValue={markets[0]}>{markets.map((m) => <option key={m} value={m}>{m}</option>)}</select></div>
      <div className="field"><label className="label" htmlFor="im-map">Account mapping (EXTERNAL_ID=nexora_account, comma separated)</label>
        <input id="im-map" name="map" className="input" defaultValue={defaultMap} autoComplete="off" spellCheck={false} /></div>
      <div className="field"><label className="label" htmlFor="im-csv">CSV (Name,Field,Value,Edit) — order bots and volume bots</label>
        <textarea id="im-csv" name="csv" className="input" spellCheck={false} required placeholder={"SellS0,Field,Value,Edit\n1,account_id,ACCT1,\n..."} /></div>
      <Result state={state} />
      <button type="submit" className="btn btn-primary" disabled={pending}>{pending ? "Importing…" : "Validate & import (stopped)"}</button>
      <p className="muted" style={{ fontSize: 11 }}>Anything invalid imports nothing. Imported bots start STOPPED. External account ids must be mapped to a NEXORA account explicitly.</p>
    </form>
  );
}

export function ReferenceForm({ market, current, action }: { market: string; current: string; action: FormAction }) {
  const [state, formAction, pending] = useActionState<FormState, FormData>(action, IDLE);
  return (
    <form action={formAction} className="stack" style={{ gap: 6 }} aria-label={`Reference price for ${market}`}>
      <input type="hidden" name="market" value={market} />
      <label className="label" htmlFor={`ref-${market}`}>{market}</label>
      <div style={{ display: "flex", gap: 6 }}>
        <input id={`ref-${market}`} name="price" className="input" inputMode="decimal" defaultValue={current} autoComplete="off" />
        <button type="submit" className="btn btn-sm" disabled={pending}>Set</button>
      </div>
      {state.status === "error" ? <p className="field-error">{state.message}</p> : state.status === "ok" ? <p className="up" style={{ fontSize: 12 }}>Updated</p> : null}
    </form>
  );
}

export function CloneForm({ id, suggestion, action }: { id: string; suggestion: string; action: FormAction }) {
  const [state, formAction, pending] = useActionState<FormState, FormData>(action, IDLE);
  return (
    <form action={formAction} className="stack" style={{ gap: 6 }} aria-label={`Clone ${id}`}>
      <input type="hidden" name="id" value={id} />
      <div className="row-actions">
        <label className="sr-only" htmlFor={`cl-${id}`}>New bot name</label>
        <input id={`cl-${id}`} name="name" className="input" style={{ maxWidth: 200, minHeight: 34, fontSize: 14 }} defaultValue={suggestion} autoComplete="off" />
        <button type="submit" className="btn btn-sm" disabled={pending}>Clone</button>
      </div>
      <Result state={state} />
    </form>
  );
}

export function FieldsEditor({ id, fields, disabled, action }: { id: string; fields: Record<string, string>; disabled: boolean; action: FormAction }) {
  const [state, formAction, pending] = useActionState<FormState, FormData>(action, IDLE);
  return (
    <form action={formAction} className="stack" aria-label={`Edit configuration of ${id}`}>
      <input type="hidden" name="id" value={id} />
      <div className="kv">
        {Object.entries(fields).map(([k, v]) => (
          <div key={k} style={{ display: "contents" }}>
            <label htmlFor={`${id}-${k}`}>{k}</label>
            <input id={`${id}-${k}`} name={`f:${k}`} className="input" defaultValue={v} disabled={disabled} autoComplete="off" spellCheck={false} />
          </div>
        ))}
      </div>
      <Result state={state} />
      <div className="row-actions">
        <button type="submit" className="btn btn-primary btn-sm" disabled={disabled || pending}>{pending ? "Saving…" : "Save configuration"}</button>
        {disabled ? <span className="muted" style={{ fontSize: 12 }}>Stop the bot to edit (or you lack permission).</span> : null}
      </div>
    </form>
  );
}
