import { formatGrouped } from "../../lib/money/format";
import type { PanelBot } from "../../server/demo/mm";
import type { FormAction } from "../../lib/ui/form-state";
import { StatusBadge } from "../ui/primitives";
import { CloneForm, FieldsEditor } from "./bot-forms";

interface Actions { start: (f: FormData) => Promise<void>; stop: (f: FormData) => Promise<void>; remove: (f: FormData) => Promise<void>; clone: FormAction; save: FormAction }

const fmtMs = (ms: number) => (ms >= 60_000 ? `${Math.floor(ms / 60_000)}m ${Math.floor((ms % 60_000) / 1000)}s` : `${Math.ceil(ms / 1000)}s`);

export function BotCard({ bot, quoteDecimals, baseDecimals, actions }: { bot: PanelBot; quoteDecimals: number; baseDecimals: number; actions: Actions }) {
  const idField = <input type="hidden" name="id" value={bot.id} />;
  return (
    <section className="card" aria-label={`Bot ${bot.name}`}>
      <header className="card-h">
        <div className="bot-head" style={{ width: "100%" }}>
          <div style={{ minWidth: 0 }}>
            <h2 style={{ fontSize: 14 }}>{bot.name} <span className="muted" style={{ fontWeight: 400 }}>({bot.id})</span></h2>
            <p className="muted" style={{ fontSize: 12 }}>{bot.kind === "order" ? "ORDER BOT" : "VOLUME BOT"} · {bot.market} · {bot.mode} · account {bot.accounts.join(" → ")}</p>
          </div>
          <div className="row-actions">
            <span className={`badge ${bot.running ? "badge-ok" : ""}`}>{bot.running ? "RUNNING" : "STOPPED"}</span>
            {bot.kind === "volume" ? <span className="badge badge-sim">SYNTHETIC VOLUME</span> : null}
          </div>
        </div>
      </header>
      <div className="card-b stack">
        {bot.canManage ? (
          <div className="row-actions">
            <form action={bot.running ? actions.stop : actions.start}>{idField}<button type="submit" className={`btn btn-sm ${bot.running ? "" : "btn-primary"}`}>{bot.running ? "Stop" : "Start"}</button></form>
            <form action={actions.remove}>{idField}<button type="submit" className="btn btn-sm btn-ghost" disabled={bot.running} title={bot.running ? "Stop first" : "Remove bot"}>Remove</button></form>
            <CloneForm id={bot.id} suggestion={`${bot.name} copy`.slice(0, 32)} action={actions.clone} />
          </div>
        ) : <p className="alert alert-info">View only: this bot uses an account you do not control.</p>}

        {bot.order ? (
          <>
            <p className="num muted" style={{ fontSize: 12 }}>placed {bot.order.placed} · cancelled {bot.order.cancelled} · filled {formatGrouped(BigInt(bot.order.filledQty), baseDecimals, { minFraction: 2 })} {bot.market.split("-")[0]}</p>
            {bot.order.live.length ? (
              <div className="table-wrap"><table className="tbl">
                <caption className="sr-only">Live orders of {bot.name}</caption>
                <thead><tr><th scope="col">Side</th><th scope="col">Level</th><th scope="col" className="r">Price</th><th scope="col" className="r">Remaining</th><th scope="col" className="r">Expires in</th></tr></thead>
                <tbody>{bot.order.live.map((o) => (<tr key={o.orderId}><td className={o.side === "BUY" ? "up" : "down"}>{o.side}</td><td>{o.level + 1}</td><td className="num r">{formatGrouped(BigInt(o.price), quoteDecimals)}</td><td className="num r">{formatGrouped(BigInt(o.remaining), baseDecimals, { minFraction: 2 })}</td><td className="num r">{fmtMs(o.expiresInMs)}</td></tr>))}</tbody>
              </table></div>
            ) : <p className="muted" style={{ fontSize: 12 }}>No live orders.</p>}
          </>
        ) : null}
        {bot.volume ? (
          <p className="num muted" style={{ fontSize: 12 }}>
            {bot.volume.mode === "cross" ? "cross mode" : "book mode"} · generated {formatGrouped(BigInt(bot.volume.generated), quoteDecimals)} (quote) in {bot.volume.trades} trade(s)
            {bot.running ? ` · next in ${fmtMs(bot.volume.nextInMs)}` : ""}{bot.volume.idle ? " · idle (above start threshold)" : ""}
          </p>
        ) : null}

        <details>
          <summary>Configuration (Field / Value)</summary>
          <FieldsEditor id={bot.id} fields={bot.fields} disabled={bot.running || !bot.canManage} action={actions.save} />
        </details>
      </div>
    </section>
  );
}

export { StatusBadge };
