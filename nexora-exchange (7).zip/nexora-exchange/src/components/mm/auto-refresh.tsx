"use client";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";

/** Re-renders the server component tree on an interval (no client-side state about bots). */
export function AutoRefresh({ everyMs = 3000 }: { everyMs?: number }) {
  const router = useRouter();
  const [on, setOn] = useState(true);
  useEffect(() => {
    if (!on) return;
    const id = setInterval(() => { if (document.visibilityState === "visible") router.refresh(); }, everyMs);
    return () => clearInterval(id);
  }, [on, everyMs, router]);
  return (
    <label style={{ display: "flex", gap: 6, alignItems: "center", fontSize: 12 }} className="muted">
      <input type="checkbox" checked={on} onChange={() => setOn((v) => !v)} /> Live updates ({everyMs / 1000}s)
    </label>
  );
}
