"use client";
import { useActionState, useRef } from "react";
import { IDLE, newIdempotencyKey, type FormAction, type FormState } from "../../lib/ui/form-state";

export function TransferForm({ assets, action }: { assets: string[]; action: FormAction }) {
  const keyRef = useRef<string | null>(null);
  const [state, formAction, pending] = useActionState<FormState, FormData>(async (prev, fd) => {
    keyRef.current ??= newIdempotencyKey();
    fd.set("idempotencyKey", keyRef.current);
    try {
      const res = await action(prev, fd);
      keyRef.current = null;
      return res;
    } catch {
      return { status: "error", message: "Could not reach the server, so nothing was confirmed. You can safely retry.", fieldErrors: {} };
    }
  }, IDLE);
  return (
    <form action={formAction} className="stack" noValidate aria-label="Create a simulated deposit or withdrawal request">
      <div className="field">
        <label className="label" htmlFor="tf-kind">Request type</label>
        <select id="tf-kind" name="kind" className="select" defaultValue="DEPOSIT"><option value="DEPOSIT">Simulated deposit</option><option value="WITHDRAWAL">Simulated withdrawal</option></select>
      </div>
      <div className="field">
        <label className="label" htmlFor="tf-asset">Asset</label>
        <select id="tf-asset" name="asset" className="select" defaultValue={assets[0]}>{assets.map((a) => (<option key={a} value={a}>{a}</option>))}</select>
      </div>
      <div className="field">
        <label className="label" htmlFor="tf-amount">Amount</label>
        <input id="tf-amount" name="amount" className="input" inputMode="decimal" autoComplete="off" placeholder="0.00" aria-invalid={state.fieldErrors.amount ? true : undefined} aria-describedby={state.fieldErrors.amount ? "tf-amount-err" : undefined} />
        {state.fieldErrors.amount ? <p id="tf-amount-err" className="field-error">{state.fieldErrors.amount}</p> : null}
      </div>
      <div aria-live="polite">{state.status !== "idle" ? <p className={`alert ${state.status === "ok" ? "alert-ok" : "alert-err"}`}>{state.message}</p> : null}</div>
      <button type="submit" className="btn btn-primary" disabled={pending}>{pending ? "Submitting…" : "Create simulated request"}</button>
      <p className="muted" style={{ fontSize: 11 }}>No payment provider and no blockchain are involved. Requests remain pending until an admin decision.</p>
    </form>
  );
}
