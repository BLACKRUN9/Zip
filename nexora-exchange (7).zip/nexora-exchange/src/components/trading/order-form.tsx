"use client";
import { useActionState, useMemo, useRef, useState, type ChangeEvent } from "react";
import { formatGrouped } from "../../lib/money/format";
import { estimateOrder } from "../../lib/trading/estimate";
import { IDLE, newIdempotencyKey, type FormAction, type FormState } from "../../lib/ui/form-state";

export interface OrderFormProps {
  market: string; baseSymbol: string; quoteSymbol: string; baseDecimals: number; quoteDecimals: number;
  takerFeeBps: number; makerFeeBps: number; minQty: string; minNotional: string;
  refBuy: string | null; refSell: string | null; availableBase: string; availableQuote: string;
  action: FormAction;
}

export function OrderForm(p: OrderFormProps) {
  const [side, setSide] = useState<"BUY" | "SELL">("BUY");
  const [type, setType] = useState<"MARKET" | "LIMIT">("LIMIT");
  const [qty, setQty] = useState("");
  const [price, setPrice] = useState("");
  const keyRef = useRef<string | null>(null);

  const [state, formAction, pending] = useActionState<FormState, FormData>(async (prev, fd) => {
    keyRef.current ??= newIdempotencyKey(); // stable across network retries of the same attempt
    fd.set("idempotencyKey", keyRef.current);
    try {
      const res = await p.action(prev, fd);
      keyRef.current = null; // the server has processed it; the next submit is a new order
      if (res.status === "ok") setQty("");
      return res;
    } catch {
      // Network/server failure: keep the SAME idempotency key so a retry can never create a duplicate order.
      return { status: "error", message: "Could not reach the server, so nothing was confirmed. You can safely retry.", fieldErrors: {} };
    }
  }, IDLE);

  const ref = side === "BUY" ? p.refBuy : p.refSell;
  const est = useMemo(() => estimateOrder({
    side, type, qty, price, baseDecimals: p.baseDecimals, quoteDecimals: p.quoteDecimals, takerFeeBps: p.takerFeeBps, makerFeeBps: p.makerFeeBps,
    referencePrice: ref === null ? null : BigInt(ref), minQty: BigInt(p.minQty), minNotional: BigInt(p.minNotional),
    availableBase: BigInt(p.availableBase), availableQuote: BigInt(p.availableQuote),
  }), [side, type, qty, price, ref, p.baseDecimals, p.quoteDecimals, p.takerFeeBps, p.makerFeeBps, p.minQty, p.minNotional, p.availableBase, p.availableQuote]);

  const q = (v: bigint) => formatGrouped(v, p.quoteDecimals);
  const b = (v: bigint) => formatGrouped(v, p.baseDecimals, { minFraction: 2 });
  const qtyErr = (!est.ok && est.errors.qty) || state.fieldErrors.qty;
  const priceErr = (!est.ok && est.errors.price) || state.fieldErrors.price;
  const formErr = !est.ok ? est.errors.form : undefined;
  const canSubmit = est.ok && !est.insufficient && !pending;
  const buy = side === "BUY";

  return (
    <form action={formAction} className="stack" noValidate aria-label={`Place a simulated order on ${p.market}`}>
      <fieldset className="seg" style={{ borderColor: "var(--border)" }}>
        <legend className="sr-only">Side</legend>
        <label className={`seg-item seg-buy ${buy ? "is-on" : ""}`}><input type="radio" name="side" value="BUY" checked={buy} onChange={() => setSide("BUY")} />Buy</label>
        <label className={`seg-item seg-sell ${!buy ? "is-on" : ""}`}><input type="radio" name="side" value="SELL" checked={!buy} onChange={() => setSide("SELL")} />Sell</label>
      </fieldset>
      <fieldset className="seg">
        <legend className="sr-only">Order type</legend>
        <label className={`seg-item ${type === "LIMIT" ? "is-on" : ""}`}><input type="radio" name="type" value="LIMIT" checked={type === "LIMIT"} onChange={() => setType("LIMIT")} />Limit</label>
        <label className={`seg-item ${type === "MARKET" ? "is-on" : ""}`}><input type="radio" name="type" value="MARKET" checked={type === "MARKET"} onChange={() => setType("MARKET")} />Market</label>
      </fieldset>
      <input type="hidden" name="market" value={p.market} />

      <div className="field">
        <label className="label" htmlFor="of-price">Price ({p.quoteSymbol})</label>
        <div className="input-wrap">
          <input id="of-price" name="price" className="input" inputMode="decimal" autoComplete="off" disabled={type === "MARKET"} value={type === "MARKET" ? "" : price}
            onChange={(e: ChangeEvent<HTMLInputElement>) => setPrice(e.target.value)} placeholder={type === "MARKET" ? "Market price" : ref ? q(BigInt(ref)) : "0.00"}
            aria-invalid={priceErr ? true : undefined} aria-describedby={priceErr ? "of-price-err" : undefined} />
          <span className="suffix">{p.quoteSymbol}</span>
        </div>
        {priceErr ? <p id="of-price-err" className="field-error">{priceErr}</p> : null}
      </div>
      <div className="field">
        <label className="label" htmlFor="of-qty">Quantity ({p.baseSymbol})</label>
        <div className="input-wrap">
          <input id="of-qty" name="qty" className="input" inputMode="decimal" autoComplete="off" value={qty} onChange={(e: ChangeEvent<HTMLInputElement>) => setQty(e.target.value)} placeholder="0.00"
            aria-invalid={qtyErr ? true : undefined} aria-describedby={qtyErr ? "of-qty-err" : undefined} />
          <span className="suffix">{p.baseSymbol}</span>
        </div>
        {qtyErr ? <p id="of-qty-err" className="field-error">{qtyErr}</p> : null}
      </div>

      <dl className="dl" aria-label="Order estimate">
        <dt>Available</dt><dd className="num">{buy ? `${q(BigInt(p.availableQuote))} ${p.quoteSymbol}` : `${b(BigInt(p.availableBase))} ${p.baseSymbol}`}</dd>
        <dt>Price basis</dt><dd>{est.ok ? (est.priceBasis === "LIMIT" ? "Your limit" : "Best opposite (estimate)") : "—"}</dd>
        <dt>Order value</dt><dd className="num">{est.ok ? `${q(est.notional)} ${p.quoteSymbol}` : "—"}</dd>
        <dt>Fee (est., up to {Math.max(p.takerFeeBps, p.makerFeeBps) / 100}%)</dt><dd className="num">{est.ok ? `${q(est.fee)} ${p.quoteSymbol}` : "—"}</dd>
        <dt>{buy ? "You pay (est.)" : "You receive (est.)"}</dt><dd className="num" style={{ fontWeight: 700 }}>{est.ok ? `${q(est.total)} ${p.quoteSymbol}` : "—"}</dd>
      </dl>

      {formErr ? <p role="alert" className="alert alert-warn">{formErr}</p> : null}
      {est.ok && est.insufficient ? (
        <p role="alert" className="alert alert-warn">Insufficient balance: this needs {est.neededAsset === "QUOTE" ? `${q(est.needed)} ${p.quoteSymbol}` : `${b(est.needed)} ${p.baseSymbol}`}.</p>
      ) : null}
      <div aria-live="polite">
        {state.status !== "idle" ? <p className={`alert ${state.status === "ok" ? "alert-ok" : "alert-err"}`}>{state.message}</p> : null}
      </div>
      <button type="submit" className={`btn btn-block ${buy ? "btn-buy" : "btn-sell"}`} disabled={!canSubmit}>
        {pending ? "Submitting…" : `${buy ? "Buy" : "Sell"} ${p.baseSymbol} (simulated)`}
      </button>
      <p className="muted" style={{ fontSize: 11 }}>Estimates are a preview. Balances, fills and fees are confirmed by the server. Simulated order — no real funds.</p>
    </form>
  );
}
