import Link from "next/link";

export function MarketNav({ symbols, current }: { symbols: string[]; current: string }) {
  return (
    <nav aria-label="Select market" className="market-pills">
      {symbols.map((s) => (<Link key={s} href={`/trade/${s}`} className="pill" aria-current={s === current ? "page" : undefined}>{s.replace("-", " / ")}</Link>))}
    </nav>
  );
}
