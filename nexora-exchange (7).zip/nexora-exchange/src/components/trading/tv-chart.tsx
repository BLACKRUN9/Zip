"use client";
import { useEffect, useRef, useState } from "react";
import { sma, type Ohlc } from "../../lib/ui/chart-geometry";

interface Series { setData(d: unknown[]): void }
interface Handles { chart: { remove(): void; timeScale(): { fitContent(): void } }; candle: Series; volume: Series; ma: Series }

/** TradingView's open-source Lightweight Charts (v5 API) fed ONLY with NEXORA trades. Volume and MA are toggleable indicators. */
export function TvChart({ candles, quoteDecimals, baseDecimals, showVolume, showMa }: { candles: readonly Ohlc[]; quoteDecimals: number; baseDecimals: number; showVolume: boolean; showMa: boolean }) {
  const host = useRef<HTMLDivElement | null>(null);
  const h = useRef<Handles | null>(null);
  const fitted = useRef(false);
  const [ready, setReady] = useState(false);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let disposed = false;
    import("lightweight-charts").then((lw) => {
      if (disposed || !host.current) return;
      const prec = Math.min(quoteDecimals, 8);
      const chart = lw.createChart(host.current, {
        autoSize: true, height: 340,
        layout: { background: { type: lw.ColorType.Solid, color: "#202936" }, textColor: "#9AA6B8", fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace" },
        grid: { vertLines: { color: "#283348" }, horzLines: { color: "#283348" } },
        rightPriceScale: { borderColor: "#33415a" }, timeScale: { borderColor: "#33415a", timeVisible: true, secondsVisible: false },
      });
      const candle = chart.addSeries(lw.CandlestickSeries, { upColor: "#B9F36B", downColor: "#FF7A85", wickUpColor: "#B9F36B", wickDownColor: "#FF7A85", borderVisible: false, priceFormat: { type: "price", precision: prec, minMove: 1 / 10 ** prec } });
      const volume = chart.addSeries(lw.HistogramSeries, { priceFormat: { type: "volume" }, priceScaleId: "" });
      volume.priceScale().applyOptions({ scaleMargins: { top: 0.8, bottom: 0 } });
      const ma = chart.addSeries(lw.LineSeries, { color: "#6fb3ff", lineWidth: 2, priceLineVisible: false, lastValueVisible: false });
      h.current = { chart, candle, volume, ma } as unknown as Handles;
      setReady(true);
    }).catch(() => { if (!disposed) setFailed(true); });
    return () => { disposed = true; h.current?.chart.remove(); h.current = null; fitted.current = false; };
  }, [quoteDecimals]);

  useEffect(() => {
    const api = h.current;
    if (!api || !ready) return;
    const pf = 10 ** quoteDecimals, bf = 10 ** baseDecimals, t = (ts: number) => Math.floor(ts / 1000);
    api.candle.setData(candles.map((c) => ({ time: t(c.ts), open: Number(c.open) / pf, high: Number(c.high) / pf, low: Number(c.low) / pf, close: Number(c.close) / pf })));
    api.volume.setData(showVolume ? candles.map((c) => ({ time: t(c.ts), value: Number(c.volume ?? 0n) / bf, color: c.close >= c.open ? "rgba(185,243,107,0.45)" : "rgba(255,122,133,0.45)" })) : []);
    const m = sma(candles.map((c) => c.close), 20);
    api.ma.setData(showMa ? candles.flatMap((c, i) => { const v = m[i]; return v === null || v === undefined ? [] : [{ time: t(c.ts), value: Number(v) / pf }]; }) : []);
    if (!fitted.current && candles.length > 0) { api.chart.timeScale().fitContent(); fitted.current = true; }
  }, [candles, showVolume, showMa, ready, quoteDecimals, baseDecimals]);

  if (failed) return <p role="alert" className="alert alert-warn">The TradingView chart library could not be loaded. Use the NEXORA chart tab.</p>;
  if (candles.length === 0) return <p className="muted" style={{ padding: 24, textAlign: "center" }}>No trades yet. Candles appear as soon as trades happen on NEXORA.</p>;
  return <div ref={host} className="tv-host" role="img" aria-label="TradingView Lightweight Charts candlestick chart of NEXORA trades" />;
}
