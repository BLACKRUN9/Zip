import { formatGrouped, formatUtc } from "../../lib/money/format";
import { candleGeometry, sma, timeLabelIndices, volumeBars, type Ohlc } from "../../lib/ui/chart-geometry";

const W = 640, H = 320, VOL_H = 56;

/** NEXORA's own SVG chart: candles from simulated trades, optional volume histogram and moving averages. */
export function CandleChart({ candles, quoteDecimals, label, sourceLabel = "simulated candles (fictional data)", visible = 72, volume = false, maPeriods = [] }:
  { candles: readonly Ohlc[]; quoteDecimals: number; label: string; sourceLabel?: string; visible?: number; volume?: boolean; maPeriods?: number[] }) {
  const shown = candles.slice(-visible);
  if (shown.length === 0) return <p className="muted" style={{ padding: 24, textAlign: "center" }}>No trades yet. Candles appear as soon as trades happen on NEXORA.</p>;
  const g = candleGeometry(shown, { width: W, height: H, padRight: 74, padTop: 10, padBottom: 24 + (volume ? VOL_H + 8 : 0), tickCount: 5 });
  const first = shown[0] as Ohlc, last = shown[shown.length - 1] as Ohlc;
  const timeIdx = timeLabelIndices(shown.length);
  const bars = volume ? volumeBars(shown, { plotWidth: g.plotWidth, baseY: H - 24, maxHeight: VOL_H }) : [];
  const closes = candles.map((c) => c.close);
  const lines = maPeriods.map((p) => {
    const pts = sma(closes, p).slice(-shown.length);
    const d = pts.flatMap((v, i) => (v === null ? [] : [`${g.candles[i]!.cx} ${g.priceY(v)}`])).map((xy, i) => `${i === 0 ? "M" : "L"}${xy}`).join(" ");
    return { p, d };
  });
  return (
    <svg className="chart-svg" viewBox={`0 0 ${W} ${H}`} role="img" aria-label={`${label} candlestick chart (${sourceLabel}), ${shown.length} candles from ${formatUtc(first.ts)} to ${formatUtc(last.ts)} UTC${volume ? ", with volume" : ""}`}>
      <title>{`${label} — ${sourceLabel}`}</title>
      {g.ticks.map((t, ti) => (
        <g key={`tick-${ti}`}>
          <line className="chart-grid" x1={0} x2={g.plotWidth} y1={t.y} y2={t.y} />
          <text className="chart-label" x={g.plotWidth + 6} y={t.y + 4}>{formatGrouped(t.price, quoteDecimals)}</text>
        </g>
      ))}
      {bars.map((b, i) => (<rect key={`v${i}`} className={b.up ? "v-up" : "v-down"} x={b.cx - b.w / 2} y={b.y} width={b.w} height={b.h} />))}
      {g.candles.map((c, i) => (
        <g key={i} className={c.up ? "c-up" : "c-down"}>
          <line x1={c.cx} x2={c.cx} y1={c.wickTop} y2={c.wickBottom} strokeWidth={1.5} />
          <rect x={c.cx - c.w / 2} y={c.bodyTop} width={c.w} height={c.bodyHeight} />
        </g>
      ))}
      {lines.map((l, i) => (l.d ? <path key={`ma-${i}`} className={`c-ma c-ma${i}`} d={l.d} fill="none" strokeWidth={1.8} /> : null))}
      {lines.length ? <text className="chart-label" x={6} y={20}>{lines.map((l) => `MA${l.p}`).join(" · ")}</text> : null}
      {volume ? <text className="chart-label" x={6} y={H - 30 - VOL_H}>Vol</text> : null}
      {timeIdx.map((i) => (
        <text key={`time-${i}`} className="chart-label" x={Math.min(Math.max((g.candles[i] as { cx: number }).cx, 24), g.plotWidth - 24)} y={H - 6} textAnchor="middle">{formatUtc((shown[i] as Ohlc).ts).slice(6)}</text>
      ))}
    </svg>
  );
}
