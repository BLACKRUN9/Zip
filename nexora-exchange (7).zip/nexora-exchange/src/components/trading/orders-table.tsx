import type { OrderRow } from "../../server/demo/view";
import { StatusBadge } from "../ui/primitives";

const REASON: Record<string, string> = { INSUFFICIENT_FUNDS: "Insufficient funds", NO_LIQUIDITY: "No liquidity", BELOW_MIN_NOTIONAL: "Below minimum", MARKET_REMAINDER_UNFILLED: "Remainder cancelled", USER_REQUEST: "Cancelled by you" };

export function OrdersTable({ rows, empty, cancelAction, showMarket = true }: { rows: OrderRow[]; empty: string; cancelAction?: (formData: FormData) => Promise<void>; showMarket?: boolean }) {
  if (rows.length === 0) return <p className="muted" style={{ padding: 16, textAlign: "center" }}>{empty}</p>;
  return (
    <div className="table-wrap">
      <table className="tbl">
        <caption className="sr-only">Simulated orders</caption>
        <thead>
          <tr>
            <th scope="col">Time (UTC)</th>{showMarket ? <th scope="col">Market</th> : null}<th scope="col">Side</th><th scope="col">Type</th>
            <th scope="col" className="r">Price</th><th scope="col" className="r">Size</th><th scope="col" className="r">Filled</th><th scope="col">Status</th>{cancelAction ? <th scope="col"><span className="sr-only">Actions</span></th> : null}
          </tr>
        </thead>
        <tbody>
          {rows.map((o) => (
            <tr key={o.id}>
              <td className="num muted">{o.at}</td>{showMarket ? <td>{o.market}</td> : null}
              <td className={o.side === "BUY" ? "up" : "down"}>{o.side}</td><td>{o.type}</td>
              <td className="num r">{o.price}</td><td className="num r">{o.qty}</td><td className="num r">{o.filled}</td>
              <td><StatusBadge status={o.status} />{o.reason ? <span className="muted" style={{ marginLeft: 6, fontSize: 11 }}>{REASON[o.reason] ?? o.reason}</span> : null}</td>
              {cancelAction ? (
                <td>{o.open ? (
                  <form action={cancelAction}>
                    <input type="hidden" name="orderId" value={o.id} />
                    <button type="submit" className="btn btn-ghost btn-sm" aria-label={`Cancel simulated order ${o.id}`}>Cancel</button>
                  </form>) : null}</td>
              ) : null}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
