"use client";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { formatGrouped, formatUtc } from "../../lib/money/format";
import { isCandlePayload, toOhlc, type CandlePayload } from "../../lib/ui/candle-payload";
import { CandleChart } from "./candle-chart";
import { TvChart } from "./tv-chart";

const INTERVALS = [{ m: 1, label: "1m" }, { m: 5, label: "5m" }, { m: 15, label: "15m" }, { m: 60, label: "1h" }];
const REFRESH_MS = 5_000;
class ChartError extends Error {}

function degradedText(d: string): string {
  if (d.startsWith("STALE_CACHE")) return "The data source did not respond, so the last successfully fetched candles are shown.";
  if (d.startsWith("LIVE_FEED_UNAVAILABLE")) return "The data source is unavailable, so fallback candles are shown instead.";
  return "Data may be degraded.";
}
function sourceBadge(p: CandlePayload): { cls: string; text: string } {
  if (p.source === "NEXORA-TRADES") return { cls: "badge-ok", text: "NEXORA · built from simulated trades" };
  if (p.source === "KRAKEN-PUBLIC") return { cls: "badge-ok", text: "LIVE REFERENCE · Kraken public data" };
  return { cls: "badge-sim", text: "SIMULATED SEED DATA" };
}

export function LiveChart({ initial, symbol, label, quoteDecimals, baseDecimals }: { initial: CandlePayload; symbol: string; label: string; quoteDecimals: number; baseDecimals: number }) {
  const [payload, setPayload] = useState<CandlePayload>(initial);
  const [minutes, setMinutes] = useState(initial.intervalMinutes);
  const [view, setView] = useState<"nexora" | "tv">("nexora");
  const [vol, setVol] = useState(true);
  const [ma, setMa] = useState(false);
  const [live, setLive] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const load = useCallback(async (m: number) => {
    abortRef.current?.abort();
    const ac = new AbortController();
    abortRef.current = ac;
    setLoading(true);
    try {
      const res = await fetch(`/api/market/${encodeURIComponent(symbol)}/candles?interval=${m}&limit=240`, { signal: ac.signal, headers: { accept: "application/json" } });
      if (!res.ok) throw new ChartError(res.status === 429 ? "Too many refreshes. Please wait a moment." : "Could not refresh the chart.");
      const data: unknown = await res.json();
      if (!isCandlePayload(data)) throw new ChartError("The server returned unexpected chart data.");
      if (ac.signal.aborted) return;
      setPayload(data);
      setError(null);
    } catch (e) {
      if (ac.signal.aborted) return;
      setError(e instanceof ChartError ? e.message : "Could not refresh the chart.");
    } finally {
      if (abortRef.current === ac) setLoading(false);
    }
  }, [symbol]);

  useEffect(() => {
    if (!live) return;
    const id = setInterval(() => { if (document.visibilityState === "visible") void load(minutes); }, REFRESH_MS);
    return () => clearInterval(id);
  }, [live, minutes, load]);
  useEffect(() => () => abortRef.current?.abort(), []);

  const ohlc = useMemo(() => toOhlc(payload), [payload]);
  const last = payload.candles[payload.candles.length - 1];
  const badge = sourceBadge(payload);
  const q = (v: string) => formatGrouped(BigInt(v), quoteDecimals);

  return (
    <div className="stack">
      <div style={{ display: "flex", flexWrap: "wrap", gap: 8, alignItems: "center", justifyContent: "space-between" }}>
        <div className="tab-row" role="group" aria-label="Chart type">
          <button type="button" className={`btn btn-sm ${view === "nexora" ? "btn-primary" : "btn-ghost"}`} aria-pressed={view === "nexora"} onClick={() => setView("nexora")}>NEXORA</button>
          <button type="button" className={`btn btn-sm ${view === "tv" ? "btn-primary" : "btn-ghost"}`} aria-pressed={view === "tv"} onClick={() => setView("tv")}>TradingView</button>
        </div>
        <div role="group" aria-label="Timeframe" style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
          {INTERVALS.map((i) => (
            <button key={i.m} type="button" className={`btn btn-sm ${minutes === i.m ? "btn-primary" : "btn-ghost"}`} aria-pressed={minutes === i.m}
              onClick={() => { setMinutes(i.m); void load(i.m); }}>{i.label}</button>
          ))}
        </div>
      </div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 12, alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap" }} role="group" aria-label="Indicators">
          <span className="label">Indicators</span>
          <label style={{ display: "flex", gap: 6, alignItems: "center", fontSize: 13 }}><input type="checkbox" checked={vol} onChange={() => setVol((v) => !v)} /> Volume</label>
          <label style={{ display: "flex", gap: 6, alignItems: "center", fontSize: 13 }}><input type="checkbox" checked={ma} onChange={() => setMa((v) => !v)} /> MA 20</label>
        </div>
        <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
          <label style={{ display: "flex", gap: 6, alignItems: "center", fontSize: 12 }} className="muted"><input type="checkbox" checked={live} onChange={() => setLive((v) => !v)} /> Auto-refresh (5s)</label>
          <button type="button" className="btn btn-sm" onClick={() => void load(minutes)} disabled={loading} aria-label="Refresh chart now">{loading ? "Refreshing…" : "↻ Refresh"}</button>
        </div>
      </div>

      <div style={{ display: "flex", flexWrap: "wrap", gap: 8, alignItems: "center" }}>
        <span className={`badge ${badge.cls}`}>{badge.text}</span>
        {payload.synthetic ? <span className="badge badge-sim" title="Some trades were generated by simulation volume bots">Includes SIMULATED bot volume</span> : null}
        <span className="muted" style={{ fontSize: 12 }} role="status" aria-live="polite">Updated {formatUtc(payload.asOf, true)} UTC</span>
      </div>
      {payload.degraded ? <p role="alert" className="alert alert-warn">{degradedText(payload.degraded)}</p> : null}
      {error ? <p role="alert" className="alert alert-err">{error}{" "}<button type="button" className="btn btn-sm" onClick={() => void load(minutes)}>Retry</button></p> : null}

      {view === "nexora"
        ? <CandleChart candles={ohlc} quoteDecimals={quoteDecimals} label={label} visible={80} volume={vol} maPeriods={ma ? [20] : []} sourceLabel="NEXORA simulated trades" />
        : <TvChart candles={ohlc} quoteDecimals={quoteDecimals} baseDecimals={baseDecimals} showVolume={vol} showMa={ma} />}
      {last ? (
        <p className="num muted" style={{ fontSize: 12 }}>
          Latest candle (still forming) · O {q(last.o)} · H {q(last.h)} · L {q(last.l)} · C {q(last.c)} · Vol {formatGrouped(BigInt(last.v), baseDecimals, { minFraction: 2 })}
        </p>
      ) : null}
      <p className="muted" style={{ fontSize: 11 }}>Every candle is built from fills on this SIMULATED exchange. Nothing here is a real market price.</p>
    </div>
  );
}
