import type { CSSProperties } from "react";
import type { DepthRow } from "../../server/demo/view";

const bar = (pct: number): CSSProperties => ({ ["--p" as string]: `${pct}%` });

interface Props { asks: DepthRow[]; bids: DepthRow[]; spread: string | null; spreadPct: string | null; mid: string | null; asOf: string; baseSymbol: string; quoteSymbol: string }

/** Real simulated orders only (users + bots). Cumulative totals, depth bars, best prices emphasised, mid/spread in the middle. */
export function OrderBook({ asks, bids, spread, spreadPct, mid, asOf, baseSymbol, quoteSymbol }: Props) {
  const empty = asks.length === 0 && bids.length === 0;
  return (
    <div className="book">
      {empty ? (
        <div style={{ padding: "28px 16px", textAlign: "center" }}>
          <p style={{ fontWeight: 600 }}>The book is empty</p>
          <p className="muted" style={{ marginTop: 4, fontSize: 12 }}>Orders from users and market-maker bots appear here as soon as they are placed. Nothing is pre-filled.</p>
        </div>
      ) : (
        <div className="book-scroll">
          <table className="tbl book-tbl">
            <caption className="sr-only">Simulated order book for {baseSymbol}/{quoteSymbol}</caption>
            <thead>
              <tr><th scope="col">Price ({quoteSymbol})</th><th scope="col" className="r">Size ({baseSymbol})</th><th scope="col" className="r">Total ({baseSymbol})</th></tr>
            </thead>
            <tbody>
              {asks.map((r, i) => (
                <tr key={`a-${i}`} className={`depth-row depth-ask${i === asks.length - 1 ? " best" : ""}`} style={bar(r.pct)}>
                  <td className="num down">{r.price}</td><td className="num r">{r.qty}</td><td className="num r muted">{r.total}</td>
                </tr>
              ))}
              <tr className="book-mid">
                <td colSpan={3}>
                  <span className="num" style={{ fontSize: 16, fontWeight: 700 }}>{mid ?? "—"}</span>
                  <span className="muted" style={{ marginLeft: 10, fontSize: 12 }}>Spread {spread ?? "—"}{spreadPct ? ` (${spreadPct})` : ""}</span>
                </td>
              </tr>
              {bids.map((r, i) => (
                <tr key={`b-${i}`} className={`depth-row depth-bid${i === 0 ? " best" : ""}`} style={bar(r.pct)}>
                  <td className="num up">{r.price}</td><td className="num r">{r.qty}</td><td className="num r muted">{r.total}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <p className="muted" style={{ fontSize: 11, padding: "8px 12px" }}>SIMULATED orders · {asks.length + bids.length} price levels · as of {asOf} UTC · not a real exchange quote</p>
    </div>
  );
}
