"use client";
import { useState, type ReactNode } from "react";
import { LAYOUT_THEMES, layoutCookie, type LayoutTheme } from "../../lib/ui/layout-theme";

/** Arranges the five terminal panels in one of three layouts. The choice is a cookie (UI preference only) so the server renders the right one first. */
export function TerminalShell({ initial, chart, book, form, trades, orders }: { initial: LayoutTheme; chart: ReactNode; book: ReactNode; form: ReactNode; trades: ReactNode; orders: ReactNode }) {
  const [theme, setTheme] = useState<LayoutTheme>(initial);
  const choose = (t: LayoutTheme) => { setTheme(t); try { document.cookie = layoutCookie(t); } catch { /* cookies blocked: the choice just lasts for this page view */ } };
  return (
    <div className="stack">
      <div className="layout-switch" role="group" aria-label="Terminal layout">
        <span className="label">Layout</span>
        <div className="tab-row">
          {LAYOUT_THEMES.map((t) => (
            <button key={t.id} type="button" className={`btn btn-sm ${theme === t.id ? "btn-primary" : "btn-ghost"}`} aria-pressed={theme === t.id} title={t.hint} onClick={() => choose(t.id)}>{t.label}</button>
          ))}
        </div>
      </div>
      <div className={`terminal terminal-${theme}`}>
        <div className="t-chart">{chart}</div>
        <div className="t-book">{book}</div>
        <div className="t-form">{form}</div>
        <div className="t-trades">{trades}</div>
        <div className="t-orders">{orders}</div>
      </div>
    </div>
  );
}
