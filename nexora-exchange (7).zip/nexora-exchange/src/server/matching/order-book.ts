/**
 * Deterministic in-memory order book with strict price-time priority.
 * Pure logic: no I/O, no clock, no randomness. Persistence and locking live in the DB layer.
 * SIMULATED liquidity only.
 */
export type Side = "BUY" | "SELL";

export interface RestingOrder {
  id: string;
  userId: string;
  side: Side;
  price: bigint; // quote atomic per whole base unit
  remaining: bigint; // base atomic
  seq: number; // monotonically increasing arrival sequence (time priority)
}

export interface IncomingOrder {
  id: string;
  userId: string;
  side: Side;
  /** null = market order */
  limitPrice: bigint | null;
  qty: bigint;
}

export interface Fill {
  makerOrderId: string;
  takerOrderId: string;
  makerUserId: string;
  takerUserId: string;
  price: bigint; // always the maker's resting price
  qty: bigint;
}

export interface MatchResult {
  fills: Fill[];
  remaining: bigint;
  /** Resting remainder (limit orders only); market remainder is cancelled by the caller. */
  rested: RestingOrder | null;
}

export class OrderBook {
  private bids: RestingOrder[] = [];
  private asks: RestingOrder[] = [];
  private seq = 0;

  /** Test/seed helper: add liquidity without matching. */
  addResting(o: Omit<RestingOrder, "seq">): RestingOrder {
    if (o.remaining <= 0n || o.price <= 0n) throw new Error("resting order needs positive price and qty");
    const r: RestingOrder = { ...o, seq: ++this.seq };
    (o.side === "BUY" ? this.bids : this.asks).push(r);
    this.sort();
    return r;
  }

  submit(o: IncomingOrder): MatchResult {
    if (o.qty <= 0n) throw new Error("qty must be positive");
    if (o.limitPrice !== null && o.limitPrice <= 0n) throw new Error("limit price must be positive");
    const book = o.side === "BUY" ? this.asks : this.bids;
    const fills: Fill[] = [];
    let remaining = o.qty;

    for (let i = 0; i < book.length && remaining > 0n; ) {
      const maker = book[i] as RestingOrder;
      const crosses =
        o.limitPrice === null ||
        (o.side === "BUY" ? maker.price <= o.limitPrice : maker.price >= o.limitPrice);
      if (!crosses) break; // book is sorted best-first; nothing further can cross
      if (maker.userId === o.userId) { i++; continue; } // self-trade prevention: skip own resting orders
      const qty = remaining < maker.remaining ? remaining : maker.remaining;
      fills.push({ makerOrderId: maker.id, takerOrderId: o.id, makerUserId: maker.userId, takerUserId: o.userId, price: maker.price, qty });
      maker.remaining -= qty;
      remaining -= qty;
      if (maker.remaining === 0n) book.splice(i, 1); else i++;
    }

    let rested: RestingOrder | null = null;
    if (remaining > 0n && o.limitPrice !== null) {
      rested = this.addResting({ id: o.id, userId: o.userId, side: o.side, price: o.limitPrice, remaining });
    }
    return { fills, remaining, rested };
  }

  /** Deep copy, used to preview a market order without mutating the live book. */
  clone(): OrderBook {
    const c = new OrderBook();
    c.bids = this.bids.map((r) => ({ ...r }));
    c.asks = this.asks.map((r) => ({ ...r }));
    c.seq = this.seq;
    return c;
  }

  cancel(orderId: string): RestingOrder | null {
    for (const side of [this.bids, this.asks]) {
      const idx = side.findIndex((r) => r.id === orderId);
      if (idx >= 0) return side.splice(idx, 1)[0] as RestingOrder;
    }
    return null;
  }

  snapshot(): { bids: readonly RestingOrder[]; asks: readonly RestingOrder[] } {
    return { bids: this.bids.map((r) => ({ ...r })), asks: this.asks.map((r) => ({ ...r })) };
  }

  private sort(): void {
    this.bids.sort((a, b) => (a.price === b.price ? a.seq - b.seq : a.price > b.price ? -1 : 1));
    this.asks.sort((a, b) => (a.price === b.price ? a.seq - b.seq : a.price < b.price ? -1 : 1));
  }
}
