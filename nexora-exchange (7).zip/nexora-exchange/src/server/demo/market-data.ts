import "server-only";
import { ExchangeTradesProvider } from "../market-data/trades";
import type { MarketDataProvider } from "../market-data/provider";
import { getRuntime } from "./runtime";

/** Charts are built ONLY from fills on this simulated exchange (one-to-one with the transactions table). */
const g = globalThis as unknown as { __nexoraTrades?: MarketDataProvider };
export function getMarketData(): { primary: MarketDataProvider; fallback: MarketDataProvider } {
  const p = (g.__nexoraTrades ??= new ExchangeTradesProvider(async (m) => (await getRuntime()).exchange.marketTrades(m)));
  return { primary: p, fallback: p };
}
