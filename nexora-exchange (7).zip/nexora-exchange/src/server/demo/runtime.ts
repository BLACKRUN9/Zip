import "server-only";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { ACCOUNTS, isMmAccount } from "../accounts/directory";
import { makeAuditEvent, type AuditEvent } from "../audit/redact";
import { importBots } from "../mm/config";
import { MarketMakerEngine } from "../mm/engine";
import { LogBuffer } from "../mm/log";
import { VolumeBotEngine } from "../mm/volume-engine";
import { DemoExchange } from "../trading/exchange";
import { MARKETS, MARKET_META, SEED_ADMIN } from "./config";

export interface BotMeta { kind: "order" | "volume"; market: string; accountMap: Record<string, string> }
export interface Runtime { exchange: DemoExchange; references: Map<string, bigint>; mm: MarketMakerEngine; vol: VolumeBotEngine; log: LogBuffer; meta: Map<string, BotMeta>; audit: AuditEvent[]; seededAt: number }
const g = globalThis as unknown as { __nexoraRuntime?: Promise<Runtime>; __nexoraMmTimer?: ReturnType<typeof setInterval> };

/** Process-wide SIMULATED exchange (in-memory; resets on restart). No seeded order book and no fake trades: liquidity comes only from real orders. */
export function getRuntime(): Promise<Runtime> {
  if (!g.__nexoraRuntime) g.__nexoraRuntime = createRuntime().catch((e) => { delete g.__nexoraRuntime; throw e; });
  return g.__nexoraRuntime;
}

const SEED_BALANCES: Record<string, Record<string, bigint>> = {
  user1: { USD: 10_000_000n, USDT: 10_000_000_000n, BTC: 50_000_000n, ETH: 500_000_000n, SOL: 10_000_000_000n, NXR: 100_000_000_000n },
  user2: { USD: 10_000_000n, USDT: 10_000_000_000n, BTC: 50_000_000n, ETH: 500_000_000n, SOL: 10_000_000_000n, NXR: 100_000_000_000n },
  mm: { USD: 100_000_000n, USDT: 5_000_000_000_000n, BTC: 10_000_000_000n, ETH: 100_000_000_000n, SOL: 1_000_000_000_000n, NXR: 500_000_000_000_000n },
  mm2: { USD: 100_000_000n, USDT: 5_000_000_000_000n, BTC: 10_000_000_000n, ETH: 100_000_000_000n, SOL: 1_000_000_000_000n, NXR: 500_000_000_000_000n },
  admin: { USDT: 1_000_000_000n },
};

export async function createRuntime(opts: { autostart?: boolean } = {}): Promise<Runtime> {
  const exchange = new DemoExchange({ markets: MARKETS }); // reads DEMO_MODE from process.env; refuses to run unless "true"
  for (const acc of ACCOUNTS) for (const [asset, amount] of Object.entries(SEED_BALANCES[acc.id] ?? {})) {
    const d = await exchange.requestDeposit(acc.id, { idempotencyKey: `seed-${acc.id}-${asset}`, asset, amount });
    await exchange.decideTransfer(SEED_ADMIN, d.id, "COMPLETE");
  }
  const references = new Map(Object.entries(MARKET_META).map(([k, v]) => [k, v.referencePrice]));
  const log = new LogBuffer();
  const deps = { exchange, markets: new Map(MARKETS.map((m) => [m.symbol, m])), reference: (m: string) => references.get(m) ?? null, isMmAccount, log };
  const mm = new MarketMakerEngine(deps);
  const vol = new VolumeBotEngine(deps);
  const rt: Runtime = { exchange, references, mm, vol, log, meta: new Map(), audit: [], seededAt: Date.now() };
  if (opts.autostart ?? process.env["MM_AUTOSTART"] === "true") await autostart(rt);
  ensureScheduler(rt);
  return rt;
}

function ensureScheduler(rt: Runtime): void {
  if (g.__nexoraMmTimer) clearInterval(g.__nexoraMmTimer);
  let busy = false;
  const timer = setInterval(() => { if (busy) return; busy = true; Promise.all([rt.mm.tick(), rt.vol.tick()]).catch(() => undefined).finally(() => { busy = false; }); }, 500);
  timer.unref?.();
  g.__nexoraMmTimer = timer;
}

/** Operator-level config (server deployment), not a web endpoint. Loads config/mm.config.json and starts the strategies. */
async function autostart(rt: Runtime): Promise<void> {
  try {
    const cfg = JSON.parse(readFileSync(join(process.cwd(), "config", "mm.config.json"), "utf8")) as { csv: string; market: string; accountMap: Record<string, string> };
    const r = importBots(readFileSync(join(process.cwd(), cfg.csv), "utf8"), { market: cfg.market, accountMap: cfg.accountMap });
    if (r.errors.length) { console.error("[nexora] MM autostart: config errors:", r.errors.slice(0, 5)); return; }
    for (const b of r.bots) {
      if (b.kind === "order") { rt.mm.addStrategy(b); await rt.mm.start(b.id); } else { rt.vol.addBot(b); await rt.vol.start(b.id); }
      rt.meta.set(b.id, { kind: b.kind, market: cfg.market, accountMap: cfg.accountMap });
      rt.audit.push(makeAuditEvent("system", "BOT_AUTOSTART", b.id, Date.now(), { market: b.market, account: b.account }));
    }
  } catch (e) { console.error("[nexora] MM autostart failed:", e instanceof Error ? e.message.slice(0, 120) : "error"); }
}
