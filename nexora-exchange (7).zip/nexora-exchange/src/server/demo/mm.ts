import "server-only";
import { canManageStrategy, type Principal } from "../accounts/directory";
import { makeAuditEvent } from "../audit/redact";
import { requirePermission } from "../auth/actor";
import { parseDecimal } from "../../lib/money/decimal";
import { importBots, rebuildBot, type AnyBot } from "../mm/config";
import type { StrategyStatus } from "../mm/engine";
import type { VolStatus } from "../mm/volume-engine";
import { findMarket, MARKETS } from "./config";
import { getRuntime, type Runtime } from "./runtime";

export interface PanelBot { id: string; name: string; kind: "order" | "volume"; account: string; accounts: string[]; market: string; mode: string; running: boolean; canManage: boolean; fields: Record<string, string>; order?: StrategyStatus; volume?: VolStatus }
export interface OpResult { ok: boolean; errors: string[] }
const ok: OpResult = { ok: true, errors: [] };
const fail = (...errors: string[]): OpResult => ({ ok: false, errors });
const ID = /^[a-z0-9_-]{1,32}$/;

const accountsOf = (b: AnyBot) => [b.account, ...(b.kind === "volume" && b.sellAccount ? [b.sellAccount] : [])];
/** ADMIN: any bot. MM: only bots whose EVERY account is its own (so cross-account volume bots are ADMIN-only). */
const manageable = (a: Principal, b: AnyBot) => accountsOf(b).every((acc) => canManageStrategy(a, acc));
const botOf = (rt: Runtime, id: string): AnyBot | null => rt.mm.strategy(id) ?? rt.vol.bot(id);
const audit = (rt: Runtime, a: Principal, action: string, target: string, meta: unknown = {}) => rt.audit.push(makeAuditEvent(a.userId, action, target, Date.now(), meta));

function parseMap(text: string): Record<string, string> | string {
  const out: Record<string, string> = {};
  for (const part of text.split(",").map((x) => x.trim()).filter(Boolean)) {
    const m = /^([A-Za-z0-9_.-]{1,40})=([a-z0-9]{1,32})$/.exec(part);
    if (!m) return `Invalid account mapping "${part.slice(0, 30)}" (use EXTERNAL_ID=nexora_account, comma separated)`;
    out[m[1] as string] = m[2] as string;
  }
  return out;
}

export async function panelSnapshot(actor: Principal | null) {
  const a = requirePermission(actor, "mm:view");
  const rt = await getRuntime();
  const visible = (b: AnyBot) => a.role === "ADMIN" || accountsOf(b).includes(a.userId);
  const bots: PanelBot[] = [];
  const os = new Map(rt.mm.status().map((s) => [s.id, s])); const vs = new Map(rt.vol.status().map((s) => [s.id, s]));
  for (const [id, st] of os) { const b = rt.mm.strategy(id); if (b && visible(b)) bots.push({ id, name: b.name, kind: "order", account: b.account, accounts: accountsOf(b), market: b.market, mode: b.side, running: st.running, canManage: manageable(a, b), fields: b.fields, order: st }); }
  for (const [id, st] of vs) { const b = rt.vol.bot(id); if (b && visible(b)) bots.push({ id, name: b.name, kind: "volume", account: b.account, accounts: accountsOf(b), market: b.market, mode: st.mode, running: st.running, canManage: manageable(a, b), fields: b.fields, volume: st }); }
  const ids = new Set(bots.map((b) => b.id));
  return {
    actor: a, bots,
    logs: rt.log.recent(80).filter((l) => ids.has(l.strategyId)),
    references: MARKETS.map((m) => ({ market: m.symbol, price: rt.references.get(m.symbol) ?? 0n, decimals: m.quote.decimals })),
    synthetic: MARKETS.map((m) => ({ market: m.symbol, trades: rt.vol.syntheticCount(m.symbol) })).filter((x) => x.trades > 0),
  };
}

type Op = "start" | "stop" | "remove";
export async function botOp(actor: Principal | null, id: string, op: Op): Promise<OpResult> {
  const a = requirePermission(actor, "mm:control");
  if (!ID.test(id)) return fail("Invalid bot id");
  const rt = await getRuntime(); const b = botOf(rt, id);
  if (!b || !manageable(a, b)) return fail("Bot not found"); // same answer for missing and not-yours (no oracle)
  try {
    const eng = b.kind === "order" ? rt.mm : rt.vol;
    if (op === "start") await eng.start(id); else if (op === "stop") await eng.stop(id);
    else { if (b.kind === "order") await rt.mm.removeStrategy(id); else await rt.vol.removeBot(id); rt.meta.delete(id); }
    audit(rt, a, `BOT_${op.toUpperCase()}`, id, { kind: b.kind, market: b.market });
    return ok;
  } catch (e) { return fail(e instanceof Error ? e.message.slice(0, 160) : "Operation failed"); }
}

function register(rt: Runtime, b: AnyBot, accountMap: Record<string, string>): void {
  if (b.kind === "order") rt.mm.addStrategy(b); else rt.vol.addBot(b);
  rt.meta.set(b.id, { kind: b.kind, market: b.market, accountMap });
}

export async function importCsv(actor: Principal | null, csv: string, market: string, mapText: string): Promise<OpResult & { count: number }> {
  const a = requirePermission(actor, "mm:config");
  if (csv.length > 50_000) return { ...fail("CSV is too large (max 50 KB)"), count: 0 };
  if (!findMarket(market)) return { ...fail("Unknown market"), count: 0 };
  const map = parseMap(mapText); if (typeof map === "string") return { ...fail(map), count: 0 };
  const rt = await getRuntime();
  const r = importBots(csv, { market, accountMap: map });
  if (r.errors.length) return { ok: false, errors: r.errors.slice(0, 12), count: 0 };
  const denied = r.bots.filter((b) => !manageable(a, b));
  if (denied.length) return { ok: false, errors: [`You cannot create bots for account(s): ${[...new Set(denied.flatMap(accountsOf))].join(", ")}`], count: 0 };
  const dup = r.bots.filter((b) => botOf(rt, b.id));
  if (dup.length) return { ok: false, errors: [`Bot id already exists: ${dup.map((b) => b.id).join(", ")}`], count: 0 };
  try { for (const b of r.bots) register(rt, b, map); } catch (e) { return { ok: false, errors: [e instanceof Error ? e.message.slice(0, 160) : "Import failed"], count: 0 }; }
  audit(rt, a, "BOT_IMPORT", market, { count: r.bots.length, ids: r.bots.map((b) => b.id) });
  return { ...ok, count: r.bots.length };
}

export async function cloneBot(actor: Principal | null, id: string, newName: string): Promise<OpResult> {
  const a = requirePermission(actor, "mm:config");
  if (!ID.test(id)) return fail("Invalid bot id");
  const name = newName.trim().slice(0, 32);
  if (!/^[A-Za-z0-9 _-]{1,32}$/.test(name)) return fail("Name may use letters, digits, space, - and _ (max 32)");
  const rt = await getRuntime(); const src = botOf(rt, id); const meta = rt.meta.get(id);
  if (!src || !meta || !manageable(a, src)) return fail("Bot not found");
  const r = rebuildBot(src.kind, name, src.fields, { market: meta.market, accountMap: meta.accountMap });
  if (!r.bot) return fail(...r.errors);
  if (botOf(rt, r.bot.id)) return fail(`A bot named "${name}" already exists`);
  try { register(rt, r.bot, meta.accountMap); } catch (e) { return fail(e instanceof Error ? e.message.slice(0, 160) : "Clone failed"); }
  audit(rt, a, "BOT_CLONE", r.bot.id, { from: id });
  return ok;
}

/** Edit raw fields of a STOPPED bot (same validation as import). */
export async function saveBot(actor: Principal | null, id: string, fields: Record<string, string>): Promise<OpResult> {
  const a = requirePermission(actor, "mm:config");
  if (!ID.test(id)) return fail("Invalid bot id");
  const rt = await getRuntime(); const cur = botOf(rt, id); const meta = rt.meta.get(id);
  if (!cur || !meta || !manageable(a, cur)) return fail("Bot not found");
  const running = cur.kind === "order" ? rt.mm.status().find((s) => s.id === id)?.running : rt.vol.status().find((s) => s.id === id)?.running;
  if (running) return fail("Stop the bot before editing its configuration");
  const clean: Record<string, string> = {};
  for (const [k, v] of Object.entries(fields)) clean[k.slice(0, 60)] = String(v).slice(0, 400).trim();
  const r = rebuildBot(cur.kind, cur.name, clean, { market: meta.market, accountMap: meta.accountMap });
  if (!r.bot) return fail(...r.errors);
  if (!manageable(a, r.bot)) return fail("You cannot assign that account");
  try {
    if (cur.kind === "order") await rt.mm.removeStrategy(id); else await rt.vol.removeBot(id);
    register(rt, r.bot, meta.accountMap);
  } catch (e) { return fail(e instanceof Error ? e.message.slice(0, 160) : "Save failed"); }
  audit(rt, a, "BOT_EDIT", id, { fields: Object.keys(clean) });
  return ok;
}

export async function setReference(actor: Principal | null, market: string, price: string): Promise<OpResult> {
  const a = requirePermission(actor, "mm:config");
  const m = findMarket(market); if (!m) return fail("Unknown market");
  let p = 0n; try { p = parseDecimal(price, m.quote.decimals); } catch { return fail(`Enter a positive price (max ${m.quote.decimals} decimals)`); }
  if (p <= 0n) return fail("Price must be greater than zero");
  const rt = await getRuntime(); rt.references.set(market, p);
  audit(rt, a, "REFERENCE_SET", market, { price: p.toString() });
  return ok;
}
