import "server-only";
import { RateLimiter } from "../security/rate-limit";
import { candlesWithFallback, toPayload } from "../market-data/service";
import { ProviderError, validateRequest, type MarketDataProvider } from "../market-data/provider";
import { findMarket } from "./config";
import { getMarketData } from "./market-data";
import { getRuntime } from "./runtime";

export interface ApiDeps { primary: MarketDataProvider; fallback: MarketDataProvider; limiter: RateLimiter; synthetic?: (market: string) => Promise<boolean> }
const g = globalThis as unknown as { __nexoraLimiter?: RateLimiter };
const defaultDeps = (): ApiDeps => ({ ...getMarketData(), limiter: (g.__nexoraLimiter ??= new RateLimiter(120, 60_000)), synthetic: async (m) => (await getRuntime()).vol.syntheticCount(m) > 0 });
const json = (body: unknown, status = 200, headers: Record<string, string> = {}) => Response.json(body, { status, headers: { "Cache-Control": "no-store", ...headers } });
const err = (status: number, code: string, message: string, headers: Record<string, string> = {}) => json({ error: { code, message } }, status, headers);

/** GET /api/market/:symbol/candles?interval=15&limit=120 — read-only, validated, rate limited, generic errors. */
export async function handleCandles(request: Request, symbol: string, deps: ApiDeps = defaultDeps()): Promise<Response> {
  const market = findMarket(symbol.toUpperCase());
  if (!market) return err(404, "UNKNOWN_MARKET", "Unknown market");
  const ip = (request.headers.get("x-forwarded-for") ?? "unknown").split(",")[0]!.trim().slice(0, 64);
  const rl = deps.limiter.check(ip);
  if (!rl.allowed) return err(429, "RATE_LIMITED", "Too many requests. Please wait a moment.", { "Retry-After": String(Math.ceil(rl.retryAfterMs / 1000)) });
  const q = new URL(request.url).searchParams;
  const req = { market: market.symbol, intervalMinutes: Number(q.get("interval") ?? 15), limit: Number(q.get("limit") ?? 120) };
  try { validateRequest(req); } catch { return err(400, "INVALID_REQUEST", "Invalid interval or limit"); }
  try {
    return json(toPayload(req, await candlesWithFallback(deps.primary, deps.fallback, req), deps.synthetic ? await deps.synthetic(market.symbol) : false));
  } catch (e) {
    console.error("[nexora] candles failed:", e instanceof ProviderError ? e.code : "unknown"); // no details to the client
    return err(502, "MARKET_DATA_UNAVAILABLE", "Market data is temporarily unavailable.");
  }
}
