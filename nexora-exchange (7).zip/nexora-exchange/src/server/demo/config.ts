import type { MarketConfig } from "../trading/exchange";

export const SEED_ADMIN = { userId: "system-seed", role: "ADMIN" as const };
const USD = { symbol: "USD", decimals: 2 };
const USDT = { symbol: "USDT", decimals: 6 };
const fees = { takerFeeBps: 25, makerFeeBps: 10 };

export const MARKETS: readonly MarketConfig[] = [
  { symbol: "NXR-USDT", base: { symbol: "NXR", decimals: 8 }, quote: USDT, ...fees, minQty: 1_000_000n, minNotional: 10_000n },
  { symbol: "BTC-USD", base: { symbol: "BTC", decimals: 8 }, quote: USD, ...fees, minQty: 10_000n, minNotional: 100n },
  { symbol: "ETH-USD", base: { symbol: "ETH", decimals: 8 }, quote: USD, ...fees, minQty: 100_000n, minNotional: 100n },
  { symbol: "SOL-USD", base: { symbol: "SOL", decimals: 8 }, quote: USD, ...fees, minQty: 1_000_000n, minNotional: 100n },
];

/** `referencePrice` (quote atomic units per whole base) is what bots with price_source=reference quote from. Editable by MM/ADMIN. */
export const MARKET_META: Record<string, { name: string; referencePrice: bigint }> = {
  "NXR-USDT": { name: "NEXORA demo token (simulated)", referencePrice: 4_000_000n },
  "BTC-USD": { name: "Bitcoin (simulated)", referencePrice: 6_400_000n },
  "ETH-USD": { name: "Ethereum (simulated)", referencePrice: 176_000n },
  "SOL-USD": { name: "Solana (simulated)", referencePrice: 7_400n },
};
export const DEFAULT_MARKET = "NXR-USDT";
export const findMarket = (symbol: string) => MARKETS.find((m) => m.symbol === symbol);
