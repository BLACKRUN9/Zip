import "server-only";
import { MoneyError, parseDecimal } from "../../lib/money/decimal";
import { DemoModeError } from "../config/demo-guard";
import { ExchangeError } from "../trading/exchange";
import { MARKETS, findMarket } from "./config";
import { getRuntime } from "./runtime";

import type { FormState } from "../../lib/ui/form-state";
const fail = (message: string, fieldErrors: Record<string, string> = {}): FormState => ({ status: "error", message, fieldErrors });

const REASONS: Record<string, string> = {
  INSUFFICIENT_FUNDS: "Insufficient available balance (confirmed by the server). Nothing was reserved.",
  NO_LIQUIDITY: "No simulated liquidity is available for this market order.",
  BELOW_MIN_NOTIONAL: "The order value is below the market minimum.",
};

function safeError(e: unknown): FormState {
  if (e instanceof ExchangeError) return fail(e.message);
  if (e instanceof DemoModeError) return fail("The server is not configured for demo mode, so this operation is disabled.");
  console.error("[nexora] unexpected error", e instanceof Error ? e.name : "unknown"); // never send details to the client
  return fail("Something went wrong. Please try again.");
}

export interface OrderRequest { idempotencyKey: string; market: string; side: string; type: string; qty: string; price: string }

export async function submitOrder(userId: string, r: OrderRequest): Promise<FormState> {
  const m = findMarket(r.market);
  if (!m) return fail("Unknown market");
  if (r.side !== "BUY" && r.side !== "SELL") return fail("Choose Buy or Sell");
  if (r.type !== "MARKET" && r.type !== "LIMIT") return fail("Choose Market or Limit");
  const fieldErrors: Record<string, string> = {};
  let qty = 0n; let price: bigint | null = null;
  try { qty = parseDecimal(r.qty, m.base.decimals); } catch (e) { fieldErrors.qty = e instanceof MoneyError && e.code === "PRECISION_EXCEEDED" ? `At most ${m.base.decimals} decimal places` : "Enter a positive number"; }
  if (r.type === "LIMIT") { try { price = parseDecimal(r.price, m.quote.decimals); } catch (e) { fieldErrors.price = e instanceof MoneyError && e.code === "PRECISION_EXCEEDED" ? `At most ${m.quote.decimals} decimal places` : "Enter a positive price"; } }
  if (Object.keys(fieldErrors).length) return fail("Please correct the highlighted fields.", fieldErrors);
  try {
    const { exchange } = await getRuntime();
    const res = await exchange.placeOrder({ idempotencyKey: r.idempotencyKey, userId, market: m.symbol, side: r.side, type: r.type, qty, price });
    if (res.order.status === "REJECTED") return fail(REASONS[res.order.reason ?? ""] ?? "The order was rejected.");
    const fills = res.fills.length;
    return { status: "ok", message: `SIMULATED order ${res.order.id} is ${res.order.status.replace("_", " ").toLowerCase()} (${fills} simulated fill${fills === 1 ? "" : "s"}).`, fieldErrors: {} };
  } catch (e) { return safeError(e); }
}

export async function cancelOrder(userId: string, orderId: string): Promise<void> {
  try { const { exchange } = await getRuntime(); await exchange.cancelOrder(userId, orderId); }
  catch (e) { if (!(e instanceof ExchangeError)) console.error("[nexora] cancel failed"); } // page re-render shows the true state
}

export interface TransferRequest { idempotencyKey: string; kind: string; asset: string; amount: string }

export async function submitTransfer(userId: string, r: TransferRequest): Promise<FormState> {
  if (r.kind !== "DEPOSIT" && r.kind !== "WITHDRAWAL") return fail("Unknown request type");
  const asset = MARKETS.flatMap((m) => [m.base, m.quote]).find((a) => a.symbol === r.asset);
  if (!asset) return fail("Unknown asset", { asset: "Choose an asset" });
  let amount = 0n;
  try { amount = parseDecimal(r.amount, asset.decimals); if (amount <= 0n) throw new MoneyError("NEGATIVE", "x"); }
  catch { return fail("Please correct the highlighted fields.", { amount: `Enter a positive amount (max ${asset.decimals} decimals)` }); }
  try {
    const { exchange } = await getRuntime();
    const input = { idempotencyKey: r.idempotencyKey, asset: asset.symbol, amount };
    const t = r.kind === "DEPOSIT" ? await exchange.requestDeposit(userId, input) : await exchange.requestWithdrawal(userId, input);
    if (t.status === "REJECTED") return fail("Insufficient available balance for this simulated withdrawal.");
    return { status: "ok", message: `SIMULATED ${t.kind.toLowerCase()} request ${t.id} created. It stays pending until an admin decision (no real money moves).`, fieldErrors: {} };
  } catch (e) { return safeError(e); }
}
