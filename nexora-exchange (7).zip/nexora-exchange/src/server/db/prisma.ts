import { PrismaPg } from "@prisma/adapter-pg";
import { PrismaClient } from "../../generated/prisma/client"; // created by `npx prisma generate` (gitignored)

/** Prisma 7 needs a driver adapter. One client per process (survives dev hot reloads). */
const g = globalThis as unknown as { __nexoraPrisma?: PrismaClient };
export function getPrisma(databaseUrl: string): PrismaClient {
  return (g.__nexoraPrisma ??= new PrismaClient({ adapter: new PrismaPg({ connectionString: databaseUrl }) }));
}
