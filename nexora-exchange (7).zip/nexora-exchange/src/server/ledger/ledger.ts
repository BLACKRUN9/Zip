import { assertBalanced, type JournalEntry } from "./journal";

export class LedgerError extends Error {
  constructor(public readonly code: "DUPLICATE_OPERATION" | "NEGATIVE_BALANCE" | "INVALID_ENTRY", message: string) {
    super(message);
    this.name = "LedgerError";
  }
}

const key = (accountId: string, currency: string) => `${accountId}|${currency}`;

/**
 * Append-only ledger with a balance projection that is ONLY changed by posting balanced entries.
 * Balance = credits - debits. Accounts starting with "user:" may never go negative; system accounts may.
 * The DB-backed version must perform the same checks inside one serializable transaction.
 */
export class Ledger {
  private readonly log: JournalEntry[] = [];
  private readonly ops = new Set<string>();
  private readonly bal = new Map<string, bigint>();

  get entries(): readonly JournalEntry[] { return this.log; }
  balances(): ReadonlyMap<string, bigint> { return this.bal; }
  balance(accountId: string, currency: string): bigint { return this.bal.get(key(accountId, currency)) ?? 0n; }

  post(entry: JournalEntry): JournalEntry {
    if (this.ops.has(entry.operationId)) throw new LedgerError("DUPLICATE_OPERATION", `Operation ${entry.operationId} already posted`);
    let posted: JournalEntry;
    try { posted = assertBalanced(entry); } catch (e) { throw new LedgerError("INVALID_ENTRY", (e as Error).message); }

    const deltas = new Map<string, bigint>();
    for (const l of posted.lines) {
      const k = key(l.accountId, l.currency);
      deltas.set(k, (deltas.get(k) ?? 0n) + l.credit - l.debit);
    }
    for (const [k, d] of deltas) {
      if (k.startsWith("user:") && (this.bal.get(k) ?? 0n) + d < 0n) {
        throw new LedgerError("NEGATIVE_BALANCE", `Posting ${posted.operationId} would make ${k.split("|")[0]} negative`);
      }
    }
    for (const [k, d] of deltas) this.bal.set(k, (this.bal.get(k) ?? 0n) + d);
    this.ops.add(posted.operationId);
    this.log.push(posted);
    return posted;
  }
}
