import { assertBalanced, type JournalEntry, type JournalLine } from "./journal";

export type AccountKind = "available" | "reserved" | "pending";
export const userAccount = (userId: string, asset: string, kind: AccountKind) => `user:${userId}:${asset}:${kind}`;
export const feeAccount = (asset: string) => `system:fees:${asset}`;
export const faucetAccount = (asset: string) => `system:demo-faucet:${asset}`;
export const sinkAccount = (asset: string) => `system:demo-sink:${asset}`;

/** Moves `amount` of one currency from one account to another (debit `from`, credit `to`). */
export function buildTransferJournal(operationId: string, memo: string, currency: string, from: string, to: string, amount: bigint): JournalEntry {
  return assertBalanced({
    operationId, memo,
    lines: [
      { accountId: from, currency, debit: amount, credit: 0n },
      { accountId: to, currency, debit: 0n, credit: amount },
    ],
  });
}

export interface FillJournalParams {
  operationId: string;
  buyerId: string;
  sellerId: string;
  baseSymbol: string;
  quoteSymbol: string;
  qty: bigint;
  notional: bigint;
  buyerFee: bigint;
  sellerFee: bigint;
}

/** Settlement of one SIMULATED fill. Both sides pay from their reserved balance; proceeds go to available. */
export function buildFillJournal(p: FillJournalParams): JournalEntry {
  const lines: JournalLine[] = [
    { accountId: userAccount(p.buyerId, p.quoteSymbol, "reserved"), currency: p.quoteSymbol, debit: p.notional + p.buyerFee, credit: 0n },
    { accountId: userAccount(p.sellerId, p.quoteSymbol, "available"), currency: p.quoteSymbol, debit: 0n, credit: p.notional - p.sellerFee },
    { accountId: feeAccount(p.quoteSymbol), currency: p.quoteSymbol, debit: 0n, credit: p.buyerFee + p.sellerFee },
    { accountId: userAccount(p.sellerId, p.baseSymbol, "reserved"), currency: p.baseSymbol, debit: p.qty, credit: 0n },
    { accountId: userAccount(p.buyerId, p.baseSymbol, "available"), currency: p.baseSymbol, debit: 0n, credit: p.qty },
  ].filter((l) => l.debit > 0n || l.credit > 0n);
  return assertBalanced({ operationId: p.operationId, memo: "SIMULATED fill settlement", lines });
}
