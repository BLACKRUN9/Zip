import { assertBalanced, type JournalEntry } from "./journal";
import { feeOf, notional } from "../../lib/money/trade-math";

export interface TradeParams {
  operationId: string;
  buyerId: string;
  sellerId: string;
  base: { symbol: string; decimals: number };
  quote: { symbol: string };
  qty: bigint;
  price: bigint;
  buyerFeeBps: number;
  sellerFeeBps: number;
  feeAccountId: string;
}

const acct = (user: string, cur: string) => `user:${user}:${cur}:available`;

/** Builds the balanced journal entry for one simulated fill. Fees are charged in the quote asset. */
export function buildTradeJournal(p: TradeParams): JournalEntry {
  const n = notional(p.qty, p.price, p.base.decimals);
  const buyerFee = feeOf(n, p.buyerFeeBps);
  const sellerFee = feeOf(n, p.sellerFeeBps);
  const lines = [
    { accountId: acct(p.buyerId, p.quote.symbol), currency: p.quote.symbol, debit: n + buyerFee, credit: 0n },
    { accountId: acct(p.sellerId, p.quote.symbol), currency: p.quote.symbol, debit: 0n, credit: n - sellerFee },
    { accountId: p.feeAccountId, currency: p.quote.symbol, debit: 0n, credit: buyerFee + sellerFee },
    { accountId: acct(p.sellerId, p.base.symbol), currency: p.base.symbol, debit: p.qty, credit: 0n },
    { accountId: acct(p.buyerId, p.base.symbol), currency: p.base.symbol, debit: 0n, credit: p.qty },
  ].filter((l) => l.debit > 0n || l.credit > 0n);
  return assertBalanced({ operationId: p.operationId, memo: "SIMULATED trade fill", lines });
}
