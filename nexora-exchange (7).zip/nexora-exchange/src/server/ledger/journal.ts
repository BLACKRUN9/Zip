/**
 * Double-entry journal primitives. Pure and immutable by construction (frozen objects).
 * All amounts are atomic-unit bigints. User balances are liability accounts:
 * debit = balance decreases, credit = balance increases.
 */
export interface JournalLine {
  accountId: string;
  currency: string;
  debit: bigint;
  credit: bigint;
}
export interface JournalEntry {
  operationId: string; // globally unique; backs idempotency
  memo: string;
  lines: readonly JournalLine[];
  reversesOperationId?: string;
}

export type ReconIssue =
  | { kind: "UNBALANCED"; operationId: string; currency: string; diff: bigint }
  | { kind: "DUPLICATE_OPERATION"; operationId: string }
  | { kind: "INVALID_LINE"; operationId: string; index: number }
  | { kind: "TOO_FEW_LINES"; operationId: string }
  | { kind: "MISSING_REVERSAL_TARGET"; operationId: string; target: string };

export function checkEntry(e: JournalEntry): ReconIssue[] {
  const issues: ReconIssue[] = [];
  if (e.lines.length < 2) issues.push({ kind: "TOO_FEW_LINES", operationId: e.operationId });
  const totals = new Map<string, bigint>();
  e.lines.forEach((l, index) => {
    const oneSided = (l.debit > 0n && l.credit === 0n) || (l.credit > 0n && l.debit === 0n);
    if (!oneSided || l.debit < 0n || l.credit < 0n) issues.push({ kind: "INVALID_LINE", operationId: e.operationId, index });
    totals.set(l.currency, (totals.get(l.currency) ?? 0n) + l.debit - l.credit);
  });
  for (const [currency, diff] of totals) if (diff !== 0n) issues.push({ kind: "UNBALANCED", operationId: e.operationId, currency, diff });
  return issues;
}

export function assertBalanced(e: JournalEntry): JournalEntry {
  const issues = checkEntry(e);
  if (issues.length) throw new Error(`Refusing to post invalid journal entry ${e.operationId}: ${issues.map((i) => i.kind).join(", ")}`);
  return Object.freeze({ ...e, lines: Object.freeze(e.lines.map((l) => Object.freeze({ ...l }))) });
}

/** Posted entries are never edited; corrections are compensating entries with swapped sides. */
export function compensate(e: JournalEntry, newOperationId: string, memo: string): JournalEntry {
  return assertBalanced({
    operationId: newOperationId,
    memo,
    reversesOperationId: e.operationId,
    lines: e.lines.map((l) => ({ accountId: l.accountId, currency: l.currency, debit: l.credit, credit: l.debit })),
  });
}

/** Detects unbalanced, duplicated, malformed entries and dangling reversals across a full ledger. */
export function reconcile(entries: readonly JournalEntry[]): ReconIssue[] {
  const issues: ReconIssue[] = [];
  const seen = new Set<string>();
  const all = new Set(entries.map((e) => e.operationId));
  for (const e of entries) {
    if (seen.has(e.operationId)) issues.push({ kind: "DUPLICATE_OPERATION", operationId: e.operationId });
    seen.add(e.operationId);
    issues.push(...checkEntry(e));
    if (e.reversesOperationId && !all.has(e.reversesOperationId))
      issues.push({ kind: "MISSING_REVERSAL_TARGET", operationId: e.operationId, target: e.reversesOperationId });
  }
  return issues;
}

/** Balance of one account/currency (credit - debit, i.e. liability view). */
export function accountBalance(entries: readonly JournalEntry[], accountId: string, currency: string): bigint {
  let b = 0n;
  for (const e of entries) for (const l of e.lines) if (l.accountId === accountId && l.currency === currency) b += l.credit - l.debit;
  return b;
}
