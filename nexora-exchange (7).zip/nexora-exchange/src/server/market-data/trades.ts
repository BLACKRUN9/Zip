import { ProviderError, validateRequest, type CandleRequest, type CandleResult, type MarketCandle, type MarketDataProvider } from "./provider";

export interface TradeLike { at: number; price: bigint; qty: bigint }

/**
 * OHLCV from exchange fills. open/close = first/last fill of the bucket, volume = sum of base quantity.
 * Buckets with no fills between the first fill and `nowMs` are flat candles at the previous close (volume 0).
 */
export function aggregateTrades(trades: readonly TradeLike[], o: { intervalMs: number; nowMs: number; limit: number }): MarketCandle[] {
  if (trades.length === 0) return [];
  const sorted = [...trades].sort((a, b) => a.at - b.at); // stable: equal timestamps keep arrival order
  const buckets = new Map<number, MarketCandle>();
  for (const t of sorted) {
    const ts = Math.floor(t.at / o.intervalMs) * o.intervalMs;
    const c = buckets.get(ts);
    if (!c) buckets.set(ts, { ts, open: t.price, high: t.price, low: t.price, close: t.price, volume: t.qty });
    else { if (t.price > c.high) c.high = t.price; if (t.price < c.low) c.low = t.price; c.close = t.price; c.volume += t.qty; }
  }
  const first = Math.floor((sorted[0] as TradeLike).at / o.intervalMs) * o.intervalMs;
  const lastBucket = Math.max(Math.floor(o.nowMs / o.intervalMs) * o.intervalMs, Math.floor((sorted[sorted.length - 1] as TradeLike).at / o.intervalMs) * o.intervalMs);
  const out: MarketCandle[] = [];
  let prev: bigint | null = null;
  for (let ts = first; ts <= lastBucket; ts += o.intervalMs) {
    const c = buckets.get(ts);
    if (c) { out.push(c); prev = c.close; }
    else if (prev !== null) out.push({ ts, open: prev, high: prev, low: prev, close: prev, volume: 0n });
  }
  return out.slice(-o.limit);
}

/** Candles built ONLY from fills that happened on this (simulated) exchange. */
export class ExchangeTradesProvider implements MarketDataProvider {
  readonly id = "NEXORA-TRADES" as const;
  constructor(private readonly tradesOf: (market: string) => Promise<readonly TradeLike[]>, private readonly now: () => number = () => Date.now()) {}
  async getCandles(req: CandleRequest): Promise<CandleResult> {
    validateRequest(req);
    let trades: readonly TradeLike[];
    try { trades = await this.tradesOf(req.market); } catch { throw new ProviderError("UNSUPPORTED", "Unknown market"); }
    const t = this.now();
    return { source: this.id, kind: "SIMULATED", asOf: t, degraded: null, candles: aggregateTrades(trades, { intervalMs: req.intervalMinutes * 60_000, nowMs: t, limit: req.limit }) };
  }
}
