/**
 * Fictional, deterministic market data. NOT real quotes. Every output carries source "SIMULATED-SEED".
 * The PRNG uses integer bit-ops only; prices stay in BigInt atomic units.
 */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return (t ^ (t >>> 14)) >>> 0;
  };
}

export interface Candle { ts: number; open: bigint; high: bigint; low: bigint; close: bigint; volume: bigint; source: "SIMULATED-SEED" }

export function generateCandles(p: { seed: number; startPrice: bigint; count: number; intervalMs: number; startTs: number }): Candle[] {
  if (p.startPrice <= 0n || p.count < 0 || p.intervalMs <= 0) throw new Error("invalid candle parameters");
  const rnd = mulberry32(p.seed);
  const out: Candle[] = [];
  let prev = p.startPrice;
  for (let i = 0; i < p.count; i++) {
    const stepBps = BigInt((rnd() % 81) - 40); // -40..+40 bps per candle
    let close = prev + (prev * stepBps) / 10_000n;
    if (close < 1n) close = 1n;
    const hi = (prev > close ? prev : close) + (prev * BigInt(rnd() % 20)) / 10_000n;
    let lo = (prev < close ? prev : close) - (prev * BigInt(rnd() % 20)) / 10_000n;
    if (lo < 1n) lo = 1n;
    out.push({ ts: p.startTs + i * p.intervalMs, open: prev, high: hi, low: lo, close, volume: BigInt((rnd() % 1_000_000_000) + 1), source: "SIMULATED-SEED" });
    prev = close;
  }
  return out;
}

export interface LadderOrder { side: "BUY" | "SELL"; price: bigint; qty: bigint }

/**
 * Documented mock liquidity model: `levels` price steps of `spacingBps` on each side of `mid`,
 * with quantity growing linearly away from the touch. Mid is excluded so the book is never crossed.
 */
export function buildLiquidityLadder(p: { mid: bigint; levels: number; spacingBps: number; baseQty: bigint }): LadderOrder[] {
  if (p.mid <= 0n || p.levels < 1 || p.spacingBps < 1 || p.baseQty <= 0n) throw new Error("invalid ladder parameters");
  const out: LadderOrder[] = [];
  for (let i = 1; i <= p.levels; i++) {
    const off = (p.mid * BigInt(p.spacingBps * i)) / 10_000n;
    const qty = p.baseQty * BigInt(i);
    const ask = p.mid + (off > 0n ? off : BigInt(i));
    const bid = p.mid - (off > 0n ? off : BigInt(i));
    out.push({ side: "SELL", price: ask, qty });
    if (bid > 0n) out.push({ side: "BUY", price: bid, qty });
  }
  return out;
}
