/**
 * Market-data provider boundary. READ-ONLY by construction: providers can only return candles.
 * Nothing here can place orders, move funds, or call a trading/payment API.
 */
import { generateCandles } from "./seeded";

export type ProviderId = "NEXORA-TRADES" | "SIMULATED-SEED" | "KRAKEN-PUBLIC";
export interface CandleRequest { market: string; intervalMinutes: number; limit: number }
export interface MarketCandle { ts: number; open: bigint; high: bigint; low: bigint; close: bigint; volume: bigint }
export interface CandleResult {
  source: ProviderId;
  kind: "SIMULATED" | "REFERENCE";
  /** When this data was obtained from its source (ms since epoch). */
  asOf: number;
  /** Non-null when the data is a degraded substitute (stale cache, simulated fallback). Never silent. */
  degraded: string | null;
  candles: MarketCandle[];
}
export interface MarketDataProvider { readonly id: ProviderId; getCandles(req: CandleRequest): Promise<CandleResult> }

export type ProviderErrorCode = "INVALID_REQUEST" | "UNSUPPORTED" | "UPSTREAM" | "TIMEOUT" | "BAD_RESPONSE" | "RATE_LIMITED";
export class ProviderError extends Error {
  constructor(public readonly code: ProviderErrorCode, message: string) { super(message); this.name = "ProviderError"; }
}

export const ALLOWED_INTERVALS: readonly number[] = [1, 5, 15, 60];
export const MAX_LIMIT = 720;

export function validateRequest(r: CandleRequest): void {
  if (!ALLOWED_INTERVALS.includes(r.intervalMinutes)) throw new ProviderError("INVALID_REQUEST", `interval must be one of ${ALLOWED_INTERVALS.join(", ")}`);
  if (!Number.isInteger(r.limit) || r.limit < 1 || r.limit > MAX_LIMIT) throw new ProviderError("INVALID_REQUEST", `limit must be an integer in [1, ${MAX_LIMIT}]`);
}

/** Deterministic fictional candles ending at the current (forming) bucket. Same last price regardless of `limit`. */
export class SimulatedProvider implements MarketDataProvider {
  readonly id = "SIMULATED-SEED" as const;
  constructor(private readonly meta: Readonly<Record<string, { seed: number; startPrice: bigint }>>, private readonly now: () => number = () => Date.now()) {}

  async getCandles(req: CandleRequest): Promise<CandleResult> {
    validateRequest(req);
    const m = this.meta[req.market];
    if (!m) throw new ProviderError("UNSUPPORTED", "Unknown market");
    const iv = req.intervalMinutes * 60_000;
    const t = this.now();
    const end = Math.floor(t / iv) * iv;
    const all = generateCandles({ seed: m.seed + req.intervalMinutes, startPrice: m.startPrice, count: MAX_LIMIT, intervalMs: iv, startTs: end - (MAX_LIMIT - 1) * iv });
    const candles = all.slice(-req.limit).map(({ ts, open, high, low, close, volume }) => ({ ts, open, high, low, close, volume }));
    return { source: this.id, kind: "SIMULATED", asOf: t, degraded: null, candles };
  }
}
