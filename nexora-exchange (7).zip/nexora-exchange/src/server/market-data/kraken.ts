/**
 * Kraken PUBLIC market data (read-only, no API key, no account).
 * Endpoint per Kraken docs: GET https://api.kraken.com/0/public/OHLC?pair=<pair>&interval=<minutes>
 * Response: { error: string[], result: { "<pairKey>": [[time(s), open, high, low, close, vwap, volume, count], ...], last } }
 * The last row is the current, not-yet-committed candle. Docs advise >= 1 s between OHLC calls.
 * Safety: fixed host, GET only, pair from static config, timeout, size cap, TTL cache, serialized calls.
 */
import { parseDecimalRounded } from "../../lib/money/decimal";
import { ProviderError, validateRequest, type CandleRequest, type CandleResult, type MarketCandle, type MarketDataProvider } from "./provider";

const ORIGIN = "https://api.kraken.com";
const MAX_BODY_CHARS = 5_000_000;
const PAIR_RE = /^[A-Z0-9]{3,12}$/;

export interface KrakenMarket { pair: string; quoteDecimals: number; baseDecimals: number }
export interface KrakenOptions {
  markets: Readonly<Record<string, KrakenMarket>>;
  fetchImpl?: typeof fetch;
  now?: () => number;
  ttlMs?: number;
  timeoutMs?: number;
  minGapMs?: number;
}
interface CacheEntry { at: number; candles: MarketCandle[] }

const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

export function parseKrakenOhlc(body: unknown, m: KrakenMarket): MarketCandle[] {
  if (typeof body !== "object" || body === null) throw new ProviderError("BAD_RESPONSE", "Unexpected response shape");
  const { error, result } = body as { error?: unknown; result?: unknown };
  if (!Array.isArray(error) || typeof result !== "object" || result === null) throw new ProviderError("BAD_RESPONSE", "Unexpected response shape");
  if (error.length > 0) {
    const text = error.map(String).join(", ").slice(0, 120);
    throw new ProviderError(/unknown asset pair/i.test(text) ? "UNSUPPORTED" : "UPSTREAM", `Upstream error: ${text}`);
  }
  const key = Object.keys(result).find((k) => k !== "last");
  const rows = key ? (result as Record<string, unknown>)[key] : undefined;
  if (!Array.isArray(rows)) throw new ProviderError("BAD_RESPONSE", "No candle data in response");
  const num = (v: unknown, d: number): bigint | null => { if (typeof v !== "string") return null; try { return parseDecimalRounded(v, d); } catch { return null; } };
  const byTs = new Map<number, MarketCandle>();
  for (const row of rows) {
    if (!Array.isArray(row) || row.length < 7) continue;
    const t = Number(row[0]);
    const open = num(row[1], m.quoteDecimals), high = num(row[2], m.quoteDecimals), low = num(row[3], m.quoteDecimals), close = num(row[4], m.quoteDecimals);
    if (!Number.isInteger(t) || t <= 0 || open === null || high === null || low === null || close === null) continue;
    if (open <= 0n || close <= 0n || high <= 0n || low <= 0n) continue;
    const hi = open > close ? open : close, lo = open > close ? close : open;
    if (high < hi || low > lo) continue; // inconsistent candle: drop rather than draw nonsense
    byTs.set(t * 1000, { ts: t * 1000, open, high, low, close, volume: num(row[6], m.baseDecimals) ?? 0n });
  }
  const candles = [...byTs.values()].sort((a, b) => a.ts - b.ts);
  if (candles.length === 0) throw new ProviderError("BAD_RESPONSE", "No valid candles in response");
  return candles;
}

export class KrakenPublicProvider implements MarketDataProvider {
  readonly id = "KRAKEN-PUBLIC" as const;
  private readonly fetchImpl: typeof fetch;
  private readonly now: () => number;
  private readonly ttlMs: number; private readonly timeoutMs: number; private readonly minGapMs: number;
  private readonly cache = new Map<string, CacheEntry>();
  private readonly inflight = new Map<string, Promise<CacheEntry>>();
  private chain: Promise<void> = Promise.resolve();
  private lastCall = 0;

  constructor(private readonly opts: KrakenOptions) {
    this.fetchImpl = opts.fetchImpl ?? fetch;
    this.now = opts.now ?? (() => Date.now());
    this.ttlMs = opts.ttlMs ?? 10_000; this.timeoutMs = opts.timeoutMs ?? 5_000; this.minGapMs = opts.minGapMs ?? 1_000;
    for (const [k, v] of Object.entries(opts.markets)) if (!PAIR_RE.test(v.pair)) throw new Error(`invalid Kraken pair for ${k}`);
  }

  async getCandles(req: CandleRequest): Promise<CandleResult> {
    validateRequest(req);
    const cfg = this.opts.markets[req.market];
    if (!cfg) throw new ProviderError("UNSUPPORTED", "Unknown market");
    const key = `${req.market}:${req.intervalMinutes}`;
    const cached = this.cache.get(key);
    if (cached && this.now() - cached.at < this.ttlMs) return this.view(cached, req.limit, null);
    let p = this.inflight.get(key);
    if (!p) { p = this.fetchUpstream(key, cfg, req.intervalMinutes).finally(() => this.inflight.delete(key)); this.inflight.set(key, p); }
    try { return this.view(await p, req.limit, null); }
    catch (e) {
      if (cached) return this.view(cached, req.limit, `STALE_CACHE:${e instanceof ProviderError ? e.code : "UPSTREAM"}`);
      throw e;
    }
  }

  private view(e: CacheEntry, limit: number, degraded: string | null): CandleResult {
    return { source: this.id, kind: "REFERENCE", asOf: e.at, degraded, candles: e.candles.slice(-limit) };
  }

  private gate(): Promise<void> {
    const run = this.chain.then(async () => {
      const wait = this.lastCall + this.minGapMs - this.now();
      if (wait > 0) await sleep(wait);
      this.lastCall = this.now();
    });
    this.chain = run.catch(() => undefined);
    return run;
  }

  private async fetchUpstream(key: string, cfg: KrakenMarket, interval: number): Promise<CacheEntry> {
    await this.gate();
    const url = `${ORIGIN}/0/public/OHLC?pair=${cfg.pair}&interval=${interval}`;
    let res: Response;
    try { res = await this.fetchImpl(url, { signal: AbortSignal.timeout(this.timeoutMs), headers: { accept: "application/json" } }); }
    catch (e) {
      const name = (e as { name?: string } | null)?.name;
      throw new ProviderError(name === "TimeoutError" || name === "AbortError" ? "TIMEOUT" : "UPSTREAM", "Could not reach the market-data source");
    }
    if (res.status === 429) throw new ProviderError("RATE_LIMITED", "Market-data source is rate limiting requests");
    if (!res.ok) throw new ProviderError("UPSTREAM", `Market-data source returned HTTP ${res.status}`);
    const text = await res.text();
    if (text.length > MAX_BODY_CHARS) throw new ProviderError("BAD_RESPONSE", "Response too large");
    let json: unknown;
    try { json = JSON.parse(text); } catch { throw new ProviderError("BAD_RESPONSE", "Response was not valid JSON"); }
    const entry: CacheEntry = { at: this.now(), candles: parseKrakenOhlc(json, cfg) };
    this.cache.set(key, entry);
    return entry;
  }
}
