import type { CandlePayload } from "../../lib/ui/candle-payload";
import { ProviderError, type CandleRequest, type CandleResult, type MarketDataProvider } from "./provider";

/** Try the primary source; on failure fall back to the simulated source and SAY SO via `degraded`. Never silent. */
export async function candlesWithFallback(primary: MarketDataProvider, fallback: MarketDataProvider, req: CandleRequest): Promise<CandleResult> {
  try { return await primary.getCandles(req); }
  catch (e) {
    if (e instanceof ProviderError && e.code === "INVALID_REQUEST") throw e;
    if (primary.id === fallback.id) throw e;
    const r = await fallback.getCandles(req);
    return { ...r, degraded: `LIVE_FEED_UNAVAILABLE:${e instanceof ProviderError ? e.code : "UPSTREAM"}` };
  }
}

export function toPayload(req: CandleRequest, r: CandleResult, synthetic = false): CandlePayload {
  return {
    synthetic,
    market: req.market, intervalMinutes: req.intervalMinutes, source: r.source, kind: r.kind, asOf: r.asOf, degraded: r.degraded,
    candles: r.candles.map((c) => ({ t: c.ts, o: c.open.toString(), h: c.high.toString(), l: c.low.toString(), c: c.close.toString(), v: c.volume.toString() })),
  };
}
