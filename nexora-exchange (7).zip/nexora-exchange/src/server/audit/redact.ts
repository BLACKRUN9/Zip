/** Deep-redacts secrets before anything is written to an audit log. BigInt -> string; cycles and depth are bounded. */
const SENSITIVE = /pass(word|wd)?|secret|token|cookie|authorization|api[-_]?key|private[-_]?key|seed|mnemonic|session|credential|csrf/i;

export function redact(value: unknown, depth = 0, seen: WeakSet<object> = new WeakSet()): unknown {
  if (typeof value === "bigint") return value.toString();
  if (value === null || typeof value !== "object") return value;
  if (depth >= 8) return "[TRUNCATED]";
  if (seen.has(value)) return "[CIRCULAR]";
  seen.add(value);
  if (Array.isArray(value)) return value.map((v) => redact(v, depth + 1, seen));
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(value)) out[k] = SENSITIVE.test(k) ? "[REDACTED]" : redact(v, depth + 1, seen);
  return out;
}

export interface AuditEvent { actorId: string; action: string; target: string; at: number; metadata: unknown }
export function makeAuditEvent(actorId: string, action: string, target: string, at: number, metadata: unknown): AuditEvent {
  return Object.freeze({ actorId, action, target, at, metadata: redact(metadata) });
}
