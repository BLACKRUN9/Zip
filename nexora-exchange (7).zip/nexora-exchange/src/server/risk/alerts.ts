/** Basic anomaly rules over simulated activity. Pure: callers pass events and a config. */
export interface RiskEvent { userId: string; kind: "ORDER" | "CANCEL" | "REJECT" | "DEPOSIT"; at: number; amount: bigint }
export interface RiskConfig { windowMs: number; cancelBurst: number; rejectBurst: number; largeOrderNotional: bigint; largeDeposit: bigint }
export interface RiskAlert { rule: "LARGE_ORDER" | "CANCEL_BURST" | "REJECT_BURST" | "LARGE_DEPOSIT"; userId: string; at: number; detail: string }

export function evaluateRisk(events: readonly RiskEvent[], cfg: RiskConfig): RiskAlert[] {
  const sorted = [...events].sort((a, b) => a.at - b.at);
  const alerts: RiskAlert[] = [];
  const seen = new Set<string>();
  const recent = new Map<string, number[]>();
  for (const e of sorted) {
    if (e.kind === "ORDER" && e.amount >= cfg.largeOrderNotional) alerts.push({ rule: "LARGE_ORDER", userId: e.userId, at: e.at, detail: `order notional ${e.amount} >= ${cfg.largeOrderNotional}` });
    if (e.kind === "DEPOSIT" && e.amount >= cfg.largeDeposit) alerts.push({ rule: "LARGE_DEPOSIT", userId: e.userId, at: e.at, detail: `deposit ${e.amount} >= ${cfg.largeDeposit}` });
    const burst = e.kind === "CANCEL" ? { rule: "CANCEL_BURST" as const, n: cfg.cancelBurst } : e.kind === "REJECT" ? { rule: "REJECT_BURST" as const, n: cfg.rejectBurst } : null;
    if (!burst) continue;
    const k = `${e.userId}:${e.kind}`;
    const list = (recent.get(k) ?? []).filter((t) => e.at - t < cfg.windowMs);
    list.push(e.at);
    recent.set(k, list);
    const bucket = `${k}:${Math.floor(e.at / cfg.windowMs)}`;
    if (list.length >= burst.n && !seen.has(bucket)) {
      seen.add(bucket);
      alerts.push({ rule: burst.rule, userId: e.userId, at: e.at, detail: `${list.length} ${e.kind.toLowerCase()} events within ${cfg.windowMs}ms` });
    }
  }
  return alerts;
}
