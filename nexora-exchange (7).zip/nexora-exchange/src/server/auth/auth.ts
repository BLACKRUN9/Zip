import { betterAuth } from "better-auth";
import { prismaAdapter } from "better-auth/adapters/prisma";
import { nextCookies } from "better-auth/next-js";
import { getPrisma } from "../db/prisma";
import { readAuthEnv } from "./mode";

/**
 * Better Auth (maintained library): scrypt password hashing, signed httpOnly session cookies, DB-backed sessions.
 * - Self-registration is OFF in the app instance. Accounts exist only through the dev seed (allowSignUp: true, script only).
 * - Sessions last 8 hours; cookies are Secure in production.
 * - The user's ROLE is not stored here: it is derived on the server from the seeded email (see mode.ts / directory.ts).
 */
export function createAuth(opts: { allowSignUp: boolean; withNextCookies?: boolean; env?: Readonly<Record<string, string | undefined>> }) {
  const env = readAuthEnv(opts.env ?? process.env);
  const codespaces = (opts.env ?? process.env)["CODESPACES"] === "true";
  return betterAuth({
    appName: "NEXORA Demo",
    secret: env.secret,
    baseURL: env.baseUrl,
    trustedOrigins: [...env.trustedOrigins, ...(codespaces ? ["https://*.app.github.dev"] : [])],
    database: prismaAdapter(getPrisma(env.databaseUrl), { provider: "postgresql" }),
    emailAndPassword: { enabled: true, disableSignUp: !opts.allowSignUp },
    session: { expiresIn: 60 * 60 * 8, updateAge: 60 * 30 },
    advanced: { useSecureCookies: env.secureCookies },
    plugins: opts.withNextCookies === false ? [] : [nextCookies()], // must stay last: lets server actions set the session cookie
  });
}
export type Auth = ReturnType<typeof createAuth>;

const g = globalThis as unknown as { __nexoraAuth?: Auth };
export function getAuth(): Auth { return (g.__nexoraAuth ??= createAuth({ allowSignUp: false })); }
