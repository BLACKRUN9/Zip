import { accountById, type Principal } from "../accounts/directory";

/**
 * TEMPORARY, development only (until real authentication in Milestone 2).
 * The acting account is chosen by the SERVER OPERATOR through NEXORA_DEV_ACTOR; nothing the browser sends can change it.
 * Disabled in production builds and whenever DEMO_MODE is not exactly "true".
 */
export function resolveDevActor(env: Readonly<Record<string, string | undefined>>): Principal | null {
  if (env["NODE_ENV"] === "production") return null;
  if (env["DEMO_MODE"] !== "true") return null;
  const id = env["NEXORA_DEV_ACTOR"];
  if (!id) return null;
  const a = accountById(id);
  return a ? { userId: a.id, role: a.role } : null;
}
