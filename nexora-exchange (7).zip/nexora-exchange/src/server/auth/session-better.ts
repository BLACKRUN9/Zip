import "server-only";
import { headers } from "next/headers";
import { getAuth } from "./auth";

/** Email of the signed-in user, or null. Only the email is used; the role is derived server-side from the directory. */
export async function getSessionEmail(): Promise<string | null> {
  const session = await getAuth().api.getSession({ headers: await headers() });
  return session?.user.email ?? null;
}
