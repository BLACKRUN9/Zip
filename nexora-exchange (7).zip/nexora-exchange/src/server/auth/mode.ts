import { accountByEmail, type Principal } from "../accounts/directory";
import { resolveDevActor } from "./dev-actor";

export type AuthMode = "dev" | "better-auth";
type Env = Readonly<Record<string, string | undefined>>;

/** AUTH_MODE selects how the acting account is found. Unknown values are an error (no silent fallback). */
export function readAuthMode(env: Env): AuthMode {
  const v = env["AUTH_MODE"] ?? "dev";
  if (v === "dev" || v === "better-auth") return v;
  throw new Error(`Unsupported AUTH_MODE "${v.slice(0, 20)}". Allowed: dev, better-auth.`);
}

/** Seeded login email -> account. Role always comes from the server-side directory, never from the session payload or the browser. */
export function actorFromEmail(email: string | null | undefined): Principal | null {
  if (!email) return null;
  const a = accountByEmail(email);
  return a ? { userId: a.id, role: a.role } : null;
}

/** In better-auth mode NEXORA_DEV_ACTOR is ignored completely. */
export function resolveActor(env: Env, sessionEmail: string | null | undefined): Principal | null {
  return readAuthMode(env) === "better-auth" ? actorFromEmail(sessionEmail) : resolveDevActor(env);
}

export interface AuthEnv { secret: string; baseUrl: string; databaseUrl: string; trustedOrigins: string[]; secureCookies: boolean }
const PLACEHOLDER = /replace-with|changeme|example|password|secret$/i;

/** Validated at first use (server startup path). Throws one aggregated, secret-free message. */
export function readAuthEnv(env: Env): AuthEnv {
  const problems: string[] = [];
  const secret = env["BETTER_AUTH_SECRET"] ?? env["AUTH_SECRET"] ?? "";
  if (secret.length < 32 || PLACEHOLDER.test(secret)) problems.push("BETTER_AUTH_SECRET must be a random string of at least 32 characters (try: openssl rand -base64 32)");
  const databaseUrl = env["DATABASE_URL"] ?? "";
  if (!/^postgres(ql)?:\/\/.+/.test(databaseUrl) || /USER:PASSWORD/.test(databaseUrl)) problems.push("DATABASE_URL must be a real postgresql:// connection string");
  const production = env["NODE_ENV"] === "production";
  let baseUrl = env["BETTER_AUTH_URL"] ?? "";
  try { const u = new URL(baseUrl); if (!["http:", "https:"].includes(u.protocol)) throw new Error(); if (production && u.protocol !== "https:") problems.push("BETTER_AUTH_URL must use https in production"); baseUrl = u.origin; }
  catch { problems.push("BETTER_AUTH_URL must be the public URL of the app (for example https://<name>-3000.app.github.dev or http://localhost:3000)"); }
  const trusted = (env["TRUSTED_ORIGINS"] ?? "").split(",").map((x) => x.trim()).filter(Boolean);
  for (const t of trusted) if (!/^https?:\/\/[A-Za-z0-9*.-]+(:\d+)?$/.test(t)) problems.push(`TRUSTED_ORIGINS entry "${t.slice(0, 40)}" is not a valid origin`);
  if (problems.length) throw new Error(`Invalid authentication configuration:\n - ${problems.join("\n - ")}`);
  return { secret, baseUrl, databaseUrl, trustedOrigins: trusted, secureCookies: production };
}

export interface SeedGuard { ok: boolean; reason: string }
/** The dev seed refuses to run unless every condition holds. */
export function checkSeedAllowed(env: Env): SeedGuard {
  if (env["NODE_ENV"] === "production") return { ok: false, reason: "refusing to seed in production" };
  if (env["DEMO_MODE"] !== "true") return { ok: false, reason: "DEMO_MODE must be exactly true" };
  if (env["ALLOW_DEV_SEED"] !== "true") return { ok: false, reason: "set ALLOW_DEV_SEED=true to confirm this is a development database" };
  const pw = env["SEED_DEV_PASSWORD"] ?? "";
  if (pw.length < 12 || pw.length > 128) return { ok: false, reason: "SEED_DEV_PASSWORD must be 12-128 characters (choose it yourself; it is never printed)" };
  return { ok: true, reason: "" };
}
