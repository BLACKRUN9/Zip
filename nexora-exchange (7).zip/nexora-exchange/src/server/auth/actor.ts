import "server-only";
import { can, type Permission, type Principal } from "../accounts/directory";
import { readAuthMode, resolveActor } from "./mode";

/**
 * AUTH_MODE=better-auth: the signed-in session decides (NEXORA_DEV_ACTOR is ignored).
 * AUTH_MODE=dev (default): the operator-chosen development actor, disabled in production builds.
 */
export async function getActor(): Promise<Principal | null> {
  let email: string | null = null;
  if (readAuthMode(process.env) === "better-auth") {
    try { email = await (await import("./session-better")).getSessionEmail(); } catch { email = null; } // any auth failure = anonymous, never an error page or a leak
  }
  return resolveActor(process.env, email);
}

export class AuthzError extends Error {
  constructor(public readonly code: "UNAUTHENTICATED" | "FORBIDDEN", message: string) { super(message); this.name = "AuthzError"; }
}
export function requirePermission(actor: Principal | null, p: Permission): Principal {
  if (!actor) throw new AuthzError("UNAUTHENTICATED", "Sign-in required");
  if (!can(actor.role, p)) throw new AuthzError("FORBIDDEN", "You do not have permission for this action");
  return actor;
}
