export type Role = "USER" | "MM" | "ADMIN";
export type Permission = "trade" | "wallet" | "mm:view" | "mm:control" | "mm:config" | "admin:view" | "transfers:decide";

const MATRIX: Readonly<Record<Role, readonly Permission[]>> = {
  USER: ["trade", "wallet"],
  MM: ["trade", "wallet", "mm:view", "mm:control", "mm:config"],
  ADMIN: ["trade", "wallet", "mm:view", "mm:control", "mm:config", "admin:view", "transfers:decide"],
};
export const can = (role: Role, p: Permission): boolean => MATRIX[role]?.includes(p) ?? false;

export interface AccountInfo { id: string; role: Role; label: string; email: string }
/** Fixed demo directory. Credentials come with real authentication (Milestone 2); roles are never taken from the browser. */
export const ACCOUNTS: readonly AccountInfo[] = [
  { id: "user1", email: "user1@nexora.invalid", role: "USER", label: "Demo user 1" },
  { id: "user2", email: "user2@nexora.invalid", role: "USER", label: "Demo user 2" },
  { id: "mm", email: "mm@nexora.invalid", role: "MM", label: "Market maker" },
  { id: "mm2", email: "mm2@nexora.invalid", role: "MM", label: "Market maker 2 (volume bot counterparty)" },
  { id: "admin", email: "admin@nexora.invalid", role: "ADMIN", label: "Administrator" },
];
/** `.invalid` is reserved (RFC 2606): these addresses can never receive real mail. */
export const accountByEmail = (email: string): AccountInfo | null => ACCOUNTS.find((a) => a.email === email.trim().toLowerCase()) ?? null;
export const accountById = (id: string): AccountInfo | null => ACCOUNTS.find((a) => a.id === id) ?? null;
export const isMmAccount = (id: string): boolean => accountById(id)?.role === "MM";

export interface Principal { userId: string; role: Role }
/** ADMIN may manage any strategy; MM only strategies that trade for its own account. */
export function canManageStrategy(actor: Principal, strategyAccount: string): boolean {
  if (actor.role === "ADMIN") return can(actor.role, "mm:control");
  return actor.role === "MM" && can(actor.role, "mm:control") && actor.userId === strategyAccount;
}
