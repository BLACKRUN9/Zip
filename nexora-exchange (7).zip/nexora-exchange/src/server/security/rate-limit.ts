/** Fixed-window in-memory rate limiter with an injectable clock. Swap the store for Redis/DB when scaling out. */
export class RateLimiter {
  private readonly hits = new Map<string, { start: number; count: number }>();
  constructor(private readonly limit: number, private readonly windowMs: number, private readonly now: () => number = () => Date.now()) {
    if (limit < 1 || windowMs < 1) throw new Error("invalid rate limit configuration");
  }
  check(key: string): { allowed: boolean; remaining: number; retryAfterMs: number } {
    const t = this.now();
    if (this.hits.size > 10_000) for (const [k, v] of this.hits) if (t - v.start >= this.windowMs) this.hits.delete(k);
    let h = this.hits.get(key);
    if (!h || t - h.start >= this.windowMs) { h = { start: t, count: 0 }; this.hits.set(key, h); }
    if (h.count >= this.limit) return { allowed: false, remaining: 0, retryAfterMs: h.start + this.windowMs - t };
    h.count++;
    return { allowed: true, remaining: this.limit - h.count, retryAfterMs: 0 };
  }
}

/** Baseline security headers for the Next.js config / middleware. */
export const SECURITY_HEADERS: Readonly<Record<string, string>> = Object.freeze({
  "X-Content-Type-Options": "nosniff",
  "X-Frame-Options": "DENY",
  "Referrer-Policy": "strict-origin-when-cross-origin",
  "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
  "Strict-Transport-Security": "max-age=63072000; includeSubDomains",
  "Content-Security-Policy": "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'",
});
