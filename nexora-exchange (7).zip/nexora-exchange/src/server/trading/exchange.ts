/**
 * Reference implementation of the SIMULATED spot exchange (in-memory).
 * - All balance changes go through Ledger.post() with balanced journal entries.
 * - Every public mutation is serialised through withLock(); the DB version replaces this with row locks /
 *   SERIALIZABLE transactions and must keep the same invariants.
 * - Every mutation calls requireDemo() first.
 */
import { requireDemo } from "../config/demo-guard";
import { OrderBook, type Fill, type Side } from "../matching/order-book";
import { reconcile, type ReconIssue } from "../ledger/journal";
import { Ledger } from "../ledger/ledger";
import { buildFillJournal, buildTransferJournal, faucetAccount, sinkAccount, userAccount } from "../ledger/fill-journal";
import { feeOf, notional } from "../../lib/money/trade-math";

export type ExchangeErrorCode = "VALIDATION" | "UNKNOWN_MARKET" | "IDEMPOTENCY_CONFLICT" | "NOT_FOUND" | "INVALID_STATE" | "FORBIDDEN";
export class ExchangeError extends Error {
  constructor(public readonly code: ExchangeErrorCode, message: string) { super(message); this.name = "ExchangeError"; }
}

export interface Asset { symbol: string; decimals: number }
export interface MarketConfig {
  symbol: string;
  base: Asset;
  quote: Asset;
  takerFeeBps: number;
  makerFeeBps: number;
  minQty: bigint;
  minNotional: bigint;
}
export type OrderStatus = "OPEN" | "PARTIALLY_FILLED" | "FILLED" | "CANCELLED" | "REJECTED";
export type OrderType = "MARKET" | "LIMIT";
export interface Order {
  id: string; userId: string; market: string; side: Side; type: OrderType;
  price: bigint | null; qty: bigint; filledQty: bigint; status: OrderStatus;
  reserveAsset: string; reservedRemaining: bigint; reason: string | null;
  createdAt: number; updatedAt: number; simulated: true;
}
export interface TradeRecord {
  id: string; market: string; price: bigint; qty: bigint; takerOrderId: string; makerOrderId: string;
  takerSide: Side; at: number; simulated: true;
}
export interface LifecycleEvent { orderId: string; at: number; from: OrderStatus | null; to: OrderStatus; note: string | null }
export interface PlaceOrderInput {
  idempotencyKey: string; userId: string; market: string; side: Side; type: OrderType; qty: bigint; price: bigint | null;
}
export interface PlaceOrderResult { order: Order; fills: TradeRecord[]; replayed: boolean }
export interface Actor { userId: string; role: "USER" | "MM" | "ADMIN" }
export interface DemoTransfer {
  id: string; userId: string; kind: "DEPOSIT" | "WITHDRAWAL"; asset: string; amount: bigint;
  status: "PENDING" | "COMPLETED" | "REJECTED"; reason: string | null; createdAt: number; updatedAt: number; simulated: true;
}
export type ExchangeReconIssue =
  | ReconIssue
  | { kind: "PROJECTION_MISMATCH" | "NEGATIVE_BALANCE" | "RESERVE_MISMATCH" | "PENDING_MISMATCH"; account: string; expected: bigint; actual: bigint };

export interface ExchangeOptions {
  markets: readonly MarketConfig[];
  clock?: () => number;
  env?: Readonly<Record<string, string | undefined>>;
}

type Role = "TAKER" | "MAKER";
interface FeeState { TAKER: { n: bigint; fee: bigint }; MAKER: { n: bigint; fee: bigint } }
interface IdemRecord { fingerprint: string; kind: "ORDER" | "TRANSFER"; refId: string }

const USER_ID_RE = /^[A-Za-z0-9_-]{1,64}$/; // no ':' or '|' => cannot forge ledger account ids
const KEY_RE = /^[A-Za-z0-9_.:-]{1,128}$/;

const fp = (o: Record<string, string | bigint | null>) => JSON.stringify(o, (_k, v) => (typeof v === "bigint" ? `${v}n` : v));

export class DemoExchange {
  readonly ledger = new Ledger();
  private readonly markets = new Map<string, MarketConfig>();
  private readonly assets = new Map<string, Asset>();
  private readonly books = new Map<string, OrderBook>();
  private readonly orders = new Map<string, Order>();
  private readonly feeStates = new Map<string, FeeState>();
  private readonly trades: TradeRecord[] = [];
  private readonly events: LifecycleEvent[] = [];
  private readonly transfers = new Map<string, DemoTransfer>();
  private readonly idem = new Map<string, IdemRecord>();
  private orderSeq = 0; private tradeSeq = 0; private opSeq = 0; private transferSeq = 0;
  private tail: Promise<unknown> = Promise.resolve();
  private readonly clock: () => number;
  private readonly env: Readonly<Record<string, string | undefined>>;

  constructor(opts: ExchangeOptions) {
    this.clock = opts.clock ?? (() => Date.now());
    this.env = opts.env ?? process.env;
    for (const m of opts.markets) {
      if (m.takerFeeBps < 0 || m.makerFeeBps < 0 || m.takerFeeBps > 10_000 || m.makerFeeBps > 10_000) throw new Error("fee bps out of range");
      this.markets.set(m.symbol, m);
      this.books.set(m.symbol, new OrderBook());
      this.assets.set(m.base.symbol, m.base);
      this.assets.set(m.quote.symbol, m.quote);
    }
  }

  private withLock<T>(fn: () => T): Promise<T> {
    const run = this.tail.then(() => fn());
    this.tail = run.then(() => undefined, () => undefined);
    return run;
  }

  // ------------------------------------------------------------------ orders
  placeOrder(input: PlaceOrderInput): Promise<PlaceOrderResult> { return this.withLock(() => this.placeOrderLocked(input)); }

  private placeOrderLocked(input: PlaceOrderInput): PlaceOrderResult {
    requireDemo(this.env);
    this.validateIds(input.userId, input.idempotencyKey);
    const m = this.markets.get(input.market);
    if (!m) throw new ExchangeError("UNKNOWN_MARKET", "Unknown market");
    if (input.side !== "BUY" && input.side !== "SELL") throw new ExchangeError("VALIDATION", "side must be BUY or SELL");
    if (input.type !== "MARKET" && input.type !== "LIMIT") throw new ExchangeError("VALIDATION", "type must be MARKET or LIMIT");
    if (typeof input.qty !== "bigint" || input.qty <= 0n || input.qty < m.minQty) throw new ExchangeError("VALIDATION", "quantity below minimum or not positive");
    if (input.type === "LIMIT" && (input.price === null || input.price <= 0n)) throw new ExchangeError("VALIDATION", "limit orders need a positive price");
    if (input.type === "MARKET" && input.price !== null) throw new ExchangeError("VALIDATION", "market orders must not carry a price");

    const fingerprint = fp({ m: input.market, s: input.side, t: input.type, q: input.qty, p: input.price });
    const idemKey = `${input.userId}:${input.idempotencyKey}`;
    const prior = this.idem.get(idemKey);
    if (prior) {
      if (prior.fingerprint !== fingerprint || prior.kind !== "ORDER") throw new ExchangeError("IDEMPOTENCY_CONFLICT", "Idempotency key reused with a different request");
      return { order: this.copyOrder(this.mustOrder(prior.refId)), fills: this.tradesOf(prior.refId), replayed: true };
    }

    const book = this.mustBook(m.symbol);
    const id = `ord_${++this.orderSeq}`;
    const isBuy = input.side === "BUY";
    const reserveAsset = isBuy ? m.quote.symbol : m.base.symbol;
    const maxBps = Math.max(m.takerFeeBps, m.makerFeeBps);
    const limitPrice = input.price;

    let required: bigint;
    if (input.type === "LIMIT" && limitPrice !== null) {
      const n = notional(input.qty, limitPrice, m.base.decimals);
      if (n < m.minNotional) return this.reject(id, input, m, reserveAsset, "BELOW_MIN_NOTIONAL", idemKey, fingerprint);
      required = isBuy ? n + feeOf(n, maxBps) + 1n : input.qty; // +1: rounding slack, see docs/FINANCIAL_MODEL.md
    } else {
      const preview = book.clone().submit({ id, userId: input.userId, side: input.side, limitPrice: null, qty: input.qty });
      if (preview.fills.length === 0) return this.reject(id, input, m, reserveAsset, "NO_LIQUIDITY", idemKey, fingerprint);
      let total = 0n;
      for (const f of preview.fills) total += notional(f.qty, f.price, m.base.decimals);
      if (total < m.minNotional) return this.reject(id, input, m, reserveAsset, "BELOW_MIN_NOTIONAL", idemKey, fingerprint);
      required = isBuy ? total + feeOf(total, m.takerFeeBps) + 1n : input.qty;
    }

    const availKey = userAccount(input.userId, reserveAsset, "available");
    if (this.ledger.balance(availKey, reserveAsset) < required) {
      return this.reject(id, input, m, reserveAsset, "INSUFFICIENT_FUNDS", idemKey, fingerprint);
    }

    // reserve
    this.ledger.post(buildTransferJournal(`rsv:${id}`, "SIMULATED reserve", reserveAsset, availKey, userAccount(input.userId, reserveAsset, "reserved"), required));
    const now = this.clock();
    const order: Order = {
      id, userId: input.userId, market: m.symbol, side: input.side, type: input.type, price: limitPrice, qty: input.qty,
      filledQty: 0n, status: "OPEN", reserveAsset, reservedRemaining: required, reason: null, createdAt: now, updatedAt: now, simulated: true,
    };
    this.orders.set(id, order);
    this.feeStates.set(id, { TAKER: { n: 0n, fee: 0n }, MAKER: { n: 0n, fee: 0n } });
    this.events.push({ orderId: id, at: now, from: null, to: "OPEN", note: null });
    this.idem.set(idemKey, { fingerprint, kind: "ORDER", refId: id });

    // match
    const res = book.submit({ id, userId: input.userId, side: input.side, limitPrice, qty: input.qty });
    const touchedMakers = new Set<string>();
    for (const f of res.fills) { this.settleFill(order, f, m); touchedMakers.add(f.makerOrderId); }
    for (const mid of touchedMakers) { const mk = this.mustOrder(mid); if (mk.status === "FILLED") this.release(mk); }

    if (order.filledQty === order.qty) { this.release(order); }
    else if (input.type === "MARKET") {
      this.release(order);
      this.transition(order, "CANCELLED", "MARKET_REMAINDER_UNFILLED");
    }
    return { order: this.copyOrder(order), fills: this.tradesOf(id), replayed: false };
  }

  cancelOrder(userId: string, orderId: string): Promise<Order> {
    return this.withLock(() => {
      requireDemo(this.env);
      this.validateIds(userId, "x");
      const o = this.orders.get(orderId);
      if (!o || o.userId !== userId) throw new ExchangeError("NOT_FOUND", "Order not found"); // same error for missing and foreign (no IDOR oracle)
      if (o.status !== "OPEN" && o.status !== "PARTIALLY_FILLED") throw new ExchangeError("INVALID_STATE", `Order is ${o.status} and cannot be cancelled`);
      if (!this.mustBook(o.market).cancel(orderId)) throw new ExchangeError("INVALID_STATE", "Order is not resting on the book");
      this.release(o);
      this.transition(o, "CANCELLED", "USER_REQUEST");
      return this.copyOrder(o);
    });
  }

  private reject(id: string, input: PlaceOrderInput, m: MarketConfig, reserveAsset: string, reason: string, idemKey: string, fingerprint: string): PlaceOrderResult {
    const now = this.clock();
    const order: Order = {
      id, userId: input.userId, market: m.symbol, side: input.side, type: input.type, price: input.price, qty: input.qty,
      filledQty: 0n, status: "REJECTED", reserveAsset, reservedRemaining: 0n, reason, createdAt: now, updatedAt: now, simulated: true,
    };
    this.orders.set(id, order);
    this.events.push({ orderId: id, at: now, from: null, to: "REJECTED", note: reason });
    this.idem.set(idemKey, { fingerprint, kind: "ORDER", refId: id });
    return { order: this.copyOrder(order), fills: [], replayed: false };
  }

  private chargeFee(order: Order, role: Role, n: bigint, m: MarketConfig): bigint {
    const st = (this.feeStates.get(order.id) as FeeState)[role];
    const bps = role === "TAKER" ? m.takerFeeBps : m.makerFeeBps;
    const newN = st.n + n;
    const newFee = feeOf(newN, bps); // cumulative rounding => total fee == ceil(total notional * bps), never drifts
    const fee = newFee - st.fee;
    st.n = newN; st.fee = newFee;
    return fee;
  }

  private settleFill(taker: Order, f: Fill, m: MarketConfig): void {
    const maker = this.mustOrder(f.makerOrderId);
    const buyer = taker.side === "BUY" ? taker : maker;
    const seller = taker.side === "BUY" ? maker : taker;
    const n = notional(f.qty, f.price, m.base.decimals);
    const buyerFee = this.chargeFee(buyer, buyer === taker ? "TAKER" : "MAKER", n, m);
    const sellerFee = this.chargeFee(seller, seller === taker ? "TAKER" : "MAKER", n, m);
    this.ledger.post(buildFillJournal({
      operationId: `fill:${taker.id}:${maker.id}:${++this.opSeq}`,
      buyerId: buyer.userId, sellerId: seller.userId, baseSymbol: m.base.symbol, quoteSymbol: m.quote.symbol,
      qty: f.qty, notional: n, buyerFee, sellerFee,
    }));
    buyer.reservedRemaining -= n + buyerFee;
    seller.reservedRemaining -= f.qty;
    for (const o of [buyer, seller]) {
      o.filledQty += f.qty;
      this.transition(o, o.filledQty === o.qty ? "FILLED" : "PARTIALLY_FILLED", null);
    }
    this.trades.push({ id: `trd_${++this.tradeSeq}`, market: m.symbol, price: f.price, qty: f.qty, takerOrderId: taker.id, makerOrderId: maker.id, takerSide: taker.side, at: this.clock(), simulated: true });
    this.tradeOrderIndex.push([taker.id, this.trades.length - 1]);
  }
  private readonly tradeOrderIndex: Array<[string, number]> = [];

  private release(o: Order): void {
    if (o.reservedRemaining <= 0n) return;
    this.ledger.post(buildTransferJournal(`rel:${o.id}:${++this.opSeq}`, "SIMULATED reserve release", o.reserveAsset,
      userAccount(o.userId, o.reserveAsset, "reserved"), userAccount(o.userId, o.reserveAsset, "available"), o.reservedRemaining));
    o.reservedRemaining = 0n;
  }

  private transition(o: Order, to: OrderStatus, note: string | null): void {
    if (o.status === to) return;
    this.events.push({ orderId: o.id, at: this.clock(), from: o.status, to, note });
    o.status = to; o.updatedAt = this.clock();
    if (note !== null) o.reason = note;
  }

  // --------------------------------------------------------- simulated wallet
  requestDeposit(userId: string, input: { idempotencyKey: string; asset: string; amount: bigint }): Promise<DemoTransfer> {
    return this.withLock(() => this.requestTransfer("DEPOSIT", userId, input));
  }
  requestWithdrawal(userId: string, input: { idempotencyKey: string; asset: string; amount: bigint }): Promise<DemoTransfer> {
    return this.withLock(() => this.requestTransfer("WITHDRAWAL", userId, input));
  }

  private requestTransfer(kind: "DEPOSIT" | "WITHDRAWAL", userId: string, input: { idempotencyKey: string; asset: string; amount: bigint }): DemoTransfer {
    requireDemo(this.env);
    this.validateIds(userId, input.idempotencyKey);
    if (!this.assets.has(input.asset)) throw new ExchangeError("VALIDATION", "Unknown asset");
    if (typeof input.amount !== "bigint" || input.amount <= 0n) throw new ExchangeError("VALIDATION", "amount must be positive");
    const fingerprint = fp({ k: kind, a: input.asset, m: input.amount });
    const idemKey = `${userId}:${input.idempotencyKey}`;
    const prior = this.idem.get(idemKey);
    if (prior) {
      if (prior.fingerprint !== fingerprint || prior.kind !== "TRANSFER") throw new ExchangeError("IDEMPOTENCY_CONFLICT", "Idempotency key reused with a different request");
      return { ...(this.transfers.get(prior.refId) as DemoTransfer) };
    }
    const now = this.clock();
    const t: DemoTransfer = { id: `xfer_${++this.transferSeq}`, userId, kind, asset: input.asset, amount: input.amount, status: "PENDING", reason: null, createdAt: now, updatedAt: now, simulated: true };
    if (kind === "WITHDRAWAL") {
      const avail = userAccount(userId, input.asset, "available");
      if (this.ledger.balance(avail, input.asset) < input.amount) { t.status = "REJECTED"; t.reason = "INSUFFICIENT_FUNDS"; }
      else this.ledger.post(buildTransferJournal(`wdl:${t.id}`, "SIMULATED withdrawal lock", input.asset, avail, userAccount(userId, input.asset, "pending"), input.amount));
    }
    this.transfers.set(t.id, t);
    this.idem.set(idemKey, { fingerprint, kind: "TRANSFER", refId: t.id });
    return { ...t };
  }

  /** ADMIN only. Stands in for a payment/custody partner; it never contacts anything external. */
  decideTransfer(actor: Actor, transferId: string, decision: "COMPLETE" | "REJECT"): Promise<DemoTransfer> {
    return this.withLock(() => {
      requireDemo(this.env);
      if (actor.role !== "ADMIN") throw new ExchangeError("FORBIDDEN", "Admin role required");
      const t = this.transfers.get(transferId);
      if (!t) throw new ExchangeError("NOT_FOUND", "Transfer not found");
      if (t.status !== "PENDING") throw new ExchangeError("INVALID_STATE", `Transfer is already ${t.status}`);
      const user = (k: "available" | "pending") => userAccount(t.userId, t.asset, k);
      if (t.kind === "DEPOSIT" && decision === "COMPLETE")
        this.ledger.post(buildTransferJournal(`dep:${t.id}`, "SIMULATED deposit credit", t.asset, faucetAccount(t.asset), user("available"), t.amount));
      if (t.kind === "WITHDRAWAL" && decision === "COMPLETE")
        this.ledger.post(buildTransferJournal(`wdc:${t.id}`, "SIMULATED withdrawal settle", t.asset, user("pending"), sinkAccount(t.asset), t.amount));
      if (t.kind === "WITHDRAWAL" && decision === "REJECT")
        this.ledger.post(buildTransferJournal(`wdr:${t.id}`, "SIMULATED withdrawal release", t.asset, user("pending"), user("available"), t.amount));
      t.status = decision === "COMPLETE" ? "COMPLETED" : "REJECTED";
      if (decision === "REJECT") t.reason = "REJECTED_BY_ADMIN";
      t.updatedAt = this.clock();
      return { ...t };
    });
  }

  // ------------------------------------------------------------------- reads
  getBalances(userId: string): Record<string, { available: bigint; reserved: bigint; pending: bigint }> {
    this.validateIds(userId, "x");
    const out: Record<string, { available: bigint; reserved: bigint; pending: bigint }> = {};
    const prefix = `user:${userId}:`;
    for (const [k, v] of this.ledger.balances()) {
      const accountId = k.split("|")[0] as string;
      if (!accountId.startsWith(prefix)) continue;
      const parts = accountId.split(":");
      const asset = parts[2]; const kind = parts[3];
      if (!asset || (kind !== "available" && kind !== "reserved" && kind !== "pending")) continue;
      const row = (out[asset] ??= { available: 0n, reserved: 0n, pending: 0n });
      row[kind] = v;
    }
    return out;
  }
  getOrder(userId: string, orderId: string): Order | null {
    const o = this.orders.get(orderId);
    return o && o.userId === userId ? this.copyOrder(o) : null;
  }
  listOrders(userId: string, filter: "OPEN" | "ALL" = "ALL"): Order[] {
    return [...this.orders.values()].filter((o) => o.userId === userId && (filter === "ALL" || o.status === "OPEN" || o.status === "PARTIALLY_FILLED")).map((o) => this.copyOrder(o));
  }
  listTransfers(userId: string): DemoTransfer[] {
    return [...this.transfers.values()].filter((t) => t.userId === userId).map((t) => ({ ...t }));
  }
  /** All fills of a market in chronological order (source of truth for candles). */
  marketTrades(market: string): TradeRecord[] { return this.trades.filter((t) => t.market === market).map((t) => ({ ...t })); }
  allTransfers(status?: DemoTransfer["status"]): DemoTransfer[] { return [...this.transfers.values()].filter((t) => !status || t.status === status).map((t) => ({ ...t })); }
  recentTrades(market: string, limit = 50): TradeRecord[] {
    return this.trades.filter((t) => t.market === market).slice(-limit).reverse().map((t) => ({ ...t }));
  }
  lifecycle(orderId: string): LifecycleEvent[] { return this.events.filter((e) => e.orderId === orderId).map((e) => ({ ...e })); }
  /** Aggregated depth. Liquidity is SIMULATED; prices are fictional and not real exchange quotes. */
  depth(market: string, levels = 20) {
    const snap = this.mustBook(market).snapshot();
    const agg = (rows: readonly { price: bigint; remaining: bigint }[]) => {
      const m = new Map<bigint, bigint>();
      for (const r of rows) m.set(r.price, (m.get(r.price) ?? 0n) + r.remaining);
      return [...m.entries()].slice(0, levels).map(([price, qty]) => ({ price, qty }));
    };
    return { market, simulated: true as const, source: "SIMULATED" as const, asOf: this.clock(), bids: agg(snap.bids), asks: agg(snap.asks) };
  }

  stats(): { orders: number; openOrders: number; trades: number; transfers: number; pendingTransfers: number; ledgerEntries: number } {
    const orders = [...this.orders.values()];
    const transfers = [...this.transfers.values()];
    return {
      orders: orders.length,
      openOrders: orders.filter((o) => o.status === "OPEN" || o.status === "PARTIALLY_FILLED").length,
      trades: this.trades.length,
      transfers: transfers.length,
      pendingTransfers: transfers.filter((t) => t.status === "PENDING").length,
      ledgerEntries: this.ledger.entries.length,
    };
  }
  /** Fills in which `userId` was taker or maker, newest first. */
  userTrades(userId: string, limit = 100): Array<TradeRecord & { userSide: Side; role: "TAKER" | "MAKER" }> {
    const out: Array<TradeRecord & { userSide: Side; role: "TAKER" | "MAKER" }> = [];
    for (let i = this.trades.length - 1; i >= 0 && out.length < limit; i--) {
      const t = this.trades[i] as TradeRecord;
      const taker = this.orders.get(t.takerOrderId);
      const maker = this.orders.get(t.makerOrderId);
      if (taker?.userId === userId) out.push({ ...t, userSide: taker.side, role: "TAKER" });
      else if (maker?.userId === userId) out.push({ ...t, userSide: maker.side, role: "MAKER" });
    }
    return out;
  }

  // ----------------------------------------------------------- reconciliation
  reconcileExchange(): ExchangeReconIssue[] {
    const issues: ExchangeReconIssue[] = [...reconcile(this.ledger.entries)];
    const derived = new Map<string, bigint>();
    for (const e of this.ledger.entries) for (const l of e.lines) {
      const k = `${l.accountId}|${l.currency}`;
      derived.set(k, (derived.get(k) ?? 0n) + l.credit - l.debit);
    }
    const live = this.ledger.balances();
    for (const k of new Set([...derived.keys(), ...live.keys()])) {
      const d = derived.get(k) ?? 0n; const a = live.get(k) ?? 0n;
      if (d !== a) issues.push({ kind: "PROJECTION_MISMATCH", account: k, expected: d, actual: a });
      if (k.startsWith("user:") && a < 0n) issues.push({ kind: "NEGATIVE_BALANCE", account: k, expected: 0n, actual: a });
    }
    const expectReserved = new Map<string, bigint>();
    for (const o of this.orders.values()) if (o.status === "OPEN" || o.status === "PARTIALLY_FILLED") {
      const k = `${userAccount(o.userId, o.reserveAsset, "reserved")}|${o.reserveAsset}`;
      expectReserved.set(k, (expectReserved.get(k) ?? 0n) + o.reservedRemaining);
    }
    const expectPending = new Map<string, bigint>();
    for (const t of this.transfers.values()) if (t.kind === "WITHDRAWAL" && t.status === "PENDING") {
      const k = `${userAccount(t.userId, t.asset, "pending")}|${t.asset}`;
      expectPending.set(k, (expectPending.get(k) ?? 0n) + t.amount);
    }
    const check = (kind: ":reserved|" | ":pending|", expected: Map<string, bigint>, label: "RESERVE_MISMATCH" | "PENDING_MISMATCH") => {
      for (const k of new Set([...expected.keys(), ...[...live.keys()].filter((x) => x.startsWith("user:") && x.includes(kind))])) {
        const e = expected.get(k) ?? 0n; const a = live.get(k) ?? 0n;
        if (e !== a) issues.push({ kind: label, account: k, expected: e, actual: a });
      }
    };
    check(":reserved|", expectReserved, "RESERVE_MISMATCH");
    check(":pending|", expectPending, "PENDING_MISMATCH");
    return issues;
  }

  // ------------------------------------------------------------------ helpers
  private validateIds(userId: string, key: string): void {
    if (typeof userId !== "string" || !USER_ID_RE.test(userId)) throw new ExchangeError("VALIDATION", "Invalid user id");
    if (typeof key !== "string" || !KEY_RE.test(key)) throw new ExchangeError("VALIDATION", "Invalid idempotency key");
  }
  private mustOrder(id: string): Order { const o = this.orders.get(id); if (!o) throw new Error(`invariant: order ${id} missing`); return o; }
  private mustBook(market: string): OrderBook { const b = this.books.get(market); if (!b) throw new ExchangeError("UNKNOWN_MARKET", "Unknown market"); return b; }
  private copyOrder(o: Order): Order { return { ...o }; }
  private tradesOf(orderId: string): TradeRecord[] {
    return this.tradeOrderIndex.filter(([id]) => id === orderId).map(([, i]) => ({ ...(this.trades[i] as TradeRecord) }));
  }
}
