/**
 * Market-maker engine for the SIMULATED NEXORA exchange. It can only call DemoExchange (never an external venue),
 * only for accounts that hold the MM role, and every action is logged.
 */
import { MoneyError, parseDecimal, pow10 } from "../../lib/money/decimal";
import { mulberry32 } from "../market-data/seeded";
import { requireDemo } from "../config/demo-guard";
import type { DemoExchange, MarketConfig } from "../trading/exchange";
import type { MmStrategy } from "./config";
import { LogBuffer, type MmLogEntry, type MmLogKind } from "./log";
export type { MmLogEntry, MmLogKind } from "./log";

interface Slot { side: "BUY" | "SELL"; level: number; orderId: string | null; expireAt: number; retryAt: number; filledSeen: bigint }
interface Calc { minQty: bigint; maxQty: bigint; qtyStep: bigint; priceStep: bigint; cum: bigint[]; sellMin: bigint | null; buyMax: bigint | null }
interface State { cfg: MmStrategy; market: MarketConfig; calc: Calc; running: boolean; slots: Slot[]; seq: number; placed: number; cancelled: number; filledQty: bigint }

export interface MmDeps {
  exchange: DemoExchange;
  markets: ReadonlyMap<string, MarketConfig>;
  reference: (market: string) => bigint | null;
  isMmAccount: (id: string) => boolean;
  now?: () => number;
  rand?: () => number;
  log?: LogBuffer;
  env?: Readonly<Record<string, string | undefined>>;
}
export interface LiveOrder { side: "BUY" | "SELL"; level: number; orderId: string; price: string; remaining: string; expiresInMs: number }
export interface StrategyStatus { id: string; name: string; account: string; market: string; side: string; running: boolean; orderCount: number; placed: number; cancelled: number; filledQty: string; live: LiveOrder[] }

const RETRY_MS = 5_000;

export class MarketMakerEngine {
  private readonly states = new Map<string, State>();
  readonly buffer: LogBuffer;
  private readonly now: () => number;
  private readonly rand: () => number;
  constructor(private readonly d: MmDeps) { this.now = d.now ?? (() => Date.now()); this.buffer = d.log ?? new LogBuffer(this.now); this.rand = d.rand ?? mulberry32((Date.now() & 0xffffffff) >>> 0); }

  private note(s: string, kind: MmLogKind, message: string): void { this.buffer.add(s, kind, message); }
  logs(limit = 100): MmLogEntry[] { return this.buffer.recent(limit); }
  has(id: string): boolean { return this.states.has(id); }
  strategy(id: string): MmStrategy | null { return this.states.get(id)?.cfg ?? null; }

  addStrategy(cfg: MmStrategy): void {
    const market = this.d.markets.get(cfg.market);
    if (!market) throw new Error(`Unknown market ${cfg.market}`);
    if (!this.d.isMmAccount(cfg.account)) throw new Error(`Account "${cfg.account}" does not hold the MM role`);
    if (this.states.has(cfg.id)) throw new Error(`Strategy ${cfg.id} already exists`);
    if (cfg.priceDecimals > market.quote.decimals || cfg.quantityDecimals > market.base.decimals) throw new Error("price/quantity decimals exceed the market precision");
    const money = (v: string, dec: number, what: string) => { try { return parseDecimal(v, dec); } catch (e) { throw new Error(`${what}: ${e instanceof MoneyError ? e.message : "invalid"}`); } };
    const cum: bigint[] = []; let acc = 0n;
    for (const s of cfg.splitRange) { acc += money(s, 6, "split_range"); cum.push(acc); } // micro-percent
    this.states.set(cfg.id, { cfg, market, running: false, seq: 0, placed: 0, cancelled: 0, filledQty: 0n, slots: [],
      calc: { minQty: money(cfg.minQty, market.base.decimals, "random_min_quantity"), maxQty: money(cfg.maxQty, market.base.decimals, "random_max_quantity"),
        qtyStep: pow10(market.base.decimals - cfg.quantityDecimals), priceStep: pow10(market.quote.decimals - cfg.priceDecimals), cum,
        sellMin: cfg.sellMinPrice ? money(cfg.sellMinPrice, market.quote.decimals, "sell_min_price_limit") : null,
        buyMax: cfg.buyMaxPrice ? money(cfg.buyMaxPrice, market.quote.decimals, "buy_max_price_limit") : null } });
  }

  async removeStrategy(id: string): Promise<void> {
    const s = this.must(id); if (s.running) await this.stop(id); this.states.delete(id);
  }
  private must(id: string): State { const s = this.states.get(id); if (!s) throw new Error(`Unknown strategy ${id}`); return s; }

  async start(id: string): Promise<void> {
    requireDemo(this.d.env ?? process.env);
    const s = this.must(id); if (s.running) return;
    const sides: Array<"BUY" | "SELL"> = s.cfg.side === "both" ? ["SELL", "BUY"] : s.cfg.side === "sell_only" ? ["SELL"] : ["BUY"];
    s.slots = sides.flatMap((side) => Array.from({ length: s.cfg.orderCount }, (_, level): Slot => ({ side, level, orderId: null, expireAt: 0, retryAt: 0, filledSeen: 0n })));
    s.running = true;
    this.note(id, "START", `Started ${s.cfg.name} on ${s.cfg.market} (${s.cfg.side}, ${s.cfg.orderCount} levels)`);
  }

  async stop(id: string): Promise<void> {
    const s = this.must(id); if (!s.running) return;
    s.running = false;
    for (const sl of s.slots) await this.cancelSlot(s, sl, "stopped");
    this.note(id, "STOP", `Stopped ${s.cfg.name}; live orders cancelled`);
  }

  async stopAll(): Promise<void> { for (const [id, s] of this.states) if (s.running) await this.stop(id); }

  /** One scheduler step: settle slots (fills/expiry) then place missing orders. Deterministic given clock + rand. */
  async tick(): Promise<void> {
    requireDemo(this.d.env ?? process.env);
    for (const s of this.states.values()) {
      if (!s.running) continue;
      for (const sl of s.slots) {
        const t = this.now();
        if (sl.orderId) {
          const o = this.d.exchange.getOrder(s.cfg.account, sl.orderId);
          if (!o) sl.orderId = null;
          else {
            if (o.filledQty > sl.filledSeen) { this.note(s.cfg.id, "FILL", `${sl.side} L${sl.level} filled ${o.filledQty - sl.filledSeen} (atomic) of ${o.qty}`); s.filledQty += o.filledQty - sl.filledSeen; sl.filledSeen = o.filledQty; }
            if (o.status === "FILLED" || o.status === "CANCELLED" || o.status === "REJECTED") sl.orderId = null;
            else if (t >= sl.expireAt) await this.cancelSlot(s, sl, "expired");
          }
        }
        if (!sl.orderId && s.running && t >= sl.retryAt) await this.place(s, sl);
      }
    }
  }

  private async cancelSlot(s: State, sl: Slot, why: string): Promise<void> {
    if (!sl.orderId) return;
    const id = sl.orderId; sl.orderId = null;
    try { await this.d.exchange.cancelOrder(s.cfg.account, id); s.cancelled++; this.note(s.cfg.id, "CANCEL", `${sl.side} L${sl.level} ${id} cancelled (${why})`); }
    catch { /* already filled or cancelled */ }
  }

  private base(s: State): bigint | null {
    const m = s.cfg.market;
    if (s.cfg.priceSource === "reference") return this.d.reference(m);
    if (s.cfg.priceSource === "last") return this.d.exchange.recentTrades(m, 1)[0]?.price ?? null;
    const dp = this.d.exchange.depth(m, 1); const b = dp.bids[0]?.price, a = dp.asks[0]?.price;
    return b !== undefined && a !== undefined ? (b + a) / 2n : null;
  }

  private jitter(pct: number): bigint { const bp = Math.round(pct * 100); return bp === 0 ? 0n : BigInt((this.rand() % (2 * bp + 1)) - bp); } // basis points of the value

  private async place(s: State, sl: Slot): Promise<void> {
    const id = s.cfg.id; const t = this.now(); const c = s.calc;
    const ref = this.base(s);
    if (ref === null || ref <= 0n) { this.note(id, "SKIP", `no ${s.cfg.priceSource} price available`); sl.retryAt = t + RETRY_MS; return; }
    const off = ((c.cum[sl.level] as bigint) * (10_000n + this.jitter(s.cfg.jitterPricePct))) / 10_000n; // micro-percent, jittered
    const raw = (ref * (100_000_000n + (sl.side === "SELL" ? off : -off))) / 100_000_000n;
    const price = ((raw + c.priceStep / 2n) / c.priceStep) * c.priceStep;
    if (price <= 0n) { sl.retryAt = t + RETRY_MS; return; }
    if (sl.side === "SELL" && c.sellMin !== null && price < c.sellMin) { this.note(id, "SKIP", `SELL L${sl.level} price ${price} below sell_min_price_limit`); sl.retryAt = t + RETRY_MS; return; }
    if (sl.side === "BUY" && c.buyMax !== null && price > c.buyMax) { this.note(id, "SKIP", `BUY L${sl.level} price ${price} above buy_max_price_limit`); sl.retryAt = t + RETRY_MS; return; }
    const steps = (c.maxQty - c.minQty) / c.qtyStep;
    const qty = c.minQty + c.qtyStep * (BigInt(this.rand()) % (steps + 1n));
    if (qty < s.market.minQty) { this.note(id, "SKIP", `quantity ${qty} below market minimum`); sl.retryAt = t + RETRY_MS; return; }
    try {
      const r = await this.d.exchange.placeOrder({ idempotencyKey: `mm-${id}-${++s.seq}`, userId: s.cfg.account, market: s.cfg.market, side: sl.side, type: "LIMIT", qty, price });
      if (r.order.status === "REJECTED") { this.note(id, "ERROR", `${sl.side} L${sl.level} rejected: ${r.order.reason ?? "unknown"}`); sl.retryAt = t + RETRY_MS; return; }
      sl.orderId = r.order.id; sl.filledSeen = r.order.filledQty;
      sl.expireAt = t + Math.round(s.cfg.expireSeconds * 1000 * (10_000 + Number(this.jitter(s.cfg.jitterTimingPct))) / 10_000);
      s.placed++;
      this.note(id, "PLACE", `${sl.side} L${sl.level} ${r.order.id} qty ${qty} @ ${price} (atomic)`);
      if (r.fills.length) { this.note(id, "FILL", `${sl.side} L${sl.level} crossed the book: ${r.fills.length} fill(s)`); s.filledQty += r.order.filledQty; }
    } catch (e) { this.note(id, "ERROR", `${sl.side} L${sl.level}: ${e instanceof Error ? e.message.slice(0, 120) : "error"}`); sl.retryAt = t + RETRY_MS; }
  }

  status(): StrategyStatus[] {
    const t = this.now();
    return [...this.states.values()].map((s) => ({
      id: s.cfg.id, name: s.cfg.name, account: s.cfg.account, market: s.cfg.market, side: s.cfg.side, running: s.running, orderCount: s.cfg.orderCount,
      placed: s.placed, cancelled: s.cancelled, filledQty: s.filledQty.toString(),
      live: s.slots.flatMap((sl) => {
        const o = sl.orderId ? this.d.exchange.getOrder(s.cfg.account, sl.orderId) : null;
        return o && o.price !== null ? [{ side: sl.side, level: sl.level, orderId: o.id, price: o.price.toString(), remaining: (o.qty - o.filledQty).toString(), expiresInMs: Math.max(0, sl.expireAt - t) }] : [];
      }),
    }));
  }
}
