/**
 * Market-maker strategy config + CSV importer for the "Field,Value,Edit" panel export format.
 * Strict by design: unknown fields, unsupported modes and unmapped accounts are ERRORS, never silently ignored.
 */
export type MmSide = "sell_only" | "buy_only" | "both";
export type MmPriceSource = "reference" | "last" | "mid";
export interface MmStrategy {
  kind: "order"; fields: Record<string, string>;
  id: string; name: string; account: string; market: string;
  priceSource: MmPriceSource; priceDecimals: number; quantityDecimals: number;
  minQty: string; maxQty: string; orderCount: number; expireSeconds: number; side: MmSide;
  /** [first level offset %, step % ...] one entry per level (decimal strings, exact). */
  splitRange: string[];
  buyMaxPrice: string | null; sellMinPrice: string | null; jitterTimingPct: number; jitterPricePct: number;
}
export interface RawSection { name: string; fields: Record<string, string> }

const VOLUME_ONLY = ["volume_price_decimal", "volume_quantity_decimal", "volume_random_min_quantity", "volume_random_max_quantity", "min_delay", "max_delay", "min_difference", "max_difference", "priority", "max_limit_price", "min_limit_price", "vol_idr_stop_target", "vol_idr_start_threshold", "volume_sell_account_id"];
const ORDER_ONLY = ["price_source", "price_decimal", "quantity_decimal", "random_min_quantity", "random_max_quantity", "order_count", "expire_time", "transaction_type", "split_order_mode", "split_range", "buy_trailing_min_percentage", "buy_trailing_max_percentage", "sell_trailing_min_percentage", "sell_trailing_max_percentage", "buy_max_price_limit", "sell_min_price_limit", "jitter_timing_pct", "jitter_price_pct"];
export const isVolumeSection = (f: Readonly<Record<string, string>>) => Object.keys(f).some((k) => VOLUME_ONLY.includes(k));
const KNOWN = new Set(["account_id", ...VOLUME_ONLY, ...ORDER_ONLY]);

const DEC = /^\d+(\.\d+)?$/;
const NONE = (v: string | undefined) => v === undefined || v === "" || v.toLowerCase() === "none";

export function parseCsv(text: string): string[][] {
  const rows: string[][] = []; let row: string[] = []; let cell = ""; let q = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i] as string;
    if (q) { if (ch === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += ch; }
    else if (ch === '"') q = true;
    else if (ch === ",") { row.push(cell); cell = ""; }
    else if (ch === "\n" || ch === "\r") { if (ch === "\r" && text[i + 1] === "\n") i++; row.push(cell); rows.push(row); row = []; cell = ""; }
    else cell += ch;
  }
  if (cell !== "" || row.length) { row.push(cell); rows.push(row); }
  return rows.filter((r) => r.some((c) => c.trim() !== ""));
}

export function parseMmCsv(text: string): { sections: RawSection[]; errors: string[] } {
  const sections: RawSection[] = []; const errors: string[] = []; let cur: RawSection | null = null;
  for (const r of parseCsv(text)) {
    if (r.length >= 3 && (r[1] ?? "").trim() === "Field") { cur = { name: (r[0] ?? "").trim(), fields: {} }; sections.push(cur); continue; }
    if (!cur || r.length < 3) continue;
    const k = (r[1] ?? "").trim(), v = (r[2] ?? "").trim();
    if (!KNOWN.has(k)) { errors.push(`${cur.name}: unknown field "${k.slice(0, 40)}"`); continue; }
    cur.fields[k] = v;
  }
  if (sections.length === 0) errors.push("No strategy sections found (expected rows like 'Name,Field,Value,Edit')");
  return { sections, errors };
}

const num = (v: string | undefined) => (v !== undefined && DEC.test(v) ? Number(v) : NaN);

export function buildStrategy(raw: RawSection, ctx: { market: string; accountMap: Readonly<Record<string, string>> }): { strategy?: MmStrategy; errors: string[] } {
  const f = raw.fields; const errors: string[] = []; const e = (m: string) => errors.push(`${raw.name}: ${m}`);
  for (const k of Object.keys(f)) if (VOLUME_ONLY.includes(k)) e(`field ${k} belongs to a volume bot, not an order bot`);
  const need = (k: string) => { if (f[k] === undefined) e(`missing field ${k}`); return f[k]; };
  const ext = need("account_id"); const account = ext ? ctx.accountMap[ext] : undefined;
  if (ext && !account) e(`account_id "${ext.slice(0, 20)}" is not mapped to a NEXORA account (map it explicitly, e.g. ${ext.slice(0, 20)}=mm)`);
  const ps = need("price_source");
  if (ps && !["reference", "last", "mid"].includes(ps)) e(`price_source "${ps}" is not supported (use reference, last or mid)`);
  const pd = num(need("price_decimal")), qd = num(need("quantity_decimal"));
  if (!Number.isInteger(pd) || pd < 0 || pd > 8) e("price_decimal must be an integer 0-8");
  if (!Number.isInteger(qd) || qd < 0 || qd > 8) e("quantity_decimal must be an integer 0-8");
  const minQ = need("random_min_quantity"), maxQ = need("random_max_quantity");
  if (!minQ || !DEC.test(minQ) || !maxQ || !DEC.test(maxQ) || !(Number(minQ) > 0) || Number(minQ) > Number(maxQ)) e("random_min_quantity/random_max_quantity must be positive decimals with min <= max");
  const oc = num(need("order_count"));
  if (!Number.isInteger(oc) || oc < 1 || oc > 20) e("order_count must be an integer 1-20");
  const ex = num(need("expire_time"));
  if (!(ex > 0) || ex > 86_400) e("expire_time must be seconds in (0, 86400]");
  const side = need("transaction_type");
  if (side && !["sell_only", "buy_only", "both"].includes(side)) e(`transaction_type "${side}" is not supported (use sell_only, buy_only or both)`);
  if (need("split_order_mode") !== "manual") e('split_order_mode must be "manual" (other modes are not supported)');
  let split: string[] = [];
  try {
    const arr: unknown = JSON.parse(need("split_range") ?? "null");
    if (!Array.isArray(arr) || arr.length !== oc) throw new Error();
    split = arr.map((x) => { const s = typeof x === "number" ? String(x) : ""; if (!DEC.test(s)) throw new Error(); return s; });
  } catch { e("split_range must be a JSON array of non-negative decimals with exactly order_count entries"); }
  for (const k of ["buy_trailing_min_percentage", "buy_trailing_max_percentage", "sell_trailing_min_percentage", "sell_trailing_max_percentage"]) if (!NONE(f[k])) e(`${k} is not supported yet; it must be None`);
  const lim = (k: string) => { const v = f[k]; if (NONE(v)) return null; if (!v || !DEC.test(v) || !(Number(v) > 0)) { e(`${k} must be None or a positive decimal`); return null; } return v; };
  const buyMax = lim("buy_max_price_limit"), sellMin = lim("sell_min_price_limit");
  const jt = num(need("jitter_timing_pct")), jp = num(need("jitter_price_pct"));
  if (!(jt >= 0 && jt <= 50) || !(jp >= 0 && jp <= 50)) e("jitter_timing_pct and jitter_price_pct must be 0-50");
  if (errors.length) return { errors };
  return { errors, strategy: {
    kind: "order", fields: { ...f }, id: raw.name.toLowerCase().replace(/[^a-z0-9_-]/g, "-").slice(0, 32), name: raw.name, account: account as string, market: ctx.market,
    priceSource: ps as MmPriceSource, priceDecimals: pd, quantityDecimals: qd, minQty: minQ as string, maxQty: maxQ as string, orderCount: oc,
    expireSeconds: ex, side: side as MmSide, splitRange: split, buyMaxPrice: buyMax, sellMinPrice: sellMin, jitterTimingPct: jt, jitterPricePct: jp,
  } };
}

export function importMmCsv(text: string, ctx: { market: string; accountMap: Readonly<Record<string, string>> }): { strategies: MmStrategy[]; errors: string[] } {
  const parsed = parseMmCsv(text); const errors = [...parsed.errors]; const strategies: MmStrategy[] = [];
  for (const s of parsed.sections) { const r = buildStrategy(s, ctx); errors.push(...r.errors); if (r.strategy) strategies.push(r.strategy); }
  const seen = new Set<string>();
  for (const s of strategies) { if (seen.has(s.id)) errors.push(`${s.name}: duplicate strategy id "${s.id}"`); seen.add(s.id); }
  return { strategies: errors.length ? [] : strategies, errors };
}

// ------------------------------------------------------------------ volume bots
export type VolPriority = "random" | "buy" | "sell";
export interface VolStrategy {
  kind: "volume"; fields: Record<string, string>; id: string; name: string; market: string;
  account: string; sellAccount: string | null;
  priceDecimals: number; quantityDecimals: number; minQty: string; maxQty: string;
  minDelaySec: number; maxDelaySec: number; minDiffPct: string; maxDiffPct: string; priority: VolPriority;
  maxLimitPrice: string | null; minLimitPrice: string | null; stopTarget: string | null; startThreshold: string | null;
}
export type AnyBot = MmStrategy | VolStrategy;

export function buildVolumeStrategy(raw: RawSection, ctx: { market: string; accountMap: Readonly<Record<string, string>> }): { strategy?: VolStrategy; errors: string[] } {
  const f = raw.fields; const errors: string[] = []; const e = (m: string) => errors.push(`${raw.name}: ${m}`);
  for (const k of Object.keys(f)) if (ORDER_ONLY.includes(k)) e(`field ${k} belongs to an order bot, not a volume bot`);
  const need = (k: string) => { if (f[k] === undefined) e(`missing field ${k}`); return f[k]; };
  const ext = need("account_id"); const account = ext ? ctx.accountMap[ext] : undefined;
  if (ext && !account) e(`account_id "${ext.slice(0, 20)}" is not mapped to a NEXORA account (map it explicitly, e.g. ${ext.slice(0, 20)}=mm)`);
  let sellAccount: string | null = null;
  if (!NONE(f["volume_sell_account_id"])) {
    sellAccount = ctx.accountMap[f["volume_sell_account_id"] as string] ?? null;
    if (!sellAccount) e(`volume_sell_account_id "${(f["volume_sell_account_id"] as string).slice(0, 20)}" is not mapped to a NEXORA account`);
    else if (sellAccount === account) e("volume_sell_account_id must differ from account_id");
  }
  const pd = num(need("volume_price_decimal")), qd = num(need("volume_quantity_decimal"));
  if (!Number.isInteger(pd) || pd < 0 || pd > 8) e("volume_price_decimal must be an integer 0-8");
  if (!Number.isInteger(qd) || qd < 0 || qd > 8) e("volume_quantity_decimal must be an integer 0-8");
  const minQ = need("volume_random_min_quantity"), maxQ = need("volume_random_max_quantity");
  if (!minQ || !DEC.test(minQ) || !maxQ || !DEC.test(maxQ) || !(Number(minQ) > 0) || Number(minQ) > Number(maxQ)) e("volume_random_min_quantity/volume_random_max_quantity must be positive decimals with min <= max");
  const d1 = num(need("min_delay")), d2 = num(need("max_delay"));
  if (!(d1 >= 0.1) || !(d2 <= 3600) || d1 > d2) e("min_delay/max_delay must be seconds in [0.1, 3600] with min <= max");
  const f1 = need("min_difference"), f2 = need("max_difference");
  if (!f1 || !DEC.test(f1) || !f2 || !DEC.test(f2) || Number(f1) > Number(f2) || Number(f2) > 50) e("min_difference/max_difference must be percentages 0-50 with min <= max");
  const pr = need("priority");
  if (pr && !["random", "buy", "sell"].includes(pr)) e(`priority "${pr}" is not supported (use random, buy or sell)`);
  const lim = (k: string) => { const v = f[k]; if (NONE(v)) return null; if (!v || !DEC.test(v) || !(Number(v) > 0)) { e(`${k} must be None or a positive decimal`); return null; } return v; };
  const maxP = lim("max_limit_price"), minP = lim("min_limit_price"), stop = lim("vol_idr_stop_target"), start = lim("vol_idr_start_threshold");
  if (maxP && minP && Number(minP) > Number(maxP)) e("min_limit_price must be <= max_limit_price");
  if (errors.length) return { errors };
  return { errors, strategy: {
    kind: "volume", fields: { ...f }, id: raw.name.toLowerCase().replace(/[^a-z0-9_-]/g, "-").slice(0, 32), name: raw.name, market: ctx.market, account: account as string, sellAccount,
    priceDecimals: pd, quantityDecimals: qd, minQty: minQ as string, maxQty: maxQ as string, minDelaySec: d1, maxDelaySec: d2, minDiffPct: f1 as string, maxDiffPct: f2 as string,
    priority: pr as VolPriority, maxLimitPrice: maxP, minLimitPrice: minP, stopTarget: stop, startThreshold: start } };
}

/** Imports order bots and volume bots from one CSV; any error imports nothing. */
export function importBots(text: string, ctx: { market: string; accountMap: Readonly<Record<string, string>> }): { bots: AnyBot[]; errors: string[] } {
  const parsed = parseMmCsv(text); const errors = [...parsed.errors]; const bots: AnyBot[] = [];
  for (const sec of parsed.sections) {
    const r = isVolumeSection(sec.fields) ? buildVolumeStrategy(sec, ctx) : buildStrategy(sec, ctx);
    errors.push(...r.errors); if (r.strategy) bots.push(r.strategy);
  }
  const seen = new Set<string>();
  for (const b of bots) { if (seen.has(b.id)) errors.push(`${b.name}: duplicate bot id "${b.id}"`); seen.add(b.id); }
  return { bots: errors.length ? [] : bots, errors };
}

/** Rebuild a bot from edited raw fields (same validation as import). Used by the panel's edit and clone. */
export function rebuildBot(kind: "order" | "volume", name: string, fields: Record<string, string>, ctx: { market: string; accountMap: Readonly<Record<string, string>> }): { bot?: AnyBot; errors: string[] } {
  const r = kind === "volume" ? buildVolumeStrategy({ name, fields }, ctx) : buildStrategy({ name, fields }, ctx);
  return { errors: r.errors, ...(r.strategy ? { bot: r.strategy } : {}) };
}
