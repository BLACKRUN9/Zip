export type MmLogKind = "START" | "STOP" | "PLACE" | "CANCEL" | "FILL" | "SKIP" | "ERROR" | "VOLUME";
export interface MmLogEntry { at: number; strategyId: string; kind: MmLogKind; message: string }
const MAX = 500;
/** Shared ring buffer for every bot. */
export class LogBuffer {
  private readonly entries: MmLogEntry[] = [];
  constructor(private readonly now: () => number = () => Date.now()) {}
  add(strategyId: string, kind: MmLogKind, message: string): void {
    this.entries.push({ at: this.now(), strategyId, kind, message });
    if (this.entries.length > MAX) this.entries.splice(0, this.entries.length - MAX);
  }
  recent(limit = 100, strategyId?: string): MmLogEntry[] {
    const src = strategyId ? this.entries.filter((e) => e.strategyId === strategyId) : this.entries;
    return src.slice(-limit).reverse();
  }
}
