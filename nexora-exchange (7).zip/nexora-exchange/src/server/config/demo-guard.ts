/**
 * Server-side demo-only guard. There is intentionally NO live mode and NO override flag.
 * Any value other than the exact string "true" aborts startup.
 */
export class DemoModeError extends Error {
  constructor(message: string) { super(message); this.name = "DemoModeError"; }
}

export function assertDemoMode(env: Readonly<Record<string, string | undefined>>): void {
  if (env["DEMO_MODE"] !== "true") {
    throw new DemoModeError("NEXORA runs in DEMO_MODE=true only. Live financial operations do not exist in this codebase.");
  }
}

/** Every balance-affecting server operation calls this first. */
export function requireDemo(env: Readonly<Record<string, string | undefined>> = process.env): void {
  assertDemoMode(env);
}
