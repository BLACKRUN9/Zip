import { expect, test } from "@playwright/test";

const ROUTES = ["/", "/login", "/register", "/dashboard", "/markets", "/trade/NXR-USDT", "/trade/NXR-USDT", "/portfolio", "/orders", "/wallet", "/settings", "/mm", "/admin"];
const WIDTHS = [320, 360, 390, 768, 1280];

for (const width of WIDTHS) {
  for (const route of ROUTES) {
    test(`no horizontal overflow: ${route} @ ${width}px, DEMO banner visible`, async ({ page }) => {
      await page.setViewportSize({ width, height: 800 });
      await page.goto(route);
      await expect(page.getByRole("status", { name: "Demo mode indicator" })).toBeVisible();
      const m = await page.evaluate(() => {
        const vw = document.documentElement.clientWidth;
        const offenders: string[] = [];
        for (const el of Array.from(document.querySelectorAll("body *"))) {
          if (el.closest(".table-wrap, .market-pills, .skip-link, .sr-only")) continue; // intentionally scrollable / hidden
          const r = el.getBoundingClientRect();
          if (r.width > 0 && (r.right > vw + 1 || r.left < -1)) offenders.push(`${el.tagName.toLowerCase()}.${String((el as HTMLElement).className).slice(0, 40)}`);
        }
        return { scrollWidth: document.documentElement.scrollWidth, vw, offenders: offenders.slice(0, 5) };
      });
      expect(m.scrollWidth).toBeLessThanOrEqual(m.vw);
      expect(m.offenders).toEqual([]);
    });
  }
}

test("navigation: mobile bottom nav on phones, sidebar on desktop", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 800 });
  await page.goto("/dashboard");
  await expect(page.getByRole("navigation", { name: "Mobile navigation" })).toBeVisible();
  await expect(page.getByRole("navigation", { name: "Main navigation" })).toBeHidden();
  await page.getByRole("navigation", { name: "Mobile navigation" }).getByRole("link", { name: "Markets" }).click();
  await expect(page).toHaveURL(/\/markets$/);
  await page.getByText("More", { exact: true }).click();
  await page.getByRole("link", { name: "Wallet (demo)" }).click();
  await expect(page).toHaveURL(/\/wallet$/);
  await page.setViewportSize({ width: 1280, height: 800 });
  await expect(page.getByRole("navigation", { name: "Main navigation" })).toBeVisible();
  await expect(page.getByRole("navigation", { name: "Mobile navigation" })).toBeHidden();
});

test("trading terminal: market selector, validation, insufficient balance, simulated order", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 900 });
  await page.goto("/trade/NXR-USDT");
  await page.getByRole("link", { name: "BTC / USD" }).click();
  await expect(page).toHaveURL(/\/trade\/BTC-USD$/);
  await page.getByRole("link", { name: "NXR / USDT" }).click();

  const submit = page.getByRole("button", { name: /Buy NXR \(simulated\)/ });
  await expect(submit).toBeDisabled();
  await page.getByLabel(/Quantity/).fill("abc");
  await expect(page.getByText("Enter a positive number")).toBeVisible();
  await page.getByLabel(/Quantity/).fill("0.123456789");
  await expect(page.getByText("At most 8 decimal places")).toBeVisible();

  await page.getByLabel(/Price/).fill("4");
  await page.getByLabel(/Quantity/).fill("99999999");
  await expect(page.getByRole("alert").filter({ hasText: "Insufficient balance" })).toBeVisible();
  await expect(submit).toBeDisabled();

  await page.getByRole("radio", { name: "Market" }).check({ force: true });
  await page.getByLabel(/Quantity/).fill("1");
  await expect(submit).toBeEnabled();
  await submit.click();
  await expect(page.getByText(/SIMULATED order ord_\d+ is filled/)).toBeVisible();
  await page.goto("/orders");
  await expect(page.getByRole("table", { name: "Simulated fills" })).toBeVisible();
});

test("chart: refresh button, timeframe and source label", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 900 });
  await page.goto("/trade/NXR-USDT");
  await expect(page.getByText(/NEXORA · built from simulated trades/)).toBeVisible();
  await expect(page.getByRole("group", { name: "Indicators" })).toBeVisible();
  await page.getByRole("button", { name: "TradingView" }).click();
  await expect(page.getByRole("img", { name: /TradingView Lightweight Charts/ })).toBeVisible();
  await page.getByRole("button", { name: "NEXORA" }).click();
  const refresh = page.getByRole("button", { name: "Refresh chart now" });
  const responded = page.waitForResponse((r) => r.url().includes("/api/market/NXR-USDT/candles") && r.status() === 200);
  await refresh.click();
  await responded;
  await expect(refresh).toBeEnabled();
  await expect(page.getByRole("status").filter({ hasText: /Updated \d\d:\d\d:\d\d UTC/ })).toBeVisible();
  const hour = page.waitForResponse((r) => r.url().includes("interval=60"));
  await page.getByRole("button", { name: "1h" }).click();
  await hour;
  await expect(page.getByRole("button", { name: "1h" })).toHaveAttribute("aria-pressed", "true");
  const bad = await page.request.get("/api/market/NXR-USDT/candles?interval=7");
  expect(bad.status()).toBe(400);
});

test("keyboard: order side radios are reachable and switch with arrow keys", async ({ page }) => {
  await page.setViewportSize({ width: 1280, height: 900 });
  await page.goto("/trade/NXR-USDT");
  await page.getByRole("radio", { name: "Buy" }).focus();
  await page.keyboard.press("ArrowRight");
  await expect(page.getByRole("radio", { name: "Sell" })).toBeChecked();
  await expect(page.getByRole("button", { name: /Sell NXR \(simulated\)/ })).toBeVisible();
});

test("unbuilt features are visibly disabled, not faked", async ({ page }) => {
  await page.goto("/login");
  await expect(page.getByLabel("Email")).toBeDisabled();
  await expect(page.getByRole("button", { name: /Log in \(available in Milestone 2\)/ })).toBeDisabled();
  await page.goto("/settings");
  await expect(page.getByRole("button", { name: "Change password" })).toBeDisabled();
  await page.goto("/admin");
  await expect(page.getByText(/cannot access the admin dashboard/)).toBeVisible(); // user1 is a USER: server-side role check
  await page.goto("/mm");
  await expect(page.getByText(/cannot access the market maker console/)).toBeVisible();
});

test("visual baselines (static pages only; run once with --update-snapshots)", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  for (const route of ["/", "/login"]) {
    await page.goto(route);
    await expect(page).toHaveScreenshot(`${route === "/" ? "landing" : "login"}-mobile.png`, { fullPage: true, maxDiffPixelRatio: 0.03 });
  }
});
