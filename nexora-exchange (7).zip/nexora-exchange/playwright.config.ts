import { defineConfig, devices } from "@playwright/test";

// NOT RUN in the authoring sandbox (no browsers there). Run locally: `npx playwright install chromium && npm run e2e`.
export default defineConfig({
  testDir: "./e2e",
  fullyParallel: true,
  retries: 0,
  reporter: [["list"]],
  use: { baseURL: "http://localhost:3000", trace: "retain-on-failure" },
  webServer: {
    command: "npm run dev",
    url: "http://localhost:3000",
    reuseExistingServer: true,
    timeout: 240_000,
    env: { DEMO_MODE: "true", NEXORA_DEV_ACTOR: "user1", MM_AUTOSTART: "true" }, // dev actor + order bots so the book has liquidity
  },
  projects: [{ name: "chromium", use: { ...devices["Desktop Chrome"] } }],
});
