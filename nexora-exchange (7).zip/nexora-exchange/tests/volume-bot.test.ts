import { test } from "node:test";
import assert from "node:assert/strict";
import { DemoExchange, type MarketConfig } from "../src/server/trading/exchange";
import { DemoModeError } from "../src/server/config/demo-guard";
import { importBots, rebuildBot, type VolStrategy, type MmStrategy } from "../src/server/mm/config";
import { LogBuffer } from "../src/server/mm/log";
import { MarketMakerEngine } from "../src/server/mm/engine";
import { VolumeBotEngine } from "../src/server/mm/volume-engine";
import { mulberry32 } from "../src/server/market-data/seeded";
import { aggregateTrades } from "../src/server/market-data/trades";

const MKT: MarketConfig = { symbol: "NXR-USDT", base: { symbol: "NXR", decimals: 8 }, quote: { symbol: "USDT", decimals: 6 }, takerFeeBps: 25, makerFeeBps: 10, minQty: 1_000_000n, minNotional: 10_000n };
const ENV = { DEMO_MODE: "true" };
const ADMIN = { userId: "admin", role: "ADMIN" as const };
const isMm = (id: string) => id === "mm" || id === "mm2";
const ctx = { market: "NXR-USDT", accountMap: { A1: "mm", A2: "mm2", U1: "user1" } };
const VOL_FIELDS = (over: Record<string, string> = {}) => ({ account_id: "A1", volume_price_decimal: "4", volume_quantity_decimal: "2", volume_random_min_quantity: "10", volume_random_max_quantity: "20", min_delay: "1", max_delay: "3", min_difference: "0.1", max_difference: "0.5", priority: "random", max_limit_price: "4.6", min_limit_price: "3.5", vol_idr_stop_target: "None", vol_idr_start_threshold: "None", volume_sell_account_id: "A2", ...over });
const csvOf = (name: string, f: Record<string, string>) => `${name},Field,Value,Edit\n` + Object.entries(f).map(([k, v], i) => `${i + 2},${k},${v.includes(",") ? `"${v}"` : v},`).join("\n") + "\n";
const vol = (over: Record<string, string> = {}): VolStrategy => { const r = importBots(csvOf("Vol1", VOL_FIELDS(over)), ctx); assert.deepEqual(r.errors, []); return r.bots[0] as VolStrategy; };

async function world() {
  let t = 5_000_000; const clock = { now: () => t, advance: (ms: number) => { t += ms; } };
  const ex = new DemoExchange({ markets: [MKT], clock: clock.now, env: ENV });
  const fund = async (u: string, a: string, n: bigint) => { const d = await ex.requestDeposit(u, { idempotencyKey: `f-${u}-${a}`, asset: a, amount: n }); await ex.decideTransfer(ADMIN, d.id, "COMPLETE"); };
  for (const u of ["mm", "mm2"]) { await fund(u, "NXR", 10_000_000_000_000n); await fund(u, "USDT", 10_000_000_000_000n); }
  await fund("user1", "USDT", 1_000_000_000n); await fund("user1", "NXR", 100_000_000_000n);
  const log = new LogBuffer(clock.now);
  const deps = (over = {}) => ({ exchange: ex, markets: new Map([[MKT.symbol, MKT]]), reference: () => 4_000_000n as bigint | null, isMmAccount: isMm, log, now: clock.now, rand: mulberry32(5), env: ENV, ...over });
  return { ex, clock, log, vb: (over = {}) => new VolumeBotEngine(deps(over)), mm: (over = {}) => new MarketMakerEngine(deps(over)) };
}

test("generic import: order bots and volume bots in one CSV; unmapped/invalid values are errors", () => {
  const order = Object.fromEntries(Object.entries({ account_id: "A1", price_source: "reference", price_decimal: "4", quantity_decimal: "2", random_min_quantity: "12.0", random_max_quantity: "28.0", order_count: "2", expire_time: "100", transaction_type: "buy_only", split_order_mode: "manual", split_range: "[0.1, 0.2]", buy_trailing_min_percentage: "None", buy_trailing_max_percentage: "None", sell_trailing_min_percentage: "None", sell_trailing_max_percentage: "None", buy_max_price_limit: "4.6", sell_min_price_limit: "3.5", jitter_timing_pct: "20", jitter_price_pct: "5" }));
  const r = importBots(csvOf("Buy1", order) + csvOf("Vol1", VOL_FIELDS()), ctx);
  assert.deepEqual(r.errors, []); assert.deepEqual(r.bots.map((b) => `${b.kind}:${b.id}`), ["order:buy1", "volume:vol1"]);
  const v = r.bots[1] as VolStrategy;
  assert.deepEqual([v.account, v.sellAccount, v.priority, v.minDelaySec, v.maxDelaySec, v.stopTarget, v.maxLimitPrice], ["mm", "mm2", "random", 1, 3, null, "4.6"]);
  const bad = (over: Record<string, string>) => importBots(csvOf("Vol1", VOL_FIELDS(over)), ctx).errors.join("|");
  assert.match(bad({ volume_sell_account_id: "ZZZ" }), /not mapped/); assert.match(bad({ volume_sell_account_id: "A1" }), /must differ/);
  assert.match(bad({ priority: "chaos" }), /priority/); assert.match(bad({ min_delay: "5", max_delay: "2" }), /min_delay/);
  assert.match(bad({ min_difference: "2", max_difference: "1" }), /min_difference/); assert.match(bad({ min_limit_price: "9" }), /min_limit_price/);
  assert.match(bad({ vol_idr_stop_target: "-5" }), /vol_idr_stop_target/); assert.match(bad({ volume_random_max_quantity: "5" }), /min <= max/);
  assert.match(importBots(csvOf("Vol1", { ...VOL_FIELDS(), order_count: "5" }), ctx).errors.join("|"), /order bot/);
  assert.match(importBots(csvOf("Buy1", { ...order, min_delay: "1" }), ctx).errors.join("|"), /volume bot/);
});

test("clone/edit rebuild: same validation, new id, independent config", () => {
  const base = vol();
  const clone = rebuildBot("volume", "Vol1 copy", { ...base.fields, volume_random_max_quantity: "40", min_delay: "2" }, ctx);
  assert.deepEqual(clone.errors, []); const c = clone.bot as VolStrategy;
  assert.equal(c.id, "vol1-copy"); assert.equal(c.maxQty, "40"); assert.equal(base.maxQty, "20"); assert.equal(c.minDelaySec, 2);
  assert.ok(rebuildBot("volume", "x", { ...base.fields, priority: "nope" }, ctx).errors.length > 0);
});

test("cross mode: trades between the two MM accounts at the configured price band; candles match; trades are tagged synthetic", async () => {
  const w = await world(); const b = w.vb(); b.addBot(vol());
  await b.start("vol1"); await b.tick();
  const trades = w.ex.marketTrades("NXR-USDT");
  assert.equal(trades.length, 1);
  const tr = trades[0]!;
  assert.ok(tr.price >= 3_990_000n && tr.price <= 4_020_100n, `price within +-0.5% of 4.0 (${tr.price})`);
  assert.ok(tr.qty >= 1_000_000_000n && tr.qty <= 2_000_000_000n && tr.qty % 1_000_000n === 0n, "qty in [10,20] with 2 decimals");
  assert.equal(w.ex.depth("NXR-USDT").bids.length + w.ex.depth("NXR-USDT").asks.length, 0, "no stray legs left on the book");
  assert.ok(b.isSynthetic("NXR-USDT", tr.id)); assert.equal(b.syntheticCount("NXR-USDT"), 1);
  const [c] = aggregateTrades(trades, { intervalMs: 60_000, nowMs: w.clock.now(), limit: 5 });
  assert.deepEqual([c!.open, c!.close, c!.volume], [tr.price, tr.price, tr.qty]);
  assert.equal(BigInt(b.status()[0]!.generated), (tr.qty * tr.price) / 100_000_000n);
  assert.deepEqual(w.ex.reconcileExchange(), []);
  assert.ok(w.log.recent().some((l) => l.kind === "VOLUME"));
});

test("delays are random within [min,max] and trades keep flowing; limits are respected", async () => {
  const w = await world(); const b = w.vb(); b.addBot(vol());
  await b.start("vol1"); let last = 0; const gaps: number[] = [];
  for (let i = 0; i < 60; i++) { const before = w.ex.marketTrades("NXR-USDT").length; await b.tick(); if (w.ex.marketTrades("NXR-USDT").length > before) { if (last) gaps.push(w.clock.now() - last); last = w.clock.now(); } w.clock.advance(500); }
  assert.ok(gaps.length >= 5, `enough trades happened (${gaps.length})`);
  assert.ok(gaps.every((g) => g >= 1000 && g <= 3500), `gaps within 1-3s (+tick granularity): ${gaps}`);
  for (const t of w.ex.marketTrades("NXR-USDT")) assert.ok(t.price >= 3_500_000n && t.price <= 4_600_000n);
  const tight = await world(); const tb = tight.vb(); tb.addBot(vol({ max_limit_price: "3.9" })); await tb.start("vol1"); await tb.tick();
  assert.equal(tight.ex.marketTrades("NXR-USDT").length, 0); assert.ok(tight.log.recent().some((l) => /outside min\/max_limit_price/.test(l.message)));
  assert.deepEqual(w.ex.reconcileExchange(), []);
});

test("vol_idr_stop_target auto-stops; vol_idr_start_threshold gates on trailing 24h volume", async () => {
  const w = await world(); const b = w.vb(); b.addBot(vol({ vol_idr_stop_target: "100", min_delay: "1", max_delay: "1" }));
  await b.start("vol1");
  for (let i = 0; i < 40 && b.status()[0]!.running; i++) { await b.tick(); w.clock.advance(1000); }
  const st = b.status()[0]!; assert.equal(st.running, false); assert.ok(BigInt(st.generated) >= 100_000_000n);
  assert.ok(w.log.recent().some((l) => /stop_target reached/.test(l.message)));
  const g = await world(); const gb = g.vb(); gb.addBot(vol({ vol_idr_start_threshold: "50", min_delay: "1", max_delay: "1" }));
  await gb.start("vol1");
  for (let i = 0; i < 6; i++) { await gb.tick(); g.clock.advance(1000); }
  const n = g.ex.marketTrades("NXR-USDT").length; assert.ok(n >= 1 && n <= 6);
  for (let i = 0; i < 10; i++) { await gb.tick(); g.clock.advance(6000); }
  assert.equal(g.ex.marketTrades("NXR-USDT").length, n, "above the 24h threshold the bot idles");
  assert.ok(gb.status()[0]!.idle); assert.ok(g.log.recent().some((l) => /above vol_idr_start_threshold/.test(l.message)));
});

test("book mode takes real liquidity from order-bot quotes (no counterparty account)", async () => {
  const w = await world(); const mmE = w.mm(); const vb = w.vb();
  const sell = importBots(csvOf("Sell1", { account_id: "A1", price_source: "reference", price_decimal: "4", quantity_decimal: "2", random_min_quantity: "50", random_max_quantity: "60", order_count: "2", expire_time: "600", transaction_type: "sell_only", split_order_mode: "manual", split_range: "[0.1, 0.2]", buy_trailing_min_percentage: "None", buy_trailing_max_percentage: "None", sell_trailing_min_percentage: "None", sell_trailing_max_percentage: "None", buy_max_price_limit: "None", sell_min_price_limit: "3.5", jitter_timing_pct: "0", jitter_price_pct: "0" }), ctx);
  assert.deepEqual(sell.errors, []); mmE.addStrategy(sell.bots[0] as MmStrategy); await mmE.start("sell1"); await mmE.tick();
  vb.addBot(vol({ account_id: "A2", volume_sell_account_id: "None", priority: "buy" })); await vb.start("vol1"); await vb.tick();
  const trades = w.ex.marketTrades("NXR-USDT"); assert.equal(trades.length, 1);
  assert.equal(trades[0]!.takerSide, "BUY"); assert.ok(vb.isSynthetic("NXR-USDT", trades[0]!.id));
  assert.equal(vb.status()[0]!.mode, "book");
  assert.deepEqual(w.ex.reconcileExchange(), []);
  const empty = await world(); const eb = empty.vb(); eb.addBot(vol({ volume_sell_account_id: "None", priority: "buy" })); await eb.start("vol1"); await eb.tick();
  assert.ok(empty.log.recent().some((l) => /no liquidity/.test(l.message)));
});

test("safety: MM-role accounts only, demo mode enforced, insufficient funds are logged", async () => {
  const w = await world();
  const asUser = importBots(csvOf("Vol1", VOL_FIELDS({ account_id: "U1" })), ctx).bots[0] as VolStrategy;
  assert.throws(() => w.vb().addBot(asUser), /MM role/);
  const asSellUser = importBots(csvOf("Vol1", VOL_FIELDS({ volume_sell_account_id: "U1" })), ctx).bots[0] as VolStrategy;
  assert.throws(() => w.vb().addBot(asSellUser), /MM role/);
  assert.throws(() => w.vb().addBot(vol({ min_difference: "0.1" }) && { ...vol(), market: "BTC-USD" }), /Unknown market/);
  const off = w.vb({ env: { DEMO_MODE: "false" } }); off.addBot(vol());
  await assert.rejects(off.start("vol1"), DemoModeError); await assert.rejects(off.tick(), DemoModeError);
  const poor = new DemoExchange({ markets: [MKT], clock: w.clock.now, env: ENV });
  const pb = new VolumeBotEngine({ exchange: poor, markets: new Map([[MKT.symbol, MKT]]), reference: () => 4_000_000n, isMmAccount: isMm, log: w.log, now: w.clock.now, rand: mulberry32(1), env: ENV });
  pb.addBot(vol()); await pb.start("vol1"); await pb.tick();
  assert.ok(w.log.recent().some((l) => l.kind === "ERROR" && /rejected/.test(l.message)));
  assert.equal(poor.marketTrades("NXR-USDT").length, 0);
});
