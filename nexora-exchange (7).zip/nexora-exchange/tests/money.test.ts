import { test } from "node:test";
import assert from "node:assert/strict";
import { parseDecimal, formatAtomic, MoneyError } from "../src/lib/money/decimal";
import { feeOf, notional } from "../src/lib/money/trade-math";

test("parse/format round-trip is exact where floats are not (0.1 + 0.2)", () => {
  const a = parseDecimal("0.1", 8), b = parseDecimal("0.2", 8);
  assert.equal(formatAtomic(a + b, 8), "0.30000000");
});
test("rejects excess precision rather than rounding", () => {
  assert.throws(() => parseDecimal("1.123456789", 8), (e) => e instanceof MoneyError && e.code === "PRECISION_EXCEEDED");
});
test("rejects negatives, exponents, empty and junk input", () => {
  for (const bad of ["-1", "1e5", "", ".5", "1.", "abc", "1,5", "0x10"]) {
    assert.throws(() => parseDecimal(bad, 8), MoneyError, bad);
  }
});
test("large values stay exact beyond Number.MAX_SAFE_INTEGER", () => {
  assert.equal(formatAtomic(parseDecimal("90071992547409.93", 2), 2), "90071992547409.93");
});
test("notional floors and fee rounds up", () => {
  // 1 atomic base * 100_500_000 / 1e8 = 1.005 -> floor 1
  assert.equal(notional(1n, parseDecimal("100.5", 6), 8), 1n);
  // 1 atomic base * 99_999_999 / 1e8 = 0.99999999 -> floor 0 (never rounds up in the payer's disfavour)
  assert.equal(notional(1n, 99_999_999n, 8), 0n);
  assert.equal(feeOf(1n, 10), 1n); // ceil(10/10000) = 1
  assert.equal(feeOf(10_000n, 10), 10n);
  assert.equal(feeOf(0n, 10), 0n);
});
test("fee bps bounds enforced", () => {
  assert.throws(() => feeOf(100n, -1), MoneyError);
  assert.throws(() => feeOf(100n, 10_001), MoneyError);
  assert.throws(() => feeOf(100n, 1.5), MoneyError);
});
