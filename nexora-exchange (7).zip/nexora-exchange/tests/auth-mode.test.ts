import { test } from "node:test";
import assert from "node:assert/strict";
import { actorFromEmail, checkSeedAllowed, readAuthEnv, readAuthMode, resolveActor } from "../src/server/auth/mode";
import { ACCOUNTS, accountByEmail } from "../src/server/accounts/directory";

const GOOD = { BETTER_AUTH_SECRET: "k3Jx9mPq2Lw8Zr5Tn7Vb4Hc6Yd1Fg0Aa", DATABASE_URL: "postgresql://nexora:s3cret@localhost:5432/nexora_demo", BETTER_AUTH_URL: "http://localhost:3000" };

test("every seeded account has a unique reserved .invalid email and maps back to itself", () => {
  const emails = ACCOUNTS.map((a) => a.email);
  assert.equal(new Set(emails).size, emails.length);
  assert.ok(emails.every((e) => e.endsWith("@nexora.invalid")));
  for (const a of ACCOUNTS) assert.deepEqual(actorFromEmail(a.email), { userId: a.id, role: a.role });
  assert.deepEqual(actorFromEmail(" ADMIN@Nexora.Invalid "), { userId: "admin", role: "ADMIN" });
});

test("only directory emails become actors; the role never comes from anywhere else", () => {
  for (const e of [null, undefined, "", "root@nexora.invalid", "admin@evil.com", "admin@nexora.invalid.evil.com", "user1+admin@nexora.invalid"]) assert.equal(actorFromEmail(e), null, String(e));
  assert.equal(accountByEmail("nobody@nexora.invalid"), null);
});

test("AUTH_MODE: default dev, explicit better-auth, anything else is an error", () => {
  assert.equal(readAuthMode({}), "dev"); assert.equal(readAuthMode({ AUTH_MODE: "dev" }), "dev"); assert.equal(readAuthMode({ AUTH_MODE: "better-auth" }), "better-auth");
  for (const bad of ["", "none", "BETTER-AUTH", "off", "jwt"]) assert.throws(() => readAuthMode({ AUTH_MODE: bad }), /Unsupported AUTH_MODE/, bad);
});

test("actor resolution: better-auth mode ignores the dev actor completely; dev mode ignores sessions; production kills the dev actor", () => {
  const dev = { DEMO_MODE: "true", NEXORA_DEV_ACTOR: "admin", NODE_ENV: "development" };
  assert.deepEqual(resolveActor({ ...dev, AUTH_MODE: "dev" }, "user1@nexora.invalid"), { userId: "admin", role: "ADMIN" }, "dev mode: operator-chosen actor");
  assert.equal(resolveActor({ ...dev, AUTH_MODE: "better-auth" }, null), null, "better-auth + no session = anonymous even if NEXORA_DEV_ACTOR=admin");
  assert.deepEqual(resolveActor({ ...dev, AUTH_MODE: "better-auth" }, "user1@nexora.invalid"), { userId: "user1", role: "USER" }, "session decides, not NEXORA_DEV_ACTOR");
  assert.equal(resolveActor({ ...dev, NODE_ENV: "production" }, "admin@nexora.invalid"), null, "production + dev mode is locked");
  assert.equal(resolveActor({ ...dev, DEMO_MODE: "false" }, null), null);
});

test("auth env validation: accepts a sane config, rejects placeholders and weak values without echoing secrets", () => {
  const ok = readAuthEnv(GOOD);
  assert.deepEqual([ok.baseUrl, ok.secureCookies, ok.trustedOrigins], ["http://localhost:3000", false, []]);
  assert.equal(readAuthEnv({ ...GOOD, BETTER_AUTH_SECRET: undefined, AUTH_SECRET: GOOD.BETTER_AUTH_SECRET }).secret.length, 32); // legacy AUTH_SECRET name is still accepted
  const msg = (over: Record<string, string>) => { try { readAuthEnv({ ...GOOD, ...over }); return ""; } catch (e) { return (e as Error).message; } };
  assert.match(msg({ BETTER_AUTH_SECRET: "short" }), /at least 32/); assert.match(msg({ BETTER_AUTH_SECRET: "replace-with-output-of: openssl rand -base64 32" }), /at least 32/);
  assert.match(msg({ DATABASE_URL: 'postgresql://USER:PASSWORD@localhost:5432/nexora_demo' }), /DATABASE_URL/); assert.match(msg({ DATABASE_URL: "mysql://x" }), /DATABASE_URL/);
  assert.match(msg({ BETTER_AUTH_URL: "not a url" }), /BETTER_AUTH_URL/); assert.match(msg({ BETTER_AUTH_URL: "ftp://x.com" }), /BETTER_AUTH_URL/);
  assert.match(msg({ NODE_ENV: "production" }), /https in production/);
  assert.equal(readAuthEnv({ ...GOOD, NODE_ENV: "production", BETTER_AUTH_URL: "https://app.example.com" }).secureCookies, true);
  assert.match(msg({ TRUSTED_ORIGINS: "https://ok.example.com, javascript:alert(1)" }), /not a valid origin/);
  assert.deepEqual(readAuthEnv({ ...GOOD, TRUSTED_ORIGINS: "https://*.app.github.dev, http://localhost:3000" }).trustedOrigins, ["https://*.app.github.dev", "http://localhost:3000"]);
  const leak = msg({ BETTER_AUTH_SECRET: "short", DATABASE_URL: "postgresql://u:topsecretpw@h/db?bad" });
  assert.ok(!leak.includes("topsecretpw") && !leak.includes("short"));
});

test("dev seed guard: production, demo mode, explicit consent and a user-chosen password are all required", () => {
  const ok = { NODE_ENV: "development", DEMO_MODE: "true", ALLOW_DEV_SEED: "true", SEED_DEV_PASSWORD: "a-long-dev-password" };
  assert.equal(checkSeedAllowed(ok).ok, true);
  for (const [over, why] of [[{ NODE_ENV: "production" }, /production/], [{ DEMO_MODE: "false" }, /DEMO_MODE/], [{ ALLOW_DEV_SEED: undefined }, /ALLOW_DEV_SEED/], [{ SEED_DEV_PASSWORD: "short" }, /12-128/], [{ SEED_DEV_PASSWORD: undefined }, /12-128/], [{ SEED_DEV_PASSWORD: "x".repeat(200) }, /12-128/]] as const) {
    const r = checkSeedAllowed({ ...ok, ...over } as Record<string, string | undefined>); assert.equal(r.ok, false); assert.match(r.reason, why);
  }
});
