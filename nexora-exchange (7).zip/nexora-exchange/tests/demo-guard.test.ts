import { test } from "node:test";
import assert from "node:assert/strict";
import { assertDemoMode, DemoModeError, requireDemo } from "../src/server/config/demo-guard";

test("accepts only the exact string 'true'", () => {
  assert.doesNotThrow(() => assertDemoMode({ DEMO_MODE: "true" }));
  for (const v of [undefined, "", "false", "TRUE", "1", "yes", " true", "live", "production"]) {
    assert.throws(() => assertDemoMode({ DEMO_MODE: v }), DemoModeError, String(v));
  }
});
test("no override flags can bypass the guard", () => {
  assert.throws(() => assertDemoMode({ DEMO_MODE: "false", LIVE_MODE: "true", ALLOW_LIVE: "true", NODE_ENV: "production" }), DemoModeError);
});
test("requireDemo reads the real environment by default", () => {
  const prev = process.env["DEMO_MODE"];
  try {
    delete process.env["DEMO_MODE"];
    assert.throws(() => requireDemo(), DemoModeError);
    process.env["DEMO_MODE"] = "true";
    assert.doesNotThrow(() => requireDemo());
  } finally {
    if (prev === undefined) delete process.env["DEMO_MODE"]; else process.env["DEMO_MODE"] = prev;
  }
});
