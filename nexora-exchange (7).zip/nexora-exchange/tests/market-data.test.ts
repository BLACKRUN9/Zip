import { test } from "node:test";
import assert from "node:assert/strict";
import { parseDecimalRounded, MoneyError } from "../src/lib/money/decimal";
import { KrakenPublicProvider, parseKrakenOhlc } from "../src/server/market-data/kraken";
import { ProviderError, SimulatedProvider, type MarketDataProvider } from "../src/server/market-data/provider";
import { candlesWithFallback, toPayload } from "../src/server/market-data/service";
import { isCandlePayload, toOhlc } from "../src/lib/ui/candle-payload";

const CFG = { pair: "XBTUSD", quoteDecimals: 2, baseDecimals: 8 };
// Same shape as Kraken's documented OHLC response (prices/volume are strings, time is in seconds).
const row = (t: number, o: string, h: string, l: string, c: string, v = "1.5") => [t, o, h, l, c, "0", v, 7];
const ok = (rows: unknown[], key = "XXBTZUSD") => ({ error: [], result: { [key]: rows, last: 1688672160 } });
const FIXTURE = ok([row(1688671200, "30306.1", "30306.2", "30305.7", "30305.7", "3.39243896"), row(1688672100, "30305.7", "30320.0", "30300.0", "30310.5")]);
const resp = (body: unknown, status = 200) => new Response(typeof body === "string" ? body : JSON.stringify(body), { status });

test("parseDecimalRounded rounds half-up for display data and rejects junk", () => {
  assert.equal(parseDecimalRounded("142.355", 2), 14236n);
  assert.equal(parseDecimalRounded("142.354", 2), 14235n);
  assert.equal(parseDecimalRounded("0.123456789", 8), 12345679n);
  assert.equal(parseDecimalRounded("5", 2), 500n);
  assert.equal(parseDecimalRounded("1.5", 0), 2n);
  for (const bad of ["-1", "1e5", "", "abc"]) assert.throws(() => parseDecimalRounded(bad, 2), MoneyError);
});

test("parses a Kraken-shaped response: exact BigInt prices, ms timestamps, any pair key", () => {
  const c = parseKrakenOhlc(FIXTURE, CFG);
  assert.equal(c.length, 2);
  assert.deepEqual(c[0], { ts: 1688671200_000, open: 3030610n, high: 3030620n, low: 3030570n, close: 3030570n, volume: 339243896n });
  assert.equal(parseKrakenOhlc(ok([row(1, "1", "2", "1", "2")], "WHATEVERKEY"), CFG).length, 1);
});

test("drops malformed/inconsistent candles, sorts ascending and de-duplicates by time", () => {
  const c = parseKrakenOhlc(ok([
    row(300, "10", "12", "9", "11"), row(100, "10", "12", "9", "11"), row(200, "10", "9", "9", "11"), // 200: high < max(o,c) -> dropped
    row(100, "10", "13", "9", "12"), // duplicate time: later row wins
    row(400, "x", "12", "9", "11"), row(500, "0", "12", "0", "11"), ["bad"], row(-5, "1", "2", "1", "2"),
  ]), CFG);
  assert.deepEqual(c.map((x) => x.ts), [100_000, 300_000]);
  assert.equal(c[0]!.high, 1300n);
});

test("upstream errors map to typed ProviderErrors without leaking internals", () => {
  const code = (body: unknown) => { try { parseKrakenOhlc(body, CFG); } catch (e) { return (e as ProviderError).code; } return "none"; };
  assert.equal(code({ error: ["EQuery:Unknown asset pair"], result: {} }), "UNSUPPORTED");
  assert.equal(code({ error: ["EGeneral:Internal error"], result: {} }), "UPSTREAM");
  assert.equal(code({ result: {} }), "BAD_RESPONSE");
  assert.equal(code(null), "BAD_RESPONSE");
  assert.equal(code(ok([])), "BAD_RESPONSE");
  assert.equal(code({ error: [], result: { last: 1 } }), "BAD_RESPONSE");
});

function harness(over: { body?: () => Response | Promise<Response> } = {}) {
  let now = 1_000_000; const calls: Array<{ url: string; init?: RequestInit }> = [];
  const fetchImpl = (async (url: string, init?: RequestInit) => { calls.push({ url, ...(init ? { init } : {}) }); return over.body ? over.body() : resp(FIXTURE); }) as unknown as typeof fetch;
  const p = new KrakenPublicProvider({ markets: { "BTC-USD": CFG }, fetchImpl, now: () => now, ttlMs: 10_000, minGapMs: 0 });
  return { p, calls, advance: (ms: number) => { now += ms; } };
}
const REQ = { market: "BTC-USD", intervalMinutes: 15, limit: 120 };

test("only ever issues a read-only GET to the fixed Kraken public OHLC URL", async () => {
  const h = harness();
  const r = await h.p.getCandles(REQ);
  assert.equal(r.kind, "REFERENCE"); assert.equal(r.source, "KRAKEN-PUBLIC"); assert.equal(r.degraded, null);
  assert.equal(h.calls.length, 1);
  assert.equal(h.calls[0]!.url, "https://api.kraken.com/0/public/OHLC?pair=XBTUSD&interval=15");
  assert.equal(h.calls[0]!.init?.method, undefined); assert.equal(h.calls[0]!.init?.body, undefined);
  assert.ok(h.calls[0]!.init?.signal, "a timeout signal must be attached");
});

test("rejects bad requests before any network call; pairs are validated at construction", async () => {
  const h = harness();
  for (const bad of [{ ...REQ, intervalMinutes: 7 }, { ...REQ, limit: 0 }, { ...REQ, limit: 721 }, { ...REQ, limit: 1.5 }]) await assert.rejects(h.p.getCandles(bad), (e: unknown) => (e as ProviderError).code === "INVALID_REQUEST");
  await assert.rejects(h.p.getCandles({ ...REQ, market: "DOGE-USD" }), (e: unknown) => (e as ProviderError).code === "UNSUPPORTED");
  assert.equal(h.calls.length, 0);
  assert.throws(() => new KrakenPublicProvider({ markets: { X: { ...CFG, pair: "../../evil?x=1" } } }));
});

test("TTL cache, in-flight coalescing and limit slicing", async () => {
  const h = harness();
  const [a, b, c] = await Promise.all([h.p.getCandles(REQ), h.p.getCandles(REQ), h.p.getCandles({ ...REQ, limit: 1 })]);
  assert.equal(h.calls.length, 1, "concurrent identical requests share one upstream call");
  assert.equal(c.candles.length, 1); assert.equal(a.candles.length, 2); assert.equal(b.asOf, a.asOf);
  h.advance(9_000); await h.p.getCandles(REQ); assert.equal(h.calls.length, 1, "within TTL");
  h.advance(2_000); await h.p.getCandles(REQ); assert.equal(h.calls.length, 2, "after TTL");
  await h.p.getCandles({ ...REQ, intervalMinutes: 60 }); assert.equal(h.calls.length, 3, "different interval is a different key");
});

test("failure handling: stale cache is labelled, otherwise a typed error", async () => {
  let fail: "none" | "net" | "timeout" | "500" | "429" | "json" | "big" = "none";
  const h = harness({ body: () => {
    if (fail === "net") throw new TypeError("fetch failed secret-host:443");
    if (fail === "timeout") throw new DOMException("x", "TimeoutError");
    if (fail === "500") return resp("boom", 500);
    if (fail === "429") return resp("", 429);
    if (fail === "json") return resp("<html>not json</html>");
    if (fail === "big") return resp("x".repeat(5_000_001));
    return resp(FIXTURE);
  } });
  const codeOf = async () => { try { await h.p.getCandles(REQ); return "none"; } catch (e) { return `${(e as ProviderError).code}|${(e as Error).message}`; } };
  fail = "net"; assert.match(await codeOf(), /^UPSTREAM\|Could not reach the market-data source$/); // no host/URL in the message
  fail = "timeout"; assert.match(await codeOf(), /^TIMEOUT/);
  fail = "500"; assert.match(await codeOf(), /^UPSTREAM\|.*HTTP 500/);
  fail = "429"; assert.match(await codeOf(), /^RATE_LIMITED/);
  fail = "json"; assert.match(await codeOf(), /^BAD_RESPONSE/);
  fail = "big"; assert.match(await codeOf(), /^BAD_RESPONSE/);
  fail = "none"; const good = await h.p.getCandles(REQ); assert.equal(good.degraded, null);
  h.advance(60_000); fail = "net";
  const stale = await h.p.getCandles(REQ);
  assert.equal(stale.degraded, "STALE_CACHE:UPSTREAM"); assert.equal(stale.candles.length, 2); assert.equal(stale.asOf, good.asOf);
});

test("simulated provider: deterministic, labelled, same last price for any limit", async () => {
  const meta = { "BTC-USD": { seed: 11, startPrice: 4_250_000n } };
  const p = new SimulatedProvider(meta, () => Date.UTC(2026, 9, 18, 9, 7, 0));
  const a = await p.getCandles({ market: "BTC-USD", intervalMinutes: 15, limit: 120 });
  const b = await p.getCandles({ market: "BTC-USD", intervalMinutes: 15, limit: 10 });
  assert.equal(a.kind, "SIMULATED"); assert.equal(a.source, "SIMULATED-SEED");
  assert.equal(a.candles.at(-1)!.close, b.candles.at(-1)!.close);
  assert.equal(a.candles.at(-1)!.ts, Date.UTC(2026, 9, 18, 9, 0, 0));
  assert.deepEqual(a, await p.getCandles({ market: "BTC-USD", intervalMinutes: 15, limit: 120 }));
});

test("fallback is explicit (never silent) and request errors are not masked", async () => {
  const sim = new SimulatedProvider({ "BTC-USD": { seed: 1, startPrice: 1_000_000n } });
  const broken: MarketDataProvider = { id: "KRAKEN-PUBLIC", getCandles: async () => { throw new ProviderError("TIMEOUT", "t"); } };
  const r = await candlesWithFallback(broken, sim, REQ);
  assert.equal(r.kind, "SIMULATED"); assert.equal(r.degraded, "LIVE_FEED_UNAVAILABLE:TIMEOUT");
  const invalid: MarketDataProvider = { id: "KRAKEN-PUBLIC", getCandles: async () => { throw new ProviderError("INVALID_REQUEST", "bad"); } };
  await assert.rejects(candlesWithFallback(invalid, sim, REQ), (e: unknown) => (e as ProviderError).code === "INVALID_REQUEST");
  await assert.rejects(candlesWithFallback(sim, sim, { ...REQ, market: "NOPE" }), ProviderError);
});

test("wire payload is JSON-safe (no BigInt) and validated before the client trusts it", async () => {
  const sim = new SimulatedProvider({ "BTC-USD": { seed: 1, startPrice: 1_000_000n } });
  const payload = toPayload(REQ, await sim.getCandles(REQ));
  const wire: unknown = JSON.parse(JSON.stringify(payload));
  assert.ok(isCandlePayload(wire));
  if (isCandlePayload(wire)) { const o = toOhlc(wire); assert.equal(o.length, 120); assert.equal(typeof o[0]!.open, "bigint"); }
  for (const bad of [null, {}, { ...payload, kind: "LIVE" }, { ...payload, candles: [{ t: 1, o: "1.5", h: "1", l: "1", c: "1", v: "1" }] }, { ...payload, candles: [{ t: 1, o: "1", h: "1", l: "1", c: "1" }] }, { ...payload, degraded: 5 }]) assert.equal(isCandlePayload(bad), false);
});
