import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { DemoExchange, type MarketConfig } from "../src/server/trading/exchange";
import { DemoModeError } from "../src/server/config/demo-guard";
import { importMmCsv, parseCsv, type MmStrategy } from "../src/server/mm/config";
import { MarketMakerEngine } from "../src/server/mm/engine";
import { mulberry32 } from "../src/server/market-data/seeded";
import { ExchangeTradesProvider, aggregateTrades } from "../src/server/market-data/trades";
import { sma, volumeBars, candleGeometry } from "../src/lib/ui/chart-geometry";
import { ACCOUNTS, can, canManageStrategy, isMmAccount } from "../src/server/accounts/directory";
import { resolveDevActor } from "../src/server/auth/dev-actor";

const CSV = readFileSync(new URL("./fixtures/mm-sample.csv", import.meta.url ?? "file://" + __filename), "utf8");
const MKT: MarketConfig = { symbol: "NXR-USDT", base: { symbol: "NXR", decimals: 8 }, quote: { symbol: "USDT", decimals: 6 }, takerFeeBps: 25, makerFeeBps: 10, minQty: 1_000_000n, minNotional: 10_000n };
const ENV = { DEMO_MODE: "true" };
const ADMIN = { userId: "admin", role: "ADMIN" as const };
const REF = 4_000_000n; // 4.0000 USDT
const NXR = (n: number) => BigInt(Math.round(n * 1e8));
const ctx = { market: "NXR-USDT", accountMap: { ACCT1: "mm" } };

async function world(opts: { mmNxr?: number } = {}) {
  let t = 1_000_000;
  const clock = { now: () => t, advance: (ms: number) => { t += ms; } };
  const ex = new DemoExchange({ markets: [MKT], clock: clock.now, env: ENV });
  const fund = async (u: string, a: string, amt: bigint) => { const d = await ex.requestDeposit(u, { idempotencyKey: `f-${u}-${a}`, asset: a, amount: amt }); await ex.decideTransfer(ADMIN, d.id, "COMPLETE"); };
  await fund("mm", "NXR", NXR(opts.mmNxr ?? 100_000)); await fund("mm", "USDT", 1_000_000_000_000n);
  await fund("user1", "USDT", 1_000_000_000n); await fund("user1", "NXR", NXR(1000));
  return { ex, clock, fund };
}
const engineOf = (ex: DemoExchange, now: () => number, over: Partial<ConstructorParameters<typeof MarketMakerEngine>[0]> = {}, seed = 1) =>
  new MarketMakerEngine({ exchange: ex, markets: new Map([[MKT.symbol, MKT]]), reference: () => REF, isMmAccount, now, rand: mulberry32(seed), env: ENV, ...over });
const strat = (over: Partial<MmStrategy> = {}): MmStrategy => ({ ...importMmCsv(CSV, ctx).strategies[0]!, jitterPricePct: 0, jitterTimingPct: 0, ...over });

test("CSV parser handles quotes/CRLF and imports the 4 strategies with exact values", () => {
  assert.deepEqual(parseCsv('a,"b,c",d\r\n"x ""y""",2,3\n'), [["a", "b,c", "d"], ['x "y"', "2", "3"]]);
  const r = importMmCsv(CSV, ctx);
  assert.deepEqual(r.errors, []);
  assert.deepEqual(r.strategies.map((s) => s.id), ["sells0", "sells2", "sells3", "sells4"]);
  const s0 = r.strategies[0]!;
  assert.deepEqual([s0.account, s0.side, s0.priceSource, s0.orderCount, s0.expireSeconds, s0.minQty, s0.maxQty, s0.sellMinPrice, s0.buyMaxPrice], ["mm", "sell_only", "reference", 5, 113, "12.0", "28.0", "3.5", "4.6"]);
  assert.deepEqual(s0.splitRange, ["0.045", "0.3", "0.3", "0.3", "0.3"]);
});

test("CSV import is strict: unmapped account, unsupported modes, bad ranges and unknown fields are errors", () => {
  const bad = (from: string, to: string, ctxOver = ctx) => importMmCsv(CSV.replace(from, to), ctxOver);
  assert.ok(importMmCsv(CSV, { market: "NXR-USDT", accountMap: {} }).errors.some((e) => /not mapped/.test(e)));
  assert.ok(bad("sell_only", "sideways").errors.some((e) => /transaction_type/.test(e)));
  assert.ok(bad("split_order_mode,manual", "split_order_mode,auto").errors.some((e) => /split_order_mode/.test(e)));
  assert.ok(bad("[0.045, 0.3, 0.3, 0.3, 0.3]", "[0.045, 0.3]").errors.some((e) => /split_range/.test(e)));
  assert.ok(bad("price_source,reference", "price_source,orderbook").errors.some((e) => /price_source/.test(e)));
  assert.ok(bad("buy_trailing_min_percentage,None", "buy_trailing_min_percentage,1.5").errors.some((e) => /not supported/.test(e)));
  assert.ok(bad("random_min_quantity,12.0", "random_min_quantity,99.0").errors.some((e) => /min <= max/.test(e)));
  assert.ok(bad("order_count,5", "order_count,500").errors.some((e) => /order_count/.test(e)));
  assert.ok(importMmCsv(CSV + "\n99,secret_api_key,abc,\n", ctx).errors.some((e) => /unknown field/.test(e)));
  assert.equal(importMmCsv("", ctx).strategies.length, 0);
  assert.equal(importMmCsv(CSV.replace("[0.045", "[0.045x"), ctx).strategies.length, 0, "any error imports nothing");
});

test("engine places the configured ladder as REAL orders in the exchange book", async () => {
  const { ex, clock } = await world();
  const e = engineOf(ex, clock.now); e.addStrategy(strat());
  await e.start("sells0"); await e.tick();
  const d = ex.depth("NXR-USDT", 20);
  assert.equal(d.bids.length, 0); assert.equal(d.asks.length, 5);
  assert.deepEqual(d.asks.map((a) => a.price), [4_001_800n, 4_013_800n, 4_025_800n, 4_037_800n, 4_049_800n]); // ref 4.0 +0.045%, then +0.3% steps (rounded to 4 dp)
  for (const a of d.asks) { assert.ok(a.qty >= NXR(12) && a.qty <= NXR(28), "qty within [min,max]"); assert.equal(a.qty % 1_000_000n, 0n, "2-decimal quantity"); assert.ok(a.price >= 3_500_000n); }
  const reserved = ex.getBalances("mm")["NXR"]!.reserved;
  assert.equal(reserved, d.asks.reduce((s, a) => s + a.qty, 0n));
  assert.deepEqual(ex.reconcileExchange(), []);
  assert.equal(e.status()[0]!.live.length, 5);
  assert.ok(e.logs().some((l) => l.kind === "START") && e.logs().filter((l) => l.kind === "PLACE").length === 5);
});

test("fills drive candles: a user trade against the bot produces the matching OHLCV candle and the bot refills", async () => {
  const { ex, clock } = await world();
  const e = engineOf(ex, clock.now); e.addStrategy(strat());
  await e.start("sells0"); await e.tick();
  const best = ex.depth("NXR-USDT", 1).asks[0]!;
  const buyQty = best.qty / 2n;
  const r = await ex.placeOrder({ idempotencyKey: "u1-buy", userId: "user1", market: "NXR-USDT", side: "BUY", type: "MARKET", qty: buyQty, price: null });
  assert.equal(r.order.status, "FILLED");
  const trades = ex.marketTrades("NXR-USDT");
  assert.equal(trades.length, 1); assert.equal(trades[0]!.price, best.price); assert.equal(trades[0]!.qty, buyQty);
  const candles = aggregateTrades(trades, { intervalMs: 60_000, nowMs: clock.now(), limit: 10 });
  assert.deepEqual([candles.length, candles[0]!.open, candles[0]!.high, candles[0]!.low, candles[0]!.close, candles[0]!.volume], [1, best.price, best.price, best.price, best.price, buyQty]);
  await e.tick();
  assert.ok(e.logs().some((l) => l.kind === "FILL"));
  assert.equal(BigInt(e.status()[0]!.filledQty), buyQty);
  assert.deepEqual(ex.reconcileExchange(), []);
  const prov = new ExchangeTradesProvider(async (m) => ex.marketTrades(m), clock.now);
  const res = await prov.getCandles({ market: "NXR-USDT", intervalMinutes: 1, limit: 5 });
  assert.equal(res.source, "NEXORA-TRADES"); assert.equal(res.kind, "SIMULATED"); assert.equal(res.candles[0]!.volume, buyQty);
});

test("orders expire and are re-quoted; reserves are released and reconcile stays clean", async () => {
  const { ex, clock } = await world();
  const e = engineOf(ex, clock.now); e.addStrategy(strat());
  await e.start("sells0"); await e.tick();
  const first = e.status()[0]!.live.map((l) => l.orderId);
  clock.advance(112_000); await e.tick();
  assert.deepEqual(e.status()[0]!.live.map((l) => l.orderId), first, "not expired yet (113 s)");
  clock.advance(2_000); await e.tick();
  const second = e.status()[0]!.live.map((l) => l.orderId);
  assert.equal(second.length, 5); assert.ok(second.every((id) => !first.includes(id)), "new orders after expiry");
  assert.equal(e.status()[0]!.cancelled, 5);
  assert.equal(ex.listOrders("mm", "OPEN").length, 5);
  assert.deepEqual(ex.reconcileExchange(), []);
});

test("stop cancels every live order and releases the reserve", async () => {
  const { ex, clock } = await world();
  const e = engineOf(ex, clock.now); e.addStrategy(strat());
  await e.start("sells0"); await e.tick(); await e.stop("sells0");
  assert.equal(ex.depth("NXR-USDT").asks.length, 0);
  assert.equal(ex.getBalances("mm")["NXR"]!.reserved, 0n);
  assert.equal(ex.getBalances("mm")["NXR"]!.available, NXR(100_000));
  await e.tick(); assert.equal(ex.depth("NXR-USDT").asks.length, 0, "stopped strategies stay quiet");
  assert.ok(e.logs().some((l) => l.kind === "STOP"));
});

test("price guards, missing price source and insufficient funds are logged, never crash", async () => {
  const w = await world();
  const guard = engineOf(w.ex, w.clock.now); guard.addStrategy(strat({ sellMinPrice: "4.5" }));
  await guard.start("sells0"); await guard.tick();
  assert.equal(w.ex.depth("NXR-USDT").asks.length, 0); assert.ok(guard.logs().some((l) => l.kind === "SKIP" && /sell_min_price_limit/.test(l.message)));
  const noRef = engineOf(w.ex, w.clock.now, { reference: () => null }); noRef.addStrategy(strat());
  await noRef.start("sells0"); await noRef.tick(); assert.ok(noRef.logs().some((l) => /no reference price/.test(l.message)));
  const poor = await world({ mmNxr: 5 });
  const p = engineOf(poor.ex, poor.clock.now); p.addStrategy(strat());
  await p.start("sells0"); await p.tick();
  assert.ok(p.logs().some((l) => l.kind === "ERROR" && /INSUFFICIENT_FUNDS/.test(l.message)));
  assert.equal(poor.ex.depth("NXR-USDT").asks.length, 0);
  const n = p.logs().length; await p.tick(); assert.equal(p.logs().length, n, "backs off 5 s before retrying");
  poor.clock.advance(5_001); await p.tick(); assert.ok(p.logs().length > n);
});

test("buy_only and both place the right sides, below/above the reference", async () => {
  const { ex, clock } = await world();
  await ex.requestDeposit("mm", { idempotencyKey: "x", asset: "USDT", amount: 1n }); // no-op, keeps ids unique
  const e = engineOf(ex, clock.now);
  e.addStrategy(strat({ id: "b", side: "buy_only", buyMaxPrice: "4.6" })); e.addStrategy(strat({ id: "both", side: "both", orderCount: 2, splitRange: ["0.5", "0.5"], sellMinPrice: null }));
  await e.start("b"); await e.start("both"); await e.tick();
  const d = ex.depth("NXR-USDT", 20);
  assert.ok(d.bids.every((b) => b.price < REF) && d.asks.every((a) => a.price > REF));
  assert.equal(d.bids.length, 5 + 2 - 0 > 0 ? d.bids.length : 0);
  assert.ok(d.asks.length >= 2 && d.bids.length >= 5);
  assert.deepEqual(ex.reconcileExchange(), []);
});

test("jitter is deterministic for a seed and bounded", async () => {
  const run = async (seed: number) => { const w = await world(); const e = engineOf(w.ex, w.clock.now, {}, seed); e.addStrategy(strat({ jitterPricePct: 5, jitterTimingPct: 20 })); await e.start("sells0"); await e.tick(); return w.ex.depth("NXR-USDT", 20).asks.map((a) => `${a.price}:${a.qty}`).join(","); };
  assert.equal(await run(7), await run(7)); assert.notEqual(await run(7), await run(8));
  const w = await world(); const e = engineOf(w.ex, w.clock.now, {}, 3); e.addStrategy(strat({ jitterPricePct: 5, jitterTimingPct: 20 }));
  await e.start("sells0"); await e.tick();
  const exp = e.status()[0]!.live.map((l) => l.expiresInMs); assert.ok(exp.every((x) => x >= 90_400 && x <= 135_600), `expiry within +-20% of 113s: ${exp}`);
  for (const [i, a] of w.ex.depth("NXR-USDT", 20).asks.entries()) { const off = [0.045, 0.345, 0.645, 0.945, 1.245][i]!; const lo = 4e6 * (1 + off * 0.95 / 100) - 100, hi = 4e6 * (1 + off * 1.05 / 100) + 100; assert.ok(Number(a.price) >= lo && Number(a.price) <= hi, `L${i} ${a.price}`); }
});

test("safety: only MM-role accounts, only the simulated exchange, demo mode enforced", async () => {
  const { ex, clock } = await world();
  assert.throws(() => engineOf(ex, clock.now).addStrategy(strat({ account: "user1" })), /MM role/);
  assert.throws(() => engineOf(ex, clock.now).addStrategy(strat({ market: "BTC-USD" })), /Unknown market/);
  assert.throws(() => engineOf(ex, clock.now).addStrategy(strat({ priceDecimals: 7 })), /precision/);
  const e = engineOf(ex, clock.now); e.addStrategy(strat()); assert.throws(() => e.addStrategy(strat()), /already exists/);
  const off = engineOf(ex, clock.now, { env: { DEMO_MODE: "false" } }); off.addStrategy(strat());
  await assert.rejects(off.start("sells0"), DemoModeError); await assert.rejects(off.tick(), DemoModeError);
});

test("candle aggregation: OHLCV buckets, flat gap candles, limit, ordering", () => {
  const T = (at: number, price: number, qty: number) => ({ at, price: BigInt(price), qty: BigInt(qty) });
  const trades = [T(61_000, 100, 5), T(10_000, 90, 2), T(59_000, 110, 3), T(20_000, 95, 1), T(200_000, 120, 4)];
  const c = aggregateTrades(trades, { intervalMs: 60_000, nowMs: 250_000, limit: 100 });
  assert.deepEqual(c.map((x) => [x.ts, x.open, x.high, x.low, x.close, x.volume]), [
    [0, 90n, 110n, 90n, 110n, 6n],
    [60_000, 100n, 100n, 100n, 100n, 5n],
    [120_000, 100n, 100n, 100n, 100n, 0n], // gap: flat at the previous close
    [180_000, 120n, 120n, 120n, 120n, 4n],
    [240_000, 120n, 120n, 120n, 120n, 0n], // current bucket, still forming
  ]);
  assert.equal(aggregateTrades(trades, { intervalMs: 60_000, nowMs: 250_000, limit: 2 }).length, 2);
  const live = aggregateTrades(trades, { intervalMs: 60_000, nowMs: 400_000, limit: 100 }); assert.equal(live.at(-1)!.ts, 360_000); assert.equal(live.at(-1)!.volume, 0n);
  assert.deepEqual(aggregateTrades([], { intervalMs: 60_000, nowMs: 1, limit: 5 }), []);
  assert.equal(c.reduce((s, x) => s + x.volume, 0n), 15n, "candle volume equals traded volume");
});

test("indicators: SMA and volume bars", () => {
  assert.deepEqual(sma([1n, 2n, 3n, 4n, 5n], 3), [null, null, 2n, 3n, 4n]);
  assert.throws(() => sma([1n], 0));
  const c = [{ ts: 0, open: 1n, high: 2n, low: 1n, close: 2n, volume: 10n }, { ts: 1, open: 2n, high: 2n, low: 1n, close: 1n, volume: 5n }, { ts: 2, open: 1n, high: 1n, low: 1n, close: 1n }];
  const v = volumeBars(c, { plotWidth: 90, baseY: 100, maxHeight: 40 });
  assert.deepEqual(v.map((b) => [b.h, b.up]), [[40, true], [20, false], [0, true]]);
  assert.ok(v.every((b) => b.y + b.h === 100));
  const g = candleGeometry(c, { width: 100, height: 100, padRight: 10, padTop: 0, padBottom: 0, tickCount: 2 });
  assert.ok(g.priceY(2n) < g.priceY(1n));
});

test("roles and permissions: USER, MM and ADMIN; MM manages only its own strategies; dev actor is server-chosen and off in production", () => {
  assert.deepEqual(ACCOUNTS.map((a) => `${a.id}:${a.role}`), ["user1:USER", "user2:USER", "mm:MM", "mm2:MM", "admin:ADMIN"]);
  assert.ok(can("USER", "trade") && !can("USER", "mm:view") && !can("USER", "admin:view") && !can("USER", "transfers:decide"));
  assert.ok(can("MM", "mm:control") && can("MM", "mm:config") && !can("MM", "admin:view") && !can("MM", "transfers:decide"));
  assert.ok(can("ADMIN", "mm:control") && can("ADMIN", "admin:view") && can("ADMIN", "transfers:decide"));
  assert.ok(canManageStrategy({ userId: "admin", role: "ADMIN" }, "mm") && canManageStrategy({ userId: "mm", role: "MM" }, "mm"));
  assert.ok(!canManageStrategy({ userId: "mm", role: "MM" }, "mm2") && !canManageStrategy({ userId: "user1", role: "USER" }, "mm"));
  const ok = { DEMO_MODE: "true", NEXORA_DEV_ACTOR: "admin", NODE_ENV: "development" };
  assert.deepEqual(resolveDevActor(ok), { userId: "admin", role: "ADMIN" });
  for (const bad of [{ ...ok, NODE_ENV: "production" }, { ...ok, DEMO_MODE: "false" }, { ...ok, NEXORA_DEV_ACTOR: "root" }, { ...ok, NEXORA_DEV_ACTOR: undefined }, { ...ok, NEXORA_DEV_ACTOR: "ADMIN" }]) assert.equal(resolveDevActor(bad), null);
});
