import { test } from "node:test";
import assert from "node:assert/strict";
import { formatBps, formatGrouped, formatUtc, groupThousands } from "../src/lib/money/format";
import { estimateOrder, type EstimateInput } from "../src/lib/trading/estimate";
import { candleGeometry, depthPercent, sparkPath } from "../src/lib/ui/chart-geometry";

test("grouped formatting is exact for big values and negatives", () => {
  assert.equal(groupThousands("1234567"), "1,234,567");
  assert.equal(formatGrouped(123_456_789n, 2), "1,234,567.89");
  assert.equal(formatGrouped(-5n, 2), "-0.05");
  assert.equal(formatGrouped(150_000_000n, 8, { minFraction: 2 }), "1.50");
  assert.equal(formatGrouped(100_000_000n, 8, { minFraction: 0 }), "1");
  assert.equal(formatGrouped(90071992547409930n, 2), "900,719,925,474,099.30");
});
test("bps and UTC formatting are deterministic", () => {
  assert.equal(formatBps(125n), "+1.25%");
  assert.equal(formatBps(-5n), "-0.05%");
  assert.equal(formatBps(0n), "0.00%");
  assert.equal(formatUtc(Date.UTC(2026, 9, 18, 9, 5, 7), true), "09:05:07");
  assert.equal(formatUtc(Date.UTC(2026, 9, 18, 9, 5, 7)), "10-18 09:05");
});

const base: EstimateInput = {
  side: "BUY", type: "LIMIT", qty: "", price: "", baseDecimals: 8, quoteDecimals: 2, takerFeeBps: 25, makerFeeBps: 10,
  referencePrice: 4_000_000n, minQty: 10_000n, minNotional: 100n, availableBase: 100_000_000n, availableQuote: 10_000_000n,
};
test("estimate: empty fields are 'empty', not errors", () => {
  const e = estimateOrder(base);
  assert.deepEqual(e, { ok: false, empty: true, errors: {} });
  assert.equal(estimateOrder({ ...base, qty: "1" }).ok, false); // limit needs a price
});
test("estimate: limit buy computes notional, fee (max bps, ceil) and total with BigInt", () => {
  const e = estimateOrder({ ...base, qty: "0.5", price: "40000" });
  assert.ok(e.ok);
  if (e.ok) {
    assert.equal(e.notional, 2_000_000n);
    assert.equal(e.fee, 5_000n); // ceil(2,000,000 * 25 / 10,000)
    assert.equal(e.total, 2_005_000n);
    assert.equal(e.insufficient, false);
    assert.equal(e.priceBasis, "LIMIT");
  }
});
test("estimate: insufficient balance is flagged for buys and sells", () => {
  const buy = estimateOrder({ ...base, qty: "5", price: "40000" });
  assert.ok(buy.ok && buy.insufficient && buy.neededAsset === "QUOTE");
  const sell = estimateOrder({ ...base, side: "SELL", qty: "2", price: "40000" });
  assert.ok(sell.ok && sell.insufficient && sell.neededAsset === "BASE");
  const okSell = estimateOrder({ ...base, side: "SELL", qty: "1", price: "40000" });
  assert.ok(okSell.ok && !okSell.insufficient && okSell.total === 4_000_000n - 10_000n);
});
test("estimate: market orders use the reference price and fail clearly on an empty book", () => {
  const m = estimateOrder({ ...base, type: "MARKET", qty: "0.1" });
  assert.ok(m.ok && m.priceBasis === "REFERENCE" && m.price === 4_000_000n);
  const none = estimateOrder({ ...base, type: "MARKET", qty: "0.1", referencePrice: null });
  assert.ok(!none.ok && none.errors.form);
});
test("estimate: precision, format, minimums", () => {
  const p = estimateOrder({ ...base, qty: "0.123456789", price: "1" });
  assert.ok(!p.ok && p.errors.qty?.includes("8 decimal"));
  const q = estimateOrder({ ...base, qty: "1", price: "1.234" });
  assert.ok(!q.ok && q.errors.price?.includes("2 decimal"));
  for (const bad of ["-1", "abc", "1e3", "0"]) assert.ok(!estimateOrder({ ...base, qty: bad, price: "1" }).ok, bad);
  const small = estimateOrder({ ...base, qty: "0.00000001", price: "40000" });
  assert.ok(!small.ok && small.errors.qty);
  const dust = estimateOrder({ ...base, qty: "0.0001", price: "0.01" });
  assert.ok(!dust.ok && dust.errors.form);
});

test("chart geometry: candles stay inside the plot, ticks span min..max, up/down colouring", () => {
  const c = [
    { ts: 0, open: 100n, high: 120n, low: 90n, close: 110n },
    { ts: 1, open: 110n, high: 115n, low: 80n, close: 85n },
    { ts: 2, open: 85n, high: 130n, low: 85n, close: 130n },
  ];
  const g = candleGeometry(c, { width: 800, height: 360, padRight: 60, padTop: 10, padBottom: 20, tickCount: 5 });
  assert.equal(g.min, 80n); assert.equal(g.max, 130n);
  assert.deepEqual(g.candles.map((s) => s.up), [true, false, true]);
  for (const s of g.candles) {
    assert.ok(s.cx > 0 && s.cx < g.plotWidth);
    assert.ok(s.wickTop >= 10 && s.wickBottom <= 340 && s.wickTop <= s.bodyTop && s.bodyHeight >= 1);
  }
  assert.equal(g.ticks.length, 5);
  assert.equal(g.ticks[0]!.price, 80n); assert.equal(g.ticks[4]!.price, 130n);
  assert.ok(g.ticks[0]!.y > g.ticks[4]!.y); // higher price = smaller y
});
test("chart geometry: empty and flat data do not produce NaN", () => {
  assert.deepEqual(candleGeometry([], { width: 100, height: 50, padRight: 0, padTop: 0, padBottom: 0, tickCount: 3 }).candles, []);
  const flat = candleGeometry([{ ts: 0, open: 5n, high: 5n, low: 5n, close: 5n }], { width: 100, height: 50, padRight: 0, padTop: 0, padBottom: 0, tickCount: 3 });
  assert.ok(!JSON.stringify(flat, (_, v) => (typeof v === "bigint" ? "n" : v)).includes("null"));
  assert.equal(sparkPath([1n], 10, 10), "");
  assert.match(sparkPath([1n, 3n, 2n], 100, 20), /^M0 20 L50 0 L100 10$/);
  assert.equal(depthPercent(50n, 200n), 25);
  assert.equal(depthPercent(5n, 0n), 0);
});

import { timeLabelIndices } from "../src/lib/ui/chart-geometry";
import { LAYOUT_COOKIE, LAYOUT_THEMES, layoutCookie, parseLayoutTheme } from "../src/lib/ui/layout-theme";

test("regression (duplicate React keys): tick positions and time-label indices are unique for any candle count and for flat prices", () => {
  const opts = { width: 640, height: 320, padRight: 74, padTop: 10, padBottom: 24, tickCount: 5 };
  for (let n = 1; n <= 12; n++) {
    const idx = timeLabelIndices(n);
    assert.equal(new Set(idx).size, idx.length, `n=${n} labels unique`);
    assert.ok(idx.every((i) => i >= 0 && i < n) && idx.every((v, k) => k === 0 || v > idx[k - 1]!), `n=${n} sorted and in range`);
    for (const price of [1n, 4_000_000n]) {
      const flat = Array.from({ length: n }, (_, i) => ({ ts: i, open: price, high: price, low: price, close: price }));
      const g = candleGeometry(flat, opts);
      assert.equal(new Set(g.ticks.map((t) => t.y)).size, g.ticks.length, `flat n=${n} price=${price}: tick y unique`);
      assert.equal(new Set(g.ticks.map((t) => t.price)).size, g.ticks.length, "tick prices unique");
      for (const c of g.candles) assert.ok(c.wickTop >= 10 && c.wickBottom <= 296 && Number.isFinite(c.bodyTop), "flat candles sit inside the plot");
    }
  }
  assert.deepEqual(timeLabelIndices(0), []); assert.deepEqual(timeLabelIndices(1), [0]); assert.deepEqual(timeLabelIndices(2), [0, 1]); assert.deepEqual(timeLabelIndices(9), [0, 3, 6, 8]);
});

test("layout themes: three themes, safe parsing, cookie is a plain preference", () => {
  assert.deepEqual(LAYOUT_THEMES.map((t) => t.id), ["pro", "classic", "focus"]);
  for (const t of LAYOUT_THEMES) assert.equal(parseLayoutTheme(t.id), t.id);
  for (const bad of [undefined, null, "", "PRO", "grid", "classic; Path=/", "<script>"]) assert.equal(parseLayoutTheme(bad as string | null | undefined), "pro", String(bad));
  assert.match(layoutCookie("focus"), new RegExp(`^${LAYOUT_COOKIE}=focus; Path=/; Max-Age=\\d+; SameSite=Lax$`));
});
