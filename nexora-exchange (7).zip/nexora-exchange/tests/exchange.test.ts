import { test } from "node:test";
import assert from "node:assert/strict";
import { DemoExchange, ExchangeError, type Actor, type MarketConfig, type ExchangeErrorCode } from "../src/server/trading/exchange";
import { DemoModeError } from "../src/server/config/demo-guard";
import { mulberry32 } from "../src/server/market-data/seeded";

const BTC = { symbol: "BTC", decimals: 8 }, USD = { symbol: "USD", decimals: 2 };
const MKT: MarketConfig = { symbol: "BTC-USD", base: BTC, quote: USD, takerFeeBps: 25, makerFeeBps: 10, minQty: 1000n, minNotional: 1n };
const ENV = { DEMO_MODE: "true" };
const ADMIN: Actor = { userId: "admin1", role: "ADMIN" };
const ONE = 100_000_000n; // 1 BTC
const P = 4_000_000n; // 40,000.00 USD (fictional)

const mk = () => { let t = 0; return new DemoExchange({ markets: [MKT], clock: () => ++t, env: ENV }); };
let ks = 0;
const key = () => `k${++ks}`;
async function fund(ex: DemoExchange, user: string, asset: string, amount: bigint) {
  const d = await ex.requestDeposit(user, { idempotencyKey: key(), asset, amount });
  await ex.decideTransfer(ADMIN, d.id, "COMPLETE");
}
const place = (ex: DemoExchange, userId: string, side: "BUY" | "SELL", type: "MARKET" | "LIMIT", qty: bigint, price: bigint | null, idempotencyKey = key()) =>
  ex.placeOrder({ idempotencyKey, userId, market: "BTC-USD", side, type, qty, price });
const code = (c: ExchangeErrorCode) => (e: unknown) => e instanceof ExchangeError && e.code === c;
const bal = (ex: DemoExchange, u: string, a: string) => ex.getBalances(u)[a] ?? { available: 0n, reserved: 0n, pending: 0n };

test("market buy fills at maker price; fees, balances and ledger are exact and balanced", async () => {
  const ex = mk();
  await fund(ex, "s", "BTC", 2n * ONE); await fund(ex, "b", "USD", 10_000_000n);
  await place(ex, "s", "SELL", "LIMIT", ONE, P);
  const r = await place(ex, "b", "BUY", "MARKET", ONE, null);
  assert.equal(r.order.status, "FILLED");
  assert.equal(r.fills[0]?.price, P);
  assert.deepEqual(bal(ex, "b", "USD"), { available: 5_990_000n, reserved: 0n, pending: 0n }); // 4,000,000 + 10,000 taker fee
  assert.equal(bal(ex, "b", "BTC").available, ONE);
  assert.equal(bal(ex, "s", "USD").available, 3_996_000n); // 4,000,000 - 4,000 maker fee
  assert.deepEqual(bal(ex, "s", "BTC"), { available: ONE, reserved: 0n, pending: 0n });
  assert.equal(ex.ledger.balance("system:fees:USD", "USD"), 14_000n);
  assert.deepEqual(ex.reconcileExchange(), []);
});

test("limit buy never fills above its limit; remainder rests and stays reserved", async () => {
  const ex = mk();
  await fund(ex, "s", "BTC", 2n * ONE); await fund(ex, "b", "USD", 10_000_000n);
  await place(ex, "s", "SELL", "LIMIT", ONE, P); await place(ex, "s", "SELL", "LIMIT", ONE, 4_100_000n);
  const r = await place(ex, "b", "BUY", "LIMIT", 2n * ONE, 4_050_000n);
  assert.ok(r.fills.length === 1 && r.fills.every((f) => f.price <= 4_050_000n));
  assert.equal(r.order.status, "PARTIALLY_FILLED");
  assert.equal(r.order.filledQty, ONE);
  assert.ok(r.order.reservedRemaining > 0n);
  const d = ex.depth("BTC-USD");
  assert.equal(d.bids[0]?.price, 4_050_000n);
  assert.equal(d.asks[0]?.price, 4_100_000n);
  assert.equal(d.simulated, true);
  assert.deepEqual(ex.reconcileExchange(), []);
});

test("partial fill then cancel releases the remaining reserve; lifecycle is audited", async () => {
  const ex = mk();
  await fund(ex, "b", "USD", 10_000_000n); await fund(ex, "s", "BTC", ONE);
  const buy = await place(ex, "b", "BUY", "LIMIT", 2n * ONE, P);
  await place(ex, "s", "SELL", "MARKET", ONE / 2n, null);
  assert.equal(ex.getOrder("b", buy.order.id)?.status, "PARTIALLY_FILLED");
  const c = await ex.cancelOrder("b", buy.order.id);
  assert.equal(c.status, "CANCELLED");
  assert.deepEqual(bal(ex, "b", "USD"), { available: 7_998_000n, reserved: 0n, pending: 0n }); // paid 2,000,000 + 2,000 maker fee
  assert.equal(bal(ex, "b", "BTC").available, ONE / 2n);
  assert.equal(bal(ex, "s", "USD").available, 1_995_000n); // 2,000,000 - 5,000 taker fee
  await assert.rejects(ex.cancelOrder("b", buy.order.id), code("INVALID_STATE"));
  assert.deepEqual(ex.lifecycle(buy.order.id).map((e) => e.to), ["OPEN", "PARTIALLY_FILLED", "CANCELLED"]);
  assert.deepEqual(ex.reconcileExchange(), []);
});

test("market order with insufficient book: partial fill, remainder cancelled, nothing left reserved", async () => {
  const ex = mk();
  await fund(ex, "s", "BTC", ONE); await fund(ex, "b", "USD", 10_000_000n);
  await place(ex, "s", "SELL", "LIMIT", ONE / 2n, P);
  const r = await place(ex, "b", "BUY", "MARKET", ONE, null);
  assert.equal(r.order.status, "CANCELLED");
  assert.equal(r.order.reason, "MARKET_REMAINDER_UNFILLED");
  assert.equal(r.order.filledQty, ONE / 2n);
  assert.deepEqual(bal(ex, "b", "USD"), { available: 10_000_000n - 2_005_000n, reserved: 0n, pending: 0n });
  assert.deepEqual(ex.reconcileExchange(), []);
});

test("price-time priority through the exchange: earlier order at the same price fills first", async () => {
  const ex = mk();
  await fund(ex, "s1", "BTC", ONE); await fund(ex, "s2", "BTC", ONE); await fund(ex, "b", "USD", 10_000_000n);
  const a = await place(ex, "s1", "SELL", "LIMIT", ONE, P); const b = await place(ex, "s2", "SELL", "LIMIT", ONE, P);
  await place(ex, "b", "BUY", "MARKET", ONE, null);
  assert.equal(ex.getOrder("s1", a.order.id)?.status, "FILLED");
  assert.equal(ex.getOrder("s2", b.order.id)?.status, "OPEN");
});

test("self-trade is prevented: own liquidity is not matched", async () => {
  const ex = mk();
  await fund(ex, "x", "BTC", ONE); await fund(ex, "x", "USD", 10_000_000n);
  await place(ex, "x", "SELL", "LIMIT", ONE, P);
  const r = await place(ex, "x", "BUY", "MARKET", ONE, null);
  assert.equal(r.order.status, "REJECTED");
  assert.equal(r.order.reason, "NO_LIQUIDITY");
});

test("duplicate idempotency key replays the same order without reserving twice; conflicting reuse is refused", async () => {
  const ex = mk();
  await fund(ex, "b", "USD", 10_000_000n); await fund(ex, "c", "USD", 10_000_000n);
  const first = await place(ex, "b", "BUY", "LIMIT", ONE, 3_000_000n, "same-key");
  const reservedAfterFirst = bal(ex, "b", "USD").reserved;
  const again = await place(ex, "b", "BUY", "LIMIT", ONE, 3_000_000n, "same-key");
  assert.equal(again.replayed, true);
  assert.equal(again.order.id, first.order.id);
  assert.equal(bal(ex, "b", "USD").reserved, reservedAfterFirst);
  assert.equal(ex.listOrders("b").length, 1);
  await assert.rejects(place(ex, "b", "BUY", "LIMIT", 2n * ONE, 3_000_000n, "same-key"), code("IDEMPOTENCY_CONFLICT"));
  const other = await place(ex, "c", "BUY", "LIMIT", ONE, 3_000_000n, "same-key"); // keys are scoped per user
  assert.notEqual(other.order.id, first.order.id);
  const d1 = await ex.requestDeposit("b", { idempotencyKey: "dep-same", asset: "USD", amount: 5n });
  const d2 = await ex.requestDeposit("b", { idempotencyKey: "dep-same", asset: "USD", amount: 5n });
  assert.equal(d1.id, d2.id);
  await assert.rejects(ex.requestDeposit("b", { idempotencyKey: "dep-same", asset: "USD", amount: 6n }), code("IDEMPOTENCY_CONFLICT"));
});

test("insufficient funds -> REJECTED, nothing reserved or moved", async () => {
  const ex = mk();
  await fund(ex, "poor", "USD", 10_000n);
  const r = await place(ex, "poor", "BUY", "LIMIT", ONE, P);
  assert.equal(r.order.status, "REJECTED");
  assert.equal(r.order.reason, "INSUFFICIENT_FUNDS");
  assert.deepEqual(bal(ex, "poor", "USD"), { available: 10_000n, reserved: 0n, pending: 0n });
  const sell = await place(ex, "poor", "SELL", "LIMIT", ONE, P); // owns no BTC
  assert.equal(sell.order.reason, "INSUFFICIENT_FUNDS");
});

test("concurrent placement cannot overspend: exactly one of 20 simultaneous orders is accepted", async () => {
  const ex = mk();
  await fund(ex, "c1", "USD", 10_000_000n);
  const results = await Promise.all(Array.from({ length: 20 }, () => place(ex, "c1", "BUY", "LIMIT", 150_000_000n, P)));
  assert.equal(results.filter((r) => r.order.status === "OPEN").length, 1);
  assert.equal(results.filter((r) => r.order.reason === "INSUFFICIENT_FUNDS").length, 19);
  assert.equal(new Set(results.map((r) => r.order.id)).size, 20);
  const b = bal(ex, "c1", "USD");
  assert.ok(b.available >= 0n && b.reserved === 6_015_001n && b.available + b.reserved === 10_000_000n);
  assert.deepEqual(ex.reconcileExchange(), []);
});

test("concurrent identical idempotent requests create a single order", async () => {
  const ex = mk();
  await fund(ex, "c1", "USD", 10_000_000n);
  const rs = await Promise.all(Array.from({ length: 10 }, () => place(ex, "c1", "BUY", "LIMIT", ONE, 3_000_000n, "dup")));
  assert.equal(new Set(rs.map((r) => r.order.id)).size, 1);
  assert.equal(rs.filter((r) => !r.replayed).length, 1);
});

test("unauthorized access: no cross-user read/cancel, non-admins cannot decide transfers", async () => {
  const ex = mk();
  await fund(ex, "a", "USD", 10_000_000n);
  const o = await place(ex, "a", "BUY", "LIMIT", ONE, 3_000_000n);
  assert.equal(ex.getOrder("evil", o.order.id), null);
  assert.deepEqual(ex.listOrders("evil"), []);
  await assert.rejects(ex.cancelOrder("evil", o.order.id), code("NOT_FOUND"));
  await assert.rejects(ex.cancelOrder("a", "ord_999"), code("NOT_FOUND")); // identical error: no existence oracle
  const d = await ex.requestDeposit("evil", { idempotencyKey: key(), asset: "USD", amount: 1_000_000n });
  await assert.rejects(ex.decideTransfer({ userId: "evil", role: "USER" }, d.id, "COMPLETE"), code("FORBIDDEN"));
  assert.equal(bal(ex, "evil", "USD").available, 0n);
  assert.equal(ex.getOrder("a", o.order.id)?.status, "OPEN");
});

test("demo mode is enforced on the server for every mutation", async () => {
  const off = new DemoExchange({ markets: [MKT], env: { DEMO_MODE: "false" } });
  await assert.rejects(off.requestDeposit("u1", { idempotencyKey: "k", asset: "USD", amount: 1n }), DemoModeError);
  await assert.rejects(off.placeOrder({ idempotencyKey: "k", userId: "u1", market: "BTC-USD", side: "BUY", type: "LIMIT", qty: ONE, price: P }), DemoModeError);
  await assert.rejects(off.cancelOrder("u1", "ord_1"), DemoModeError);
  await assert.rejects(off.decideTransfer(ADMIN, "xfer_1", "COMPLETE"), DemoModeError);
});

test("simulated wallet: deposits credit only after admin approval; withdrawals lock, settle or release", async () => {
  const ex = mk();
  const d = await ex.requestDeposit("u", { idempotencyKey: key(), asset: "USD", amount: 100_000n });
  assert.equal(d.simulated, true);
  assert.deepEqual(ex.getBalances("u"), {});
  await ex.decideTransfer(ADMIN, d.id, "COMPLETE");
  assert.equal(bal(ex, "u", "USD").available, 100_000n);
  assert.equal(ex.ledger.balance("system:demo-faucet:USD", "USD"), -100_000n);
  await assert.rejects(ex.decideTransfer(ADMIN, d.id, "COMPLETE"), code("INVALID_STATE"));

  const w = await ex.requestWithdrawal("u", { idempotencyKey: key(), asset: "USD", amount: 40_000n });
  assert.deepEqual(bal(ex, "u", "USD"), { available: 60_000n, reserved: 0n, pending: 40_000n });
  assert.deepEqual(ex.reconcileExchange(), []);
  await ex.decideTransfer(ADMIN, w.id, "COMPLETE");
  assert.deepEqual(bal(ex, "u", "USD"), { available: 60_000n, reserved: 0n, pending: 0n });
  assert.equal(ex.ledger.balance("system:demo-sink:USD", "USD"), 40_000n);

  const w2 = await ex.requestWithdrawal("u", { idempotencyKey: key(), asset: "USD", amount: 10_000n });
  await ex.decideTransfer(ADMIN, w2.id, "REJECT");
  assert.equal(bal(ex, "u", "USD").available, 60_000n);
  const w3 = await ex.requestWithdrawal("u", { idempotencyKey: key(), asset: "USD", amount: 10n ** 12n });
  assert.equal(w3.status, "REJECTED");
  assert.equal(w3.reason, "INSUFFICIENT_FUNDS");
  assert.deepEqual(ex.reconcileExchange(), []);
});

test("input validation and ledger-account injection attempts are rejected", async () => {
  const ex = mk();
  const base: Record<string, unknown> = { idempotencyKey: "k", userId: "u1", market: "BTC-USD", side: "BUY", type: "LIMIT", qty: ONE, price: P };
  const bad: Array<[Record<string, unknown>, ExchangeErrorCode]> = [
    [{ qty: 0n }, "VALIDATION"], [{ qty: 999n }, "VALIDATION"], [{ price: null }, "VALIDATION"], [{ price: 0n }, "VALIDATION"],
    [{ type: "MARKET" }, "VALIDATION"], [{ side: "HOLD" }, "VALIDATION"], [{ type: "STOP" }, "VALIDATION"],
    [{ userId: "a:b" }, "VALIDATION"], [{ userId: "a|b" }, "VALIDATION"], [{ userId: "" }, "VALIDATION"], [{ userId: "user:victim:USD:available" }, "VALIDATION"],
    [{ idempotencyKey: "has space" }, "VALIDATION"], [{ idempotencyKey: "" }, "VALIDATION"], [{ market: "ETH-USD" }, "UNKNOWN_MARKET"],
  ];
  for (const [patch, c] of bad) await assert.rejects(ex.placeOrder({ ...base, ...patch } as never), code(c), JSON.stringify(patch, (_, v) => (typeof v === "bigint" ? `${v}n` : v)));
  await assert.rejects(ex.requestDeposit("u1", { idempotencyKey: "k", asset: "DOGE", amount: 1n }), code("VALIDATION"));
  await assert.rejects(ex.requestDeposit("u1", { idempotencyKey: "k2", asset: "USD", amount: -5n }), code("VALIDATION"));
});

test("reconciliation detects tampered reserve bookkeeping", async () => {
  const ex = mk();
  await fund(ex, "b", "USD", 10_000_000n);
  const o = await place(ex, "b", "BUY", "LIMIT", ONE, 3_000_000n);
  assert.deepEqual(ex.reconcileExchange(), []);
  (ex as unknown as { orders: Map<string, { reservedRemaining: bigint }> }).orders.get(o.order.id)!.reservedRemaining += 1n;
  assert.ok(ex.reconcileExchange().some((i) => i.kind === "RESERVE_MISMATCH"));
});

test("randomised workload (seeded): invariants hold, balances never negative, money is conserved", async () => {
  const ex = mk();
  const rnd = mulberry32(2024);
  const users = ["u1", "u2", "u3", "u4"];
  for (const u of users) { await fund(ex, u, "BTC", 50n * ONE); await fund(ex, u, "USD", 500_000_000n); }
  for (let i = 0; i < 600; i++) {
    const u = users[rnd() % 4] as string;
    if (rnd() % 10 < 2) {
      const open = ex.listOrders(u, "OPEN");
      if (open.length) await ex.cancelOrder(u, (open[rnd() % open.length] as { id: string }).id);
    } else {
      const isLimit = rnd() % 4 !== 0;
      await place(ex, u, rnd() % 2 ? "BUY" : "SELL", isLimit ? "LIMIT" : "MARKET", BigInt(100_000 + (rnd() % 50_000_000)), isLimit ? BigInt(3_900_000 + (rnd() % 200_000)) : null);
    }
    if (i % 50 === 49) {
      assert.deepEqual(ex.reconcileExchange(), [], `after op ${i}`);
      for (const [k, v] of ex.ledger.balances()) if (k.startsWith("user:")) assert.ok(v >= 0n, k);
    }
  }
  assert.deepEqual(ex.reconcileExchange(), []);
  const totals = new Map<string, bigint>();
  for (const [k, v] of ex.ledger.balances()) { const cur = k.split("|")[1] as string; totals.set(cur, (totals.get(cur) ?? 0n) + v); }
  for (const [cur, v] of totals) assert.equal(v, 0n, `conservation ${cur}`);
  assert.ok(ex.recentTrades("BTC-USD", 1000).length > 20, "workload must actually trade");
  const statuses = new Set(users.flatMap((u) => ex.listOrders(u).map((o) => o.status)));
  for (const s of ["FILLED", "CANCELLED", "OPEN"]) assert.ok(statuses.has(s as never), `status ${s} exercised`);
  assert.ok(ex.ledger.balance("system:fees:USD", "USD") > 0n);
});
