import { test } from "node:test";
import assert from "node:assert/strict";
import { accountBalance, assertBalanced, compensate, reconcile, type JournalEntry } from "../src/server/ledger/journal";
import { buildTradeJournal } from "../src/server/ledger/trade-journal";
import { parseDecimal } from "../src/lib/money/decimal";

const params = (id: string) => ({
  operationId: id, buyerId: "b", sellerId: "s",
  base: { symbol: "BTC", decimals: 8 }, quote: { symbol: "USD" },
  qty: parseDecimal("0.12345678", 8), price: parseDecimal("43210.55", 2),
  buyerFeeBps: 25, sellerFeeBps: 10, feeAccountId: "exchange:fees:USD",
});

test("trade journal balances per currency for awkward decimals", () => {
  const e = buildTradeJournal(params("op1"));
  assert.deepEqual(reconcile([e]), []);
});
test("balanced property holds across many fee/price/qty combinations", () => {
  const entries: JournalEntry[] = [];
  let i = 0;
  for (const bps of [0, 1, 7, 25, 99, 10_000]) for (const price of [1n, 333n, 4_321_055n]) for (const qty of [1n, 3n, 123_456_789n]) {
    entries.push(buildTradeJournal({ ...params(`op${i++}`), price, qty, buyerFeeBps: bps, sellerFeeBps: bps === 10_000 ? 0 : bps }));
  }
  assert.deepEqual(reconcile(entries), []);
});
test("unbalanced entries are refused at post time", () => {
  assert.throws(() => assertBalanced({ operationId: "x", memo: "bad", lines: [
    { accountId: "a", currency: "USD", debit: 10n, credit: 0n },
    { accountId: "b", currency: "USD", debit: 0n, credit: 9n } ] }));
});
test("both-sided, zero and negative lines are invalid", () => {
  for (const line of [{ debit: 5n, credit: 5n }, { debit: 0n, credit: 0n }, { debit: -1n, credit: 0n }]) {
    assert.throws(() => assertBalanced({ operationId: "x", memo: "bad", lines: [
      { accountId: "a", currency: "USD", ...line }, { accountId: "b", currency: "USD", debit: 0n, credit: 1n } ] }));
  }
});
test("posted entries are frozen (immutable)", () => {
  const e = buildTradeJournal(params("op1"));
  assert.ok(Object.isFrozen(e) && Object.isFrozen(e.lines) && Object.isFrozen(e.lines[0]));
  const before = e.lines[0]!.debit;
  try { (e.lines[0] as { debit: bigint }).debit = 0n; } catch { /* strict mode throws, sloppy mode ignores */ }
  assert.equal(e.lines[0]!.debit, before, "frozen line must keep its value");
});
test("compensating entry nets every account to zero", () => {
  const e = buildTradeJournal(params("op1"));
  const c = compensate(e, "op1-rev", "SIMULATED correction");
  for (const l of e.lines) assert.equal(accountBalance([e, c], l.accountId, l.currency), 0n);
  assert.deepEqual(reconcile([e, c]), []);
});
test("reconciliation detects duplicates, unbalanced entries and dangling reversals", () => {
  const good = buildTradeJournal(params("op1"));
  const dup = buildTradeJournal(params("op1"));
  const broken: JournalEntry = { operationId: "bad", memo: "", lines: [
    { accountId: "a", currency: "USD", debit: 5n, credit: 0n }, { accountId: "b", currency: "USD", debit: 0n, credit: 4n } ] };
  const dangling: JournalEntry = { ...good, operationId: "r", reversesOperationId: "ghost" };
  const kinds = reconcile([good, dup, broken, dangling]).map((i) => i.kind);
  assert.ok(kinds.includes("DUPLICATE_OPERATION"));
  assert.ok(kinds.includes("UNBALANCED"));
  assert.ok(kinds.includes("MISSING_REVERSAL_TARGET"));
});
test("fees land in the fee account exactly", () => {
  const e = buildTradeJournal(params("op1"));
  const fee = accountBalance([e], "exchange:fees:USD", "USD");
  assert.ok(fee > 0n);
});
