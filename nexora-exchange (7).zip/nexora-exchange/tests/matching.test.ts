import { test } from "node:test";
import assert from "node:assert/strict";
import { OrderBook } from "../src/server/matching/order-book";

const mk = () => new OrderBook();

test("price-time priority: better price first, then earlier arrival", () => {
  const b = mk();
  b.addResting({ id: "a1", userId: "m1", side: "SELL", price: 101n, remaining: 5n });
  b.addResting({ id: "a2", userId: "m2", side: "SELL", price: 100n, remaining: 5n });
  b.addResting({ id: "a3", userId: "m3", side: "SELL", price: 100n, remaining: 5n });
  const r = b.submit({ id: "t", userId: "taker", side: "BUY", limitPrice: null, qty: 12n });
  assert.deepEqual(r.fills.map((f) => [f.makerOrderId, f.price, f.qty]), [["a2", 100n, 5n], ["a3", 100n, 5n], ["a1", 101n, 2n]]);
});
test("limit buy never fills above its limit; remainder rests", () => {
  const b = mk();
  b.addResting({ id: "a1", userId: "m", side: "SELL", price: 100n, remaining: 3n });
  b.addResting({ id: "a2", userId: "m", side: "SELL", price: 105n, remaining: 3n });
  const r = b.submit({ id: "t", userId: "u", side: "BUY", limitPrice: 102n, qty: 10n });
  assert.ok(r.fills.every((f) => f.price <= 102n));
  assert.equal(r.remaining, 7n);
  assert.equal(r.rested?.price, 102n);
});
test("limit sell never fills below its limit", () => {
  const b = mk();
  b.addResting({ id: "b1", userId: "m", side: "BUY", price: 99n, remaining: 3n });
  b.addResting({ id: "b2", userId: "m", side: "BUY", price: 95n, remaining: 3n });
  const r = b.submit({ id: "t", userId: "u", side: "SELL", limitPrice: 98n, qty: 10n });
  assert.deepEqual(r.fills.map((f) => f.price), [99n]);
  assert.ok(r.fills.every((f) => f.price >= 98n));
});
test("fills execute at the maker's price (price improvement for taker)", () => {
  const b = mk();
  b.addResting({ id: "a1", userId: "m", side: "SELL", price: 100n, remaining: 1n });
  const r = b.submit({ id: "t", userId: "u", side: "BUY", limitPrice: 110n, qty: 1n });
  assert.equal(r.fills[0]?.price, 100n);
});
test("partial fill leaves maker remainder; fully filled makers are removed", () => {
  const b = mk();
  b.addResting({ id: "a1", userId: "m", side: "SELL", price: 100n, remaining: 10n });
  b.submit({ id: "t", userId: "u", side: "BUY", limitPrice: null, qty: 4n });
  assert.equal(b.snapshot().asks[0]?.remaining, 6n);
  b.submit({ id: "t2", userId: "u", side: "BUY", limitPrice: null, qty: 6n });
  assert.equal(b.snapshot().asks.length, 0);
});
test("market order on empty book fills nothing and never rests", () => {
  const b = mk();
  const r = b.submit({ id: "t", userId: "u", side: "BUY", limitPrice: null, qty: 5n });
  assert.equal(r.fills.length, 0);
  assert.equal(r.remaining, 5n);
  assert.equal(r.rested, null);
});
test("self-trade prevention skips own resting orders", () => {
  const b = mk();
  b.addResting({ id: "own", userId: "u", side: "SELL", price: 99n, remaining: 5n });
  b.addResting({ id: "other", userId: "m", side: "SELL", price: 100n, remaining: 5n });
  const r = b.submit({ id: "t", userId: "u", side: "BUY", limitPrice: null, qty: 5n });
  assert.deepEqual(r.fills.map((f) => f.makerOrderId), ["other"]);
});
test("cancel removes a resting order exactly once", () => {
  const b = mk();
  b.addResting({ id: "a1", userId: "m", side: "SELL", price: 100n, remaining: 5n });
  assert.equal(b.cancel("a1")?.id, "a1");
  assert.equal(b.cancel("a1"), null);
});
test("invalid inputs rejected", () => {
  const b = mk();
  assert.throws(() => b.submit({ id: "t", userId: "u", side: "BUY", limitPrice: null, qty: 0n }));
  assert.throws(() => b.submit({ id: "t", userId: "u", side: "BUY", limitPrice: 0n, qty: 1n }));
});
test("determinism: identical input sequence yields identical output", () => {
  const run = () => {
    const b = mk();
    b.addResting({ id: "a1", userId: "m", side: "SELL", price: 100n, remaining: 7n });
    b.addResting({ id: "a2", userId: "m2", side: "SELL", price: 100n, remaining: 7n });
    return JSON.stringify(b.submit({ id: "t", userId: "u", side: "BUY", limitPrice: 100n, qty: 10n }).fills, (_, v) => (typeof v === "bigint" ? v.toString() : v));
  };
  assert.equal(run(), run());
});
