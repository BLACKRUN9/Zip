import { test } from "node:test";
import assert from "node:assert/strict";
import { buildLiquidityLadder, generateCandles } from "../src/server/market-data/seeded";
import { RateLimiter, SECURITY_HEADERS } from "../src/server/security/rate-limit";
import { makeAuditEvent, redact } from "../src/server/audit/redact";
import { evaluateRisk } from "../src/server/risk/alerts";

test("seeded candles are deterministic, labelled SIMULATED and OHLC-consistent", () => {
  const args = { seed: 42, startPrice: 4_000_000n, count: 200, intervalMs: 60_000, startTs: 1_700_000_000_000 };
  const a = generateCandles(args), b = generateCandles(args);
  assert.deepEqual(a, b);
  assert.notDeepEqual(a, generateCandles({ ...args, seed: 43 }));
  for (const c of a) {
    assert.equal(c.source, "SIMULATED-SEED");
    assert.ok(c.high >= c.open && c.high >= c.close && c.low <= c.open && c.low <= c.close && c.low >= 1n);
  }
  for (let i = 1; i < a.length; i++) assert.equal(a[i]!.open, a[i - 1]!.close);
});
test("liquidity ladder never crosses and quantity grows away from touch", () => {
  const l = buildLiquidityLadder({ mid: 4_000_000n, levels: 10, spacingBps: 5, baseQty: 1_000_000n });
  const asks = l.filter((o) => o.side === "SELL"), bids = l.filter((o) => o.side === "BUY");
  assert.ok(Math.min(...asks.map((o) => Number(o.price))) > Math.max(...bids.map((o) => Number(o.price))));
  assert.ok(asks[9]!.qty > asks[0]!.qty);
});
test("rate limiter blocks after the limit and resets after the window", () => {
  let t = 0;
  const r = new RateLimiter(3, 1000, () => t);
  assert.deepEqual([1, 2, 3].map(() => r.check("ip").allowed), [true, true, true]);
  const blocked = r.check("ip");
  assert.equal(blocked.allowed, false);
  assert.equal(blocked.retryAfterMs, 1000);
  assert.equal(r.check("other").allowed, true);
  t = 1000;
  assert.equal(r.check("ip").allowed, true);
});
test("security headers deny framing and sniffing", () => {
  assert.equal(SECURITY_HEADERS["X-Frame-Options"], "DENY");
  assert.equal(SECURITY_HEADERS["X-Content-Type-Options"], "nosniff");
  assert.match(SECURITY_HEADERS["Content-Security-Policy"]!, /frame-ancestors 'none'/);
});
test("audit redaction removes secrets at any depth and handles bigint/cycles", () => {
  const cyc: Record<string, unknown> = { name: "x" }; cyc["self"] = cyc;
  const out = redact({ user: "u1", password: "p", nested: { sessionToken: "t", list: [{ apiKey: "k", ok: 1n }] }, cyc, Authorization: "Bearer z" }) as Record<string, any>;
  const s = JSON.stringify(out);
  for (const secret of ['"p"', '"t"', '"k"', "Bearer z"]) assert.ok(!s.includes(secret), secret);
  assert.equal(out.password, "[REDACTED]");
  assert.equal(out.nested.list[0].ok, "1");
  assert.equal(out.cyc.self, "[CIRCULAR]");
  const ev = makeAuditEvent("admin1", "FEE_UPDATE", "market:BTC-USD", 5, { oldBps: 10n, secret: "s" });
  assert.ok(Object.isFrozen(ev));
  assert.equal((ev.metadata as any).secret, "[REDACTED]");
});
test("risk rules: large order/deposit, cancel burst and reject burst (one alert per window)", () => {
  const cfg = { windowMs: 1000, cancelBurst: 3, rejectBurst: 2, largeOrderNotional: 1000n, largeDeposit: 500n };
  const ev = [
    { userId: "a", kind: "ORDER" as const, at: 1, amount: 1000n },
    { userId: "a", kind: "DEPOSIT" as const, at: 2, amount: 499n },
    { userId: "a", kind: "DEPOSIT" as const, at: 3, amount: 500n },
    ...[10, 20, 30, 40].map((at) => ({ userId: "b", kind: "CANCEL" as const, at, amount: 0n })),
    ...[10, 20].map((at) => ({ userId: "c", kind: "REJECT" as const, at, amount: 0n })),
    ...[10, 2000].map((at) => ({ userId: "d", kind: "REJECT" as const, at, amount: 0n })),
  ];
  const rules = evaluateRisk(ev, cfg).map((a) => `${a.rule}:${a.userId}`).sort();
  assert.deepEqual(rules, ["CANCEL_BURST:b", "LARGE_DEPOSIT:a", "LARGE_ORDER:a", "REJECT_BURST:c"]);
});
