// Adds npm scripts to package.json without overwriting existing ones. Run: node scripts/add-scripts.mjs
import fs from "node:fs";
const pkg = JSON.parse(fs.readFileSync("package.json", "utf8"));
pkg.scripts ??= {};
const add = {
  test: "tsx --test tests/*.test.ts",
  "test:server": "tsx --conditions=react-server --test tests-server/*.test.ts",
  typecheck: "tsc --noEmit",
  e2e: "playwright test",
  "db:generate": "prisma generate",
  "db:migrate": "prisma migrate dev",
  "db:seed": "tsx prisma/seed.ts",
};
for (const [k, v] of Object.entries(add)) {
  if (pkg.scripts[k]) console.log(`kept existing script "${k}": ${pkg.scripts[k]}`);
  else { pkg.scripts[k] = v; console.log(`added script "${k}"`); }
}
fs.writeFileSync("package.json", JSON.stringify(pkg, null, 2) + "\n");
