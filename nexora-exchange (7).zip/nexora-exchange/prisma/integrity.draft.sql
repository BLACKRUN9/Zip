-- UNTESTED DRAFT: not executed against PostgreSQL (none available in the authoring sandbox).
-- Intended to be added as a hand-written Prisma migration AFTER the models exist, then covered by DB integration tests.

ALTER TABLE journal_lines ADD CONSTRAINT journal_lines_one_sided
  CHECK ((debit > 0 AND credit = 0) OR (credit > 0 AND debit = 0));
ALTER TABLE orders ADD CONSTRAINT orders_qty_positive CHECK (qty > 0 AND filled_qty >= 0 AND filled_qty <= qty AND reserved_remaining >= 0);
ALTER TABLE markets ADD CONSTRAINT markets_fee_range CHECK (taker_fee_bps BETWEEN 0 AND 10000 AND maker_fee_bps BETWEEN 0 AND 10000);
ALTER TABLE ledger_accounts ADD CONSTRAINT user_accounts_non_negative CHECK (id NOT LIKE 'user:%' OR balance >= 0);

-- Posted ledger rows are immutable.
CREATE OR REPLACE FUNCTION forbid_mutation() RETURNS trigger AS $$
BEGIN RAISE EXCEPTION 'ledger rows are immutable; post a compensating entry'; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER journal_lines_immutable BEFORE UPDATE OR DELETE ON journal_lines FOR EACH ROW EXECUTE FUNCTION forbid_mutation();
CREATE TRIGGER ledger_tx_immutable BEFORE UPDATE OR DELETE ON ledger_transactions FOR EACH ROW EXECUTE FUNCTION forbid_mutation();

-- Every transaction must balance per asset at COMMIT.
CREATE OR REPLACE FUNCTION assert_tx_balanced() RETURNS trigger AS $$
DECLARE bad int;
BEGIN
  SELECT count(*) INTO bad FROM (
    SELECT asset FROM journal_lines WHERE transaction_id = NEW.transaction_id GROUP BY asset HAVING sum(debit) <> sum(credit)
  ) s;
  IF bad > 0 THEN RAISE EXCEPTION 'unbalanced journal transaction %', NEW.transaction_id; END IF;
  RETURN NULL;
END; $$ LANGUAGE plpgsql;
CREATE CONSTRAINT TRIGGER journal_lines_balanced AFTER INSERT ON journal_lines
  DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION assert_tx_balanced();
