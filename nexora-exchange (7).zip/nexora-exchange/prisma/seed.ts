/**
 * DEVELOPMENT-ONLY seed: creates the five demo accounts (user1, user2, mm, mm2, admin) through Better Auth.
 * Run:  ALLOW_DEV_SEED=true SEED_DEV_PASSWORD='<your 12+ char password>' npm run db:seed
 * Refuses to run in production, without DEMO_MODE=true, without ALLOW_DEV_SEED=true, or with a short password.
 * The password comes from YOUR environment and is never printed or stored in the repository.
 */
import "dotenv/config";
import { ACCOUNTS } from "../src/server/accounts/directory";
import { createAuth } from "../src/server/auth/auth";
import { checkSeedAllowed, readAuthEnv } from "../src/server/auth/mode";
import { getPrisma } from "../src/server/db/prisma";

async function main(): Promise<void> {
  const guard = checkSeedAllowed(process.env);
  if (!guard.ok) { console.error(`Seed refused: ${guard.reason}`); process.exit(1); }
  const prisma = getPrisma(readAuthEnv(process.env).databaseUrl);
  const auth = createAuth({ allowSignUp: true, withNextCookies: false }); // seed-only instance; the app instance has sign-up disabled
  const password = process.env["SEED_DEV_PASSWORD"] as string;
  for (const a of ACCOUNTS) {
    if (await prisma.user.findUnique({ where: { email: a.email } })) { console.log(`exists   ${a.email}`); continue; }
    await auth.api.signUpEmail({ body: { email: a.email, password, name: a.label } });
    const created = await prisma.user.findUnique({ where: { email: a.email } });
    if (created) await prisma.session.deleteMany({ where: { userId: created.id } }); // sign-up may auto-create a session; we want none
    console.log(`created  ${a.email}  (${a.role})`);
  }
  console.log("Done. Sign in with these emails and the value of SEED_DEV_PASSWORD (not printed).");
}

main().then(() => process.exit(0)).catch((e) => { console.error("Seed failed:", e instanceof Error ? e.message.split("\n")[0] : "error"); process.exit(1); });
