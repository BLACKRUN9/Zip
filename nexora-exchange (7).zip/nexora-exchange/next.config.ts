import type { NextConfig } from "next";

// Development convenience only. GitHub Codespaces proxies the app, so the Origin header (public URL) differs from
// X-Forwarded-Host and Next.js rejects Server Actions as a CSRF protection. We trust the Codespaces domain ONLY
// when running inside Codespaces; every other environment keeps the framework default (same-origin only).
const inCodespaces = process.env.CODESPACES === "true" || Boolean(process.env.GITHUB_CODESPACES_PORT_FORWARDING_DOMAIN);

const nextConfig: NextConfig = {
  experimental: {
    serverActions: {
      allowedOrigins: inCodespaces ? ["*.app.github.dev", "localhost:3000"] : [],
    },
  },
};

export default nextConfig;
