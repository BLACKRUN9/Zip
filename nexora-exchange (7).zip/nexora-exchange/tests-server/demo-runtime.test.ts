// Requires `server-only` to be resolvable. Run with: tsx --conditions=react-server --test tests-server/*.test.ts
import { test } from "node:test";
import assert from "node:assert/strict";
process.env["DEMO_MODE"] = "true";
import { cancelOrder, submitOrder, submitTransfer } from "../src/server/demo/commands";
import { createRuntime, getRuntime } from "../src/server/demo/runtime";
import { getAdminView, getBalances, getMarkets, getOrdersView, getTerminal, getWalletView } from "../src/server/demo/view";
import { botOp, cloneBot, importCsv, panelSnapshot, saveBot, setReference } from "../src/server/demo/mm";
import { AuthzError, requirePermission } from "../src/server/auth/actor";
import { DemoModeError } from "../src/server/config/demo-guard";
import { handleCandles } from "../src/server/demo/market-api";
import { RateLimiter } from "../src/server/security/rate-limit";
import { SimulatedProvider, ProviderError, type MarketDataProvider } from "../src/server/market-data/provider";
import { readFileSync } from "node:fs";

const U1 = { userId: "user1", role: "USER" as const }, MM = { userId: "mm", role: "MM" as const }, ADMIN = { userId: "admin", role: "ADMIN" as const };
const order = (userId: string, o: Partial<Parameters<typeof submitOrder>[1]> & { idempotencyKey: string }) => submitOrder(userId, { market: "NXR-USDT", side: "BUY", type: "LIMIT", qty: "10", price: "1", ...o });
const SELL_CSV = readFileSync("config/mm-strategies.csv", "utf8");
const VOL_CSV = (name: string, extra: Record<string, string> = {}) => `${name},Field,Value,Edit\n` + Object.entries({ account_id: "ACCT1", volume_price_decimal: "4", volume_quantity_decimal: "2", volume_random_min_quantity: "10", volume_random_max_quantity: "20", min_delay: "1", max_delay: "2", min_difference: "0.1", max_difference: "0.3", priority: "random", max_limit_price: "None", min_limit_price: "None", vol_idr_stop_target: "None", vol_idr_start_threshold: "None", volume_sell_account_id: "ACCT2", ...extra }).map(([k, v], i) => `${i + 2},${k},${v},`).join("\n") + "\n";
const MAP = "ACCT1=mm,ACCT2=mm2";

test("fresh runtime has NO mock liquidity and NO fake trades; chart is empty until real trades happen", async () => {
  const markets = await getMarkets();
  assert.deepEqual(markets.map((m) => m.symbol), ["NXR-USDT", "BTC-USD", "ETH-USD", "SOL-USD"]);
  for (const m of markets) {
    const t = (await getTerminal(m.symbol, null))!;
    assert.equal(t.depth.asks.length + t.depth.bids.length, 0, `${m.symbol} book is empty`);
    assert.equal(t.trades.length, 0); assert.equal(t.chart.candles.length, 0); assert.equal(t.chart.source, "NEXORA-TRADES");
    assert.equal(t.lastSource, "REFERENCE"); assert.equal(t.canTrade, false); assert.equal(t.chart.synthetic, false);
  }
  const rt = await getRuntime();
  for (const id of ["user1", "user2", "mm", "mm2", "admin"]) assert.ok(Object.keys(rt.exchange.getBalances(id)).length > 0, `${id} is funded`);
  assert.deepEqual((await getAdminView()).issues, []);
});

test("real orders from two users create the book, the trade, and the matching candle", async () => {
  assert.equal((await order("user1", { idempotencyKey: "srv-sell-0001", side: "SELL", price: "4.0000", qty: "100" })).status, "ok");
  assert.equal((await getTerminal("NXR-USDT", "user1"))!.depth.asks.length, 1);
  assert.equal((await order("user2", { idempotencyKey: "srv-buy-00001", type: "MARKET", qty: "40", price: "" })).status, "ok");
  const t = (await getTerminal("NXR-USDT", "user2"))!;
  assert.equal(t.trades.length, 1); assert.equal(t.trades[0]!.price, "4.000000"); assert.equal(t.trades[0]!.qty, "40.00");
  assert.equal(t.chart.candles.length >= 1, true);
  const c = t.chart.candles.at(-1)!;
  assert.deepEqual([c.o, c.h, c.l, c.c, c.v], ["4000000", "4000000", "4000000", "4000000", "4000000000"]);
  assert.equal(t.lastSource, "TRADE"); assert.equal(t.chart.synthetic, false);
  assert.equal((await getOrdersView("user2")).trades.length, 1);
  assert.equal((await getOrdersView("user1")).trades[0]!.role, "MAKER");
  await cancelOrder("user2", (await getOrdersView("user1")).open[0]!.id); // foreign id: no effect, no throw
  assert.equal((await getOrdersView("user1")).open.length, 1);
  assert.deepEqual((await getAdminView()).issues, []);
});

test("order/wallet commands validate and stay simulated", async () => {
  const bad = await order("user1", { idempotencyKey: "srv-bad-00001", qty: "0.123456789" });
  assert.equal(bad.status, "error"); assert.match(bad.fieldErrors.qty ?? "", /8 decimal/);
  assert.equal((await order("user1", { idempotencyKey: "srv-big-00001", qty: "999999999" })).status, "error");
  const dep = await submitTransfer("user1", { idempotencyKey: "srv-xfer-0001", kind: "DEPOSIT", asset: "USDT", amount: "250.50" });
  assert.equal(dep.status, "ok"); assert.match(dep.message, /SIMULATED/);
  assert.equal((await getWalletView("user1")).transfers.some((t) => t.status === "PENDING"), true);
  assert.equal((await submitTransfer("user1", { idempotencyKey: "srv-xfer-0002", kind: "SWEEP", asset: "USDT", amount: "1" })).status, "error");
  assert.equal((await getBalances("user2")).rows.length > 0, true);
});

test("authorization: unauthenticated, USER, MM and ADMIN against the panel and its operations", async () => {
  await assert.rejects(panelSnapshot(null), (e: unknown) => e instanceof AuthzError && e.code === "UNAUTHENTICATED");
  await assert.rejects(panelSnapshot(U1), (e: unknown) => e instanceof AuthzError && e.code === "FORBIDDEN");
  await assert.rejects(importCsv(U1, SELL_CSV, "NXR-USDT", MAP), AuthzError);
  await assert.rejects(botOp(U1, "sells0", "start"), AuthzError); await assert.rejects(setReference(U1, "NXR-USDT", "4"), AuthzError);
  assert.throws(() => requirePermission(MM, "admin:view"), AuthzError); assert.throws(() => requirePermission(MM, "transfers:decide"), AuthzError);

  const imp = await importCsv(MM, SELL_CSV, "NXR-USDT", MAP);
  assert.deepEqual([imp.ok, imp.count, imp.errors], [true, 4, []]);
  assert.equal((await panelSnapshot(MM)).bots.length, 4);
  assert.equal((await panelSnapshot(ADMIN)).bots.length, 4);
  const denied = await importCsv(MM, VOL_CSV("Cross1"), "NXR-USDT", MAP); // touches mm2 as well => ADMIN only
  assert.equal(denied.ok, false); assert.match(denied.errors.join(), /cannot create bots/);
  const crossOwn = await importCsv(ADMIN, VOL_CSV("Cross1"), "NXR-USDT", MAP);
  assert.equal(crossOwn.ok, true);
  const seen = (await panelSnapshot(MM)).bots.find((b) => b.id === "cross1");
  assert.ok(seen && seen.canManage === false, "MM can SEE a bot that uses its account but cannot control it");
  assert.ok((await panelSnapshot(MM)).bots.filter((b) => b.id.startsWith("sells")).every((b) => b.canManage), "...and controls its own bots");
  assert.equal((await botOp(MM, "cross1", "start")).ok, false, "MM cannot control it (same answer as 'not found')");
  assert.equal((await importCsv(ADMIN, SELL_CSV, "NXR-USDT", MAP)).ok, false, "duplicate ids are refused");
  assert.equal((await importCsv(MM, "garbage", "NXR-USDT", MAP)).ok, false);
  assert.equal((await importCsv(MM, SELL_CSV, "NXR-USDT", "ACCT1=user1")).ok, false);
  assert.equal((await importCsv(MM, "x".repeat(60_000), "NXR-USDT", MAP)).ok, false);
});

test("order bots from the CSV quote real orders; MM can start/stop/clone/edit its own bots; audit is written", async () => {
  const rt = await getRuntime();
  assert.equal((await botOp(MM, "sells0", "start")).ok, true);
  await rt.mm.tick();
  const t = (await getTerminal("NXR-USDT", null))!;
  assert.ok(t.depth.asks.length >= 5, "bot quotes are in the public book");
  assert.ok(Object.keys(rt.exchange.getBalances("mm")).includes("NXR"));
  assert.equal((await saveBot(MM, "sells0", { account_id: "ACCT1" })).ok, false, "cannot edit while running");
  const clone = await cloneBot(MM, "sells0", "Sell Wide");
  assert.equal(clone.ok, true);
  const snap = (await panelSnapshot(MM)).bots;
  assert.ok(snap.find((b) => b.id === "sell-wide" && !b.running), "clone is stopped");
  assert.equal((await cloneBot(MM, "sells0", "Sell Wide")).ok, false, "name must be unique");
  const fields = { ...snap.find((b) => b.id === "sell-wide")!.fields, random_max_quantity: "40.0", order_count: "5" };
  assert.equal((await saveBot(MM, "sell-wide", fields)).ok, true);
  assert.equal((await saveBot(MM, "sell-wide", { ...fields, transaction_type: "teleport" })).ok, false);
  assert.equal((await botOp(MM, "sells0", "stop")).ok, true);
  assert.equal((await getTerminal("NXR-USDT", null))!.depth.asks.filter((a) => a.qty !== "").length >= 1, true, "user1's own ask is still there");
  assert.equal((await botOp(MM, "sell-wide", "remove")).ok, true);
  assert.ok(rt.audit.some((e) => e.action === "BOT_CLONE") && rt.audit.some((e) => e.action === "BOT_START"));
  assert.deepEqual((await getAdminView()).issues, []);
});

test("volume bot (ADMIN): synthetic trades are tagged and the chart says so; candles equal trade volume", async () => {
  const rt = await getRuntime();
  assert.equal((await botOp(ADMIN, "cross1", "start")).ok, true);
  for (let i = 0; i < 4; i++) { await rt.vol.tick(); await new Promise((r) => setTimeout(r, 1100)); }
  const t = (await getTerminal("NXR-USDT", null))!;
  assert.ok(rt.vol.syntheticCount("NXR-USDT") >= 1);
  assert.equal(t.chart.synthetic, true); assert.ok(t.trades.some((x) => x.synthetic));
  const total = rt.exchange.marketTrades("NXR-USDT").reduce((s, x) => s + x.qty, 0n);
  assert.equal(t.chart.candles.reduce((s, c) => s + BigInt(c.v), 0n), total, "candle volume == traded volume");
  await botOp(ADMIN, "cross1", "stop");
  assert.deepEqual((await getAdminView()).issues, []);
});

test("reference price: MM may set it, validated", async () => {
  assert.equal((await setReference(MM, "NXR-USDT", "4.2500")).ok, true);
  assert.equal((await getRuntime()).references.get("NXR-USDT"), 4_250_000n);
  for (const bad of ["0", "-1", "abc", "1.1234567"]) assert.equal((await setReference(MM, "NXR-USDT", bad)).ok, false, bad);
  assert.equal((await setReference(MM, "DOGE-USD", "1")).ok, false);
});

test("autostart from config/mm.config.json starts all four CSV bots on a fresh runtime", async () => {
  const rt = await createRuntime({ autostart: true });
  await rt.mm.tick();
  assert.equal(rt.mm.status().filter((s) => s.running).length, 4);
  assert.ok(rt.exchange.depth("NXR-USDT", 30).asks.length >= 5);
  assert.deepEqual(rt.exchange.reconcileExchange(), []);
  await rt.mm.stopAll();
});

test("runtime refuses to start unless DEMO_MODE is exactly 'true'", async () => {
  const prev = process.env["DEMO_MODE"];
  try { process.env["DEMO_MODE"] = "false"; await assert.rejects(createRuntime(), DemoModeError); delete process.env["DEMO_MODE"]; await assert.rejects(createRuntime(), DemoModeError); }
  finally { process.env["DEMO_MODE"] = prev; }
});

test("candles API: validation, rate limit, generic 502", async () => {
  const sim = new SimulatedProvider({ "NXR-USDT": { seed: 1, startPrice: 4_000_000n } });
  const down: MarketDataProvider = { id: "NEXORA-TRADES", getCandles: async () => { throw new ProviderError("UPSTREAM", "secret internal detail postgres://u:p@h"); } };
  const get = (deps: Parameters<typeof handleCandles>[2], path: string, sym = "NXR-USDT", ip = "1.2.3.4") => handleCandles(new Request(`http://x/api/market/${sym}/candles${path}`, { headers: { "x-forwarded-for": ip } }), sym, deps);
  const deps = { primary: sim, fallback: sim, limiter: new RateLimiter(100, 60_000), synthetic: async () => true };
  const ok = await get(deps, "?interval=15&limit=50");
  assert.equal(ok.status, 200); assert.equal(ok.headers.get("cache-control"), "no-store");
  const body = (await ok.json()) as { candles: unknown[]; synthetic: boolean }; assert.equal(body.candles.length, 50); assert.equal(body.synthetic, true);
  assert.equal((await get(deps, "", "DOGE-USD")).status, 404);
  for (const q of ["?interval=7", "?limit=0", "?limit=99999", "?interval=abc"]) assert.equal((await get(deps, q)).status, 400, q);
  const both = await get({ primary: down, fallback: down, limiter: new RateLimiter(50, 60_000) }, ""); const text = await both.text();
  assert.equal(both.status, 502); assert.ok(!/secret|postgres/.test(text));
  const lim = { primary: sim, fallback: sim, limiter: new RateLimiter(2, 60_000) };
  const st: number[] = []; for (let i = 0; i < 4; i++) st.push((await get(lim, "", "NXR-USDT", "9.9.9.9")).status);
  assert.deepEqual(st, [200, 200, 429, 429]);
});
