import mongoose from 'mongoose';
import { createApp } from './api/app.ts';
import { SimChain } from './chain/simChain.ts';
import { EvmRpcChain } from './chain/evmRpc.ts';
import type { ChainAdapter } from './chain/types.ts';
import { CHAIN_CONFIRMATIONS, network } from './config.ts';
import { DepositAddress } from './db/models.ts';
import { initDb } from './db/init.ts';
import { MatchingEngine } from './engine/engine.ts';
import { SimProvider } from './payments/provider.ts';
import { SignerClient } from './signer/http.ts';
import { seedBasics } from './seed.ts';
import { configureSecurity } from './security/crypto.ts';
import { ChainWorker } from './services/chain.ts';
import { dispatchApprovedPayouts, handlePaymentWebhook } from './services/fiat.ts';
import { resubmitPending } from './services/orders.ts';
import type { EngineGateway } from './services/orders.ts';
import { applyEngineEvent } from './services/settlement.ts';
import { MarketFeed } from './marketdata/feed.ts';
import { attachWebSocket } from './ws/server.ts';

function need(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`missing env ${name}`);
  return v;
}
const log = (m: object) => console.log(JSON.stringify(m));

async function main() {
  const prod = process.env.NODE_ENV === 'production';
  const payMode = process.env.PAYMENT_PROVIDER ?? ''; // '' | 'sim'
  const chainMode = process.env.CHAIN_MODE ?? ''; // '' | 'sim' | 'evm'
  if (prod && (payMode === 'sim' || chainMode === 'sim')) throw new Error('simulated payments/chains must not run in production');

  configureSecurity(need('DATA_ENCRYPTION_KEY'), need('BLIND_INDEX_KEY'));
  await mongoose.connect(need('MONGODB_URI')); // must be a replica set
  await initDb();
  await seedBasics({ usdtChain: chainMode === 'evm' ? 'ETH' : undefined }); // Sepolia hosts USDT as an ERC-20 on the ETH chain

  // Single-process wiring: engine + settlement consumer in the API process. Split them (and persist the
  // consumer's last applied seq per market) before running more than one instance.
  const engine = new MatchingEngine();
  const feed = new MarketFeed(engine);
  const process_ = async (events: Awaited<ReturnType<typeof engine.submit>>) => {
    for (const e of events) await applyEngineEvent(e); // ledger first: the ledger is the truth
    await feed.onEngineEvents(events); // then publish; never throws
  };
  const gateway: EngineGateway = {
    async submit(o) { await process_(await engine.submit(o)); },
    async cancel(marketId, orderId) { await process_(await engine.cancel(marketId, orderId)); },
  };
  setInterval(() => { resubmitPending(gateway).catch((e) => console.error('resubmit failed', e)); }, 10_000).unref();

  // ---- IDR gateway (simulated)
  let payments: { provider: SimProvider; sim: SimProvider } | undefined;
  if (payMode === 'sim') {
    const p: SimProvider = new SimProvider({ secret: need('SIM_WEBHOOK_SECRET'), deliver: (raw, headers) => handlePaymentWebhook(p, headers, raw) });
    payments = { provider: p, sim: p };
    setInterval(() => { dispatchApprovedPayouts(p).catch((e) => console.error('payout sweep failed', e)); }, 15_000).unref();
    const auto = process.env.SIM_AUTO_PAYOUT ?? 'completed'; // completed | failed | manual
    if (auto !== 'manual') {
      setInterval(() => { // the pretend bank settles processing payouts after a few seconds
        for (const [ref, po] of p.payouts) if (po.status === 'processing') void p.simulatePayoutResult(ref, auto === 'failed' ? 'failed' : 'completed', auto === 'failed' ? 'simulasi: rekening ditolak' : undefined).catch(() => {});
      }, 8_000).unref();
    }
    log({ msg: 'SIMULATED IDR payment gateway enabled (development only)' });
  }

  // ---- chains (simulated testnet or a real EVM testnet)
  const chains: Record<string, ChainAdapter> = {};
  let simChains: Record<string, SimChain> | undefined;
  const workers: ChainWorker[] = [];
  if (chainMode === 'sim') {
    network.testnet = true;
    Object.assign(CHAIN_CONFIRMATIONS, { BTC: 2, ETH: 2, TRON: 2 }); // fast demos
    simChains = { BTC: new SimChain('BTC'), ETH: new SimChain('ETH'), TRON: new SimChain('TRON') };
    for (const [name, c] of Object.entries(simChains)) { chains[name] = c; workers.push(new ChainWorker(c, { log })); setInterval(() => c.mine(), 5_000).unref(); }
    log({ msg: 'SIMULATED testnet chains enabled (BTC, ETH, TRON)' });
  } else if (chainMode === 'evm') {
    network.testnet = process.env.CHAIN_NETWORK !== 'mainnet';
    const usdt = process.env.EVM_USDT_ADDRESS;
    // payouts go through the separate signer service (it alone holds the key). Without SIGNER_URL payouts stay disabled.
    const signer = process.env.SIGNER_URL ? new SignerClient({ url: process.env.SIGNER_URL, secret: need('SIGNER_SECRET'), fetch: (u, i) => fetch(u, i) }) : undefined;
    const hot = process.env.SIGNER_HOT_ADDRESS; // printed by the signer at start-up; counted as custody
    const eth = new EvmRpcChain({
      chain: 'ETH', rpcUrl: need('EVM_RPC_URL'), fetch: (u, i) => fetch(u, i), nativeAsset: 'ETH', tokens: usdt ? { USDT: usdt } : {}, maxScan: 100, signer,
      custodyAddresses: async () => [...(hot ? [hot] : []), ...(await DepositAddress.find({ chain: 'ETH' }).lean()).map((r: any) => r.address)],
    });
    chains.ETH = eth;
    workers.push(new ChainWorker(eth, { log }));
  }
  for (const w of workers) setInterval(() => { void w.tick(); }, 3_000).unref();

  const app = createApp({
    gateway, engine, payments, chains, simChains,
    mailer: {
      async sendPasswordReset(email, token) {
        if (prod) throw new Error('no mailer configured'); // wire a real provider; never log tokens in production
        console.log(`[dev] password reset for ${email}: ${token}`);
      },
    },
    corsOrigins: (process.env.CORS_ORIGINS ?? '').split(',').filter(Boolean),
    trustProxy: process.env.TRUST_PROXY ? Number(process.env.TRUST_PROXY) : false,
    adminIpAllowlist: (process.env.ADMIN_IP_ALLOWLIST ?? '').split(',').filter(Boolean),
  });
  const server = app.listen(Number(process.env.PORT ?? 3000), () => console.log('listening'));
  const ws = attachWebSocket(server, {
    feed,
    gateway,
    allowedOrigins: (process.env.CORS_ORIGINS ?? '').split(',').filter(Boolean),
    trustProxy: !!process.env.TRUST_PROXY,
  });
  const stop = () => { ws.close().then(() => server.close(() => mongoose.disconnect().then(() => process.exit(0)))); };
  process.on('SIGTERM', stop);
  process.on('SIGINT', stop);
}
main().catch((e) => { console.error(e); process.exit(1); });
